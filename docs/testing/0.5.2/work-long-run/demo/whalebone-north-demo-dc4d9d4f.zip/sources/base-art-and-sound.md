# 《鲸骨以北》网页构建 82f600b0 的材料出处

构建编号为 `82f600b0d79b2a9cc484e2973d4187361607e58f5a7e4f2e42e70ff4482231fe`。网页包有 489 个文件，含 440 个 JavaScript 模块、10 张样式表、1 个 HTML、21 幅 PNG、16 段 Ogg 与 1 份语音来源表。可按同目录下的逐文件 SHA-256 核实这次构建。游戏脚本使用浏览器平台能力。浏览器及测试工具由运行环境提供。

游戏画面由地图场景绘制、项目的十八幅对话肖像、两幅海岸光影素材及本版的铜穹顶组成。铜板的铆钉、弧面和铜绿由项目脚本 `game/production/light-on-a-working-copper-dome/beat-the-ribs-and-green-the-copper.py` 绘制。480 × 325 像素的成图 SHA-256 为 `0975d58eb1e9b2083149fc4069e7bea1625f8cec3c2f5016e7467fd6d7775790`。三版同位置的实际游戏画面保存在 `evidence/tests/stage-82f600b0-the-clock-the-water-and-the-actual-same-view.json`。

白崖港厨房的十六段固定普通话对白由制作工作线创作，经 eSpeak NG 的普通话语音合成，再作为 Ogg 分发。生成工具为 npm 包 `@echogarden/espeak-ng-emscripten` 0.3.5，原包 SHA-256 为 `6b0bac048e123de9a690e3fe79346ed377c18797e9b09c3e0d8761a3ac00abe6`。工具声明的 GPL-3.0 许可文本另存于 `game/tests/content/lullaby-voice-license.txt`。游戏构建的 `assets/lullaby-voices/source.json` 逐段登记作者所写对白、发声角色、音高、时长、字节数及散列。网页仅需加载固定音频。盐市和北航的音乐用 Web Audio 合成，其编写来源及实录见 `delivery/rights/dc52632f-coasts-and-instruments.md`。网页使用设备自带字体。

玩家介绍包 `4a1fee24dfcf92fd9470d39f1fad93d34df66f82a22b4dd1a8a0be97ae7afeb9` 收录本版的七张实机原图。每张对应的测试报告和内容哈希见 `player/screens-82f600b0.json`。两张宣传插画《夏末离港》《改潮图》分别标出性质，并与原创绘制脚本一同保留在 `player/promo/`。网页入口与游戏资源在本机受保护的测试服务验收。对外可访问的私有地址、真人试玩时长及商业发布前的逐项权利复核仍待单列证明。
