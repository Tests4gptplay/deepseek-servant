import { createHash, randomUUID } from 'node:crypto';
import { createServer } from 'node:http';
import { readFile, realpath } from 'node:fs/promises';
import { extname, join, sep } from 'node:path';

const allowed = new Set(['index.html','styles','runtime','content','assets','rules','audio','fonts','favicon.ico']);
const types = {'.html':'text/html; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.svg':'image/svg+xml','.webp':'image/webp','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.ogg':'audio/ogg','.mp3':'audio/mpeg','.wav':'audio/wav','.woff':'font/woff','.woff2':'font/woff2','.glb':'model/gltf-binary','.gltf':'model/gltf+json'};

export async function openBuild(inputRoot, record, manifestPaths = null, session = null, port = 0) {
  let activeRoot=await realpath(inputRoot),activePaths=manifestPaths;
  const secret=randomUUID(),knownRoots=new Set([activeRoot]);
  async function activate(next,paths=manifestPaths){const directory=await realpath(next);knownRoots.add(directory);activeRoot=directory;activePaths=paths;}
  const visible=value=>{let text=String(value).replaceAll(secret,'[local-preview]');for(const root of knownRoots)text=text.replaceAll(root,'[game-root]');return text;};
  const server=createServer(async(req,res)=>{
    const gameRoot=activeRoot,paths=activePaths;
    try{
      const parts=decodeURIComponent(new URL(req.url,'http://localhost').pathname).split('/').filter(Boolean);
      if(session){
        if(!await session.authorize(req,res,parts))return;
      }else if(parts.shift()!==secret){res.writeHead(401,{'cache-control':'no-store'}).end();return;}
      if(!parts.length)parts.push('index.html');
      const id=parts.join('/');
      const listed=paths?paths.has(id):allowed.has(parts[0]);
      if(!['GET','HEAD'].includes(req.method)||!listed||parts.some(p=>p==='.'||p==='..')){
        res.writeHead(404).end();return;
      }
      const path=await realpath(join(gameRoot,id));
      if(!path.startsWith(gameRoot+sep)){res.writeHead(403).end();return;}
      const bytes=await readFile(path);
      record({path:id,status:200,size:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')},gameRoot);
      res.writeHead(200,{'content-type':types[extname(path)]||'application/octet-stream','cache-control':'no-store','x-content-type-options':'nosniff'}).end(req.method==='HEAD'?undefined:bytes);
    }catch{record({path:visible(req.url),status:404});res.writeHead(404).end();}
  });
  await new Promise((ok,fail)=>{server.once('error',fail);server.listen(port,'127.0.0.1',ok);});
  const origin='http://127.0.0.1:'+server.address().port;
  if(session)session.bind(origin);
  return {server,origin,address:session?origin+'/':origin+'/'+secret+'/',visible,activate};
}
