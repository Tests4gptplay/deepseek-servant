import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {openBuild} from './local-server.mjs';
const game=fileURLToPath(new URL('./game/',import.meta.url));
const meta=JSON.parse(await readFile(new URL('./game/build-manifest.json',import.meta.url),'utf8'));
const port=Number(process.argv[2]||43872);
if(!Number.isInteger(port)||port<1024||port>65535)throw Error('端口应为 1024 到 65535 之间的整数。');
try{
 const app=await openBuild(game,()=>{},new Set(meta.files.map(r=>r.path)),null,port);
 console.log('鲸骨以北 · 本机试玩\n'+app.address+'\n请将此整行地址复制到浏览器。结束时在此窗口按 Ctrl+C。');
}catch(e){
 if(e.code==='EADDRINUSE'){console.error('本机端口已占用。可以关闭上一次试玩窗口，或运行 node start.mjs 43873。');process.exitCode=1;}
 else throw e;
}
