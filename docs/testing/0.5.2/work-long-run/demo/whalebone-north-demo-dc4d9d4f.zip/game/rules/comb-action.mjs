const other=side=>side==='inner'?'outer':'inner';
export function combAction(b,h,kind) {
  const c=b.comb,tell=b.intent;
  let hit=0,detail='';
  if(kind==='inner'||kind==='outer') {
    h.combLane=kind;h.mp=Math.min(h.maxMp,h.mp+1);
    detail=kind==='inner'?'挪到短桩，缓过一口气':'沿踏石换到深水面，呼吸转稳';
  }else if(kind==='cover'){
    h.combLane=tell.side;h.cover=true;
    h.mp=Math.min(h.maxMp,h.mp+2);
    if(tell.stage===2&&!c.openedThisRound){c.openedThisRound=true;c.brood++;detail='把一串幼珠送过了桩缝';}
    else detail='在前沿留出一道护索';
  }else if(kind==='tonic'||kind==='salve'){
    const key=kind==='salve'?'brine-dose':'tonic',item=b.items[key];
    if(!item||!(b.stock[key]>0))return {error:'包里已经没有这种药。'};
    if(kind==='tonic'&&h.hp>=h.maxHp&&h.mp>=h.maxMp)return {error:'先收好药，这位同伴现在用不着。'};
    b.stock[key]--;h.hp=Math.min(h.maxHp,h.hp+(item.heal||0));h.mp=Math.min(h.maxMp,h.mp+(item.restore||0));
    if(kind==='salve')h.combWard=true;
    detail=item.name+(h.combWard?'在湿衣外结了一层盐膜':'');
  }else if(kind==='attack'||kind==='skill'){
    const s=h.skill;
    if(kind==='skill'&&h.mp<(s.cost??2))return {error:'气力不足。换位或护住桩缝可以回气。'};
    hit=h.attack+(kind==='skill'?(s.power||3):0);
    if(kind==='skill'){
      h.mp-=s.cost??2;detail=s.name;
      if(s.kind==='heal'){for(const p of b.party)if(p.hp>0)p.hp=Math.min(p.maxHp,p.hp+(s.heal||5));hit=Math.ceil(hit*.45);detail+='，潮线温暖了四个人的手';}
      if(s.kind==='brace'){c.rope=true;h.cover=true;hit=Math.ceil(hit*.55);detail+='，系住这一轮的护索';}
      if(s.kind==='break'){c.wedge=true;hit+=h.pierce||0;detail+='，帆骨之间多了一掌宽';}
      if(s.kind==='mark'){c.mark=2;detail+='，在腹珠旁压下两段标线';}
    }else detail='试探帘缘';
    if(tell.stage===1&&h.combLane===tell.side&&!c.wedge&&c.mark===0)hit=Math.max(1,Math.floor(hit*.23));
    else if(tell.stage===1&&h.combLane===other(tell.side))hit+=3;
    if(c.mark>0&&!(kind==='skill'&&s.kind==='mark')){hit+=4;c.mark--;}
    if(tell.stage===2&&c.openedThisRound)hit+=2;
  }else return {error:'这一手无法施行。'};
  return {hit:Math.max(0,hit),detail};
}
export function combWave(b){
  const c=b.comb,t=b.intent,hits=[];
  for(const h of b.party){
    h.hurt=0;if(h.hp<=0)continue;
    const exposed=h.combLane===t.side;
    let wave=exposed?(b.spec.attack||6)+(t.stage===1?2:0):t.stage===2?2:0;
    if(c.rope)wave-=3;if(h.cover)wave-=4;if(h.combWard)wave-=4;
    if(h.charm==='comb-bracer'&&h.cover)wave-=2;
    const resistance=Math.min(.75,h.resists?.[t.stage===1?'impact':'tide']||0);
    const harm=Math.max(0,Math.round(wave*(1-resistance))-Math.floor(h.defense/5));h.hp=Math.max(0,h.hp-harm);h.hurt=harm;
    if(harm)hits.push(h.id);h.cover=false;h.combWard=false;
  }
  c.rope=false;c.wedge=false;c.openedThisRound=false;
  return hits;
}
