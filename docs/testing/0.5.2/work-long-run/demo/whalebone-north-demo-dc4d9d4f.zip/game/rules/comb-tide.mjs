// Outer-coast thread combs follow loose weed, not ships. No story gate looks at these flags.
const mark = (id,name,x,y,part) => ({id,name,x,y,kind:'object',action:{type:'comb-coast',part}});
export const combSites = {
  'lower-tide': [
    mark('comb-step','露苔的上沿踏脚',5,4,'dry'),
    mark('comb-seam','停在两股泡线间的透明小帆',10,9,'foam'),
    mark('comb-splice','沉下一半的旧牵环',14,6,'ring')
  ],
  'lead-sound': [
    mark('comb-basket','被推回岸边的虾笼',10,10,'basket'),
    mark('comb-shadow','半张帆影底下的珠串',18,9,'shadow'),
    mark('comb-reel','可以换手的听潮卷和护索扣',17,8,'tools')
  ],
  'moor-pocket': [
    mark('comb-crown','堵在背流面的帘梳冠群',12,6,'crown'),
    mark('comb-quiet','通向静水的窄缝',10,9,'quiet'),
    mark('comb-backwater','旧里桩留下的回水口',11,7,'return')
  ]
};
export const combKit = {
  'comb-listener':{name:'空螺音扣',slot:'charm',resists:{tide:.25,shock:.18}},
  'comb-bracer':{name:'双襻软腕套',slot:'charm',resists:{impact:.25,wind:.18}},
  'comb-glass':{name:'回汐影尺',slot:'charm',resists:{tide:.34,wind:.13}},
  'comb-sheath':{name:'卸力垫肩',slot:'armor',defense:5}
};
const threat = (id,name,hp,attack,level,xp) => ({id,name,enemy:name,visual:'comb-colony',hp,attack,level,
  rewards:{xp,repeatXp:0,items:{},label:'四个人都回到桩旁。'}});
export const combThreats = {
  'comb-skein':threat('comb-skein','卡在浅笼上的一簇帘梳',63,5,4,16),
  'comb-crown':threat('comb-crown','回水里的整冠帘梳',143,8,7,46)
};
export function withTideCombs(world) {
  const maps={...world.maps};
  for(const [id,extra] of Object.entries(combSites)){
    const map=maps[id];if(!map)continue;
    const existing=new Set(map.entities.map(e=>e.id));
    maps[id]={...map,entities:[...map.entities,...extra.filter(e=>!existing.has(e.id))]};
  }
  return {...world,maps,equipment:{...world.equipment,...combKit},encounters:{...world.encounters,...combThreats}};
}
export function combReadings(s) {
  return Number(Boolean(s.flags['comb-foam']))+Number(Boolean(s.flags['comb-ring']))+
    Number(Boolean(s.flags['comb-shadow']))+Number(Boolean(s.flags['comb-basket']));
}
export function combStage(b) {
  if(b.spec.id==='comb-skein')return b.hp>b.max*.45?0:1;
  return b.hp>b.max*.70?0:b.hp>b.max*.34?1:2;
}
export function combTell(b) {
  const stage=combStage(b),turn=b.round,side=turn%2===1?'inner':'outer';
  if(stage===0)return {stage,side,kind:'sweep',name:'斜帘过礁',
    sign:side==='inner'?'短桩一面的白浪尖连成了线。':'深水一面的白浪尖连成了线。',
    hint:'那一面会扫过去。另一条水带仍有完整倒影。'};
  if(stage===1)return {stage,side,kind:'fold',name:'翻冠藏腹',
    sign:side==='inner'?'近桩的帆背贴紧，深水侧的琥珀腹珠露了出来。':'深水帆背闭拢，短桩侧露出琥珀腹珠。',
    hint:'壳背卸力。换到开口一侧、用标线定住腹珠，或者让重装队员撑开帆骨。'};
  return {stage,side,kind:'nursery',name:'母冠回收幼串',
    sign:side==='inner'?'一串细小白珠沿短桩回流，母冠横在出口前。':'深水里的细白珠在回涡里打转，帆梢正向幼串弯下。',
    hint:'同一轮留一人护住幼串，可以腾出通口。也能由外侧继续逼退母冠。'};
}
