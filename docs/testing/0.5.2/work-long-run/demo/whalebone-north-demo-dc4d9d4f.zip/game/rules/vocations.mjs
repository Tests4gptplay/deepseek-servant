// Each path is learnt through an observed story event or experience. Switching paths costs no resources.
export const paths={
 mara:{title:'殓舟守',gate:'maker-known',where:'查明偏销签图',choices:[
  {id:'bearer',name:'守柩师',tech:'镇舷',kind:'brace',element:'iron',power:1,cost:2,ward:'impact',amount:.28,field:'brace',out:'垫住承梁',desc:'受击前把一部分冲击传给梁。协作技护住本轮同行者。'},
  {id:'wedger',name:'寻楔人',tech:'裂楔',kind:'break',element:'iron',power:6,cost:3,ward:'shock',amount:.14,field:'mark',out:'以短锤试榫',desc:'拆开机壳时提高伤害，勘验后留下第一次攻击的破口。'}]},
 ivo:{title:'巡港绳手',gate:'harbor-truth',where:'查清西窗的求救信号',choices:[
  {id:'rigger',name:'转缆手',tech:'双套系援',kind:'brace',element:'wind',power:2,cost:2,ward:'wind',amount:.22,field:'brace',out:'架一根救扶索',desc:'把施术人带到外侧，扶索替同伴减轻一轮伤害。'},
  {id:'lampwatch',name:'逆窗领航',tech:'远窗反照',kind:'mark',element:'light',power:4,cost:3,ward:'tide',amount:.18,field:'mark',out:'校准近远标',desc:'沿敌人回身的缝隙标出下一击，野外另能读清最近的路口。'}]},
 selene:{title:'潮量师',gate:'fresh-proved',where:'亲自核对双水芯',choices:[
  {id:'brine',name:'退盐术师',tech:'折潮回击',kind:'break',element:'tide',power:5,cost:3,ward:'cold',amount:.30,field:'ward',out:'覆一层退盐膜',desc:'潮术撬开热铁或甲缝，编队准备可抵一次寒潮。'},
  {id:'warmwick',name:'暖灯药师',tech:'温脉回汐',kind:'heal',element:'tide',power:1,heal:9,cost:3,ward:'tide',amount:.24,field:'tend',out:'温水换敷',desc:'潮术同时恢复队伍，途中可用一次换敷为同行者治疗。'}]},
 mira:{title:'图署学徒',gate:'pin-rub',where:'取到斜销反拓',choices:[
  {id:'sounding',name:'探深师',tech:'铅落软点',kind:'break',element:'impact',power:5,cost:3,ward:'tide',amount:.20,field:'ward',out:'量水留深签',desc:'以探铅找出硬壳与软窝的差别，水道里先留一道潮护。'},
  {id:'surveyor',name:'远标绘师',tech:'三角定星',kind:'mark',element:'light',power:3,cost:2,ward:'wind',amount:.24,field:'mark',out:'记下反向航标',desc:'用两重交点暴露弱处供后手追击，识读地图最近的路口。'}]}
};
export const basics={
 mara:{tech:'护送',kind:'break',element:'iron',field:'brace',out:'校准垫铁'},
 ivo:{tech:'回索',kind:'brace',element:'wind',field:'brace',out:'打救扶活结'},
 selene:{tech:'退潮',kind:'heal',element:'tide',field:'tend',out:'温水洗创'},
 mira:{tech:'标线',kind:'mark',element:'light',field:'mark',out:'量取方向'}
};
export const relics={
 'hemp-knot':{name:'抬柩绳结',slot:'charm',resists:{impact:.18},source:'coffin-aboard',context:'送客吊台收紧第一根合抬绳'},
 'blue-glass':{name:'双窗蓝玻璃',slot:'charm',resists:{wind:.21,light:.12},source:'harbor-truth',context:'重亮了远处的求救窗'},
 'sound-bead':{name:'八结铅珠',slot:'charm',resists:{tide:.28},source:'north-chart',context:'在双缝交点确认深槽'},
 'thaw-wrap':{name:'双水芯护符',slot:'charm',resists:{cold:.30,shock:.12},source:'fresh-proved',context:'在冬岸比较两支棉芯'}
};
export const terms={impact:'冲击',iron:'铁',wind:'风',light:'光',tide:'潮',cold:'寒',shock:'震'};
export const milestones=[['coffin-aboard','送棺上舟',12],['roof-shelter','在灯城找到住户',15],['harbor-truth','复核远窗事故',22],['north-ready','同行从盐市出发',24],['north-chart','用硬底实测校图',30],['maker-known','查明签图人',26],['winter-proof','复核越冬条件',36],['clutch-still','停下三段锚机',42],['grave-signed','完成两行墓志',48]];
export const selected=(s,id)=>paths[id]?.choices.find(p=>p.id===s.expedition.heroes[id]?.career);
export const openPath=(s,id)=>Boolean(paths[id]&&(s.flags[paths[id].gate]||s.expedition.heroes[id]?.level>=6));
export const nextXP=(base,level)=>base+8*(level-1)+Math.floor(Math.max(0,level-8)**2*1.3);
