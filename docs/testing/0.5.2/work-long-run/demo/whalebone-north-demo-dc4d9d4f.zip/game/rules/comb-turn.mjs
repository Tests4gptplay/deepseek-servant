import {combTell} from './comb-tide.mjs';
import {combAction,combWave} from './comb-action.mjs';
export function setCombFight(b){
  b.comb={mark:0,wedge:false,rope:false,openedThisRound:false,brood:0};
  b.party.forEach((h,i)=>{h.combLane=i%2===0?'inner':'outer';h.cover=false;});
  b.intent=combTell(b);
  return b;
}
export function combMove(b,kind,clock){
  if(b.phase!=='active')return false;
  const i=b.actor,h=b.party[i],previous=b.intent;
  const before=h.combLane,result=combAction(b,h,kind);
  if(result.error){b.log=result.error;return false;}
  const floor=b.spec.id==='comb-skein'?(previous.stage===0?Math.floor(b.max*.45):0):
    previous.stage===0?Math.floor(b.max*.70):previous.stage===1?Math.floor(b.max*.34):0;
  const old=b.hp;b.hp=Math.max(floor,b.hp-result.hit);
  const hit=old-b.hp;h.action=kind;
  b.last={a:i,kind,start:clock,hit,from:before,to:h.combLane,stage:previous.stage,side:previous.side};
  b.log=h.name+' · '+result.detail+(hit?'，帘冠松开 '+hit+'。':'。');
  if(!b.hp){b.phase='win';return true;}
  const next=b.party.findIndex((member,j)=>j>i&&member.hp>0);
  if(next>=0)b.actor=next;
  else{
    b.last.response={name:previous.name,hits:combWave(b)};
    b.round++;b.actor=b.party.findIndex(member=>member.hp>0);
    if(b.actor<0){b.phase='lose';return true;}
  }
  b.intent=combTell(b);
  return true;
}
export function listeningCue(b){
  if(!b.party.some(p=>p.hp>0&&['comb-listener','comb-glass'].includes(p.charm)))return '';
  const next=b.round%2?'深水':'短桩';
  return '　螺扣先响一拍：下轮换到'+next+'侧。';
}
