// Optional inspection exercises. Main-story exits never check the outcome of these trials.
const pattern=(hp,tell,moves)=>({fromHp:hp,tell,moves});
const move=(name,kind,element,counter,power)=>({name,kind,element,counter,power});
const tidal=move('冷浪过内侧','whirl','cold','dodge',1.05);
const chock=move('滑车压低桩','ram','impact','guard',1.35);
const recoil=move('红索弹向外架','rush','wind','dodge',1.35);
const gate=move('双闸把回水锁住','shell','tide','skill',1.1);
function course(id,name,hp,attack,level,visual,desc,phases,xp,items){
 return {id,name,enemy:name,hp,attack,level,visual,objective:desc,phases,
  resistances:visual==='training-wheel'?{iron:.78,light:1.25,tide:1.32,wind:1.08}:{tide:.77,iron:1.26,wind:1.16,light:1.1},
  rewards:{xp,repeatXp:2,items,label:'值守人签下这次检校的日期。首检给经验与用品，复检可练走位。'}};
}
export const courses=[
 course('yard-practice','肋场 · 双向滑车',39,3,1,'training-wheel','站好防风踏，试一次再说。',[pattern(39,'工牌敲了两下横杆，滑车先走里轨。',[chock,recoil]),pattern(15,'水闸锁闭，侧边还有一条泄水缝。',[gate,recoil])],12,{'brine-dose':1}),
 course('beacon-practice','红标 · 破灯回水',92,6,4,'training-tide','两面讯号板由不同的人操作，别把白水认成通路。',[pattern(92,'头两道水脊一明一暗，白沫先到。',[tidal,chock]),pattern(45,'灯臂折进内窗，回水压住外翼。',[gate,recoil])],25,{'brine-dose':1}),
 course('keel-swell','引航驳 · 双潮一试',169,8,7,'training-tide','同一组人改换岗位，校验两潮的回航路。',[pattern(169,'近舷的潮尺先没进水里，外沿仍干。',[tidal,chock]),pattern(104,'红旗反卷，顺着绳头找外架。',[recoil,gate]),pattern(47,'大水回舷，四个人共看一面尺。',[gate,tidal])],48,{'brine-dose':2}),
 course('keel-black','引航驳 · 黑潮上检',290,13,15,'training-wheel','冬岸之外，旧式卷盘要试三段复合潮压。',[pattern(290,'白格沾霜，先走侧边，再守中轴。',[tidal,chock]),pattern(175,'导轮暗红，双闸收缩，风从末段折回。',[gate,recoil]),pattern(78,'倒涌顶起木桩，最后一次极短。',[chock,tidal])],77,{'deep-lens':1,'brine-dose':1}),
 course('keel-long','引航驳 · 极北长汐',900,31,45,'training-tide','深线老手的检验。清空木槽随时可撤，结果不影响返港。',[pattern(900,'近舷银霜先走，后面才是重浪。',[tidal,chock]),pattern(540,'副线快慢相错。',[recoil,gate]),pattern(225,'回水翻到第三格，稳住出口。',[gate,chock,tidal])],140,{'brine-dose':2}),
 course('keel-polar','引航驳 · 深冬终汛',1800,58,85,'training-wheel','深冬的最终演练，适合成熟队伍。',[pattern(1800,'冰压下主桩，外缘的圈不落。',[chock,tidal]),pattern(1020,'两闸互锁，风比水先到。',[gate,recoil]),pattern(420,'黑浪扫过退路，沿分流板回舷。',[tidal,gate,chock])],230,{'brine-dose':3})
];
export const stations={
 'trim-yard':{id:'yard-school',name:'沿工轨试一次滑车',x:10,y:9,gate:'coffin-aboard',list:['yard-practice']},
 'red-beacon':{id:'red-school',name:'红标背水试位架',x:8,y:11,gate:'north-chart',list:['beacon-practice']},
 'safe-keel':{id:'keel-school',name:'旧领航员的回航试台',x:12,y:11,gate:'grave-signed',list:['keel-swell','keel-black','keel-long','keel-polar']}
};
export function withCourses(world){
 const maps={...world.maps};for(const [id,k] of Object.entries(stations)){
  if(!maps[id])continue;const original=maps[id];if(original.entities?.some(e=>e.id===k.id))continue;
  maps[id]={...original,entities:[...(original.entities||[]),{id:k.id,name:k.name,kind:'object',x:k.x,y:k.y,requires:[k.gate],lockedText:'值守人留了封条。这座试台等本地的工作告一段落后才开放。',action:{type:'practice',id:k.id}}]};
 }
 return {...world,maps,encounters:{...Object.fromEntries(courses.map(e=>[e.id,e])),...world.encounters}};
}
