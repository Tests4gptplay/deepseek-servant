import {exit,say as s} from './parts.mjs';
import {tidePost} from './district.mjs';
import {yard,cellar} from './spring-grist.mjs';
import {skiff,table,pots} from './spring-table.mjs';
import {millHint,loft,husk,mothFoe,gristGear} from './moth-hatch.mjs';
import {deck,bow} from './wren-deck.mjs';
import {pearl,cliff,moot} from './wren-coast.mjs';
import {leftDoor,bottom,spine,trawlFoe,trawlGear} from './lantern-trawl.mjs';
import {saltDepot,saltWinter,saltGrave,pearlPlant,pearlTeach,northWinter,northGrave,gristTreat,gristDebt,trawlFare} from './spring-wren-returns.mjs';

export const wakeMaps=[yard,cellar,skiff,table,loft,husk,deck,bow,pearl,cliff,moot,bottom,spine];
export const wakeGear={...gristGear,...trawlGear};
export const wakeFoes={[mothFoe.id]:mothFoe,[trawlFoe.id]:trawlFoe};
const links={
 'petition-hall':[exit(16,7,'rye-yard',[4,9],'出公议廊，到主人留春种的水磨公院')],
 'rye-yard':[exit(20,12,'split-table',[23,9],'把两班各自承担的事带去磨坊土台',['rye-offered'])],
 'germ-cellar':[exit(10,11,'moth-hatch',[4,9],'按三下拖痕移开潮线下的暗砖',['rye-taps','rye-drag','tide:low'])],
 'red-beacon':[exit(13,7,'wren-deck',[4,9],'跟两位持不同图的领航人上鹪鹩号',['north-chart'])],
 'pearl-return':[exit(23,10,'lantern-trawl',[4,9],'把第二排苗网的左暗门推开',['pearl-door'])]
};
const extras={
 'flour-skiff':[millHint,gristDebt],'rye-yard':[...pots,gristTreat],
 'north-pier':[saltDepot],'pearl-return':[pearlPlant,leftDoor,tidePost('pearl-tide',12,10)],
 'bow-parallax':[pearlTeach],'winter-ward':[saltWinter,northWinter],'burial-cape':[saltGrave,northGrave],'lee-mouth':trawlFare
};
const requirements={
 'selene-oath':['rye-received','公议已算清的三袋不能替沙荷决定种子。出东边去水磨公院，看看春芽，对过晚桨，让桌边的一家人自己选并收妥。'],
 'mara-deposition':['wren-crossed','红标外有鹪鹩号。先跟米拉、秦汐、鹤青去比前后两舷，听蕖末说明旧图的损失，履行所约的放苗或教船再回刻室。']
};
const voices={
 'ration-deputy':[['rye-seed-vote','垄瓷','春种没进锅，我的夜灶却欠独粟一个早班。种能留手是他换来的。'],['rye-pot-vote','垄瓷','稠粥能挂住勺。到来春你看我们的苗要先过夕豆的船；这勺不是凭空来的。']],
 'ticket-mother':[['rye-family-spoke','沙荷','我今日的决定算今日。没替那年的假班数讲一句好话。等我拿回那枚空印，我还得继续说。']],
 'mira-first':[['pearl-living-done','米拉','蕖末摸壳的手一直放得很平。我以前觉得图能画到碗大就足够，现在觉得一只贝张不张口才配问图好不好。'],['pearl-teaching-done','米拉','扁蒲领两条艇都没说我的姓。好。行船的人会从水里纠正我，木刻就不敢只听自己。']],
 'two-drafts':[['wren-drift','秦汐','退路搁上新布了。正走和误走我都肯签，但不能把退回来写成到过北岸。']],
 'wave-host':[['trawl-detour','冬口伙计','系好担绳。一班货没有赶上船，从陆上下来的我看着接。'],['trawl-routed','冬口伙计','整幅帆还在，我给那三只苗笼让一架。']]
};
export function withSpringAndWren(map){
 const entities=map.entities.map(original=>{
  const gate=requirements[original.id],lines=voices[original.id];let e=original;
  if(gate)e={...e,requires:[...(e.requires||[]),gate[0]],lockedText:gate[1]};
  if(lines){const key=e.after?.length?'after':'dialogue';e={...e,[key]:[...e[key],...lines.map(([im,who,text])=>({...s(who,text),if:im}))]};}
  return e;
 });
 const exits=map.id==='bow-parallax'?map.exits.map(e=>{
  if(e.to==='hook-cliff')return {...e,lockedText:'固定石肩在黑钩与远崖缺口这组线上。白尖这边会漂回贝郊。可以走出去辨认，也可以去船尾重看、改压回线索。'};
  if(e.to==='pearl-return')return {...e,lockedText:'这一步是试浮白尖时的回漂方向。若已定黑岩线，从黑钩有稳绳通到贝郊，不须故意走错。'};
  return e;
 }):map.exits;
 return {...map,entities:[...entities,...(extras[map.id]||[])],exits:[...exits,...(links[map.id]||[])]};
}
const arcs=[
 ['living-seed','谁有权磨掉半袋春种','main',['rye-open','rye-hunger','rye-air','rye-boats','rye-root','rye-offered','rye-cousin','rye-family-spoke','rye-received','rye-boats-done']],
 ['a-year-for-grain','谁把今年的种带回去','companion',['rye-boats-done','rye-winter','rye-closed']],
 ['side-of-the-brick','旧盐蛾窖的两声拖痕','hidden',['rye-drag','rye-taps','moth-open','moth-ready','moth-cleared','moth-root','moth-cold-account']],
 ['an-island-that-breathes','一块会呼吸的白岬','main',['wren-greet','wren-fore-read','wren-aft-read','wren-return-line','wren-survey','pearl-mother-heard','pearl-signed','wren-crossed']],
 ['the-empty-pearl-cage','坏苗也有一席','companion',['wren-crossed','wren-winter-seen','wren-final']],
 ['below-the-second-row','第二排向左的贝网门','hidden',['pearl-twill','pearl-groove','pearl-door','trawl-rigged','trawl-clear','trawl-test','trawl-repaid']]
];
export const wakeQuests=Object.fromEntries(arcs.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
