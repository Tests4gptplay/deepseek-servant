import {exit,object,person,say} from './parts.mjs';

// Each stroke is a shelf seen from above. Its ends and bends are playable ground.
export function bay(id,name,w,h,rocks,strokes,life,exits,stations=[]){
 const grid=Array.from({length:h},()=>Array(w).fill('~'));
 for(const [x,y,rx,ry] of rocks)for(let j=Math.max(0,y-ry);j<=Math.min(h-1,y+ry);j++)
  for(let i=Math.max(0,x-rx);i<=Math.min(w-1,x+rx);i++)if(((i-x)/rx)**2+((j-y)/ry)**2<=1)grid[j][i]='#';
 for(const [radius,...points] of strokes)for(let n=1;n<points.length;n++){
  const [a,b]=points[n-1],[d,e]=points[n],steps=Math.max(Math.abs(d-a),Math.abs(e-b));
  for(let k=0;k<=steps;k++){const x=Math.round(a+(d-a)*k/(steps||1)),y=Math.round(b+(e-b)*k/(steps||1));
   for(let j=Math.max(0,y-radius);j<=Math.min(h-1,y+radius);j++)for(let i=Math.max(0,x-radius);i<=Math.min(w-1,x+radius);i++)
    if(Math.abs(i-x)+Math.abs(j-y)<=radius)grid[j][i]='.';}
 }
 const solids=[];for(let y=0;y<h;y++)for(let x=0;x<w;){if(grid[y][x]==='.'){x++;continue;}
  const start=x;while(x<w&&grid[y][x]!=='.')x++;solids.push([start,y,x-start,1]);}
 return {id:'driftbay-'+id,name:'冬岸 · '+name,act:5,biome:'winter-coast',width:w,height:h,ground:'stone',solids,features:[],entities:stations,exits,
  driftbay:{id,relief:grid.map(r=>r.join('')),life}};
}
export function link(x,y,to,at,label,requires=[],lockedText){const e=exit(x,y,to,at,label,requires);return lockedText?{...e,lockedText}:e;}
export function scrap(id,title,x,y,lines,extra={}){
 return object('driftbay-'+id,title,x,y,lines.map(([who,text,ifFlag])=>ifFlag?{...say(who,text),if:ifFlag}:say(who,text)),extra);
}
export function voice(id,title,x,y,lines,extra={}){
 const data=scrap(id,title,x,y,lines,extra);return person(data.id,title,x,y,data.dialogue,extra);
}
