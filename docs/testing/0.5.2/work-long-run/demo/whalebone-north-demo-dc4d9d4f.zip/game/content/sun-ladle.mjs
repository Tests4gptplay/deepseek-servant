import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit,flag} from './parts.mjs';
import {setting} from './registry-parts.mjs';

export const sun=region('sun-ladle','鲸城 · 八户的半日晒台',2,'whale-roof',30,20,'wood',
 [['building',0,0,7,5,'磨菜籽用的矮棚'],['wall',12,0,5,7,'割断晨光的肋骨山墙'],['water',21,0,9,7,'居民称作白碟湾的上风海面'],['wall',0,14,9,6,'皮匠用了两代的背阴檐'],['crate',21,14,9,6,'铺满发芽菜床的浅木盘']],
 [['path',4,8,22,2,'照不到第三户房梁的窄天井'],['stairs',10,7,4,8,'能上舷台翻光的踏阶'],['rope',16,12,9,1,'串着居住铁匙的影线'],['awning',2,15,4,2,'补鞋徒弟避午光的小棚']],
 [witness('spoon-grandpa','用铜勺数早饭的木匠·榆齿',8,8,[s('榆齿','搬走床架，隔壁多了一块会晒到的地。我跟皮匠争了八年，到底那儿上午亮还是只在晚上亮。'),s('玛拉','没轮到那道光的人要怎么办？'),s('榆齿','别问我。皮匠串起三把勺，看不见天也认得每一把摸上去的温度。小苗就矫情了，它不能摸勺。')],'spoon-asked',['beds-list']),
 witness('sail-shoemaker','摸着鞋眼补鞋的田眠',18,9,[s('田眠','人说我看不清，手闲着正合适。你看这双鞋的第五只眼歪不歪？我一辈子做第五眼都歪，是为了脚背最宽的那节骨头。'),s('榆齿','你在屋里要那一点光，是要看这只眼吧。'),s('田眠','我有个徒弟。她的眼睛好，我想让她坐在我旁边，不用正午才来学。')],'loose-eyelet',['spoon-asked']),
 fixture('spoon-three','站到晒台最低的菜床摸三把勺背',14,10,[s('玛拉','上勺暖，中勺温，最下边沾衣凉。挂得再高也摸不出幼叶过午会不会黄。得去看一根影怎么落在盘底。')],'sun-low',['loose-eyelet']),
 person('plant-person','爱把葱剪得高低不齐的榴平',10,12,[s('榴平','韭是我替全院育的，葱是我嘴馋。别全当慈善，过年我还指望自己有点葱油呢。'),spoken('榴平','今年换宽盘，根没站死。分一把给女师傅，收徒那天可以煎饼。','leaves-fed'),spoken('榴平','我把能撑到明年的苗留到上台，七把葱送进孵鱼房，不跟皮匠借光了。','leather-fed')])],
 [exit(3,9,'eight-landing',[19,8],'沿八户晒被的低绳回街'),exit(25,10,'sailglass',[4,8],'上艇用的半片旧玻璃',['sun-low'])]);
export const glass=region('sailglass','鲸城 · 阳面船匠的半舷窗',2,'whale-roof',28,19,'wood',
 [['water',0,0,28,4,'沿鲸脊向外的白海面'],['wall',0,4,4,5,'夹住古鲸骨的木卡'],['wall',11,2,5,6,'一扇没有上玻璃的舷窗'],['crate',20,3,7,4,'存海图透纸的窄柜'],['wall',19,13,9,6,'落着白粉石灰的后舷']],
 [['pier',3,8,20,2,'热气能往上走的旧船台'],['rope',10,12,11,1,'让粗糙面朝下的窗铰绳'],['lamp',17,7,1,1,'不用火，借太阳的一只罩'],['rope',21,14,4,1,'可放回的舷窗手绳']],
 [witness('glass-keeper','雕旧舷玻璃的梅蹄',8,8,[s('梅蹄','尖口那面照出的墙是亮，一个眼睛瞪过去全白。沙过的毛面倒显暗，地上的影有软边。别把亮对着墙当成亮到了人。')],'glass-asked',['sun-low']),
 setting('glass-face','让玻璃最亮的尖口朝下',13,9,[s('梅蹄','看着亮得像银盾，下头的人却抬手遮眼。铰链不锁，可借绳放回。')],['glass-asked'],{'sun-scatter':false,'sun-glare':true}),
 setting('glass-grain','沿海风绳把玻璃的毛面转入天井',18,10,[s('梅蹄','白墙不那么刺。你别信我鼓掌，去下面，看看幼苗底下有没有一圈影。')],['glass-asked'],{'sun-scatter':true,'sun-glare':false}),
 person('glass-nurse','夏天借窗晒网的渔嫂·椰衣',9,12,[s('椰衣','小时候住这舷窗，一晴就是一百条咸鱼眼。现在我敢在屋里说我怕太阳，终于没人拿我放在缸盖上晒。')])],
 [exit(3,9,'sun-ladle',[24,10],'回到勺影落下的天井')]);
export const sunFinish=[
 fixture('little-leaf-shadow','蹲在幼叶与鞋眼同高处看半影',22,11,[s('田眠','我徒弟把线穿过第五眼，榴平的嫩根跟着出了一圈细影。光有这么宽，两份大约保不全。')],'sun-proof',['sun-scatter'],{lockedText:'双面舷窗的硬光刺眼，低处找不到柔边。上舷窗翻过粗糙一面后再下台试。'}),
 person('bed-sun-vote','让用光的两户交换最后一句',16,11,[s('田眠','我肯在天井口补鞋，徒弟进屋。我愿不愿意搬位置，和你有没有同情心是两回事。'),s('榴平','我也肯让出上头一半，底下宽盘还得有人照料。帮哪处，哪处就真能开工。',[{text:'把散光借给鞋窗，替菜户搬不能留的苗',set:'light-to-shoer'},{text:'把散光留菜床，替皮匠装一张廊外的工作凳',set:'light-to-leaves'}])],{requires:['sun-proof'],action:flag('sun-shared'),after:[s('田眠','原来八户床绳不是拿来立界的。天井下面还有个活，收拾完那才算同意。')]}),
 witness('bed-sun-shoes','把七把葱移上屉，与徒弟试第五眼',7,11,[s('榴平','苗托上去了。我可不是白让，等她徒弟出师得帮我补一双。'),s('田眠','丫头，别把第五眼改正。鞋脚背一弓，歪了才对。')],'leather-fed',['light-to-shoer'],{action:{type:'flag',id:'leather-fed',set:'sun-delivered'}}),
 fixture('bed-sun-leaves','在背风廊装矮凳，让田眠实坐',11,10,[s('田眠','我把去年补的靴子压实。风不穿背，脚也踩得着。'),s('榴平','苗铺起来了。我留一小束给她家煎饼。')],'leaves-fed',['light-to-leaves'],{action:{type:'flag',id:'leaves-fed',set:'sun-delivered'}})
];
