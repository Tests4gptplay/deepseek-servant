import {say as s,feature as f,exit,person,object,flag} from './parts.mjs';
export const upper={
 id:'upper-spar',name:'白崖港 · 三日清晨的追行屋桁',act:1,width:28,height:16,ground:'wood',biome:'harbor',
 solids:[[0,0,28,2],[8,3,6,2],[0,13,28,3],[13,10,4,3],[23,9,5,2]],
 features:[f('water',0,0,28,2,'鲸背与岸间的水道'),f('water',0,13,28,3,'内港'),f('pier',0,5,28,3,'高处走梁'),f('pier',2,9,10,3,'维修踏板'),f('rope',8,3,6,2,'张紧的回绳'),f('lamp',22,4,1,1,'第三晴日灯'),f('boat',18,10,4,2,'贴岸的护航驳')],
 entities:[
  person('ivo-spar','屋桁上的伊沃',6,6,[s('伊沃','别贴着绳跑。先看它投在白屋顶上的影，影子先缩，绳才会猛地往回收。'),s('玛拉','那盏是候船的灯吗？'),s('伊沃','三日集结从没在清早亮过全套。那是出港灯，泊册写的可是晚潮。'),{who:'伊沃',if:'night-lamp',text:'老汀的红灯还看得见。我们认它当岸标，成了雾也能折回。'}],{requires:['ivo-line','berth-fixed'],action:flag('early-castoff'),after:[s('伊沃','鲸提前转了！循你方才留给港上的那条路上船。护航驳贴着鲸背，未出白崖前还能来回接人。')]}),
  object('first-roof-plank','点名工班铺的两节横板',21,6,[s('夜班工','热饭赶上头一船，我们没把最后两根木板烧了取暖。你贴着板边走，别踩中间的节眼。')],{requires:['crew-first'],action:flag('crew-plank')}),
  person('ward-skiff','病船操舵的芦嬷',18,10,[s('芦嬷','十二袋全在了。担架先上，棺车靠舷。知道我为何还给它留地方？两者都不能沿路颠。')],{requires:['grain-first'],action:flag('ward-skiff-ready')}),
  object('empty-daybook','反扣在柱后的出港牌',10,8,[s('出港牌','末日三次白灯合亮，应在晚潮。今日晨雾还没落地，木牌已被翻过去，背面是「提前脱缆」。')])
 ],exits:[exit(1,6,'signal-gallery',[27,8],'拉回对绳下灯廊'),exit(4,12,'trim-yard',[18,6],'沿留夜灯回木工坑',['night-lamp']),
 exit(25,6,'whale-roofs',[5,5],'走夜班工的横板上北屋脊',['early-castoff','crew-plank']),exit(20,11,'whale-roofs',[23,13],'乘病船从南檐上鲸背',['early-castoff','ward-skiff-ready'])]
};