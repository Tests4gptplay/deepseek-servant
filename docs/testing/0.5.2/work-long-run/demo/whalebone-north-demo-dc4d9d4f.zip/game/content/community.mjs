import {shifts,office,well} from './port-shifts.mjs';
import {gantry,drain,wet,rainStep,rafters} from './port-platforms.mjs';
import {portDesk,wash,family,loft} from './port-households.mjs';
import {barge,stove,canteen} from './port-kitchens.mjs';
import {eight,sleeves,cradle} from './hull-households.mjs';
import {loom,water,jetty} from './hull-bedways.mjs';
import {testimony,school,heron,bird} from './hull-witness.mjs';
export {withPortChapters} from './community-routes.mjs';
export const chapterMaps=[shifts,office,well,gantry,drain,wet,rainStep,rafters,portDesk,wash,family,loft,barge,stove,canteen,eight,sleeves,cradle,loom,water,jetty,testimony,school,heron];
export const chapterGear={'line-brake':{name:'短距牵索护手',slot:'weapon',power:3,break:6}};
export const chapterFoes={[bird.id]:bird};
const arcs=[
 ['signed-shifts','三班交接的一张纸','main',['vigil-finished','shift-called','shift-handed','shift-receipted']],
 ['cloth-in-the-locker','给别人抬棺的人','side',['cloth-offered','cloth-matched','cloth-fold','cloth-account','cloth-choice','cloth-return']],
 ['borrowed-pot','一只锅不能开两个灶','side',['tenant-ladle','real-berths','pot-count','stove-mark','pot-chosen','pot-closed']],
 ['eight-on-two-streets','八扇门不等于八个点头','main',['beds-list','bed-permission','bed-halfweight','peg-sent','sled-tried','beds-countersigned']],
 ['right-to-answer','由她自己收回的帘','companion',['speaker-boundary','folio-corrected','speaker-choice','speaker-action','speaker-return']],
 ['net-with-room','给巢留下一根绳','side',['net-open','net-gift']]
];
export const chapterQuests=Object.fromEntries(arcs.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));