import {district,mechanism} from './district.mjs';
import {say as s,person,object,flag,exit} from './parts.mjs';

export const hall=district('petition-hall','盐市 · 公议廊与压印台',3,23,14,'stone',[
 ['building',1,1,6,3,'临时粮票兑付室'],['building',12,1,7,3,'覆潮损耗理算室'],['building',1,11,5,3,'旧词簿阁'],['building',17,11,6,3,'公印库']
],[['pier',7,6,8,2,'三格压印台：实卸、带水、虚列'],['lamp',18,5,1,1,'供证灯']],[
 mechanism('petition-counter','三格配重印台',10,8,[s('理算员','把箱差拨到三格。干尺和湿筐只准同时摆实卸格，一份货不能在两格里赔。'),s('玛拉','发单记一百五十干衡。十二个仓位各十干衡，却给我们称到一百三十二湿衡。')],['dry-factor','ticket-date','bins-seen','testimony-lodged'],'shortfall-proved','压上几枚十衡缺货印？',['一枚，余八衡记潮耗','三枚，十二衡水重另记','四枚，把十二衡水也算损失'],1,'干数只比干数，手头一百二十；湿比干多出的十二是水，不是缺粮。先收印，可以再拨。',[s('理算员','新压痕是三枚。十二衡水退回滩地，不再按人头摊还。')]),
 person('ration-deputy','粥棚代领人',6,7,[{who:'代领人',if:'witness-first',text:'你们慢半班才贴单，灶头少烧了一轮。我认她的手印，可锅底不会认。'},{who:'代领人',if:'ledger-first',text:'公开的单让米先出了库；摇码的人还戴着袖罩，不敢认谁在柜前待过。'},s('代领人','先拿空桶的位置换下病人的站位，等她能坐下，再提粮。')]),
 person('selene-oath','瑟琳 · 摘下自家饭筹',15,7,[{who:'瑟琳',if:'witness-first',text:'我把家里的第二张饭筹押给替班人，才让她说完。我表弟今晚挨哪家的桌子，我得回去自己跟他说。'},{who:'瑟琳',if:'ledger-first',text:'名单贴出去了。印房撤了我母亲惯做的封票班，说是防人情账。今后她少的工钱，我用量潮的份还。'},s('玛拉','我要去北岸量一处港，可能一冬都赚不到现粮。'),s('瑟琳','所以我来。别再让“可能有粮”盖一层公印就成了准话。给我一根探水杖，一栏能写“还不知道”的账。')],{requires:['shortfall-proved','salt-priority'],action:{type:'recruit',id:'selene',set:'north-slate'},after:[s('瑟琳','我在名单后面，不在公印下面。去北行码头，我把浅灯线给你们找齐。')]})
],[exit(2,7,'brine-weigh',[15,9],'回盐衡坊'),exit(17,9,'seal-vault',[20,9],'沿公开账牌回仓',['ledger-first']),exit(21,6,'north-pier',[3,8],'持北航候潮签去准备码头',['north-slate'])]);

export const northPier=district('north-pier','盐市 · 北行准备码头',3,27,15,'wood',[
 ['water',0,0,27,3,'外汊浮冰'],['building',2,3,5,3,'船队领水棚'],['building',13,3,5,3,'麻索行'],['building',20,8,6,4,'旧哨房'],['water',0,12,10,3,'枯水浅缆档']
],[['pier',7,8,11,2,'通向潮痕浮桩的渡桥'],['lamp',18,4,1,1,'北点灯'],['rope',11,11,5,1,'船尾三张备用索']],[
 object('north-tally','候潮签背面的空水深表',13,8,[s('瑟琳','舟首只写了浮高，水手从未到岸。我给第一根铅垂作记号，回来能用同一把尺复量。'),{who:'伊沃',if:'west-stairs',text:'西窗梯已栓牢。留给滞港的人，不拆它来给新船填料。'},{who:'玛拉',if:'grain-first',text:'先前让给粮船的时段，也得在越冬水深表背面留名。'},s('瑟琳','第二根先留白。铅垂没碰到底，谁都别给北岸画泊位。')],{requires:['north-slate','party:selene'],action:flag('north-ready'),after:[s('玛拉','第一根铅垂已在，第二根到北线现场量。岸上还可以回去逐项核实。')]}),
 person('salt-sounding-hand','候船的测缆员',10,7,[{who:'测缆员',if:'witness-first',text:'她在头班潮面认得我。我替她上船量头一根索，船上给一双防割的麻手套就成。'},{who:'测缆员',if:'ledger-first',text:'库里肯放一瓶灯油，可没人愿签字上陌生人的船。我只在岸上帮你看线。'},s('测缆员','潮倒向北了；鞋袜挂到盐阶上会干得快些。')]),
 object('witness-linesman','给志愿测缆员留泊位',17,7,[s('瑟琳','头班的见证人有人陪着回家，今晚便空出一个熟悉拦沙堤的水手。我把他的泊位刻在船头。')],{requires:['north-ready','witness-first'],action:flag('north-linesman')}),
 object('public-lampstock','领一瓶署名的公仓灯油',16,10,[s('伊沃','粮簿当众贴出来，库长才敢在油票背上署名。“夜汊一灯”，签收。')],{requires:['north-ready','ledger-first'],action:flag('north-lampstock')})
],[exit(2,8,'petition-hall',[20,6],'回公议廊')]);
