import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit,flag} from './parts.mjs';
import {tidePost} from './district.mjs';
export const red=region('red-beacon','北航 · 红石分水标',4,'north-sound',24,18,'stone',
 [['wall',2,1,7,6,'双臂信号塔'],['water',11,0,13,3,'旧远标水域'],['building',15,4,6,4,'换灯人屋舍'],['water',0,13,8,5,'石塔滴水槽']],
 [['lamp',11,7,2,2,'两臂带色玻璃'],['pier',8,10,13,2,'门闸外沿'],['rope',13,11,1,5,'手拉标旗']],
 [witness('red-keeper','远标的继任灯手',8,8,[s('灯手','你来要钥匙？上一个守灯人那晚没回来。你若只说“需要开”，我不能把轮交给你。'),s('伊沃','是我从里头灭过它。我不知道那条艇还剩什么人。你肯给我们开远窗吗？我留下教每班怎样从外面再开。'),s('灯手','先试木臂，不用蜡封。我要看我能不能自己开回去。')],'remote-key'),
 fixture('arm-out','把远窗木臂推到外侧止点',12,8,[s('灯手','从外面拉到头了。白面朝远海，红面留给窄槽。'),s('伊沃','现在把两只手柄交在两个人手里。')],'outer-arm',['remote-key','party:mira']),
 fixture('arm-in','从下检修孔复位近窗',15,10,[s('米拉','船看到两灯分开。哪一边遇险，另一个人都不会只剩盯着暗玻璃。'),spoken('灯手','西窗有梯了。我教过的新手可以上岸换两次班。','west-stairs')],'remote-lit',['outer-arm']),
 fixture('oil-gallery','用署名灯油照夜涌的西槽',19,9,[s('伊沃','灯油只浇棉芯。岩背露出一股没有白沫的回水，是到搁船的夜路。')],'oil-cut',['remote-lit','north-lampstock']),
 tidePost('red-clock',10,12)],
 [exit(2,8,'deep-sluice',[20,6],'沿深槽回铅船'),exit(21,10,'wreck-slope',[3,7],'走换班人留下的高石脊',['remote-lit']),exit(18,14,'wreck-slope',[16,12],'循公油照见的夜槽',['oil-cut'])]);
export const wreck=region('wreck-slope','北航 · 两道吃水的搁船坡',4,'north-sound',27,19,'wood',
 [['water',0,0,27,3,'钩鲸浅滩'],['boat',5,4,7,4,'侧卧的救患船'],['wall',18,3,4,5,'旧船台挤压痕'],['building',3,13,7,6,'打样铁铺'],['water',20,13,7,6,'沉锚眼']],
 [['rope',10,9,10,1,'去、返不同色的旧钩索'],['lamp',12,11,1,1,'钉头灯'],['pier',10,13,7,2,'绕船长桥']],
 [fixture('two-drafts','用布沿高低两道潮线擦船舷',9,9,[s('玛拉','低线先结盐，高线后压上去，不是同一天的一次满载。舵尾第二层破洞是后来从内侧打的补钉。'),spoken('玛拉','我早在送棺道看过这种三排钉。第二趟出发之前，它就已经修过一回。','keel-name')],'two-drafts'),
 witness('double-witness','当年在海边量船台的梅屿',14,10,[s('梅屿','我记两次，不记他好不好。头回把能走的孩子放到我的坡上，又转回去。回来时两床撑着破竹，载的是搬不动的人。'),s('玛拉','他为什么还要第二只钩？'),s('梅屿','第一只钩留在破口拖床筐。船能回，钩不能。你试试船尾那两道口子。')],'second-watch'),
 fixture('split-cleat','将两股旧索分别套入双钩口',13,12,[s('玛拉','短钩在岸；长钩够到舱底、磨到露铁。一个环走不了这两条线。'),s('伊沃','两趟救人是真的。别把船账里的名字拿去抹船台那一道压痕。')],'return-twice',['two-drafts','second-watch']),
 fixture('pin-rubbing','以薄片拓下偏斜的销槽',18,9,[s('玛拉','比我食指宽一点的斜槽。左边两个短刻、右边一长。那是刃凿走错以后才补的一笔，不是船名。')],'pin-rub'),
 tidePost('wreck-clock',12,15)],
 [exit(2,7,'red-beacon',[20,10],'沿红标高脊回灯手屋'),exit(17,12,'red-beacon',[17,14],'循夜槽返红标',['oil-cut']),exit(2,10,'deep-sluice',[24,8],'用测缆员的回筐',['sound-cable']),exit(24,9,'stamp-shop',[3,7],'持销槽拓片进打样房',['pin-rub']),exit(22,12,'lee-mouth',[2,10],'沿北标入冬岸',['maker-known','return-twice','remote-lit'])]);
export const stamp=region('stamp-shop','北航 · 船台印样间',4,'north-interior',17,13,'wood',
 [['building',1,1,4,3,'干燥的样片柜'],['crate',9,2,5,4,'报废锚销'],['wall',9,11,8,2,'炉槽隔墙']],
 [['lamp',7,6,1,1,'侧照样片的油盏'],['path',5,7,9,2,'旧尺凳']],
 [fixture('test-punch','将反拓翻到印样底座',8,7,[s('印样师','翻过来再看。新销按旧槽拓做，没翻时两处印恰好错开。'),s('玛拉','两短一长正合。领样人签“晏禾”。是养我的那个人的名字。')],'maker-known',['pin-rub']),
 person('mara-deposition','给玛拉留下的口述格',11,8,[s('印样师','你要怎样把救人和签图带回港口？'),s('玛拉','我可以先说哪一段，两件都得说。',[{text:'先写造锚责任，再写返航',set:'fault-first'},{text:'先列获救者，再附签图',set:'names-first'}])],{requires:['maker-known','return-twice'],action:flag('deposition'),after:[s('玛拉','我会用两行。留出铅笔能写异议的地方。')]}),
 object('stamp-bed','守炉人折起的小床',5,8,[s('印样师','把灯罩放回去。我在炉门边给你留一刻安静。')],{action:{type:'rest'}})],
 [exit(2,7,'wreck-slope',[23,9],'带印样回搁船坡')]);