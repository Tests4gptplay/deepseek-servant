import {theSaltRoom} from './salt-song/a-song-keeps-its-own-last-word.mjs';
import {lullabyMaps,lullabyQuest,withLullaby} from './the-crisp-edge-is-yours.mjs';
import {theDarkCrossing} from './star-clock/one-clock-aboard-two-watches.mjs';
import {driftMaps,driftGear,driftQuest,withDriftbay} from './a-pawprint-in-the-brine.mjs';
import {withNorthernWatch} from './northern-watch.mjs';
import {mainHearing} from './a-place-on-the-main-hearing-table.mjs';
import {quaybillMaps,quaybillQuest,withQuaybill} from './the-boat-name-stays-ashore.mjs';
import {withPuppetStage} from './second-shadow/the-scrim-comes-down.mjs';
import {windMaps,windQuests,windGear,windOpponents,withWind} from './where-the-light-lies-after-noon.mjs';
import {withReturningWatch} from './winter-voice/returning-in-the-rattle.mjs';
import {withWinterVoices} from './winter-voice/index.mjs';
import {keelpotMaps,keelpotQuest,withKeelpot,snapper} from './the-first-pot-and-the-second-tide.mjs';
import {heelMaps,heelQuests,withTurnedDoors} from './what-the-turned-door-kept.mjs';
import {scoreMaps,scoreQuests,withScore} from './scorerock-returns.mjs';
import {saltcoatQuests,withSaltcoat} from './the-last-word-of-the-watch.mjs';
import {drawerQuests,withDrawers} from './stone-and-twelve-drawers.mjs';
import {commonMaps,commonQuests,withCommons} from './room-to-go-home.mjs';
import {basinMaps,basinGear,basinQuests,withBasin} from './basin-and-spoon.mjs';
import {humanTideMaps,humanTideQuests,withHumanTide} from './human-tide.mjs';
import {openingMaps,openingGear,openingQuests,withOpenings} from './winter-and-openings.mjs';
import { scale } from './scale.mjs';
import { market } from './market.mjs';
import { tideway } from './tideway.mjs';
import { hoist } from './hoist.mjs';

import {portExtension,departureQuests,netCrab} from './three-days.mjs';

import {holdSaltMaps,holdSaltQuests,echoRay} from './hold-salt.mjs';

import {northToGrave,lateEncounters,voyageQuests,voyageGear} from './voyage.mjs';
import {withHomeRoutes} from './home-routes.mjs';

import {hemMaps,hemGear,hemFoes,hemQuests,withHems} from './cloth-and-current.mjs';
import {flankMaps,flankGear,flankFoes,flankQuests,withFlank} from './whale-flank.mjs';
import {nightMaps,nightGear,nightFoes,nightQuests,withNightPassage} from './night-and-tilt.mjs';
import {wakeMaps,wakeGear,wakeFoes,wakeQuests,withSpringAndWren} from './spring-and-wren.mjs';
import {streetMaps,streetQuests,withHouseStreets} from './house-streets.mjs';
import {winterExtra,winterFoes,winterGear,winterQuests,withWinterRows,cycles} from './winter-rows.mjs';
import {ledgerMaps,ledgerGear,ledgerFoes,ledgerQuests,withLedger} from './salt-north.mjs';
import {chapterMaps,chapterGear,chapterFoes,chapterQuests,withPortChapters} from './community.mjs';

const originalWorld = {
  version:1,cycles,start:{map:'wharf-scale',x:4,y:12},
  maps:Object.fromEntries([scale,market,tideway,hoist,...portExtension,...holdSaltMaps,...northToGrave,...chapterMaps,...ledgerMaps,...winterExtra,...streetMaps,...wakeMaps,...nightMaps,...flankMaps,...hemMaps,...openingMaps,...humanTideMaps,...basinMaps,...commonMaps,...scoreMaps,...heelMaps,...keelpotMaps,...windMaps,...quaybillMaps,...driftMaps,...lullabyMaps].map(withHomeRoutes).map(withPortChapters).map(withLedger).map(withWinterRows).map(withHouseStreets).map(withSpringAndWren).map(withNightPassage).map(withFlank).map(withHems).map(withOpenings).map(withHumanTide).map(withBasin).map(withCommons).map(withDrawers).map(withSaltcoat).map(withScore).map(withTurnedDoors).map(withKeelpot).map(withWind).map(withQuaybill).map(mainHearing).map(withDriftbay).map(withLullaby).map(withNorthernWatch).map(map=>[map.id,map])),
  actors:{
    mara:{id:'mara',name:'玛拉',job:'殓舟守',explore:'操作重闸',skills:['护送','墩步'],hp:48,mp:9},
    ivo:{id:'ivo',name:'伊沃',job:'巡港绳手',explore:'用索布路',skills:['回索','定架'],hp:39,mp:11},
    selene:{id:'selene',name:'瑟琳',job:'潮量师',explore:'读潮换水',skills:['退潮','盐肤'],hp:31,mp:22},
    mira:{id:'mira',name:'米拉',job:'图署学徒',explore:'勘测岔路',skills:['标线','双星'],hp:34,mp:16}
  },
  quests:{
    ...departureQuests,...holdSaltQuests,...voyageQuests,...chapterQuests,...ledgerQuests,...winterQuests,...streetQuests,...wakeQuests,...nightQuests,...flankQuests,...hemQuests,...openingQuests,...humanTideQuests,...basinQuests,...commonQuests,...drawerQuests,...saltcoatQuests,...scoreQuests,...heelQuests,[keelpotQuest.id]:keelpotQuest,...windQuests,[quaybillQuest.id]:quaybillQuest,[driftQuest.id]:driftQuest,[lullabyQuest.id]:lullabyQuest,
    'the-weight-of-a-name':{id:'the-weight-of-a-name',name:'给他留个名字',kind:'main',startFlag:'procession',endFlag:'coffin-aboard',stages:['procession','tare-seen','weighed','release','brake-order','lift-ready','coffin-aboard']},
    'supper-token':{id:'supper-token',name:'趁碗底还温',kind:'side',startFlag:'meal-open',endFlag:'night-lamp',stages:['meal-open','meal-token','night-lamp']},
    'third-row':{id:'third-row',name:'第三排铜钉',kind:'hidden',startFlag:'old-rhyme',endFlag:'keel-name',stages:['old-rhyme','keel-name']}
  },
  equipment:{...voyageGear,...chapterGear,...ledgerGear,...winterGear,...wakeGear,...nightGear,...flankGear,...hemGear,...openingGear,...basinGear,...windGear,...driftGear},
  encounters:{
    ...lateEncounters,...chapterFoes,...ledgerFoes,...winterFoes,...wakeFoes,...nightFoes,...flankFoes,...hemFoes,
    ...windOpponents,[snapper.id]:snapper,[netCrab.id]:netCrab,[echoRay.id]:echoRay,
    'bell-crab':{id:'bell-crab',name:'卡网的响壳蟹',enemy:'响壳蟹',hp:24,attack:4,level:2,
      tell:'左钳连敲两下，下一拍它会横着冲。',reward:'捞起断网',objective:'让开冲线后解网',
      phases:[{fromHp:24,tell:'钳敲两下',move:'横冲'},{fromHp:10,tell:'腹壳抬起',move:'卷网自护'}]}
  }
};

export const world = theSaltRoom(theDarkCrossing(withPuppetStage(withReturningWatch(withWinterVoices(originalWorld)))));
