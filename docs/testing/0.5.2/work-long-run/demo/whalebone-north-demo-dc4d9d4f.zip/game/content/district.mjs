import {feature,say,object} from './parts.mjs';
export function district(id,name,act,width,height,ground,blocks,land,entities,exits){
  const asFeature=([k,x,y,w,h,label])=>feature(k,x,y,w,h,label);
  return {id,name,act,width,height,ground,biome:act===2?'whale-city':'salt-market',
    solids:blocks.map(([,x,y,w,h])=>[x,y,w,h]),features:[...blocks.map(asFeature),...land.map(asFeature)],entities,exits};
}
export function mechanism(id,name,x,y,lines,need,result,prompt,options,answer,hint,after){
 return object(id,name,x,y,lines,{requires:need,action:{type:'puzzle',id:result,value:true,prompt,options,answer,hint},after});
}
export function tidePost(id,x,y){
 return object(id,'泊水双尺',x,y,[say('尺脚','把艇系在白桩，再移到上沿等一潮。涨水能换舟道，退潮可过石脚；随时可回到此处等下一潮。')],{action:{type:'tide',id:id+'-read',value:'toggle'}});
}
