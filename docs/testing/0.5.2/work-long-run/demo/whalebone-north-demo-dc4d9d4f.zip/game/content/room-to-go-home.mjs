import {apron,sound} from './passengers-return.mjs';
import {commons,doors} from './where-the-queue-turns.mjs';
import {yard,fleet} from './neighbours-out-of-line.mjs';
import {say as s,exit,person} from './parts.mjs';
import {witness,fixture,spoken} from './voyage-parts.mjs';

export const commonMaps=[apron,sound,commons,doors,yard,fleet];
const links={
 'winter-ward':[exit(5,7,'boat-back-by-supper',[4,11],'由床后的烤房去试一回真正的载重返程',['bed-count','moor-proved'])],
 'anchor-yard':[exit(16,7,'oven-shadow-square',[4,11],'到街里的鹅影下，听支持和反对重下锚的人',['winter-proof'])],
 'ratchet-loft':[exit(14,7,'oven-shadow-square',[32,16],'两处回铃之后回到方才靠船的广场，看看还剩多少时间',['clutch-still','both-bells'])],
 'flood-stair':[exit(5,7,'oven-shadow-square',[39,16],'街面已倾，回去接昨天留下要领粮的邻人',['harbor-tilted']),exit(6,8,'goose-foot-floor',[38,18],'从高门回看亲自走过的街院',['common-landed-street']),exit(7,9,'hulls-not-in-line',[40,18],'从外港口回看仍在接送邻里的家艇',['common-landed-wake'])],
 'burial-cape':[exit(16,7,'under-the-doorknock',[31,15],'从墓坡踏进衣铺，走到真正的家属门前',['base-safe'])]
};
const extra={
 'oven-shadow-square':[
  witness('common-evacuate','让发粮队的邻人自己挑能带走的一样东西，然后同其中一组走',15,16,[s('荚黎','上院的门还能开，那帮人不放饭位不肯离开。水窝里是没排过队的家船，一个个挤过去会把后头的堵在弯角。'),s('玛拉','我亲自走一边。走街院要先把自己的饭位让出来，坐家船就要把留给官货的一趟还给船主。',[{text:'进街院，跟芋娣走过她家的窗下',set:'common-street-choice'},{text:'进水窝，和住户一起等各自的艇',set:'common-wake-choice'}]),s('荚黎','另一处我找认得路的人问，别把你没走的那边也写成你的本事。')],'common-evacuating',['harbor-tilted','!common-neighbours-out','!tilt-sighted','!grave-signed'],{after:[s('荚黎','你答应过他们一条路，另一边由当时在场的人作主。')]}),
  person('common-closed-stall','房门还留在同一个地方的乔纾',18,18,[s('乔纾','我不跟着回去给锚放鞭炮。你找我就来这个门边。'),spoken('乔纾','官库交出去那一批，有人当众听见了。欠我的旧门不在账里，我也没要求你给它添上。','common-release-word'),spoken('芋娣','回港先来我家吃。我们现在知道怎样在太阳不照木鹅时回自己家。','common-landed-street'),spoken('乔纾','小艇是我自己选的，我还可以再回到这里来。你们夜里少看门外那把剪子，它的影子有点吓人。','common-landed-wake')])],
 'under-the-doorknock':[
  witness('common-cloth-back','把从坟边带回的布印交到乔纾自己还能开合的门里',12,15,[s('乔纾','好。翻面，缝在围裙内侧。我下次忘了门挂在哪儿，就自己摸一下。不用把这块印做成你们家属的东西。'),s('玛拉','我有件送还的事。到这儿才算送还。')],'common-home-after',['common-cloth-rolled','grave-signed']),
  witness('common-child-back','在染坊灶边把简杏自己挪出的凳子摆到乔纾边上',25,14,[s('简杏','我走回来比你们快。干嘛站着？空凳坐人，不用老摆给那个时候。'),s('乔纾','谁说费铎干活时坐得住。他的脚天天在我板凳上磨印。你挨我近点，我替你缉一圈短袖。')],'common-home-after',['common-child-at-stone','grave-signed'])],
 'burial-cape':[
  fixture('common-roll-cloth','等两面碑都见光，再把土沿的无名布印收回给原主',6,10,[s('玛拉','纸灰扫掉，门环布向里面卷。她准我带来，留在哪儿还该由她决定。')],'common-cloth-rolled',['grave-signed','common-cloth-at-stone']),
  fixture('common-cloth-at-grave','把没有姓名的一圈门环布印搁到土沿，站到玛拉自己能读的位置',7,7,[s('玛拉','这是一个人回到自己家，却再没等到的门。我不公开他是谁。门布不埋进去，还要送回给活着的人。')],'common-cloth-at-stone',['common-cloth-yes','coffin-home','!grave-signed']),
  witness('common-voice-at-grave','让简杏在自己的位置开口，玛拉从碑前退过一步',14,9,[s('简杏','那船第二次回来，抱我上去的人弄疼了我的下巴。疼说明我回来了，我后来学会裁袖，见到旧城的人，也还有我的坏脾气。'),s('玛拉','可以了，不必再说他是怎样的人。'),s('简杏','我本也没打算替你作那份工。我回去坐她旁边。')],'common-child-at-stone',['common-guest-yes','coffin-home','!grave-signed']),
  person('common-stone-side','坟边面向原来那条街的一小块空土',7,12,[s('玛拉','从这里看下去，家人能自己走到坡边，也能自己回家。两行石字都在。'),spoken('玛拉','布已经卷起。名字仍归那扇门里的人。','common-cloth-at-stone'),spoken('简杏','我哪天给你补补旧衣领。穿新的扎下巴。','common-child-at-stone')],{requires:['grave-signed']})]
};
const gates={
 'winter-proof':['return-crossed','两家能住，病床有数。烤房背面还有人问能不能自己回家，去晚饭埠试过满船返程再把结论告诉大家。'],
 'bran-return':['common-lowered','鹅影坪有人赞成，也有人反对。这一晚是谁决定下锚、押上什么，得由布兰在街上当众回答。'],
 'bran-unpin':['common-release-word','锚机与两处回铃都得平稳。随后从楼上去鹅影坪看第二船是否真能靠完，跟立过担保的人再回来。'],
 'cut-ramp':['common-neighbours-out','收粮坡仍有人把留住饭位看得比上坡要紧。从鹅影坪走到他们的街里或水窝，实际接出一组邻人。']
};
const touches={
 'winter-proof':[spoken('玛拉','试过的只有梨青一条载重归路。港里那些没看见的人仍有理由问，两家之外的床仍不能写在这张纸上。','return-crossed')],
 'bran-return':[spoken('布兰','我刚让第一船靠了，第二船还靠不稳。我答应过不能用别人家的人替官库押粮。','common-lowered')],
 'bran-unpin':[spoken('布兰','芋娣喊了放。她先前喊留，一样是真话。我把第二船当今晚必能回来，是我错。现在我松。','common-release-word')],
 'engrave-slot':[spoken('玛拉','门环布上有一道向下扯的纹，我不刻名字。那晚住在那里的人有她自己的家。','common-cloth-at-stone'),spoken('玛拉','乔纾失去的门上没有我父亲的签名。那一行是我在北岸亲眼核的，他签过。','common-fault-voice')],
 'engrave-return':[spoken('简杏','我那一趟没学会游水。我第二年才学会，是她带我下的水，不是那张救人名册。','common-child-at-stone')],
 'cover-letters':[spoken('玛拉','乔纾的门环印不署名，简杏把自己的活说清。哪一家也没有替我父亲赦掉另一家的事。',['common-rescue-voice','common-fault-voice'])]
};
const features={
 'boat-back-by-supper':[{id:'common-green-window',kind:'lamp',x:30,y:13,w:2,h:1,label:'只开下半面的归航绿窗',sceneStates:[{until:'return-bogged',pose:'shut'},{from:'return-bogged',pose:'lower-open'}]}],
 'keel-in-shadow':[{id:'common-mud-stripe',kind:'boat',x:9,y:13,w:3,h:1,label:'能复看的压载搁痕',sceneStates:[{until:'return-bogged',pose:'clean'},{from:'return-bogged',pose:'black-band'}]}],
 'oven-shadow-square':[{id:'common-turning-goose',kind:'sign',x:18,y:13,w:1,h:1,label:'在同一扇发粮窗望见的木鹅',sceneStates:[{until:'common-lowered',pose:'above-line'},{from:'common-lowered',until:'common-turn-seen',pose:'level'},{from:'common-turn-seen',pose:'below-window'}]}],
 'under-the-doorknock':[{id:'common-door-in-cloth',kind:'rope',x:11,y:13,w:1,h:1,label:'从未挪进晏禾棺里的家门环'}],
 'goose-foot-floor':[{id:'common-three-legs',kind:'hearth',x:17,y:15,w:2,h:1,label:'方向已变的灶脚与鹅影'}],
 'hulls-not-in-line':[{id:'common-sleeves-on-hull',kind:'boat',x:40,y:15,w:2,h:1,label:'愿意靠岸才收回的白袖',sceneStates:[{until:'common-landed-wake',pose:'hanging'},{from:'common-landed-wake',pose:'gathered'}]}]
};
export function withCommons(map){
 const entities=map.entities.map(e=>{
  if(!gates[e.id]&&!touches[e.id])return e;
  const change={};
  if(gates[e.id]){const [flag,lockedText]=gates[e.id];change.requires=[...(e.requires||[]),flag];change.lockedText=lockedText;}
  if(touches[e.id]){
   let dialogue=e.dialogue;
   if(e.id==='bran-return')dialogue=dialogue.map(l=>l.text.startsWith('我收到了内港的七结水深。')?{...l,text:'鲸群早转两潮。我让他们把今天的锚放了下去，原盼能换一晚粮。现在先去看第二船，不让仓主逼人留在将要翻落的货边。'}:l);
   change.dialogue=[...dialogue,...touches[e.id]];
   if(e.id==='cover-letters')change.after=[...(e.after||[]),...touches[e.id]];
  }
  return {...e,...change};
 });
 return {...map,entities:[...entities,...(extra[map.id]||[])],exits:[...map.exits,...(links[map.id]||[])],features:[...map.features,...(features[map.id]||[])]};
}
const rows=[
 ['a-boat-can-come-back','一条能载着人回家的路','main',['return-terms','return-empty','return-bogged','return-party','return-home','return-crossed']],
 ['the-night-that-was-owed','布兰究竟买下了哪一晚','main',['common-rations','common-opposition','common-evidence','common-lowered','common-turn-seen','common-release-word','bran-unpinned']],
 ['come-out-of-the-line','让邻人按自己的门道离开','main',['common-evacuating','common-neighbours-out']],
 ['a-visit-ends-at-home','把送别的人和物还回自家门里','side',['common-witness-choice','grave-signed','common-home-after']],
 ['the-door-that-did-not-return','一扇没回家的门','side',['common-fault-voice','common-rescue-voice','common-witness-choice']]
];
export const commonQuests=Object.fromEntries(rows.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
