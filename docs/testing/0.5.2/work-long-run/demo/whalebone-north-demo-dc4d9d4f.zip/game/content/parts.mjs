// Coordinates in this module are tile units. Entity and flag IDs persist in saves.
export function say(who, text, choices) {
  return choices ? { who, text, choices } : { who, text };
}

export function feature(kind, x, y, w, h, label) {
  return { kind, x, y, w, h, label };
}

export function exit(x, y, to, at, label, requires = []) {
  return { x, y, to, at, label, requires };
}

export function person(id, name, x, y, dialogue, extra = {}) {
  return { id, kind: 'npc', name, x, y, dialogue, ...extra };
}

export function object(id, name, x, y, dialogue, extra = {}) {
  return { id, kind: 'object', name, x, y, dialogue, ...extra };
}

export function flag(id) {
  return { type: 'flag', id, value: true };
}
