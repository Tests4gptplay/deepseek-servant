import {region} from './voyage-parts.mjs';
import {say,object,person,exit} from './parts.mjs';
export const tell=(who,text,ifFlag)=>ifFlag?{...say(who,text),if:ifFlag}:say(who,text);
export const speech=(who,text,clip,ifFlag)=>({...tell(who,text,ifFlag),lullabyClip:clip});
export const portWay=[[5,12],[9,11],[12,8],[16,7],[21,8],[23,11]];
export const roofWay=[[5,10],[9,12],[14,12],[17,9],[20,7],[24,8]];
export const lane=region('lullaby-pan-lane','白崖港 · 灶巷里反着走的送行人',1,'harbor',30,20,'stone',
 [['building',1,1,6,6,'一早添头锅油的饼业会'],['building',10,1,6,4,'檐下晒鱼的两家'],['building',19,1,9,4,'夜班女工的过堂铺'],['crate',3,15,6,4,'靠着湿石的炭担'],['building',13,15,7,5,'油蒸满窗的吊面屋'],['water',25,13,5,7,'搬进屋脚的舷水']],
 [['path',1,10,24,3,'粮车赶早时行人的反道'],['rope',9,6,12,1,'四户人家的鱼篮线'],['lull-fryer',17,8,2,1,'姜饼焦边摊'],['lull-cloths',5,8,4,2,'男人与孩子换穿的围裙']],
 [person('lullaby-saltseller','哑着嗓子卖盐青果的璞弟',9,13,[speech('璞弟','第一锅的焦边给看火的人。别等凉，凉了我就留着自己磕。','port-crust'),tell('玛拉','我小时候也这样说。他把软的一整张给我，我还以为焦的最贵。')]),
 person('lullaby-oilwife','总听见长巷响两次脚步的卞嫂',13,7,[speech('卞嫂','巷口听见脚，屋里先挪凳。他从前一脚轻一脚重，雨天照听得出来。','port-stool'),tell('列因','今天我也听见一轻一重。是玛拉推车，排水石上有一边的辙。')]),
 object('lullaby-fringe','捡到一块早已冷透的锅焦',22,13,[tell('玛拉','我把它掰成两半，里面没有热气。塔婶说家里至今还少一张能留住热饼的盖。'),tell('列因','我娘会跟人争辩盐放早了还是晚了。要她讲他好，从来就讲不出这件小事。')])],
 [exit(2,12,'wharf-scale',[6,10],'回塔婶守着的棺车'),exit(25,11,'lullaby-last-stove',[3,9],'跟列因走到最后一张灶门',['lullaby-port-led'])]);
export const stove=region('lullaby-last-stove','白崖港 · 背街最后一张灶门',1,'harbor',26,18,'wood',
 [['building',1,1,6,5,'给夜巡添锅的后屋'],['building',12,1,9,5,'有一扇不肯大开的蒸窗'],['crate',6,12,4,5,'湿柴与两个小木墩'],['building',20,12,6,6,'面团发夜的暖阁']],
 [['path',2,8,21,3,'灶前可以往回调头的小院'],['lull-fryer',13,7,3,2,'给旧邻烙姜饼的灶'],['lull-cloths',18,9,3,1,'遮住窗里人的两件油衣']],
 [person('lullaby-mother','抹去灶前热油的乔稔',12,9,[speech('乔稔','他煎鱼总把盐放早。我今天还是要说他。你要我换一句好听的，就别等。','share-salt'),tell('玛拉','有人愿意从灶前送，有人要做完这一锅。我能把车停在街口，你不用出来。'),tell('乔稔','要问就一个人问。我的脸用不着给整条街看。')],{action:{type:'flag',id:'lullaby-met'}}),
 object('lullaby-ask','从侧窗只问乔稔本人要不要听到葬车',18,8,[tell('玛拉','我过来问一声。你要听见车轮，我把靠窗的这一段推慢。'),speech('乔稔','行。就开一掌。焦的这张来不及翻，你替我跟晚班说一声。','port-window'),tell('列因','我留在外面，显得你们两个人说话。今晚那班少一锅，我去切姜补。')],{requires:['lullaby-met','!lullaby-port-choice'],action:{type:'flag',id:'lullaby-port-asked',set:'lullaby-port-choice'}}),
 object('lullaby-pass','让车走背街，把仍在煎饼的灶窗留给她',6,10,[tell('玛拉','这条背街远，有一小段谁也听不见车。就从这边走。'),speech('乔稔','饼翻过来了。门缝还留着，谁也不必替我讲一句。','port-pan'),tell('列因','晚班有热的。棺车过去时我娘还在弄面，她没能听见那一声。')],{requires:['lullaby-met','!lullaby-port-choice'],action:{type:'flag',id:'lullaby-port-quiet',set:'lullaby-port-choice'}})],
 [exit(2,9,'lullaby-pan-lane',[24,11],'穿过油巷回棺车'),exit(23,10,'coffin-hoist',[13,9],'到塔婶守着的送客吊台')]);
