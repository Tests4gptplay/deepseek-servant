import {furnishHeel} from './heelturn-interiors.mjs';
import {hall,inTime} from './the-door-that-became-a-floor.mjs';
import {high} from './the-short-hook-under-the-sill.mjs';
import {low,folded} from './the-long-bed-at-the-corner.mjs';
import {flood,ramp} from './the-night-the-sill-went-under.mjs';
import {quiet} from './a-hand-inside-the-dry-jamb.mjs';
import {proof} from './the-casting-and-the-second-boat.mjs';
import {fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';

export const heelMaps=[hall,high,low,folded,flood,ramp,quiet];
const ownMaps=new Set(heelMaps.map(map=>map.id));
const connectors={
 'crib-hold':[{...exit(19,6,'heel-hall',[4,12],'从现住的铺床巷走入昔日折腰弄',['ward-story',...inTime]),lockedText:'先听井嫂说清哪边还住着人。抵冬岸见拜蓝后，这一趟向里开旧门的机会已经过了。'}],
 'flood-stair':[{...exit(22,10,'heel-flooded-hall',[4,12],'看活水重新走进两面灶门，普通疏散坡仍通',['harbor-tilted']),lockedText:'须由布兰解锚、玛拉开出真实撤离线。'}]
};
const echoes={
 'safe-keel':[
  witness('heel-carry-spoken','听春汤和姐姐自己说清宽坡上怎样停过一次',19,8,[s('春汤','刚到半腰我还伸手夺我姐的袖子。她说慢点，袖线是昨儿补的！我想起来就觉得丢脸，又觉得能笑真好。'),
  s('雁折','若明春有人问这道新坡哪儿少了一块旧门，别把那一刨说成天生没有。')],'heel-ramp-after',['heel-ramp-walked','base-safe']),
  witness('heel-kin-spoken','听柳珏说完进门后想起的家事',13,8,[s('柳珏','大伙以为我进屋哭。我只摸了一会儿小窝，想起来该去给那双做反的鞋改脚。'),
  s('春汤','我跟姐姐从公坡上来。拐弯费了会儿工夫，人还在一块儿。你们别把我也写成走过那扇内门的家属。')],'heel-room-after',['heel-quiet-walked','base-safe']),
  person('heel-left-whole','修完普通坡鞋回来的淘岚',10,8,[s('淘岚','每个靠大坡回来的人也有家。谁下午留在门边、谁过了哪只小洞，换一张总船票就说不清。'),
  spoken('淘岚','有些活已经谈过，水上来时却来不及动手。后来问起来，把谈过和做过讲成两句。',['heel-order','!heel-ramp-walked','!heel-quiet-walked']),
  spoken('淘岚','你没往老屋里来，我给你看的只是我自己今夜踏过这道公坡的鞋。','!heel-met')])],
 'burial-cape':[
  fixture('heel-stone-casting','在造锚的碑边合拢一张旧样肩蜡印',19,10,[s('玛拉','把门烧了，旧图上的晏禾仍然是他。把获救孩子的名字添满另一面，这块偏木依旧是照他的样纸做的。我得留住这一行。')],'heel-stone-fault',['epitaph-fault','heel-fault-proved']),
  fixture('heel-stone-sleeve','在另一面碑边放下短钩窗边的压痕',13,8,[s('玛拉','他说不许小孩搂他的头，是要看船能不能从窗下倒回去。雁折还活着，能当着我的面说她不想再讲。我也被那个船头带回了岸。'),
  s('伊沃','把两次返航留在这行。我不替低层没回来的人在对面写一句同意。')],'heel-stone-rescue',['epitaph-rescue','heel-rescue-proved']),
  person('heel-no-more-questions','摸着新屐把等家人下山的雁折',22,12,[s('雁折','我今天不是证人。家人坐那边的凳。'),
  spoken('雁折','我娘今夜自己开过那扇门，出来头一句话是鞋做反了。她爱怎么记，怎么记。','heel-room-after'),
  spoken('雁折','春汤两姐妹同车到岸。我还留着削下的薄木屑，打算夹进给娘的新把。','heel-ramp-after'),
  spoken('玛拉','有的我没赶上，有的她不愿讲。碑上两行仍是我从原物和原航带回来的。',['!heel-stone-fault','!heel-stone-rescue'])])]
};
const guide='高窗要从屋里托、从外侧收短钩；下床先沿半月沟回转。实物各有来源，冬岸修成、倾港亲走后才是今天的人路。';
export function withTurnedDoors(map){
 const additions=[...(proof[map.id]||[]),...(echoes[map.id]||[])];
 if(!ownMaps.has(map.id)&&!additions.length&&!connectors[map.id])return map;
 const guided=e=>e.requires?.length?{...e,lockedText:e.lockedText||guide}:e;
 const entities=[...(ownMaps.has(map.id)?map.entities.map(guided):map.entities),...additions.map(guided)];
 return furnishHeel({...map,entities,exits:[...map.exits,...(connectors[map.id]||[])]});
}
const paths=[
 ['the-short-hook-and-the-lower-bed','上层的一双手和下面没出来的人','side',['heel-met','heel-leveled','heel-short-trace','heel-rescue-proved','heel-stone-rescue']],
 ['a-casting-under-the-varnish','钻在旧漆下面的偏肩','side',['heel-low-water','heel-low-trace','heel-stock-trace','heel-fault-proved','heel-stone-fault']],
 ['what-the-jamb-can-be','整扇门今夜给谁亲手开','side',['heel-family-grip','heel-winter-permission','heel-order']]
];
export const heelQuests=Object.fromEntries(paths.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
