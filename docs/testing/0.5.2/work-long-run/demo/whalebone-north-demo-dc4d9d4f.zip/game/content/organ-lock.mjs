import {say as s,person,object,flag,exit} from './parts.mjs';
import {district,mechanism,tidePost} from './district.mjs';
export const organ=district('organ-lock','亮灯空城 · 风琴闸腹',2,26,18,'wood',
 [['wall',0,0,26,2,'中梁'],['water',5,4,5,7,'外侧泄压槽'],['water',16,3,4,6,'内侧导槽'],['crate',19,13,6,4,'风箱总架']],
 [['pier',0,8,25,2,'操闸长板'],['crane',12,5,2,3,'两门交叉轴'],['lamp',21,8,1,1,'气舌灯']],
 [person('near-cox','近艇桨手·尤恩',4,7,[s('尤恩','灯灭那阵我还能看见近门的白边。我把九个孩子挪进了鼓腹。远标小艇在另一个门外，我数得出它敲了三次。'),s('伊沃','当时我给你让的是潮差，不是一条给所有人都开的路。')],{action:flag('near-witness')}),
 object('pressure-reed','发音方向相反的两根气舌',12,7,[s('铭刻','右舌唱低音，排向病铺。左舌唱高音，通外海。此时先放低音，井嫂的药盘会先浮起来。'),s('玛拉','横闩要压在靠病铺那扇门上，让外槽先泄压。')],{action:flag('reeds-read')}),
 mechanism('organ-crossbar','风箱横闩座',15,10,[s('伊沃','把两门一起打开，水会自己找最近的屋。听清是谁在替你吃这扇门的压力。')],['bar-freed','reeds-read'],'gate-safe','先让哪段水路通气？',['病铺门和外门一起开','先开下铺，再滑旧闩','先闩内门，再泄外槽，等两舌同音'],2,'闩住病铺才隔得开两槽。同音表示两边水头已平，可以换门。',[s('井嫂','汤药没有晃。水先从外舷的鳞窗落下去了。')]),
 tidePost('reed-gauge',21,9)],
 [exit(1,9,'crib-hold',[24,9],'回铺床巷'),exit(23,8,'west-lamp',[2,10],'沿已卸压的检修道上灯塔',['gate-safe']),exit(12,15,'bell-cistern',[7,3],'下行敲铃蓄水间',['gate-safe'])]);
