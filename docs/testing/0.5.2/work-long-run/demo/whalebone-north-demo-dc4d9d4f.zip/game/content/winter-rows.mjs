import {winterVoices} from './winter-voices.mjs';
import {pages} from './registry-parts.mjs';
import {tallow,wick,flueOutcomes} from './winter-flues.mjs';
import {larder,tender} from './winter-grain.mjs';
import {loft,brick,linen} from './winter-reed.mjs';
import {inn,gutter,shutters,landing} from './turning-inn.mjs';
import {wool,bookEnds,relief} from './wool-ferry.mjs';
import {slope,cistern,eelPump,winterGear} from './under-berth.mjs';
import {watchMaps} from './second-watch.mjs';
import {afterwatch} from './cycle-journal.mjs';
import {exit,object,say as s} from './parts.mjs';
import {fixture} from './voyage-parts.mjs';
export const winterExtra=[tallow,wick,larder,tender,loft,brick,linen,inn,gutter,shutters,landing,wool,slope,cistern,...watchMaps];
export const winterFoes={[eelPump.id]:eelPump};
export const cycles={afterwatch};
export {winterGear};
const windows={
 'winter-court':[exit(11,12,'tallow-street',[3,9],'去芯蜡市追两道烟'),exit(18,12,'loft-reed',[13,14],'去挂网街找旧图的使用人'),exit(14,13,'kin-larder',[24,9],'沿汤碗来路看家里的两张筹')],
 'winter-ward':[exit(7,10,'linen-slope',[3,8],'从铺位走去洗衣坊')],
 'kin-larder':[exit(18,11,'linen-slope',[21,8],'去暖坊找铺主和兄长')],
 'moor-pocket':[exit(10,11,'grain-tender',[3,9],'登布兰在冬岸试靠的末班驳')],
 'anchor-yard':[exit(8,11,'tilting-inn',[3,9],'进布兰正在拆门的泊客栈',['bran-at-drum']),exit(15,14,'yellow-cup',[21,9],'回看已经走到的接人台',['inn-arrived'])],
 'safe-keel':[exit(14,8,'wool-ferry',[24,9],'沿低舷去找冬洗坊交过衣的人',['base-safe']),exit(11,13,'under-berth',[3,8],'安葬后借船走北端深潮',['grave-signed'])],
 'flood-stair':[exit(25,12,'wool-ferry',[3,9],'到搬家的衣渡找应到的人',['tilt-sighted'])]
};
const guests={
 'tallow-street':flueOutcomes,
 'safe-keel':relief,
 'burial-cape':[...bookEnds,object('turn-to-afterwatch','封好首航记，另开沅籽的值灯次航',17,10,[s('沅籽','我会另起一本。你这一年想回来摸摸石头、看看家人，都还走自己的首航记。')],{requires:['grave-signed'],action:{type:'cycle',id:'afterwatch'}})],
 'winter-ward':[fixture('winter-proof-memory','重读上一航已经寄给布兰的复核签',15,9,[s('勾婶','风、水、泊位、病床都盖过。我把这张签压在锅底，后来的议债和补炉事可以另外记。')],'winter-proof-recalled',['winter-proof'])],
 'anchor-yard':[fixture('anchor-shoe-memory','看已卡稳的殓舟铁垫和旧锚痕',16,12,[s('客婆','以前顶住过的梁不必再拆掉。今天的修床和夜班，可以另外接。')],'old-shoe-seen',['shoe-held'])]
};
const more={
 'selene-ledger':{need:['house-story'],tip:'去冬岸热席巷，让旧薇和温涟拼合药铺床筹，或让海螺取沙荷主动看炉的三行收据。'},
 'winter-proof':{need:['hearth-trial','stores-backed'],tip:'查完风、水、泊位与床，还要走芯蜡市两道烟，亲眼看布兰的粮驳和哪个人先担损。'},
 'mara-shoe':{need:['inn-arrived'],tip:'客栈已经拆门。先和布兰搬空床，到铜沟核浮板或走干楼，在接人台见到客婆自己举的黄杯。'}
};
export function withWinterRows(map){
 const entities=map.entities.map(e=>{
  const gate=more[e.id],groups=winterVoices[e.id];
  const base=gate?{...e,requires:[...(e.requires||[]),...gate.need],lockedText:gate.tip}:e;
  if(!groups)return base;
  const extra=pages(groups);
  return base.after?.length?{...base,after:[...base.after,...extra]}:{...base,dialogue:[...base.dialogue,...extra]};
 });
 return {...map,entities:[...entities,...(guests[map.id]||[])],exits:[...map.exits,...(windows[map.id]||[])]};
}
const arcs=[
 ['the-smoke-is-here','屋里屋外的两根蜡芯','main',['two-flues','street-flame','flue-reading','hearth-trial']],
 ['loss-that-can-be-paid','还有谁肯开粮船','main',['hearth-count','house-story','bran-credit','bond-terms','bond-signed','stores-backed','bond-settled']],
 ['the-fifth-low-brick','错画成高处的三扇窗','side',['wrong-step','cart-scratch','brick-wet','brick-dry','chart-corrected','map-help-arrived','cart-home']],
 ['a-reversible-sleeve','能自己走出的一幅袖','side',['hem-request','hem-tested','cloak-promised','cloak-worn','cloak-arrived','cloak-home']],
 ['cup-one-can-lift','谁真正拿到这只黄杯','main',['inn-offered','inn-clear','gutter-read','float-tested','evac-elected','cup-travel','inn-arrived']],
 ['afterwatch-log','第二航次：失踪值灯人的旧窗','main',['afterwatch-open','watch-entered','watch-height','watch-shard','watch-paint-order','watch-bells','watch-baker','watch-signal','watch-stated','watch-second-end']],
 ['ebb-test','冬检的两股力','side',['deep-invited','deep-kit','deep-checked','deep-receipt']]
];
export const winterQuests=Object.fromEntries(arcs.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
