import {say as s,person,object,flag,exit} from './parts.mjs';
import {district,mechanism} from './district.mjs';
export const west=district('west-lamp','亮灯空城 · 西窗信号塔',2,21,17,'stone',
 [['wall',0,0,21,2,'风口'],['building',5,2,5,3,'灯油小库'],['wall',15,9,2,5,'信号柱'],['water',2,13,7,4,'西窗口']],
 [['lamp',10,7,2,2,'遮光百叶'],['rope',3,7,3,1,'外接西梯'],['pier',12,11,7,2,'沿海走廊']],
 [object('far-boat-list','当夜两趟返航的灯底册',7,7,[s('潮汐册','第一趟近门收九人，回点过两遍；远门第三遍铃止。补页用另一种笔「船壳冲到东盐滩，两人上岸，一盏灯下落未明」。'),s('伊沃','是两只小艇。把两行抄到一张救患船票上，就成了「谁开走了唯一一条船」。')],{action:flag('far-roll')}),
 mechanism('blind-louvers','旧夜遮光百叶',12,6,[s('玛拉','当作那一夜。把灯给哪只船看，另一个窗会留下什么？')],['near-witness','far-roll','gate-safe'],'light-replay','让近门船看见白线，又拦住外门回灌。哪套百叶能重现？',['两面通亮，假定水头相等','背外门遮住远光，留近窗白缝','灭近窗照外礁，让近船摸黑'],1,'近船能辨白边；远船敲三下无人应。两面都亮不能重现证言。',[s('伊沃','九个孩子靠这道白缝上岸。远艇仍有两人游到盐滩，还有个人我叫不回来。两句话我都得讲。')]),
  person('ivo-admission','窗边等乔的伊沃',9,9,[s('伊沃','我当年只交了进舱名册，没有交灯底册。今天让乔先看，再拿去公秤屋。'),{who:'玛拉',if:'keel-name',text:'我父亲的字也在救艇夹板里。好人坏人两个字装不下这些证据。'}],{requires:['light-replay','lift-proved','ward-story'],action:flag('harbor-truth')}),
  object('return-beacon','乔的旧罩与短芯',13,11,[s('乔','我敲两下，你不能拿灯替我舅舅说原谅。'),s('伊沃','我只回两下，意思是今天有人上岸。'),s('乔','还差一件事。西窗没有梯，亮了也走不过去。')],{requires:['wick-traced','light-replay'],action:flag('lamp-restored'),after:[s('伊沃','灯照着那个新梯座。回晒衣院，我们一起把它固定。')]})],
 [exit(1,10,'organ-lock',[22,8],'回风琴外槽'),exit(2,8,'dry-court',[11,15],'下已修西窗梯',['west-stairs']),exit(19,8,'salt-lane',[2,8],'带两份证词过盐市桥',['harbor-truth'])]);
