import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit} from './parts.mjs';

export const shoal=region('false-shoal','北航 · 折回的白泥汊',4,'north-sound',16,13,'stone',
 [['water',0,0,16,3,'冰泥槽'],['crate',5,4,3,3,'搁浅扁舟'],['water',11,9,5,4,'鲣鱼尾水']],
 [['pier',1,7,11,2,'轻舟可退的蓑草滩'],['rope',6,9,3,1,'拖舟活结']],
 [fixture('mud-wax','三结就碰底的白铅',8,7,[s('瑟琳','三结，软泥粘蜡；海水没到腰，轮不到它当粮船泊路。错走了，给后来的人留下拒航桩。')],'shoal-rejected'),
 person('shallows-netter','捉泥虾的拂婆',3,8,[s('拂婆','大船看不见泥里的小沟。我卖虾，当然盼人来，但这些木牌我替你写“别开船”。')])],
 [exit(1,6,'lead-sound',[15,12],'借回水桩拖回试铅桥'),exit(12,8,'ice-mark',[17,7],'沿退水石脚回浮尺',['tide:low'])]);
export const depth=region('deep-sluice','北航 · 双影深槽',4,'north-sound',28,18,'wood',
 [['water',0,0,28,4,'急流白脊'],['water',8,5,6,4,'假深回涡'],['water',19,10,9,6,'主槽水'],['crate',1,13,5,4,'备用铁铅']],
 [['pier',2,8,18,2,'试测栈道'],['rope',15,4,1,10,'两条定线的交点'],['lamp',20,6,1,1,'拟定航标']],
 [fixture('mud-drop','在白脊外沿放铅',6,10,[s('玛拉','拉线手上没有回重。一、二、三，蜡头裹泥。能绕船，不能巡冬。')],'near-shallow'),
 fixture('rock-drop','移到双影交点再放铅',15,7,[s('瑟琳','第八结落到硬底。涨水时第十结、平水八结，曲线往外扬；涨落都比粮船最低的六结深。')],'hard-eight',['plumb-zero','bearing-stone','bearing-ice']),
 person('ink-oath','米拉的两支图笔',17,10,[s('米拉','同一本图该留两样字。硬底位置落墨，漂冰和我先前的错线留铅。你们肯把错线也带上吗？'),s('玛拉','哪天我的名字压住证词，你也拿铅笔给我划开。'),s('米拉','好。我做定线的人。剩下的路一起走。')],{requires:['near-shallow','hard-eight'],action:{type:'recruit',id:'mira',set:'north-chart'},after:[s('米拉','从这里往红灯走，中央深槽两侧仍给浅底船留路。')]}),
 fixture('linesman-guide','测缆员下旧吊篮看背流',24,7,[s('测缆员','我的旧靴底认识这段凿槽。把你们送到搁船坡南面，再沿红标往回找也是通的。')],'sound-cable',['north-chart','north-linesman']),
 fixture('margin-prick','两张图都没标的供绳孔',10,12,[s('米拉','肋根的老钉在这儿能对上另一孔。把地图折半贴在绳上，夹出的三角背面有光。')],'rib-pocket',['north-chart','old-bone-mark'])],
 [exit(2,8,'rib-survey',[19,14],'回固定望架'),exit(21,6,'red-beacon',[3,8],'沿已实测深槽航行',['north-chart']),exit(25,7,'wreck-slope',[3,10],'工友吊篮下搁船坡',['sound-cable']),exit(10,14,'rib-pocket',[3,6],'循米拉折出的夹隙',['rib-pocket'])]);
export const pocket=region('rib-pocket','北航 · 两片骨之间',4,'north-interior',15,12,'stone',
 [['wall',0,0,15,2,'鲸肋腔'],['crate',8,3,5,3,'裹布的投书筒'],['water',0,9,6,3,'细针渗水']],
 [['lamp',7,6,1,1,'风眼里的磷光'],['rope',3,7,8,1,'信车线']],
 [fixture('returned-letters','搁在空孔下的退件',8,6,[s('米拉','是我寄出的那封。送信的人先拿它垫冻裂的舟底；回得来的一行字是“我没见过北岸”。'),s('玛拉','这句肯定比画满海岸更要紧。'),s('米拉','我把这行留在北图的边上，签自己的名。')],'honest-margin'),
 object('strap-marks','图筒上的量程皮带',10,7,[s('米拉','松开这枚铜扣，墨线能再长两掌；留给摇晃时够不到瞄具的人。')],{requires:['honest-margin'],action:{type:'item',id:'sighting-bracer',value:1}})],
 [exit(2,6,'deep-sluice',[10,13],'合上退信筒回深槽')]);