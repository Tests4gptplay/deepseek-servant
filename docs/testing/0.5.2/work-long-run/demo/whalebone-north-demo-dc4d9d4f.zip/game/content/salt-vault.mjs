import {say as s,person,object,flag,exit} from './parts.mjs';
import {district} from './district.mjs';
export const vault=district('seal-vault','盐市 · 干尺仓与潮脚',3,24,17,'stone',
 [['wall',0,0,14,2,'旧晒盐墙'],['crate',3,3,6,3,'前三仓格'],['crate',12,4,5,4,'后十二格'],['water',18,12,6,5,'石脚水门']],
 [['path',1,8,21,3,'滚筐坡'],['lamp',17,3,1,1,'潮印石']],
 [object('bin-wheels','仓地留下的轮印',11,9,[s('玛拉','灯从低处照过去：前十二格有重筐压出的双轮印，末三格是空白。'),s('仓守','末三号票跟首三号的麻结完全相同；换过日期，没换过筐。'),s('玛拉','有十二袋到仓，不是十五袋。湿袋重也不能在石面压出第二条轮印。')],{action:flag('bins-seen')}),
 object('blue-seal','原蜡还软的过仓章',17,7,[s('戚先生','公账既已挂牌，仓守可以当众比这两个印。筝没有来，我留空她名字那栏。'),s('仓守','两个印是同一处崩口。我签自己，别替她签。')],{requires:['ledger-first','bins-seen'],action:flag('testimony-lodged'),after:[s('仓守','原蜡拓本已经归档，签的是我。')] }),
 person('warehouse-keeper','管湿秤的仓守',6,8,[s('仓守','我守货不守印。先护人我也能理解，可让蜡再冒一回热气，昨天的纹路就只剩在人嘴里。'),{who:'仓守',if:'witness-first',text:'原章重新盖过。我只能承认没在末三格看到货，不能替谁认领那枚章。'}])],
 [exit(1,8,'brine-weigh',[13,12],'回公秤坡'),exit(16,2,'salt-lane',[22,14],'退潮跨石脚回市',['tide:low']),exit(21,9,'petition-hall',[16,9],'循已公开的账牌入厅',['ledger-first'])]);
export const loft=district('witness-loft','盐市 · 错层药铺',3,16,14,'wood',
 [['building',1,0,5,4,'煎药小间'],['crate',9,1,4,3,'药枕柜'],['crate',10,10,5,4,'间壁储水桶']],
 [['lamp',6,6,1,1,'浅铜药灯'],['rope',10,6,3,1,'晒根架']],
 [person('pledge-mistress','药铺主人·温涟',6,8,[s('温涟','押家里的供粮牌，病床我能空一张。明早若没续上，是你家的米先停，不是筝被我退回街上。'),s('瑟琳','我认这一天。我会去量北边的水，让他们以后有别的船靠。'),s('筝','第七潮卸，第八潮补票。我把两天都写上，名字写我的。')],{requires:['witness-first'],action:flag('testimony-lodged'),after:[s('筝','我保留署名。旧票给我留一角，之后还要靠它认我的工钱。')]}),
 object('herb-cup','挂在门内的盐橘药剂',9,8,[s('温涟','带一瓶。不是还你供粮牌；你们路上会有人眩潮。')],{requires:['testimony-lodged'],action:{type:'item',id:'tonic',value:1}})],
 [exit(2,7,'salt-dorm',[21,8],'回寄宿院')]);
