import {say as s,person,exit} from '../parts.mjs';
import {witness,spoken} from '../voyage-parts.mjs';
import {room,station} from './the-bench-above-the-boat.mjs';
export function theSaltRoom(world){
 const maps={...world.maps};
 if(maps[room.id])throw Error(room.id);maps[room.id]=room;
 function add(id,entities,exits=[]){
  const m=maps[id];maps[id]={...m,entities:[...m.entities,...entities],exits:[...m.exits,...exits]};
 }
 add('salt-dorm',[
  witness('salt-song-benchmaker','鞋尖扎着绿线的凳匠巧棠',17,10,[s('巧棠','你坐吧，坐下才听得出来。这是一条搁了浅的听凳船，船肚里住过一家子说书人。只剩凳会响，谁都说是我脚重。'),s('伊沃','你方才少踏了一脚。'),s('巧棠','是留给歌里那头鲸的。我离开这条街十二年，回来听见人人拿我的小曲催纤工。小曲还认不认我，得请当年唱词的孩子说。她已经比我高了。'),s('巧棠','先在这张凳上摸脚音，再到摸筹窗找吹簧的方莳。阿梢在船屋里等。')],'salt-song-open'),
  station('salt-song-heel-board','把手搭在旧凳沿，分出三个脚音',16,9,'heel',['salt-song-open'])],
  [exit(20,10,room.id,[3,9],'踏上借着干舷呼吸的听凳船',['salt-song-open'])]);
 add('blind-window',[station('salt-song-reed-board','把耳或手贴在木窗，分出簧片换气',7,8,'reed',['salt-song-open']),
  person('salt-song-reed-player','用两根鱼骨撑簧的方莳',10,10,[s('方莳','我不是在教人听。你听见的和我摸见的，到桌上都得给对方留点地方。两根簧片一齐抬的时候，窗棂抖得最清楚。'),spoken('方莳','我把簧带去了。那个小井口还在吗？不准把结尾写成救鲸，鲸自己会拐弯。','salt-song-reed')])],
  [exit(6,10,room.id,[25,9],'顺盐窗外的窄舷到回音阁',['salt-song-heel'])]);
 add('loft-laundry',[station('salt-song-hem','依晒阁的八枚旧布扣，给唱完的人留一小节',16,13,'hem',['salt-song-played']),
  person('salt-song-dyer','缝绯色包脚布的全娘',8,11,[s('全娘','每件衣裳都在晒，还没有风来抢我们的水。你若听见楼板响三下又歇，别跑去喊人，帮我把两脚之间那口气留着。'),spoken('全娘','听凳船那支歌唱完了？布扣底下排着五个小音，你接四个。我来收最后一截晒索。','salt-song-played')])]);
 add('tilting-inn',[station('salt-song-inn','循着熟悉的末拍走到客栈歪门边',18,10,'return',['salt-song-played','winter-proof'])]);
 const q=(id,name,kind,stages)=>({id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)});
 const tune=q('whose-song-stays-in-the-salt-room','鲸在井边等一张帆','side',['salt-song-open','salt-song-heel','salt-song-reed','salt-song-word','salt-song-played']);
 const extra=q('four-notes-still-on-the-clothesline','晒衣阁的散场小节','hidden',['salt-song-hem-heard','salt-song-wrote']);
 return {...world,maps,quests:{...world.quests,[tune.id]:tune,[extra.id]:extra}};
}
