import {die,shed} from './salt-recheck.mjs';
import {steps,windowHall} from './ration-stair.mjs';
import {ring,inner,outer,eddy} from './pilot-ring.mjs';
import {guild,inlet,fans} from './tidal-exchange.mjs';
import {saltScenes} from './salt-scenes.mjs';
import {northScenes} from './north-scenes.mjs';
import {pages} from './registry-parts.mjs';
import {fixture} from './voyage-parts.mjs';
import {exit,say as s} from './parts.mjs';
import {saltFamily,saltLanding,saltWinter,chartBoat,chartGrave} from './salt-north-returns.mjs';

export const ledgerMaps=[die,shed,steps,windowHall,ring,inner,outer,eddy,guild,inlet];
export const ledgerGear={'mat-guard':{name:'三向席纹覆肩',slot:'armor',defense:5}};
export const ledgerFoes={[fans.id]:fans};
const arcs=[
 ['proof-by-shifts','同一枚铜码过两班','main',['dry-standard','duplicate-proved','kettle-count','ration-resolved','shortfall-proved']],
 ['a-hand-can-read','等你走了仍能自己读','side',['ticket-mother-heard','board-offer','board-proved','family-choice','board-consented','board-at-sea','board-winter']],
 ['relay-in-a-changing-sea','能从另一岸还原的测线','main',['near-shallow','pilot-brief','relay-fix','relay-certified','north-chart']],
 ['two-correcting-edges','原图离岸以后','side',['chart-claim','custody-debate','lost-mat','chart-separated','custody-chosen','shore-received','boat-received','chart-returned']],
 ['sail-with-the-spawn','留出产卵石缝','side',['shoal-clear','fan-gift']]
];
export const ledgerQuests=Object.fromEntries(arcs.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
const flights={
 'salt-lane':[exit(19,11,'ticket-works',[3,8],'循回纹铜招牌入盐票作坊')],
 'brine-weigh':[exit(10,9,'transit-shed',[12,12],'循公秤车轨进临时仓棚')],
 'seal-vault':[exit(8,10,'transit-shed',[26,9],'开边门去当班临仓看斜光板')],
 'salt-dorm':[exit(5,10,'ration-stair',[3,8],'去有家属等候的两道粥阶')],
 'petition-hall':[exit(13,10,'ration-stair',[24,8],'下粮阶补办亲自领饭的班次')],
 'deep-sluice':[exit(7,11,'pilot-ring',[3,8],'试空舟，亲自核验标出航深的潮窗',['near-shallow','hard-eight'])],
 'red-beacon':[exit(11,12,'tidal-exchange',[3,8],'越过两座标门，到葵湾交割所')]
};
const people={'seal-vault':[fixture('vault-lining','从仓守锁匣取仍能核验的原票背页',7,9,[s('仓守','公账先开的那一回，原章没有重热。我在副页边缘封着压花，不必再开整本。')],'backing-known',['ledger-first','testimony-lodged'])],'deep-sluice':[fixture('agreed-chart','重读米拉已经签过的原图边',16,11,[s('米拉','你来以前签过的深槽还在。新试船能增补另一条安全回缆，不会抹去旧图的折角。')],'chart-revisited',['north-chart'])],'petition-hall':[fixture('agreed-account','领副本重读已经盖印的听证结论',12,9,[s('理算员','三枚缺货印还在。公秤现在多了一道验法，但上一次真正领办的工钱和船班都没有退单。')],'account-revisited',['shortfall-proved'])],'salt-dorm':saltFamily,'north-pier':saltLanding,'winter-court':saltWinter,'red-beacon':chartBoat,'burial-cape':chartGrave};
const scenes={...saltScenes,...northScenes};
const barriers={
 'petition-counter':{flags:['duplicate-proved','ration-resolved'],tip:'先比十二袋干湿、两班日期与仓轮印。去临仓翻同一铜码或在票作取冷样，到粥阶落实缺粮或替班，再回此处核三十干衡。'},
 'ink-oath':{flags:['relay-certified'],tip:'硬底和浅泥都要留下。沿双影深槽的下台去试船圈，从另一端回望原刻并亲验内桩或外井，米拉才肯落墨。'}
};
export function withLedger(map){
 const entities=map.entities.map(original=>{
  let e=original;if(e.id==='blue-seal')e={...e,action:{...e.action,set:'backing-known'}};
  const gate=barriers[e.id],groups=scenes[e.id];
  if(gate)e={...e,requires:[...(e.requires||[]),...gate.flags],lockedText:gate.tip};
  if(groups){
   const add=pages(groups);
   if(e.after?.length)e={...e,dialogue:[...e.dialogue,...pages(groups.filter(([when])=>!when))],after:[...e.after,...pages(groups.filter(([when])=>when))]};
   else e={...e,dialogue:[...e.dialogue,...add]};
  }
  return e;
 });
 return {...map,exits:[...map.exits,...(flights[map.id]||[])],entities:[...entities,...(people[map.id]||[])]};
}
