import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,object,person,exit} from './parts.mjs';
export const shifts=region('shift-square','白崖 · 三班交接场',1,'harbor',34,23,'stone',
 [['building',1,1,6,6,'蓝门临工房'],['building',10,1,7,5,'轮饭公所'],['building',23,1,8,6,'称砣库'],['building',2,15,7,7,'租舟人祠屋'],['building',14,15,5,5,'老换鞋房'],['crate',25,14,8,6,'临运架货场']],
 [['path',0,9,34,3,'穿城抬棺路'],['rope',9,7,12,1,'把三班隔开的结绳'],['lamp',21,10,1,1,'日班点记灯']],
 [object('shift-caller','邝二与三班点筹桌',10,9,[s('邝二','头钟点人，第二钟点还能不能转开肩，第三钟才点货。昨夜送棺，今日换工，鲸还没进外门，别数着灯当日子。'),s('玛拉','我们得把压舱表带过湿街。你要我签临工，还是让我出份力？'),s('邝二','都行。东院调配重，回仓顶层过；西院修雨棚，循窗沿送。能送到我手里就行，不收人两次工钱。')],{requires:['vigil-finished'],action:{type:'flag',id:'shift-called'},after:[spoken('临工簿','二班已接手。桌上的小碗倒扣，邝二去了过秤台。','shift-handed'),spoken('邝二','东院先借叉，西院先问棚主。交到二班桌再给我一声。','!shift-handed')]}),
 person('white-rush','在鞋底刻临工号的崔莲',13,12,[s('崔莲','船上叫我一声二十六，我就回一声。有两年还把它当自家名字，直到我娘在岸上喊我。'),spoken('崔莲','顶库让人挑担过，右脚踏久的地方起毛。我让鞋匠给她们多钉一层。','port-counter-way'),spoken('崔莲','檐路只容一个人。先过身子紧的，再运篷布，不拿小工试软木。','port-roof-way')]),
 person('paid-mourner','给送客队看衣裳的砚叔',6,11,[s('砚叔','别人家的白麻湿了我还能认。我弟那件，洗脚边蹭过的烟渍到现在也没好意思洗。'),s('玛拉','你不用现在告诉我是谁的。若想处置它，我把布柜的钥匙给你留在水盆边。')],{action:{type:'flag',id:'cloth-offered'}})],
 [exit(1,10,'wake-court',[22,11],'回摆灯院'),exit(8,7,'haul-office',[2,7],'进蓝门认临工',['shift-called']),exit(31,10,'weight-well',[2,8],'东院去秤砣井',['shift-called']),exit(10,17,'wet-arcade',[3,8],'西院进雨棚行',['shift-called']),exit(20,15,'mourning-wash',[3,7],'从换鞋房去洗麻屋'),exit(28,12,'meal-barge',[3,8],'下石级访问寄租船家')]);
export const office=region('haul-office','白崖 · 蓝门临工房',1,'harbor-interior',22,15,'wood',
 [['building',1,1,5,4,'短工上铺'],['crate',10,1,7,4,'不能挪的秤砣篮'],['building',15,10,7,5,'结账夹室']],
 [['path',2,6,17,2,'招工长凳'],['rope',8,9,5,1,'存押工扣'],['lamp',8,5,1,1,'白日签灯']],
 [witness('rotation-list','只写半天的范师',9,7,[s('范师','这些人只签过半天，夜里有孩子独自在家。我把他们的另一半木签留空；换班谁上都先问人，不替他落名。'),s('伊沃','另一半没人接，正好说明差个肩。往年我看见空格就把上一行照抄。')],'half-day'),
 fixture('counter-tag','借空砣库的刻口叉',13,7,[s('范师','配重井分两端，拨外轮先上夹层，拨内轮能回低槽。叉不能用完扔掉，它是换班人的手。')],'counter-tag',['half-day']),
 person('runner-kai','临工家属·凯芽',6,8,[s('凯芽','我能来取钱，不能替我娘再签夜班。她回家前想亲自看看自己搬过的船开没开。'),spoken('凯芽','她的欠工钱挂在外窗。我去把收据取下，留空格给下一个人。','clothes-public')])],
 [exit(1,7,'shift-square',[8,8],'出蓝门'),exit(20,7,'weight-well',[4,10],'沿称具廊到配重井'),exit(12,12,'mourning-loft',[3,8],'去欠工登记夹层',['cloth-account'])]);
export function switchWeight(id,name,x,y,open,closed,line){
 return object(id,name,x,y,[s('伊沃',line)],{action:{type:'flag',id:'wheel-touched',set:{[open]:true,[closed]:false}}});
}
export const well=region('weight-well','白崖 · 两仓配重井',1,'harbor',26,19,'wood',
 [['water',7,3,7,7,'持平水井'],['building',1,1,4,4,'临秤棚'],['crate',18,2,6,7,'铁砣靠架'],['water',17,14,9,5,'压舱水'],['crate',1,14,5,4,'量木箱']],
 [['pier',2,10,21,2,'两砣十字梁'],['rope',14,5,1,10,'看得到高低两层的绳尺'],['lamp',16,9,1,1,'平衡白刻']],
 [switchWeight('outer-pan','将空砣篮扣在外轮',6,8,'outer-bank','inner-bank','外边落，夹层桥升；我守着回轮。现在若想回头，把另一只篮扣回内轮。'),
 switchWeight('inner-pan','把配重移回内轮',15,9,'inner-bank','outer-bank','内篮一落，顶桥离开墙，低处平板贴住货架。先松回绳再动手，下次照样能升。'),
 person('counter-forewoman','怕高的砣工·盖遥',9,12,[s('盖遥','我的活在井底，手够不到外轮。装完空篮，麻烦去高层帮我挑一下红卡舌。别把整座井修成只顾上面的人。')])],
 [exit(1,8,'shift-square',[30,10],'返三班场'),exit(3,10,'haul-office',[19,7],'回领工处'),exit(22,10,'counter-gantry',[3,7],'外篮放下时踏上高架',['outer-bank','counter-tag']),exit(15,15,'pallet-drain',[3,7],'内篮放下时走井底平板',['inner-bank'])]);