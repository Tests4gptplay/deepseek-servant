import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit,flag} from './parts.mjs';
import {mechanism} from './district.mjs';

export const share=region('dry-share','冬岸 · 夜渡下层转仓屋',5,'winter-village',34,22,'wood',
 [['building',1,1,6,7,'家船上岸后的米仓'],['building',12,1,5,6,'由三家轮流持钥的病室'],['boat',23,3,10,5,'麦袋垫底的浅桨驳'],['crate',3,16,6,5,'有人认领的干谷'],['water',22,15,12,7,'几时能接小艇的凹口']],
 [['path',2,9,28,3,'小车和担架在此交叉'],['lamp',13,8,1,1,'写有谁领夜贴的木牌'],['rope',9,13,14,1,'两种船身长度的记绳']],
 [witness('night-aunt','抱着家船航签的沙荷',9,9,[spoken('沙荷','你替我保下种子，今晚独粟真不能当两家的桨。他走，我的种得背着风睡一夜。','rye-seed-vote'),spoken('沙荷','半仓已经磨了，汀籽领的是明年干泊位。今晚连这条空槽再拿去，我就要当着她的面问。','rye-pot-vote'),s('沙荷','瑟琳，你小时候觉得当潮官能叫人省力。现在请你下来，我们家和对面转仓队只有一条能装那口水罐的小船。')],'night-family'),
  witness('night-loader','脚腕肿了还守秤的转仓头·燕西',16,10,[s('燕西','我不用牺牲换一道“辛苦”。我们夜里换仓有一笔贴补。家船肯把码头空出来，我就能带小船逐户摸门；你们先开家船，我只有上堤背水。'),spoken('燕西','逢珠第三夜的工钱你们真兑过。她教我把夜贴条和欠薪分开，不能拿她那栏替布兰省。','pay-restored'),s('瑟琳','病船叫豆岚，不要写六号人。你们两个都讲完，我才敢答。')],'night-loader'),
  person('night-berth-oath','瑟琳在沙荷船边自己报值班',13,11,[s('瑟琳','我能给家船划第一趟，把转仓驳的水从堤上背上来。也能请家船等，把第一趟小船和我量潮的这一班给燕西。两边的人今天都会过来，只是有人要少睡一班。',[
    {text:'家船先靠，亲自把转仓队的水背上堤',set:'night-kin-first'},
    {text:'先给转仓驳窄口，和母亲走人力坡',set:'night-cart-first'}]),s('沙荷','请把那一户送到睡处。亲戚的一句“都好了”不能算他们已经靠过。')],{requires:['night-family','night-loader','night-water'],action:flag('night-promised'),after:[s('燕西','重罐去下层石沟。干门上面是家船的等候房，夜泊报钟在最外边。')]}),
  fixture('night-pay-stub','请逢珠用第三晚原工单为新一班担保',21,11,[s('逢珠','我拿第三晚拿回来的旧票，证明这张是上工收据。我护的是燕西新领的夜贴，不从自己以前的欠工费里倒扣一枚。'),s('燕西','有现成担保，不用再走风堤找两个见证。第一趟可以交给真正划桨的人。')],'night-subsidy',['night-promised','pay-restored']),
  fixture('night-return-slip','把画着冬口白缝的退件交给米拉核出处',19,8,[s('米拉','当初这张纸救过一条裂底船。我在空白边画了退绳孔，不是划完就有资格写这船安全。让过门的人签在另一边。')],'night-paper',['night-promised','honest-margin']),
  person('rice-sweep','把三种空米袋改牛衣的流砂',10,12,[s('流砂','谁先睡？我先把三只空袋从窗台撤下来。一阵风吹得像有人在咳，猜错了好几回。'),spoken('流砂','今晚换客人担水，我就把潮脚踮高，给挑担的鞋让个不用脱的地方。','night-kin-first'),spoken('流砂','家船让过一潮。别把米袋改成军旗，她们没让渡明年的口粮。','night-cart-first')])],
 [exit(2,9,'split-cistern',[24,10],'顺空水桶回双井'),exit(24,10,'raised-crib',[3,10],'上坡去试担架和回转',['night-promised']),exit(29,12,'weighted-slip',[4,10],'下转仓坡把一船人和水送到夜渡',['night-promised'])]);

export const crib=region('raised-crib','冬岸 · 转不过双关节的上铺屋',5,'winter-interior',28,19,'wood',
 [['wall',0,0,28,3,'老鲸背床梁'],['building',3,3,6,4,'家属自行升降的短铺'],['wall',14,2,3,6,'门里供人扶的石柱'],['crate',20,13,8,6,'挪出来的两个空柜']],
 [['path',2,9,22,2,'紧贴一侧的担架进门弯'],['rope',9,12,12,1,'劳工床脚与靠门低手环']],
 [witness('crib-daughter','自己坐在栏边数转角的豆岚',8,9,[s('豆岚','我可以直走，拐的时候右脚没有力。你们试一条空架，别让我当砝码。昨晚我爸试了门宽，他把躺着的人忘了。')],'crib-asked'),
  fixture('crib-inner','把两根长篙作空架推到门后',13,9,[s('玛拉','门够宽，尾篙会扫到井绳柱。转身之前先把鼻端送进浅窗窝，两个人就不用抬过头。')],'crib-corner',['crib-asked']),
  mechanism('crib-dry-run','在带回响的空铺过一次转角',18,10,[s('豆岚','你教的次序，我坐着喊给我爸。推不动就退，别叫一个人松手接住我。')],['crib-corner'],'crib-turned','门宽两篙，纵深少半臂。哪一步能保留两人肩下的支撑？',['抬高尾篙抢过井绳柱','拆去栏杆，把人暂放在地上','前端先进浅窗窝，后端再沿矮钩横移'],2,'窗窝的塌痕在门里，不在门外。前端先取得半臂才能平转。',[s('豆岚','现在我从头到尾都够得着扶环。你们走，我自己说什么时候停。')]),
  fixture('crib-kin-duty','陪豆岚母亲把家船那头的重罐背到屋',12,12,[s('沙荷','轮到我自己家的货走坡，我也会摔碗。燕西先送人，上面给我留一截干门和一碗冷粥就好。'),s('瑟琳','你要的是晚船的正单。我写，不拿给你粮的那条签抵消。')],'crib-family-duty',['night-cart-first','crib-turned'],{action:{type:'flag',id:'crib-family-duty',set:'night-load-ready'}}),
  witness('crib-witness','请门里和门外的两个领班各点一次水',22,11,[s('豆岚','两个人都见了我坐稳。要是没逢珠的旧担保，就靠我们两个人走回去作新保。'),s('燕西','我把这一趟背水另算，不从病船的候潮份上扣。')],'night-manual-pay',['night-promised','crib-turned'],{action:{type:'flag',id:'night-manual-pay',set:'night-subsidy'}})],
 [exit(2,10,'dry-share',[23,10],'回家船和转仓屋'),exit(24,10,'weighted-slip',[22,10],'把空架推到夜渡水线',['crib-turned'])]);

export const slip=region('weighted-slip','冬岸 · 听得见铁环假响的夜渡',5,'winter-coast',32,21,'wood',
 [['water',0,0,32,5,'黑水里的小驳'],['boat',5,4,6,4,'冰一碰铁环便会响的空船'],['building',15,2,7,5,'一盏不转的饮水窗'],['water',22,14,10,7,'真桨贴门入坞的凹口']],
 [['pier',2,9,27,3,'两个高度不同的接驳台'],['rope',9,13,13,1,'让手背发麻的岸环'],['lamp',24,8,1,1,'低到艇里能够回答的透孔灯']],
 [fixture('slip-haul','把转仓队那罐水沿沟一肩一肩传来',10,9,[s('燕西','第一艘轮给沙荷。我们爬堤传水，没来得及给孩子烧第二次热茶。你记这个，我就肯来下一班。'),s('瑟琳','我在最后一个肩位。到门口再喊已到。')],'slip-cart-duty',['night-kin-first','night-subsidy','crib-turned'],{action:{type:'flag',id:'slip-cart-duty',set:'night-load-ready'}}),
  fixture('slip-shadow','在候船侧贴腕分出活动铁环三响',14,11,[s('斑栎','冰推一下，环会响三下，水上没有第二支桨。夜里单听铁就会叫错。')],'night-false-ring',['night-load-ready']),
  witness('slip-stroke','俯身看豆岚从艇上自己答低灯',21,10,[s('豆岚','我把灯压低给你看：长亮、灭、短亮。我爸同时停第二支桨；我不用爬起来证明我在这条艇上。')],'night-true-stroke',['crib-turned','night-load-ready']),
  mechanism('slip-final','岸上把最后一道夜闩交给哪一种信号',25,11,[s('伊沃','以前我以为海上没人，是因为我只听见自己的钟。豆岚说她会自己答我。')],['night-true-stroke','night-false-ring','night-chart','night-water'],'night-landed','冰先撞响空驳，什么才表示载人的船已齐低口？',['铁声连三、岸上拉高灯','低灯一长一短、第二支桨先停','只等米仓的家船旗到齐'],1,'环会自己响，桨和低灯是两个活人各自发出的信号。答不上可重新下去辨。',[s('豆岚','我在门里了。把“到账”留给米，把“人到”写在那盏灯旁。')]),
  person('slip-deck-boy','等刮下薄冰再开炉的岛枳',17,12,[s('岛枳','空艇说得比人船还响。等完这一潮我去把铁圈绑块布，明天也不必让人猜。'),spoken('岛枳','豆岚已经接住窗下的小杯，我们家的炉可以关半扇门。','night-landed')])],
 [exit(3,10,'dry-share',[28,12],'循卸货弧回下仓'),exit(23,10,'raised-crib',[23,10],'回担架转角'),exit(27,12,'moor-pocket',[12,12],'沿夜渡的真靠岸线返回泊桩',['night-landed'])]);
