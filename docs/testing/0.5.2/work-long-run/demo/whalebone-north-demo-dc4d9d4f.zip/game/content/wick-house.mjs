import {say as s,feature as f,exit,person,object,flag} from './parts.mjs';
export const wickHouse={
 id:'wick-house',name:'白崖港 · 灯芯房',act:1,width:16,height:14,ground:'wood',biome:'interior',
 solids:[[0,0,16,2],[2,3,3,2],[11,3,4,4],[1,9,3,3],[11,11,4,2]],
 features:[f('wall',0,0,16,2,'灰砖挡潮墙'),f('crate',2,3,3,2,'铺布长桌'),f('hearth',11,3,4,4,'暖灶'),f('lamp',8,5,1,1,'同心灯盏'),f('rope',1,9,3,1,'绕芯架')],
 entities:[
  object('vigil-bowl','停棺前的浅碗',7,6,[s('玛拉','他教我给别人梳头要从发尾梳起。我给他梳，却从头顶揪下一小撮。'),s('柏姐','那就留着。人的错处，也能做灯芯。'),s('玛拉','我给他的东西，得是我亲手留下的。',[{text:'把白碗朝海，摆一撮盐',set:'vigil-salt'},{text:'把白碗朝门，搭一绺蓝线',set:'vigil-thread'}]),{who:'玛拉',if:'keel-name',text:'船底的蓝线也是这种纱。能补一条袖口，也能记住一条船。'},s('柏姐','天亮了。棺先退在高台，守棺的人也该下楼吃饭。')],{requires:['coffin-aboard'],action:flag('vigil-finished'),after:[s('柏姐','头一夜过去，灯芯要翻个面，留给后面的人。')]}),
  object('paper-boat','灶旁的折纸小艇',10,8,[s('灯户的女儿','会算潮钟的人用粉笔。我听不见钟声，就把两头都蘸过墨的纸艇放进水沟，看它先碰哪堵墙。'),s('玛拉','你教我折。我替你写上名字。'),s('灯户的女儿','写吉。一个字，别折得正好看不见。')],{action:flag('pilot-ink')})
 ],exits:[exit(7,12,'wake-court',[11,7],'回晾绳院')]
};