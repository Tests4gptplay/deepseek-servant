import {say as s,person} from './parts.mjs';
import {witness,fixture,spoken} from './voyage-parts.mjs';
import {mechanism} from './district.mjs';

export const coatFirst={
 'wharf-scale':[
  witness('saltcoat-notice','站到养父棺车背风面，低头看自己封好的棺旁越过封线的一点白花',7,7,[s('玛拉','我封盖前替他把旧外衣的领子翻过来。右边翻了一辈子，软得会自己倒下去。他早先教我：手可以离开盖子，照看人的活还没完。'),s('封车的塔婶','别开盖。你用来护住外棺的青披，白花从哪边来的？若是外头下雨，外面先湿；要是车板返潮，下面这折先发沉。'),s('卖油果子的芹绶','开市筐都从这儿过，你可以进索市借我的空架试。你若想守着他走，我替你把公用干披挂到车外。他一样能干干净净过桥。')],'saltcoat-noticed',['procession','!coffin-aboard']),
  fixture('saltcoat-high-edge','从高的一侧用空白绒面轻碰外披最先迎雨的棺肩',14,7,[s('棺肩','朝上的细绒分毫没有变深。手背旧擦痕透过布，像他冬天给孩子留窗的那一小块白光。'),s('玛拉','不该把没湿的这面烘硬。他活着时总把好东西留到穿破，再来缝给我。')],'saltcoat-top-dry',['saltcoat-noticed','!coffin-aboard']),
  fixture('saltcoat-low-edge','从车底回折的阴面托起外披，不触封线，看看布上有没有同样的白花',20,11,[s('棺边','外披朝车板的折口发凉，浅灰变深，一点一滴向上洇。封盖的线还是旧颜色。'),s('玛拉','我能判断外披和车板。我看不见里边，就不替里边说一切都好。塔婶，盖别动，请你帮我把车停到干沿。')],'saltcoat-wick-seen',['saltcoat-top-dry','!coffin-aboard']),
  person('saltcoat-cart-helper','把树脂藏在干袖口里的学徒阿汲',10,9,[s('阿汲','第一天开市先走秤桥，棺头朝岸。要赶吊台，去修索市顺着吊篮影往里走。想学看潮布，就从棺肩走到车底，再去索市空架。'),spoken('阿汲','只验车外，我问过才跟。她不给看的我不上手。','saltcoat-noticed'),spoken('阿汲','公用干披也替人挡雨。你先上船时，我会跟塔婶把它拾好。',['coffin-aboard','!saltcoat-finished'])])],
 'rope-market':[
  witness('saltcoat-lease','请果摊主人亲自给出收市前那一段空架时间',12,8,[s('芹绶','你爹怕苦。来我这里拿果脯，每回说给小孩吃，兜里就只剩核了。'),s('玛拉','他说那是路上给报更人分的。'),s('芹绶','我是报更人亲妹，十七年还没见过他那半颗。空架给你一转。要把他留在帘内，我少晒一盘果；要外面示范，只动我的空架，不碰他那层私披。'),s('阿汲','我想学。她若合帘，我回去帮你切果，不探里面。')],'saltcoat-one-turn',['saltcoat-wick-seen','!coffin-aboard']),
  mechanism('saltcoat-turn-hem','在空木架上重放车边两折，找出一条不会把地上潮水引回棺肩的下沿',17,9,[s('芹绶','架上放的是我自己的干布。刚才在车边看到什么，就把那一面转给我看。')],['saltcoat-one-turn','!coffin-aboard'],'saltcoat-airgap','上肩干，贴板的回折先发暗。外披应该怎样放回去？',['把湿边整段塞进干的棺肩以免露出来','留外侧下缘悬开一掌，水往车外走，封线仍不动','把棺盖打开从里面查，顺便给旁人看看'],1,'记得白花出在折口的阴面。让湿边离开车板，给水留下出去的那一面；没有理由动封线。',[s('玛拉','那一滴自己下去了。爸，你教我看去处，没教我轮到你时手别抖。')]),
  witness('saltcoat-own-turn','收市前只余一转架，玛拉亲自择定私披如何回棺',22,10,[s('芹绶','再下一转架就得给果摊。你愿自己跟他单独把今天那层披放回去，还是愿在外面教阿汲用空架，给别的旅人也留一路？'),s('玛拉','他在里面，外人不必知道衣领上缝的字。',[{text:'借一转内帘，亲自把外披搭到养父车上；我补果摊这盘的钱',set:'saltcoat-private'},{text:'让阿汲在摊外用空架学折法；父亲仍用塔婶的公用干披',set:'saltcoat-public'}]),s('芹绶','你只能占这一转。别到最后让两边的钱都从我果篮里飞。')],'saltcoat-chosen',['saltcoat-airgap','!coffin-aboard'],{after:[s('芹绶','工和钱已经算在这一转。去吊台等车，别另许第二盘给我。')]}),
  fixture('saltcoat-private-fee','从自己护送旅费里付掉没能晒干的果盘，把内帘钩递回主人',15,10,[s('玛拉','少这一枚，我明早就不能买棺车头位的热水了。你给果摊，不用写在父亲名下。'),s('芹绶','钱我收。帘子我拉，到什么时候请我开是你的事。')],'saltcoat-fruit-paid',['saltcoat-private','!coffin-aboard']),
  witness('saltcoat-empty-frame','站到空架另一头松开自己的手，等阿汲实际让一滴水落到外侧',8,10,[s('阿汲','外头这块是我的。右肩干着，不用假装我摸过里面。水从我鞋头前面落下了。'),s('玛拉','下回你先问家属愿不愿意给你搭手。他们摇头，你还可以替人挪一块干地。'),s('芹绶','架借光了。今晚两个人有一盘软果，硬的就别问我要了。')],'saltcoat-learnt',['saltcoat-public','!coffin-aboard']),
  person('saltcoat-candle-seller','在果盘边掰半枚甜核的老更客',7,14,[s('老更客','阿芹说我牙不行，果脯只给我软的。我牙还在，只想吃软的还不行？'),spoken('老更客','她把有盐星的那面朝外，剩下一点折角留给自己。晏禾赶孩子吃早饭，老唱错最后那个“慢”字。','saltcoat-airgap')])],
 'coffin-hoist':[
  fixture('saltcoat-private-dress','在吊台的内帘后把自己的外披重新搭好，留一指能退水的短角',12,8,[s('玛拉','我先把带名字的缝留到里面，旁边人不用知道你叫我什么。现在折角空着，你不会再替我拿肩膀挡雨了。'),s('塔婶','帘我没掀。那只装热水的陶盏明早要用钱，你已经在早市给果摊付了。')],'saltcoat-dressed',['saltcoat-fruit-paid','!coffin-aboard'],{action:{type:'flag',id:'saltcoat-dressed',set:'saltcoat-finished'}}),
  witness('saltcoat-public-dress','守着封线请塔婶搭好公用干披，学徒只在空架上照应其他丧家',20,11,[s('阿汲','这一下是她教我的，可我没摸过她父亲的披。我今天能帮别人守干沿，不能跑遍港口说我替晏禾装过身。'),s('玛拉','把自己的湿披晾在一边。明天风起来，再取它回来。他身边用的是干的，那就够了。')],'saltcoat-taught',['saltcoat-learnt','!coffin-aboard'],{action:{type:'flag',id:'saltcoat-taught',set:'saltcoat-finished'}}),
  person('saltcoat-direct-porter','守台不催家人开盖的塔婶',18,12,[s('塔婶','货梯先看轨侧印，再转手柄。棺盖一直封着，想走便走。若你自己想留一折，早市架在修索街；我在这里等你。'),spoken('塔婶','我们给他用了公用干披上船。少的那天不补作一场别人没见过的礼。',['coffin-aboard','!saltcoat-finished'])])]
};
