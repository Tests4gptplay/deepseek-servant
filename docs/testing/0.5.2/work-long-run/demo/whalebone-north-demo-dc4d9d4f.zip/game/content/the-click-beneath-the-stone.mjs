import {flat,cargo,active} from './a-boat-with-two-ribs.mjs';
import {witness,fixture,spoken} from './voyage-parts.mjs';
import {person,object,exit,say as s} from './parts.mjs';
import {mechanism} from './district.mjs';

export const snapper={
 id:'keelpot-clapper',name:'托篓石下 · 守洞的错钳泥虾',enemy:'抱片错钳泥虾',level:6,hp:86,attack:8,
 objective:'赶开挤在担路上的成虾，护住石孔里的小虾。看钳背和水珠，别把重担砸进洞里。',
 reward:'禾盏从自己干活用的布囊里拿出一份盐膏。成虾退进旧孔，幼虾仍能换水。',
 phases:[
 {fromHp:86,tell:'近钳背上两枚浅斑一齐竖起，石孔前水面变平。',moves:[
 {name:'贴底的直捶',kind:'ram',power:1.75,counter:'guard',hint:'水不翻花时是贴底推力，把双脚抵上硬石再抬担。'},
 {name:'侧须扫过石背',kind:'rush',power:1.45,counter:'dodge',hint:'横须扫石背，担杆内侧空了，往湾里让半步。'}]},
 {fromHp:43,tell:'幼虾贴回石孔；成虾将一大一小的钳颠过来，一串泥泡逆流。',moves:[
 {name:'合钳抱口',kind:'shell',power:.9,counter:'skill',hint:'硬钳叠在一起，用同伴的回索或标线从缝后引走；砸壳费力。'},
 {name:'贴腹旋泥',kind:'whirl',power:1.55,counter:'dodge',hint:'泥在担脚周围合成一圈，全队向外弧侧移。'}]}],
 rewards:{xp:21,repeatXp:0,items:{'brine-dose':1}}
};
export const neck=flat('keelpot-neck','盐市滩脚 · 托篓石的两排错齿',34,20,'stone',
 [['water',0,0,13,6,'进水主汊'],['wall',16,0,4,6,'露背的藻骨'],['water',24,0,10,6,'细泡顺石退回侧沟'],['water',0,14,8,6,'仍淹着的卤潭'],['wall',12,14,4,6,'两齿岩台'],['water',23,15,11,5,'湿脚通的内沟']],
 [['path',1,8,30,2,'担杆只够一人转身的硬脊'],['kp-burrow',17,8,4,3,'错钳虾抱幼的七孔石'],['kp-ledge',23,11,5,2,'两肩先后转过的担石'],['kp-foam',8,5,4,2,'泡沫总在背流面重现']],
 [fixture('keelpot-holes','把担杆搁在高石上，听七个孔先后弹响',9,9,[
 s('伊沃','第一声在脚下，第二声却在水流上游。这不是两群虾。大的那只合钳敲石，要幼虾顺回水找洞。'),
 s('玛拉','带着东西怎么过？'),s('伊沃','泥泡横滚的时候不能再向前抵。若不想驱赶，沿白泡去找旁孔，开一条小虾肯去的水道。都得先把担子轻轻放稳。')],'keelpot-heard',active),
 object('keelpot-stand','在担石正面替后面的人挡开守洞成虾',17,10,[
 s('玛拉','我站石面上。不要踩有小泡的软泥。我们让开的是一条肩路，成虾退进老洞就收队。'),
 s('伊沃','近钳直起来护住脚，须扫过来让半步。它肯让，咱们也让。')],{
 requires:['keelpot-heard','!keelpot-cleared','tide:low',...active],action:{type:'battle',id:snapper.id,set:['keelpot-defended','keelpot-cleared']},
 after:[s('禾盏','石没往下沉，幼虾还冒泡。我把盐膏给在外侧顶担杆的人，回去抹肩。旧洞得留一圈空，明天肩路还得从外面绕。')]}),
 cargo('foot','近岸、远岸有缺口的两块担石',26,10,'cross',['keelpot-cleared','tide:low',...active],['keelpot-crossed']),
 person('keelpot-stick','给儿子量脚底宽的小贩经伯',5,11,[s('经伯','平石留给扛东西的脚，我儿子光脚喜欢踩凉泥。我插的不是界桩，是我答应他回来接他的地方。')])],
 [exit(2,9,'keelpot-yard',[15,14],'沿高脊回小斜埠'),exit(13,12,'keelpot-side',[3,8],'跟逆流的白泡转进背汊',['keelpot-heard']),exit(30,10,'keelpot-landing',[21,12],'经过托篓石去接货坡',['keelpot-cleared','tide:low'])]);
export const side=flat('keelpot-side','盐市回水 · 两条高低不同的背汊',24,17,'sand',
 [['water',0,0,8,5,'流急的上口'],['wall',10,0,5,5,'豁口隔水脊'],['water',17,0,7,6,'短须幼虾能到达的暗水'],['water',0,12,7,5,'空螺壳积下的斜坡'],['wall',16,12,8,5,'原地保留的小虾洞']],
 [['path',1,7,20,2,'水湾内沿'],['kp-foam',4,5,4,2,'观察草屑逆行的一小段'],['kp-sluice',14,6,4,2,'只宽一掌的旁通扇']],
 [fixture('keelpot-flake','放下一片空螺盖，看它在哪个口停',6,8,[s('玛拉','上口水声大，螺盖一下翻面。下口安静，壳却慢慢沿外圈回到草根。'),s('禾盏','幼虾贴岸游，急水会把肚上的丝冲断。找有回流却不会吸住它的那头。')],'keelpot-eddy',active),
 mechanism('keelpot-side-shutter','提半掌旁通扇，把小水道带回软泥',15,8,[s('瑟琳','上口、低唇和主闸都有把手。看你那片螺盖的外沿，再动。')],['keelpot-eddy','!keelpot-cleared','tide:low',...active],'keelpot-channel',
 '把哪一口调到够幼虾自行穿过？',['拉开迎水上口','只抬低唇一掌','把朝市口的主板整个放平'],1,'螺盖在上口被翻面；放下主板会抽干背汊。仍能落回原位，再看低唇。',[s('瑟琳','这股回水窄，只能容小东西。还得回七孔石看成虾有没有跟过去。')]),
 fixture('keelpot-shell-fence','在草根侧把三枚空壳盖拢回旧沟',19,10,[s('禾盏','看，虾须从旁孔转出来了。你把最靠担石的一枚空壳也转过去，最后一只才不会留在担脚。')],'keelpot-brood-moved',['keelpot-channel','!keelpot-cleared','tide:low',...active])],
 [exit(2,8,'keelpot-neck',[12,11],'沿草根回托篓石')]);
neck.entities.push(object('keelpot-listen-again','压住空担回听，等最后一孔安静',21,10,[
 s('伊沃','第七孔没有声了。我的手放开，轻轻走。'),s('禾盏','明春这边会再出一窝。替我把那只小药瓶收走吧，搬滑担时擦破手就用。')],{
 requires:['keelpot-brood-moved','!keelpot-cleared','tide:low',...active],action:{type:'item',id:'tonic',value:1,set:['keelpot-cleared','keelpot-sheltered']}}));
