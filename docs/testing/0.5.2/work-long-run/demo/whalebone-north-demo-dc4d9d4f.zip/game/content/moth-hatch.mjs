import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit,flag} from './parts.mjs';
import {setting} from './registry-parts.mjs';
import {tidePost} from './district.mjs';

export const millHint=witness('old-hull-taps','找老搓缆工模仿三声拉苗篮的节奏',10,11,[s('圭纤','两下挨着，一下隔半步。那是早年的窖里叫人收篮，不是请屋里的人打掌。有些石砌面动起来一丝声都没有。'),s('瑟琳','水低时看得见黑缝。要照这个间距去摸，不能拿钥匙往每一块砖里试。')],'rye-taps',['rye-oars-known']);
export const loft=region('moth-hatch','盐市深窖 · 被晾网藏住的换种舱',3,'salt-interior',27,18,'stone',
 [['wall',0,0,27,2,'暗砖后仍存一行种窝'],['water',1,2,5,5,'潮低才露出的双槛'],['crate',11,2,6,4,'细灰与空蛹遮住的护面箱'],['wall',21,12,6,6,'拉开后会把锅温抽走的老风道']],
 [['pier',3,8,19,2,'沿种槽从湿向干的低栈'],['rope',8,12,11,1,'晾旧网辨雾势的绳']],
 [witness('moth-steward','曾照顾旧种房的长罗',8,8,[s('长罗','旧仓的夜蛾抱着谷皮取盐，眼见白烟就往窗上扑。我们以前靠风道将它引到菌床。新砌的墙借了灶热，一开这个道就让今晚那炉药茶凉掉。亦可在潮雾里赶它迁开，只别去碰种袋。'),s('伊沃','有人肯为一壶重煮的茶等半夜，实打实要问过。')],'moth-open',['rye-drag','rye-taps']),
 person('moth-kit','向长罗借一套临时用具',15,8,[s('长罗','一套罩口滤盐风，另一套木板挂铜片散振，都是我自己配的。挑了要去外间领，别把纸条戴脸上。',[{text:'借老船工罩，隔开带盐的潮气',set:'moth-veil-chosen'},{text:'借散振铜木护板，护住握索的手',set:'moth-board-chosen'}])],{requires:['moth-open'],action:flag('moth-chosen'),after:[s('长罗','罩在青网，板在铜钉墙。要上身用，再去队伍里挂上。')]}),
 object('moth-veil','取下青网上的防潮蚕罩',11,10,[s('长罗','最细一层用旧船篷布，大处挡不住的湿风，小处挡得住。')],{requires:['moth-veil-chosen'],action:{type:'item',id:'moth-veil',value:1,set:'moth-ready'}}),
 object('moth-board','从铜钉墙抽出散振护板',18,10,[s('伊沃','铜片跑在木板槽里，冲过来的劲能顺槽歇掉一截。')],{requires:['moth-board-chosen'],action:{type:'item',id:'moth-board',value:1,set:'moth-ready'}}),
 witness('moth-cold-kettle','请煮药茶的壁兆亲自腾出今夜炉温',8,11,[s('壁兆','我能停炉。这锅原是给夜班的暖茶，要拆成两户各自煮。一个人得送空壶去，不能把开窗写成什么都没损失。')],'moth-heat-owed',['moth-ready','!moth-cleared'])],
 [exit(3,9,'germ-cellar',[11,12],'带空苗篮回芽窖'),exit(22,9,'husk-room',[3,9],'用借到的器具进海蛾壳间',['moth-ready'])]);

export const husk=region('husk-room','盐市深窖 · 盐蛾脱壳的旧暖墙',3,'salt-interior',26,18,'stone',
 [['wall',0,0,26,2,'湿盐沾在升气的筒口'],['water',2,3,5,4,'退潮后才出味的菌床'],['crate',13,2,6,4,'浮灰堆拱的皮壳'],['wall',18,13,8,5,'与病灶共热的玉砖']],
 [['path',3,9,20,2,'可以空手退回的壳间小路'],['rope',9,11,12,1,'独粟收风兜的长柄'],['lamp',19,8,1,1,'取热位置上的红油芯']],
 [tidePost('moth-tide',8,9),
 setting('moth-air-out','打开朝病灶的热风帘',13,9,[s('壁兆','听见另一头咕噜一停，就是灶口开始凉。等退潮，菌床会出味，走到外侧把空壶接住。')],['moth-heat-owed','!moth-cleared'],{'moth-flue':true}),
 fixture('moth-pass','等菌床露出，以低风送蛾离开种槽',18,10,[s('长罗','蛾向外翻，幼壳自己落下来了。那只空壶先别放下，壳间以外还有一个人等。')],'moth-bypass',['moth-flue','tide:low','!moth-cleared'],{action:{type:'flag',id:'moth-bypass',set:'moth-cleared'}}),
 object('moth-cloud','在带盐旋风里护住蜕壳的母蛾群',15,10,[s('长罗','见腹灰收成一圈，先让开边缘；鳞片平铺时才牵开旁边的旧网。')],{requires:['moth-ready','!moth-cleared','!moth-flue'],lockedText:'若已经答应送暖风，先随通风道完成或退回关帘，再能从这边试。',action:{type:'battle',id:'husk-moths',set:['moth-cleared','moth-guarded']}}),
 setting('moth-unwind','在蛾还没离窝前将暖帘放回',11,11,[s('壁兆','我的水又开了，你仍能重来。别让半开半关的两股风兜住幼壳。')],['moth-flue','!moth-cleared'],{'moth-flue':false}),
 fixture('grain-cradle','摸到生着真根的老种窝',20,11,[s('汀籽','软根从壳里长出来的地方有点痒。不是所有的老东西都该摆进祠。它想在土里过冬。')],'moth-root',['moth-cleared'])],
 [exit(3,10,'moth-hatch',[21,9],'退回换种舱')]);
export const mothFoe={id:'husk-moths',name:'卷住育种臂的盐蛾旋群',enemy:'盐衣灯蛾',level:4,hp:49,attack:4,resistances:{wind:1.3,light:1.16,iron:.86},
 phases:[{fromHp:49,tell:'内圈扬灰，先稳住涌进来的盐风。',moves:[{name:'灰鳞回卷',kind:'ram',element:'tide',counter:'guard',power:1.15},{name:'灯前薄旋',kind:'whirl',element:'wind',counter:'dodge',power:1.12}]},{fromHp:24,tell:'腹绒贴平，轻牵挂网可让出一线。',moves:[{name:'护壳成环',kind:'shell',element:'shock',counter:'skill',power:1.12},{name:'扑向空帘',kind:'rush',element:'wind',counter:'dodge',power:1.2}]}],
 rewards:{xp:12,label:'种袋留原处，盐蛾在暖墙另一面结新壳。'}};
export const gristGear={'moth-veil':{name:'长罗的防潮蚕罩',slot:'charm',resists:{tide:.27}},'moth-board':{name:'壳间铜木护板',slot:'armor',defense:3}};
