import {fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s} from './parts.mjs';
import {mechanism} from './district.mjs';

const offer=witness('bowl-quiet','从豆腐灶外侧给芽沏留一只干碗，听她说中午要做什么',13,13,[
 s('芽沏','我午时从这里换炉。送工饭的艇过去一趟，我得等下一圈。那个钟敲得天响，落进我耳里倒像一条睡鱼的肚皮。'),
 s('方雁','她会做出全岛第一锅不破皮的豆花。我每回喊她，手离开了勺底，豆浆就焦锅。'),
 s('芽沏','别替我喊。你去我做活的位置站站。一种从脚下能觉着，一种从锅沿抬眼就能看见。让我选谁去试。',[
  {text:'我陪你试船过石阶时脚底能摸到的回颤',set:'bowl-step-pick'},
  {text:'我到背亮处替你试影子，锅前不用回头',set:'bowl-shadow-pick'}])
 ],'bowl-heard',['chart-disputed'],{after:[spoken('芽沏','我鞋底很薄，不必把踏杠弄得像踩砧板。','bowl-step-pick'),spoken('芽沏','我灶后背光，你要先找亮边和暗沿都能留下的位置。','bowl-shadow-pick')]});
const tread=fixture('bowl-tread','落水后用自己的脚踩两块离岸不同远的旧阶',11,13,[
 s('芽沏','靠仓墙那块跟风帆一起颤。往外一步，船过才先轻后重两跳。别把油锅架在上边，用这块只托我的脚后跟。')
 ],'bowl-tread-tested',['bowl-step-pick','tide:low']);
const shade=fixture('bowl-shadow','涨水时把两块旧锅盖分别举进反光与女墙阴影',22,12,[
 s('乌桅','白光一直在。把有孔的盖拿到低一档，艇帆过的时候才在灰盖心里擦一块暗。饭灶靠北站，比海上的人低得多。')
 ],'bowl-shadow-tested',['bowl-shadow-pick','tide:high']);
const hinge=mechanism('bowl-tread-pin','在灶脚给芽沏合上能单独感觉到艇过的翘杠',19,14,[s('芽沏','锅上的沫可别跟它一起抖。我换个脚，还能觉出船走没走才算装好。')],['bowl-tread-tested'],'bowl-rig',
 '一次风吹和一次有船通过都试过。哪两样应当连在一起？',['把靠仓墙的板连到灶梁','让外阶的板只顶脚跟，灶脚另固定','把送饭铃绑到汤勺'],1,
 '船过才有先轻后重两跳。灶和脚要各有支点。',[s('芽沏','来了。两下，我先抹手，锅还稳。')]);
const hood=mechanism('bowl-shadow-pin','在锅沿后固定成套的眼孔、暗盖与小帘',21,14,[s('芽沏','亮斑一直在锅上闪，我看了倒头晕。我得看见东西经过，而不是等另一种鸟。')],['bowl-shadow-tested'],'bowl-rig',
 '芽沏站在灶前时，怎样让经过的艇显在同一处？',['把暗盖挂在无遮拦的亮面上','把两扇都盖死，隔住一切海光','留窄孔投在低处灰盖，遮去上头的风影'],2,
 '同一处常亮没有报时。固定低处的灰面，只让水线的船帆挡过窄孔。',[s('芽沏','嗯。锅心不晃了，暗痕像鱼尾，我记得。')]);
const lunch=witness('bowl-lunch','在原灶前等一班工船，同芽沏赶上自己想搭的午艇',26,13,[
 spoken('芽沏','脚跟先软后硬。我出锅了。方雁你先别开嘴，让我说到了。','bowl-step-pick'),
 spoken('芽沏','一尾灰线在盖心里游过去了。我出锅。今天这船是我自己看见的。','bowl-shadow-pick'),
 s('芽沏','你喜欢哪个边角？',[{text:'接一小碗最碎的豆脑，边走边吃',set:'bowl-soft'},{text:'分一块起脆皮的锅边给收桨的人',set:'bowl-crisp'}]),
 s('方雁','下次可得自带碗。今天是我那次喊晚了请的。')
 ],'bowl-served',['bowl-rig'],{after:[spoken('方雁','你爱那种碎豆脑，得比开船早半刻来。','bowl-soft'),spoken('方雁','收桨人吃完脆边，把我的破碗磕了个更齐的口。','bowl-crisp')]});
export const kitchenStops={'leeward-buttons':[offer,hinge,hood,lunch],'sock-stair':[tread],'egg-meridian':[shade]};
