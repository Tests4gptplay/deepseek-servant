import {region,fixture,witness,spoken} from '../voyage-parts.mjs';
import {person,object,exit,say as q} from '../parts.mjs';
const H='twohand-supper-house',R='twohand-puppet-loft',D='twohand-under-the-scrim';
const ordinary=(id,name,w,h,blocks,land,people,ways)=>region(id,'亮灯空城 · '+name,2,'whale-city',w,h,'wood',blocks,land,people,ways);
const station=(id,name,x,y,op)=>object('twohand-'+id,name,x,y,[],{requires:['twohand-invited'],action:{type:'twohand-stage',op}});
export const house=ordinary(H,'演完才能开锅的皮影饭铺',29,20,
 [['building',0,0,8,5,'楼上是后厨，楼下的票窗兼卖炖豆'],['wall',10,0,5,4,'白铁碗和手鼓各占一排'],['building',19,0,10,6,'借出半面墙而住进戏里的两家人'],['wall',0,15,11,5,'贴着往年戏票的风墙'],['building',21,16,8,4,'旧盐布染坊']],
 [['path',2,8,24,3,'洗过手才踏上去的宽过道'],['stage-cooker',5,6,5,2,'藏在戏台下面的一锅豆羹与一口姜水'],['stage-screen',15,4,6,3,'一面透得出鱼骨纹的旧盐布'],['stage-bench',17,13,7,1,'大人小孩自己选离灯的位置']],
 [witness('twohand-owner','在幕前拣掉豆壳的越涟',8,10,[
  q('越涟','有一晚外头喊退潮，戏里的泥鹤还在水中央。我忙着解绳，隔壁孩子穿过幕布，托它的脚送上岸。那晚没人看完原来的结尾。'),
  q('玛拉','你还愿意演那出吗？'),q('越涟','手指不肯抻直了，锅我一个人抬得动，鹤抬不起来。我愿意演新的。门后的吊板要两个人站，阿簇把最后一把绳藏起来，你们自己问他。'),
  q('伊沃','我站索这边。想叫我松手，给我个我能看见的动作。')],'twohand-invited',['ivo-line'],{after:[q('越涟','要换人，拉近手的蓝套。索上的人站稳，台下的人踩实，这是两双鞋。别把走过的那双也画在脚底下。')]}),
  person('twohand-apprentice','扯着一小截红绳头的阿簇',17,10,[q('阿簇','上回谁喊停，越师傅都要过一拍才放。那不是她不肯放，风一大就听不到。把套递给坐得最低的人，想看完就揣着，不想看就捏一下。'),spoken('阿簇','昨夜鹤脚从我头顶过去，我没拽套。旁边的大哥先捏了，他不是胆小，是要把轮椅推到另一边。','twohand-public-loop')]),
  person('twohand-broth','算的不是人头的掌汤人蒿其',23,12,[q('蒿其','报七口饭，我便把勺放下。新生那个其实还在吃母乳，演皮影的两个还没有座。你要说几人吃哪样，别用站着的人头点锅。')]),
  fixture('twohand-try-sheet','磨薄的幕布照得到手指的弯，却照不出脸',13,12,[q('玛拉','透过布我看得见她少一截的小指，脸却像一盏没有灯芯的灯。'),q('越涟','我练了四年才肯让它像个没脸的人。你别替它画眼睛。')],'twohand-finger-print',['twohand-invited'])],
 [exit(2,10,'dry-court',[12,8],'从豆香的过道回八户晒衣院'),exit(25,10,R,[3,10],'从换鞋棚走上水偶的双巷台',['twohand-invited']),exit(14,15,D,[3,8],'向幕布背光的一面钻进去',['twohand-any-rehearsal'])]);
export const loft=ordinary(R,'让台上和台下各占一双鞋的吊板',32,21,
 [['water',0,0,10,4,'偶脚落下去的回水'],['wall',13,0,6,4,'粗响的木管'],['building',23,0,9,5,'背风工作台'],['wall',6,9,18,2,'吊板中间的船肋，两端有走人的开口'],['water',0,17,12,4,'潮水顶得到的矮格'],['building',23,17,9,4,'经手布、麻与木腿的匠人架']],
 [['path',2,5,26,3,'北路是伊沃能伸手的上绳'],['path',3,12,26,3,'南路是玛拉能踩住的踏板'],['stage-rig',8,7,13,2,'木鹤、皮海豹、两根分开的头绳与背绳'],['stage-counter',12,13,6,2,'三段真能留住重量的踏木'],['stage-stop',25,9,3,3,'能把停拍传回对面的一只蓝套']],
 [station('blue-near','在近端蓝套交班，看另一双鞋仍留在原地',4,10,'switch'),station('blue-far','在后端蓝套交班',26,10,'switch'),
  station('high-line','只伸到上巷的长颈麻索：泥鹤要它',10,6,'heron-line'),station('low-line','带一颗裂铃的短背索：小海豹要它',21,6,'seal-line'),
  station('pins','台下三段不同臂长的短踏板',12,14,'weight'),station('foot','台下面向布偶放下自己的重心',19,14,'press'),
  station('design','把桌上的木鹤或皮海豹安进影匣',5,13,'pose'),
  person('twohand-stitcher','给布偶补藏膝的邻人曲度',27,13,[q('曲度','木鹤的颈子让人先看见，翅根吃两口重。皮海豹贴着水，拉它背上的短线，一口重够了。错了先抬脚，磨坏的是我的补布，不是你们的名声。')])],
 [exit(2,11,H,[24,10],'离台解压，各自从近端回来'),exit(28,11,D,[17,8],'从幕底看自己真的托过的轮廓',['twohand-any-rehearsal'])]);
