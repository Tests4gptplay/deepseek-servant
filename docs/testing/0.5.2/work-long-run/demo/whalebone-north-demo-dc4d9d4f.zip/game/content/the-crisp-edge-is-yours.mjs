import {lane,stove,portWay,roofWay,tell,speech} from './lullaby-lane.mjs';
import {arcade,stairs} from './lullaby-stair.mjs';
import {region} from './voyage-parts.mjs';
import {person,object,exit} from './parts.mjs';
const hob=region('lullaby-clay-hob','亮灯的空城 · 盘子只响一声的晒锅间',2,'winter-interior',25,17,'wood',
 [['building',1,1,6,4,'窗眼俯对原来的送客阶'],['building',13,1,9,5,'闭着一半的两间小家'],['crate',2,13,5,4,'暖馍柳框'],['crate',16,12,8,4,'给夜班留下的一角']],
 [['pier',2,8,20,3,'看得见两个来路的长木桌'],['lull-fryer',11,7,3,1,'只热一半的铁锅'],['lull-cloths',8,4,4,1,'船上最后一条遮光帘']],
 [person('lullaby-daughter','一只手掂着饼铛的栗芽',10,9,[
 speech('栗芽','玛拉，你会煎鱼吗？我不问他会不会了。','child-question','lullaby-accompany'),
 tell('玛拉','我会。他盐放得早，我喜欢外头脆。里头刚才剩的一块，谁愿意吃？','lullaby-accompany'),
 tell('伊沃','我守住了近柱。下班的两人还是在门口多等一轮，错过刚出锅的饭。我去给他们留住下一锅。','lullaby-accompany'),
 speech('栗芽','我把那只锅坐回灶上了。玛拉走过去时，没人拿我的脸当一段送葬礼。','child-apart','lullaby-apart'),
 tell('伊沃','远台那边的人只听到潮，没有听到你的话。饭趁热上了船。','lullaby-apart'),
 tell('玛拉','我失掉了能一起问的那刻。以后想问，我会来当面问，不找他替我答。','lullaby-apart'),
 tell('栗芽','去下舱吧。我留在灶门收盘。等你回白崖的时候，亲口告诉我娘，你喜欢吃哪一边。')],{action:{type:'flag',id:'lullaby-galley'}}),
 object('lullaby-black-edge','桌上留给错班人或送葬人的半张饼',17,10,[tell('晒盘人','这份要送近柱。有人替那孩子挡了两趟饭队，我把这一面煎得软些。','lullaby-accompany'),tell('晒盘人','热饭赶上了。这份边最脆，要给自己走过西窗、没有等人回答的那个姑娘。','lullaby-apart')])],
 [exit(2,9,'lullaby-double-stair',[27,8],'回双层灶梯的东窗'),exit(7,13,'lullaby-double-stair',[7,15],'回双层灶梯的低台'),exit(22,8,'counterlift',[5,10],'从公用锅架回到原反提梯井',['roof-shelter'])]);
const byCart=person('lullaby-carter','把最后一筐姜留给夜班的列因',7,11,[tell('列因','我从棺车边挪开这只轮子。今天要去西边澄一锅老油。你父亲在那儿欠我娘一句气话，你要跟我过来，塔婶守着他。'),speech('塔婶','我不去。我留着这一端，出声的时候，他身边得有一个人。','aunt-stays')],{requires:['procession','!coffin-aboard'],action:{type:'flag',id:'lullaby-invited'}});
const later=person('lullaby-old-stove-returns','从灶里躲过潮头的乔稔与列因',12,11,[
 speech('乔稔','你回来了，玛拉。这次叫准了。我在灶边练过。没拿他的名字来叫你。','mother-open','lullaby-accompany'),
 tell('列因','那天有人替妹妹挡在低廊。她连那句鱼是软是脆都记得。','lullaby-accompany'),
 speech('乔稔','你走过那一侧时没有替我喊。今天灶凉了，我自己出来叫你。玛拉。','mother-hush','lullaby-apart'),
 tell('列因','妹妹没跟着送棺，可夜班的人吃上了。她到今天还怕以后再没有机会问鱼怎么做。','lullaby-apart'),
 tell('玛拉','外边脆。我跟他有些地方很像。你叫得出我的名字，我就可以自己回答了。'),
 tell('乔稔','第一次你停过车。那张焦的后来我吃了，从来也没有给死人的道理。','lullaby-port-asked'),
 tell('乔稔','那一锅你替我留住了。下回我真想送谁，我会告诉你，不拿锅当挡脸的东西。','lullaby-port-quiet'),
 tell('乔稔','头一趟你们就已经上船了。我没在岸上同你说过话。这是第一次，趁水还热。','!lullaby-port-choice')],{requires:['clutch-still','lullaby-galley'],action:{type:'flag',id:'lullaby-home'}});
const auntAtHoist=person('lullaby-aunt-holds','一直守着葬车后端的塔婶',9,10,[tell('塔婶','他这边没空过。我把松的那一角盖好，连停下时也照样握着。','lullaby-port-asked'),tell('塔婶','这边屋里没听见车轮，我听见了。那一段我就挨着他走，没有替谁喊。','lullaby-port-quiet'),tell('玛拉','回来的这只手有油味。我来握，你把麻了的指头挨个松开。')],{requires:['lullaby-port-choice','!coffin-aboard']});
const lowNeighbor=person('lullaby-downstairs','原梯井边让人先动脚的拾灰人',8,8,[tell('拾灰人','听到名字了。近柱的两个人错饭，我在这儿给他们留一条下梯道。','lullaby-accompany'),tell('拾灰人','刚才来的那帮人都挤到远处看潮去了，我和这个热饭筐一同下来了。','lullaby-apart')],{requires:['lullaby-galley']});
const extras={'wharf-scale':{entities:[byCart,later],exits:[exit(5,10,'lullaby-pan-lane',[3,12],'跟着移开粮车的列因穿进煎鱼灶巷',['lullaby-invited','!coffin-aboard'])]},
 'coffin-hoist':{entities:[auntAtHoist],exits:[exit(11,10,'lullaby-last-stove',[22,10],'从葬车旁原路回最后一张灶门',['lullaby-met','!coffin-aboard'])]},
 'whale-roofs':{exits:[exit(13,9,'lullaby-roof-arcade',[3,10],'随探出半身带路的栗芽进屋檐灶街',['early-castoff'])]},
 'counterlift':{entities:[lowNeighbor],exits:[exit(7,11,'lullaby-clay-hob',[21,8],'沿原楼梯去看栗芽留下的最后一锅',['lullaby-galley'])]}};
export const lullabyMaps=[{...lane,lullabyGuide:{flag:'lullaby-port-led',requires:'lullaby-invited',who:'列因',id:'lullaby-carter',path:portWay}},stove,{...arcade,lullabyGuide:{flag:'lullaby-roof-led',requires:'lullaby-child-led',who:'栗芽',id:'lullaby-child',path:roofWay}},stairs,hob];
const blocked={'lullaby-last-stove':'列因在前面招手。先跟上他的肩背，他会在最后一张灶门边让路。','lullaby-double-stair':'栗芽一只手掖着帽檐。她在檐角等你，到了才好并排下楼。','lullaby-clay-hob':'有人站在门内等栗芽。先听两个人说清想怎样过这段楼梯。','lullaby-pan-lane':'棺车还在岸上时，列因会从它另一面领路。','counterlift':'井边还没给出敲铃的回音。从旧屋顶听清下面那层怎样开门。'};
for(const m of lullabyMaps){for(const e of m.exits)if(e.requires.length&&blocked[e.to])e.lockedText=blocked[e.to];
 for(const e of m.entities)if(e.id==='lullaby-pass'||e.id==='lullaby-ask')e.lockedText='这一锅要先问过乔稔本人；若她已经答过，留住她自己选的那一次。';}
export function withLullaby(m){const ex=extras[m.id];if(!ex)return m;
 const entities=m.entities.map(e=>e.id==='pall-bearer'?{...e,after:[...e.after,tell('塔婶','列因给我指了不挡人的干辙。他在棺车另一面等；想认这道灶门就跟他，我在。','!coffin-aboard')]}:e);
 return {...m,entities:[...entities,...(ex.entities||[])],exits:[...m.exits,...(ex.exits||[])]};}
export const lullabyQuest={id:'the-crisp-edge-is-yours',name:'上一次是你父亲，这一次是你',kind:'side',startFlag:'lullaby-child-led',endFlag:'lullaby-home',stages:['lullaby-child-led','lullaby-roof-led','lullaby-choice','lullaby-galley','lullaby-home']};
