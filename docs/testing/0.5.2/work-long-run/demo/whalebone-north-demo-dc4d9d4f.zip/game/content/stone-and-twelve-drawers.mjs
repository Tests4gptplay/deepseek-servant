import {westCase,drawerWestExits} from './the-shop-which-sailed.mjs';
import {saltCase,drawerSaltExits} from './who-keeps-the-drawers.mjs';
import {person,say as s} from './parts.mjs';
import {spoken} from './voyage-parts.mjs';

const afterHours={
 'outside-row':[
  person('drawer-hear-the-loader','在披屋坐墙上等船工换好干袜，再问他究竟接到了什么',27,7,[s('关薏','我从柜底托进去，手从一边伸到另一边。十二只抽，蓝脸上有“药铺”两字。我替你数得出抽格，给你数不出住户。'),spoken('关薏','我跟她娘熟起来是后来的事，岂能说当时已知道整个家。你去旧药库问，短芹还会教你从左边扶碾。','harbor-truth')])],
 'west-lamp':[
  person('drawer-ivo-after','陪伊沃在西窗下重新读旧户栏，问哪些话当时真已说过',9,11,[s('伊沃','西窗当年的关航是我的决定，补册还有一盏不能说找到了的灯。'),spoken('伊沃','我在这块地方亲自承认过：货柜到，不等于人到。盐市的票作与仓棚各有一面可以去问。','drawer-ivo-spoke'),spoken('伊沃','那晚我先前已经说过关航，药柜却没有在你来时重走。到盐市还能碰见今天在柜后工作的人。',['harbor-truth','!drawer-ivo-spoke'])],{requires:['harbor-truth']})],
 'organ-lock':[
  person('drawer-seam-guide','站在风箱一侧等妹妹收工的检修学徒',12,12,[s('检修学徒','旧药铺的石头在铺床巷。要试窄轮，去晒衣院、反提井；要试船，从药库外沿涨潮那道坡出。你不必靠背我这些话，回来我会再告诉你。'),spoken('检修学徒','想换办法就把空柜拖回旧药库。上面那张蓝脸没飞，你可以推回来。','drawer-open')])]
};
const markers={
 'whale-roofs':[['drawer-roof-line','rope',16,10,3,1,'从屋脊一眼看见旧铺与出柜口的两条不同斜线']],
 'counterlift':[['drawer-three-tracks','pier',13,10,3,1,'只够三轮短边先过的磨蓝窄坎']],
 'dry-court':[['drawer-plum-tray','crate',15,10,2,1,'晒衣院东墙有酸梅的矮盘']],
 'crib-hold':[['drawer-stone-root','post',17,10,1,1,'内圈伸到老屋底下的一体碾心'],['drawer-blue-front','crate',20,11,2,1,'能同石座分开的蓝柜门脸']],
 'organ-lock':[['drawer-aisle-lamp','lamp',13,12,1,1,'照得见回药库路的风箱侧灯']],
 'outside-row':[['drawer-skiff-bottom','boat',22,10,3,1,'涨潮能伸手看到柜底的接货船'],['drawer-blue-marks','post',21,12,1,1,'退潮才可走近的蓝柜脚印']],
 'ticket-works':[['drawer-inner-six','crate',14,9,3,1,'票作向街的六只蓝抽']],
 'transit-shed':[['drawer-outer-six','crate',18,9,3,1,'仓棚背水的六只工人私物格']],
 'ration-stair':[['drawer-porridge-place','hearth',16,9,2,1,'给两班人分开盛的一顿饭']],
 'brine-weigh':[['drawer-watch-pole','post',15,10,1,1,'报潮人自己站在上面的窄脚']],
 'north-pier':[['drawer-watch-boat','boat',16,11,2,1,'深浅不同的两只换班小艇']]
};
const gates={
 'ivo-admission':['drawer-ivo-spoke','西窗原灯与两路船的信号先要查清。听收绳处两人的矛盾话，去晒衣院和铺床巷，从梯井或侧舷实际验证柜与人如何分开，再让伊沃当面作答。'],
 'selene-oath':['drawer-settled','旧粮差、春种与布工的安排仍各有自己的当事人。蓝柜的两面在票作和货棚，做完瑟琳愿担的半班，再请她回答要不要北航。']
};
export function withDrawers(map){
 const entities=map.entities.map(e=>{
  if(gates[e.id]){const [flag,lockedText]=gates[e.id];const lines=e.id==='ivo-admission'?
   [spoken('伊沃','我也准货柜侧过，把柜到了当作整户到。不管粮船是先开还是后开，这份错都归我。','drawer-ivo-spoke')]:
   [spoken('瑟琳','今夜少了傍潮的外快，我在货棚给药布分了格。短芹的碾可以自己重新开了。','drawer-shop-back'),spoken('瑟琳','今天的报潮钱歧米自己领走。我那份少了三枚，不能把她的工再算到我家的饭筹里。','drawer-wage-back')];
   return {...e,requires:[...(e.requires||[]),flag],lockedText,dialogue:[...e.dialogue,...lines]};
  }
  return e;
 });
 const add=(markers[map.id]||[]).map(([id,kind,x,y,w,h,label])=>({id,kind,x,y,w,h,label}));
 return {...map,entities:[...entities,...(westCase[map.id]||[]),...(saltCase[map.id]||[]),...(afterHours[map.id]||[])],
  features:[...map.features,...add],exits:[...map.exits,...(drawerWestExits[map.id]||[]),...(drawerSaltExits[map.id]||[])]};
}
const titles=[
 ['the-store-that-arrived','原药铺究竟有没有上船','main',['drawer-open','drawer-home-voice','drawer-fixed-base','drawer-proved','drawer-ivo-spoke']],
 ['these-are-still-our-drawers','十二只蓝抽现在替谁过日子','main',['drawer-salt-open','drawer-salt-scoped','drawer-two-uses','drawer-two-homes','drawer-house-picked','drawer-settled']],
 ['visit-the-mill-again','柜子里的芝麻叫什么','side',['drawer-house-picked','drawer-settled','drawer-home-visit']]
];
export const drawerQuests=Object.fromEntries(titles.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
