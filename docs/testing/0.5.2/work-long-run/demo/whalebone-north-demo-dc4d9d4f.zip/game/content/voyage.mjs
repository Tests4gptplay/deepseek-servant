import {lead,ribs,ice} from './north-bearings.mjs';
import {shoal,depth,pocket} from './north-slots.mjs';
import {red,wreck,stamp} from './north-wreck.mjs';
import {mouth,ridge,water} from './winter-ridge.mjs';
import {village,moor,ward} from './winter-harbor.mjs';
import {pump,shoalFoe,anchorFoe} from './cold-pump.mjs';
import {yard,ratchet} from './anchor-drum.mjs';
import {flood,keel,cutter} from './flood-route.mjs';
import {grave,niche} from './burial-cape.mjs';

export const northToGrave=[lead,ribs,ice,shoal,depth,pocket,red,wreck,stamp,mouth,ridge,water,village,moor,ward,pump,yard,ratchet,flood,keel,cutter,grave,niche];
export const lateEncounters={[shoalFoe.id]:shoalFoe,[anchorFoe.id]:anchorFoe};
export const voyageGear={'sighting-bracer':{name:'测深用肩护',slot:'armor',defense:4}};
const stories=[
 ['charted-depth','白岬与漂冰','main',['north-ready','plumb-zero','bearing-stone','bearing-ice','hard-eight','north-chart']],
 ['two-crossings','回港两次的人','main',['remote-key','remote-lit','two-drafts','return-twice','pin-rub','maker-known']],
 ['margin-letter','图边的退信','hidden',['old-bone-mark','rib-pocket','honest-margin']],
 ['bed-and-harbor','能过冬的四个条件','main',['wind-exposed','lee-proved','fresh-proved','moor-proved','bed-count','winter-proof']],
 ['warming-the-pump','空泵房的灯','side',['moor-proved','pump-free','spare-pump']],
 ['falling-anchor','倾港的手柄','main',['bran-at-drum','shoe-held','drum-vent','drum-chalk','clutch-still','bran-unpinned','harbor-tilted','base-safe']],
 ['two-lines','把两句话放在一起','main',['coffin-home','epitaph-fault','epitaph-rescue','grave-signed']],
 ['letters-unfilled','没核实的那盏灯','hidden',['family-shelf','living-register']]
];
export const voyageQuests=Object.fromEntries(stories.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));