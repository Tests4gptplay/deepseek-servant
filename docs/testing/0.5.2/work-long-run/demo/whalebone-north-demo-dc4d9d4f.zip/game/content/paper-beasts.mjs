import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit} from './parts.mjs';
import {mechanism} from './district.mjs';
export const booth=region('paper-beasts','冬岸 · 把爷爷演成一只虾的午场',5,'north-interior',34,22,'wood',
 [['wall',0,0,34,4,'从屋顶降下来的粗帆影墙'],['building',2,4,8,4,'台口全家只坐得开三排的戏棚'],['crane',16,3,6,6,'剪影仍插在上面的钩环架'],['crate',24,4,9,5,'虾脚、虾须和好大一头青苞'],['wall',0,16,12,6,'从侧面偷看会露馅的厚枪布']],
 [['path',3,10,27,2,'灯离幕足够远的狭窄场地'],['lamp',19,12,1,1,'小垛瞒着大家画好的一盏圆灯']],
 [witness('stage-grand','给卧缨和她小孙女一刻钟，听一出没演完的虾戏',9,11,[s('小垛','爷爷走以前答应把《虾娶球藻》演完。新演员不给我演，非说球藻没有嘴不能说“不”。'),s('卧缨','我不是不给她演。我的手直了，到了张嘴这一节，我的手比虾还不像个活东西。'),s('玛拉','故事里那团球藻真想嫁吗？'),s('小垛','它想当水手！我就是要演它逃走。')],'play-heard'),
  fixture('stage-shadow','自己站在观众席最偏的一格，数虾脚与人指影相交的数目',23,11,[s('玛拉','第一根是虾须，第二根是人的小指。它们一动，球藻的嘴好像是老手伸过来抢走的。把灯挪近不是唯一的法子。')],'play-seen',['play-heard']),
  witness('stage-choose','让小垛自己决定球藻怎样真的逃掉',15,13,[s('小垛','虾送我一条红绳，可我没说要把自己系住。奶奶，你今天愿意演虾还是演船？'),s('卧缨','只这一次我做船。你挑个转弯能过去的样子。',[{text:'让球藻和虾争过一面双头纱，借侧光滚出去',set:'play-gauze'},{text:'让球藻顺着摇橹的小台车滚走，虾撑起船篷道别',set:'play-cradle'}])],'play-picked',['play-seen']),
  witness('stage-show','回观众这一边，看球藻自己选的逃婚演完',25,13,[spoken('小垛','虾想好抱我，影子一拐，抱住自己的尾巴了。球藻船长已去看海！','play-ran-light'),spoken('卧缨','老虾怎么说？嘿，我嗓子回来了。你当船长，我撑篷送一程！','play-ran-cradle'),s('观众里的修鞋人','我买戏票还送一条逃婚虾？没有？那我留下打扫。')],'play-finished',['play-performed'])],
 [exit(3,11,'pelt-lane',[29,17],'回皮窗街午摊'),exit(29,11,'reed-flies',[4,10],'到幕后找真的轮轴或帆纱',['play-picked'])]);
export const rack=region('reed-flies','冬岸 · 两个人伸手高度不同的幕后',5,'north-interior',28,19,'wood',
 [['wall',0,0,28,4,'幕布两侧原来就不同高的架脚'],['crate',3,3,7,5,'给孙女留的矮绳排'],['crane',14,3,5,5,'卧缨直着手也能拉到的高轮'],['building',21,3,7,5,'从侧光处倒下来的纱门'],['wall',0,14,10,5,'幕下不会被观众瞧着的滚槽']],
 [['path',3,9,22,2,'靠木托和脚撑滑过去的道具沟'],['rope',8,12,13,1,'剪影和人手能错开两格的串绳']],
 [fixture('flies-gauze','从侧门到矮绳排间夹起两层纱',9,10,[s('小垛','外纱能亮，里面那层收手。奶奶不用把腕子扳回二十岁。')],'play-gauze-set',['play-gauze']),
  mechanism('flies-reflect','摆灯、侧幕和两只手的距离',19,11,[s('卧缨','正面看我手还是大，我退后，你再换一边。')],['play-gauze-set'],'play-shadow-split','要让虾爪可见、老演员的指节藏在幕后，哪边留光？',['把手贴在最前纱上','侧灯只照前虾，后纱收住手影','将前后两层都折到灯芯上'],1,'观众看的是前纱；给前纱光，人的手退进不透光的那边。',[s('卧缨','我没弯腕子，虾倒弯出了腰。')]),
  fixture('flies-skip','推一下侧光后的球藻让它滚到布外',22,12,[s('小垛','球藻转过身来那一刻，不是奶奶替它甩掉了虾。是它自己滚的。')],'play-performed',['play-shadow-split'],{action:{type:'flag',id:'play-performed',set:'play-ran-light'}}),
  fixture('flies-cradle','坐进能放开老手的矮轮台，从半坡推出道具船',12,12,[s('卧缨','没有篷船就光溜溜的。我这只老虾做一张篷，你得把轮台的尾栓放下。')],'play-wheeled',['play-cradle']),
  fixture('flies-wake','用脚把半坡末的尾栓放到虾篷背后',20,13,[s('小垛','嘘，先让虾问完。我会自己松脚，你看它走。')],'play-performed',['play-wheeled'],{action:{type:'flag',id:'play-performed',set:'play-ran-cradle'}})],
 [exit(3,10,'paper-beasts',[28,11],'从观众看不见的幕后回台前')]);
export const cubby=region('toe-cubby','冬岸 · 仅在白鞍背面露出的戏靴小窟',5,'north-interior',24,18,'stone',
 [['wall',0,0,24,4,'两半反牙终于钩合的顶穴'],['crate',3,4,5,4,'老戏靴用细草填的脚背'],['wall',15,3,7,6,'能把钩扣放回的斜槽'],['water',0,13,8,5,'低潮可出、涨潮也可沿石藤退开的窄隙']],
 [['path',3,9,18,2,'只有窄靴能从侧边取下来的小阶'],['lamp',13,11,1,1,'旧钩尖一线青面']],
 [fixture('toe-pair','把老软靴两处挫牙合起来，用自己的脚试踩侧石',8,10,[s('伊沃','这是给戏里爬桅的年长人做的，靠钩外缘，不是让人去踩别人。转一格再压体重，坏水口也能自己落脚。')],'toe-paired'),
  object('toe-get','从戏靴上解下逆齿贴帮扣，带往真湿坡',17,10,[s('靴筒','角鞍戏班，我脚若软，外牙总会先帮我咬住。')],{requires:['toe-paired'],action:{type:'item',id:'tooth-cleat',value:1,set:'toe-found'}})],
 [exit(3,10,'false-saddle',[21,12],'以顺齿方向退回白鞍')]);
export const cleat={'tooth-cleat':{name:'逆齿贴帮扣',slot:'charm',resists:{cold:.23,tide:.16}}};
