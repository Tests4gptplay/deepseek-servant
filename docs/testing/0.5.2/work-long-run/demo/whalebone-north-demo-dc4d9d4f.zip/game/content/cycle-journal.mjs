import {fresh,decode,walkable,SAVE_KEY} from '../runtime/state.mjs';

export const afterwatchKey=SAVE_KEY+'.cycle.afterwatch.v1';
export const afterwatch={
 id:'afterwatch',title:'第二航次 · 那盏灯在门外',ordinal:2,requires:'grave-signed',
 start:{map:'watch-calendar',x:3,y:8},complete:'watch-second-end',
 memories:[
  ['ledger-first','memory-public'],['witness-first','memory-witness'],['fault-first','memory-fault'],
  ['names-first','memory-names'],['original-ashore','memory-shore-map'],['original-afloat','memory-ship-map']
 ]
};
const encode=value=>typeof value==='string'?value:JSON.stringify(value);
function graduated(world,raw){
 const p=decode(world,raw);
 if(p.cycle||p.flags[afterwatch.requires]!==true)throw Error('请先完成首航两行墓志，再翻次航册。');
 return p;
}
export function beginAfterwatch(world,primary){
 const p=graduated(world,encode(primary)),cycle=world.cycles?.afterwatch;
 if(!cycle||!walkable(world.maps[cycle.start.map],cycle.start.x,cycle.start.y))throw Error('次航观灯屋尚不可用。');
 const state=fresh(world);
 Object.assign(state,cycle.start);
 state.cycle={id:cycle.id,ordinal:cycle.ordinal};
 state.flags['afterwatch-open']=true;
 for(const [previous,memory] of cycle.memories)if(p.flags[previous]===true)state.flags[memory]=true;
 return state;
}
function validNext(world,input){
 const next=decode(world,encode(input));
 if(next.cycle?.id!=='afterwatch'||next.cycle.ordinal!==2||next.flags['afterwatch-open']!==true||world.maps[next.map].campaign!=='afterwatch')throw Error('次航册与本航地图不符。原件仍保留。');
 return next;
}
function readEnvelope(storage,world){
 const raw=storage.getItem(afterwatchKey);if(raw===null)return null;
 const box=JSON.parse(raw);
 if(box?.version!==1||typeof box.primary!=='string')throw Error('次航册格式不可读。原件仍保留。');
 graduated(world,box.primary);return {primary:box.primary,next:validNext(world,box.next)};
}
export function storeAfterwatch(storage,world,primary){
 const raw=encode(primary);graduated(world,raw);
 const existing=readEnvelope(storage,world);
 if(existing){
  const incoming=JSON.parse(raw),previous=JSON.parse(existing.primary);
  for(const [flag] of afterwatch.memories){
   if(Boolean(incoming.flags[flag])!==Boolean(previous.flags[flag]))throw Error('这个首航的经历与现有次航册不一致。可从航记面板续读已存的次航。');
  }
  return existing.next;
 }
 const next=beginAfterwatch(world,raw);
 storage.setItem(afterwatchKey,JSON.stringify({version:1,primary:raw,next}));
 return next;
}
export function loadAfterwatch(storage,world){return readEnvelope(storage,world)?.next??null;}
export function firstVoyageCopy(storage,world){const box=readEnvelope(storage,world);return box?decode(world,box.primary):null;}
export function saveAfterwatch(storage,world,state){
 const box=readEnvelope(storage,world);if(!box)throw Error('请先在首航墓坡建立次航册。');
 const next=validNext(world,state);
 storage.setItem(afterwatchKey,JSON.stringify({version:1,primary:box.primary,next}));
 return next;
}
