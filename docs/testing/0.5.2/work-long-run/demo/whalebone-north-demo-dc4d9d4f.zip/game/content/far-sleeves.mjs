import {region,witness,fixture,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';

export const hem=region('salt-sleeve','盐市 · 擦盐围袖巷旁的旧衣板',3,'salt-market',37,23,'stone',
 [['building',0,0,10,7,'借来做临时补衣工位的锅边长窗'],['crate',13,2,6,6,'撑白袖的短架只高到腰'],['crane',25,2,7,6,'工友共用的坐板支架'],['water',0,16,13,7,'压衣石一边被盐渠浸掉色'],['building',24,16,13,7,'只开半扇门纳凉的前街住家']],
 [['path',3,9,31,3,'愿等的客人可在当街坐，不挤屋内'],['rope',9,13,20,1,'针从侧面可撤的自用晾绳']],
 [person('sleeve-day','在盐槽边用旧围袖猜谁吃过煎鱼的茶工',8,11,[s('茶工','这抹油是鱼还是船？我靠这套看人有三十年。'),s('玛拉','看准过吗？'),s('茶工','准过一次。那人正拿着鱼。')]),
  witness('sleeve-quiet','到两拨人不会在门里撞面的小凳前找阿漉',15,11,[s('阿漉','旧屋后廊你走过。盐市这里也差一个转角。你能不能帮我在外头停一次手？我想替另外一家的女儿腾个喘气的地方。')],'sleeve-help',['keen-quiet-room','!grave-signed']),
  witness('sleeve-bench','到禾泊给病船工人坐的旧长板前试一下',22,12,[s('禾泊','那晚歇掉的一炉饼有人老念。我把那个摊边的坐法带过来，给看盐烫伤的人先坐。叫我请所有人诉苦？还不如先搭凳。')],'sleeve-help',['keen-open-bench','!grave-signed']),
  fixture('sleeve-wait','不用练习针，把凉袖搭在自己的手臂上，等家属换位',12,14,[s('病家女儿','我托住了。谢谢你没把我的衣袖垫别人自己的臂。')],'sleeve-place',['sleeve-help','!grave-signed'],{action:{type:'flag',id:'sleeve-place',set:'sleeve-by-hand'}}),
  fixture('sleeve-slide','用自己练过的侧进双眼，把凉袖暂系再原手退针',25,14,[s('玛拉','用的是我的线，只够暂系。她把手放上去，我就能从侧面撤出来。'),spoken('阿漉','你终于肯用自己袖子试了。我那只照旧带回家。','keen-quiet-room'),spoken('禾泊','有个闲着的饼夹我本来想拿过来。见你从边上把线头送出来，我就拿回去翻饼了。','keen-open-bench')],'sleeve-place',['sleeve-help','keen-blue-thread','!grave-signed'],{action:{type:'flag',id:'sleeve-place',set:'sleeve-by-thread'}}),
  witness('sleeve-seat','把空凳从医处还到屋檐给等候的街坊',30,11,[s('街坊','以前夜里回家要绕盐槽四个角。这里能从外面等，我少跨一道台阶。你想给谁留名？'),s('玛拉','凳子的主人。'),s('街坊','那你去找个写得下四十来个屁股的名牌。')],'sleeve-done',['sleeve-place','!grave-signed'])],
 [exit(3,11,'salt-lane',[16,12],'经过盐渠的停食位返回盐巷')]);

export const layby=region('twin-tails','北航 · 一端等船尾、一端等浮篓的歇标口',4,'winter-coast',35,23,'stone',
 [['water',0,0,35,5,'北流将正船的尾花送到两根木牙之间'],['crane',2,4,7,5,'外海灯班另设的一低一高两根牙旗'],['wall',13,3,6,5,'正汊回索必须在这块石头之外收住'],['boat',24,3,10,6,'停在背流、能由一只手换舵的短艇'],['water',0,17,14,6,'北航换水比鲸城慢得多']],
 [['pier',3,10,29,2,'选好走哪股水以后才到废航标外坡'],['rope',9,14,16,1,'手放过头会被船尾花拖直的迟索']],
 [witness('tail-wrist','在较迟的北涌里与寻夕重新站开两端停船的位置',10,11,[s('寻夕','北边的水比城里慢一截。你记得关过航，就别把那一晚的拍子照搬过来。等我看见末艇船尾。'),s('伊沃','索头交给你。正汊过完我把候船的手带回去。')],'tail-ready',['cross-wrist-run','remote-lit','!grave-signed'],{action:{type:'flag',id:'tail-ready',set:'tail-wrist-turn'}}),
  fixture('tail-float','从艇尾松开练过的回篓，让它在北涌真正转过一圈',22,11,[s('弦鲐','你看它先去亲那边的石牙，再回来。你拿我旧伤说事没用，它现在转回来才有用。'),s('米拉','我在海图上画一段弯。不能画一根总朝岸的箭。')],'tail-ready',['cross-float-run','remote-lit','!grave-signed'],{action:{type:'flag',id:'tail-ready',set:'tail-float-turn'}}),
  witness('tail-nap','给先醒的船工解绳，把学会轮睡的父女真正接到北标班',27,13,[spoken('北荻','我现在听木背，钟响就让它响。','nap-knock'),spoken('小荻','我推船才把他叫起。今天我爸终于带来一份煮熟的早饭。','nap-heel')],'nap-north',['nap-on-duty','tail-ready','!grave-signed'])],
 [exit(3,11,'red-beacon',[12,12],'放下北汊余索回红标守人处'),exit(30,12,'wreck-slope',[12,12],'由已实测的北涌侧弯开到搁艇坡，不重走原高脊',['tail-ready','remote-lit'])]);

export const home=region('morrow-seat','安葬后 · 众人不必同去墓旁的后巷',6,'white-harbor',37,23,'stone',
 [['building',0,0,9,7,'窗扇开向院内的小家'],['crate',13,2,7,5,'只有把板移到外面才能看见的凳脚'],['building',25,0,12,7,'做初潮饼、再开晚火的炉舍'],['water',0,16,13,7,'坐在家门外仍能听见的低潮港'],['wall',24,17,13,6,'早年家属和后来访客各走的巷子']],
 [['path',3,10,30,2,'墓坡下各自散开、可以选择来或不来的一条街'],['lamp',16,12,1,1,'今天没人要收走的一盏小灯']],
 [person('morrow-old-guest','在门边修饼盘的禾泊',9,11,[s('禾泊','你刚从坡上回来？我今天有饼摊，不跟着全城去挤。坐一会再走。'),spoken('禾泊','那一炉我自己收的。没了最后半盘的生意，有人倒愿意带一把椅子再来。','keen-open-bench'),spoken('禾泊','你给亲人分过两拨，我居然卖出了两拨的热饼，也不能叫她总留一位给我。','keen-quiet-room')]),
  fixture('morrow-room','随阿漉去把安静小桌从门边复位，让她结束今天的探望',18,11,[s('阿漉','他那排还在，谁来谁自己坐。今天我想一个人缝我的指套。你可以走。')],'keen-home',['keen-quiet-room','grave-signed']),
  fixture('morrow-bench','在摊外坐沿帮禾泊翻起挡风板，让最后一位工人自己回家',25,12,[s('禾泊','今天我可开完了全炉。他们坐完了自己会把板推回来。你父亲也有样不会做的事——他总不会自己还盘。')],'keen-home',['keen-open-bench','grave-signed']),
  witness('morrow-sleeve','把盐市凉袖如今真的有人坐的那一小角留给后来的家属',29,13,[spoken('玛拉','那一角靠我自己托过，她们如今知道要谁的手。','sleeve-by-hand'),spoken('玛拉','两孔的线我已经还给自己，床边的人能自己轻轻拆开。','sleeve-by-thread')],'sleeve-home',['sleeve-done','grave-signed'])],
 [exit(3,11,'burial-cape',[10,12],'经墓地外面的长墙回到两行墓碑'),exit(32,12,'dry-paper-loft',[4,10],'循木屐和晾好鱼纸的味道去工人住的外港',['grave-signed'])]);

export const loft=region('dry-paper-loft','安葬后 · 赶完早市或重新晒纸的人',6,'whale-city',32,21,'wood',
 [['building',0,0,9,7,'早晚都有人来接的值船窗'],['crate',13,2,6,5,'芹壶第二次揉出的淡色鱼纸'],['boat',23,2,9,6,'已经能自己转弯也仍由原船客保有的旧艇'],['water',0,15,12,6,'旧关口还有浪，船东有独立的叫停索']],
 [['pier',3,9,26,2,'值过班的人回到自己住的灯屋后身'],['rope',9,13,16,1,'谁执过哪一头已经不同的止船索']],
 [person('dry-street','望水编筐的弦鲐',9,10,[s('弦鲐','今天我只修筐，轮到别家守水。你想来坐，我没赶你。')]),
  witness('dry-market','用手里那一端停过一次，请寻夕去把欠聂腮的一班赶完',17,10,[s('寻夕','他说周二，我说周二。帆拉起来我们就能下去，说句逢迎话没用。'),s('伊沃','你答应的班我也来。那只空筐先给我。')],'cross-home',['cross-wrist-run','grave-signed']),
  witness('dry-rub','跟弦鲐在楼上把欠纸师的湿角真正揉开，晾回夹床',24,12,[s('芹壶','这张不如当初那张平。我认得是你们重新弄过的，拿来裹新船的栓子够用。'),s('弦鲐','我还是不想给他一句原谅。你把那头拿稳，我们共事就能把纸晾完。')],'cross-home',['cross-float-run','grave-signed']),
  person('dry-nap-pot','在熟透的藻饭上睡着的小荻',20,13,[s('北荻','这次轮她睡。我保证这锅熟了。'),spoken('北荻','从北标回来她能睡两个钟。饭糊不糊跟她耳朵没有关系。','nap-north')],{requires:['nap-on-duty']})],
 [exit(3,10,'morrow-seat',[31,12],'离开仍在上工的人沿居住巷回去')]);
