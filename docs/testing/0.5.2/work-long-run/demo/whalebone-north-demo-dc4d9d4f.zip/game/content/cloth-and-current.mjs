import {kitchenStops} from './quiet-lunch.mjs';
import {court,mats,wheel} from './hem-court.mjs';
import {wrack,loft,scow} from './wrack-laundry.mjs';
import {eels,spawnHint} from './eel-cradle.mjs';
import {town,sock,meridian} from './leeward-buttons.mjs';
import {bleach,throat,tongue} from './fan-throat.mjs';
import {hide,gearHint,prismGear,shear,pairs,birds} from './giant-seam.mjs';
import {landing,dusk,endSalt,backTown} from './debt-berths.mjs';
import {say as s,exit,person} from './parts.mjs';
import {spoken} from './voyage-parts.mjs';

export const hemMaps=[court,mats,wheel,wrack,loft,scow,eels,town,sock,meridian,bleach,throat,tongue,hide,shear,pairs,landing,dusk];
export const hemGear=prismGear;
export const hemFoes={[birds.id]:birds};
const roads={
 'salt-lane':[exit(17,10,'hem-court',[4,11],'从盐市井边斜过三班布脚窝')],
 'petition-hall':[exit(11,9,'hem-court',[25,15],'离开听证门，从学堂后巷进盐市住工街')],
 'wreck-slope':[exit(12,10,'leeward-buttons',[4,11],'循米拉署过名的短北图去看返航的那条艇',['pin-rub','party:mira'])],
 'edge-bleach':[exit(19,12,'silent-gimbal',[4,10],'循漂销的虹片和石背返绳，退水摸进分光室',['prism-fleck','bleach-scar','tide:low'])],
 'moor-pocket':[exit(9,12,'hems-berth',[4,11],'沿斜泊台去实接暖砖、夜灯或盐市工班',['moor-proved'])],
 'flood-stair':[exit(13,13,'shuttle-dusk',[4,10],'侧身下塌窗的旧布巷找亲自抵达冬岸的人',['harbor-tilted']),exit(14,12,'hem-court',[31,13],'葬后乘本埠早潮货艇回访盐市旧住工街',['grave-signed']),exit(15,12,'leeward-buttons',[32,14],'葬后随回北埠换工的供粮班再抵五灯岛',['grave-signed','fan-evac'])],
 'hem-court':[exit(32,13,'flood-stair',[14,13],'沿次晨货艇回白崖的撤离坡',['grave-signed'])],
 'leeward-buttons':[exit(33,14,'flood-stair',[15,13],'返程供粮艇将岛上夜工送回白崖',['grave-signed','fan-evac'])]
};
const locations={
 'wrack-bight':[spawnHint],'egg-meridian':[gearHint],'loft-laundry':[endSalt[0]],'deck-scour':[endSalt[1]],
 'leeward-buttons':[backTown[0],backTown[1],backTown[3],{...backTown[2],requires:['fan-certified'],lockedText:'旧印图还压在灶角，补写的那条行船线眼下还空着。'}],
 'eel-cradle':[person('eel-after-tide','换过篓的卷苗和晒饼人的孩子',15,11,[spoken('卷苗','冬岸回来的布担又带回一把短草，新一批小眼在这里过了一个冬天。今晚谁要来捞，得先把鞋放下。','eel-safe'),s('阿崔家的孩子','我来要的那只筛帽是筛饼用的。等鱼走了还我戴一次。')],{requires:['grave-signed']})]
};
const tips={'selene-oath':['hem-mats-set','沙荷已在住户、作坊或工艇试过一班吗？第三晨到倒班铺看是谁真能睡，别把答应上工当作已经接手。'],'mara-deposition':['fan-certified','搁船坡还留着一张米拉自己署错的北图。去夹风岛亲自走一条改过的航道，把见过的回水和船重留给亲人。']};
export function withHems(map){
 const entities=map.entities.map(e=>{
  if(tips[e.id]){const [flag,lockedText]=tips[e.id];return {...e,requires:[...(e.requires||[]),flag],lockedText};}
  if(e.id==='mira-first')return {...e,dialogue:[...e.dialogue,{...s('米拉','这张我自己印过的小折页上，北风箭下的水线是直接朝外的。是我十天前跟艇走那一次画的，我把同一张给了茶斛。'),if:'!fan-certified'},spoken('米拉','同一张旧印我留在灶边，旁边给开回来的那条艇留了改线。','fan-certified')],action:{type:'flag',id:'old-fan-print'}};
  if(e.id==='salt-selene')return {...e,dialogue:[...e.dialogue,spoken('瑟琳','我娘在晒阁上夹布，住户可以要求她停轮。我今晚来陪她吃自己盛的第一碗饭。','hem-loft-working'),spoken('瑟琳','我娘在洗布驳学会退车，夜里赶第二趟。我给她留口热饭，不替她回绝海上的工。','hem-scow-working')]};
  return e;
 });return {...map,entities:[...entities,...(locations[map.id]||[]),...(kitchenStops[map.id]||[])],exits:[...map.exits,...(roads[map.id]||[])]};
}
const chain=[
 ['the-boat-at-lunch','芽沏自己赶午艇','side',['bowl-heard','bowl-rig','bowl-served']],
 ['work-of-the-hem','沙荷另找一件真活','main',['hem-beside','mat-lent','mat-coupons','wheel-one-shift','hem-stained','wheel-retracted','wrack-tried','hem-pledged','hem-employed','hem-mats-set']],
 ['where-a-net-can-turn','背浪里给小眼留一段水','side',['raised-eel-hole','eel-needs-space','eel-rim','eel-safe']],
 ['the-arrow-was-mine','米拉改一笔自己画错的水','main',['chart-disputed','egg-out','float-paired','sock-heard','fan-compared','fan-corrected','fan-sailed','fan-landed','fan-certified']],
 ['two-faces-of-glass','背石下的对光室','hidden',['prism-fleck','bleach-scar','prism-room','prism-found']],
 ['whose-shift-came-ashore','从盐市试工到原巷复工','side',['hem-mats-set','hem-winter','hem-evac','hem-home']],
 ['the-second-winter-boat','短路欠的砖与外路欠的灯','side',['fan-certified','fan-winter','fan-evac','fan-home']]
];
export const hemQuests=Object.fromEntries(chain.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
