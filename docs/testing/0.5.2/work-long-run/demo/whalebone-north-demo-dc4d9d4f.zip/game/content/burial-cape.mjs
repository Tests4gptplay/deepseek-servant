import {region,fixture,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit} from './parts.mjs';
export const grave=region('burial-cape','白崖北坡 · 回来的葬列',6,'winter-coast',26,18,'stone',
 [['water',0,0,26,3,'冬海浅旭'],['wall',2,4,5,5,'白崖迎风石'],['building',18,4,6,5,'备土与洗手的小屋'],['crate',5,13,4,3,'远行的旧棺车'],['wall',19,13,7,5,'刻着无名船位的低石']],
 [['path',7,9,16,2,'留给家人走的土径'],['lamp',14,6,1,1,'未点的岸灯'],['rope',9,12,5,1,'靠两人合放的棺绳']],
 [fixture('lower-coffin','和同行人一起卸下白布棺车',10,11,[s('伊沃','绳在你手里。你要退半步也行，我们三个都在。'),s('瑟琳','今天的饭在岸上留一碗。你不来，我们把碗盖上。'),s('米拉','墓在真正的岬角上。是个不需要我替你画准的地方。')],'coffin-home',['base-safe']),
 fixture('engrave-slot','把反拓和造锚图放在墓石左边',14,8,[s('玛拉','晏禾，巨锚的偏销槽由他签图。半城坠海，责任在这行；不能只刻他后来救过谁。'),spoken('玛拉','我在印样房答应从这一行开口。现在旁边还留着另一行的位置。','fault-first')],'epitaph-fault',['coffin-home','maker-known']),
 fixture('engrave-return','把两道钩痕和船名录放在墓石右边',16,10,[s('玛拉','他在断裂的船台两次返航，载过能走的孩子，也载过要躺着回去的人。其中有我。'),spoken('玛拉','我答应先列名字。墓石放不下，旁边的册子还由活着的人添。','names-first')],'epitaph-rescue',['coffin-home','return-twice']),
 fixture('cover-letters','把布罩折起，照出完整的两行碑',13,10,[s('墓碑','晏禾签下巨锚销槽，半城坠海。'),s('墓碑','晏禾两次返航，载回遇险的人。'),s('玛拉','这两句都是真的。我送他到家，到这里。'),spoken('井嫂','多出来的两张床我已亲手接下。长梯留在白崖，下次照样要修。','beds-arrived'),spoken('仓守','冬岸修索棚点灯了。油领过一次，字模和人的名字还在。','workers-arrived')],'grave-signed',['epitaph-fault','epitaph-rescue'],{after:[s('玛拉','我不在第一行下面添“但是”。也不在第二行后面问“够不够”。'),s('墓碑','晏禾签下巨锚销槽，半城坠海。晏禾两次返航，载回遇险的人。')]}),
 person('mira-after','北图边上的米拉',8,9,[spoken('米拉','退信筒里还有字。这次留给愿意自己走过去的人。','honest-margin'),s('米拉','我画了坡脚一条回去的线。来送别的人也需要知道从哪儿回家。')]),
 fixture('stone-thread','看墓坡低石上的针线记号',18,11,[s('小乌','刻缝有一长两短。有些家属想留下自己那趟船的空白，没有把纸交给编总册的人。'),s('玛拉','去看看。别人有权不把最后一页交到我手里。')],'family-shelf',['grave-signed'])],
 [exit(2,9,'safe-keel',[12,14],'沿引航驳回访余下的港人'),exit(23,11,'letter-niche',[3,6],'循低石刻线往遗属小室',['family-shelf'])]);
export const niche=region('letter-niche','白崖北坡 · 留白的小室',6,'harbor-interior',15,12,'wood',
 [['building',1,1,3,3,'空名格'],['crate',9,1,5,4,'遮潮的来信柜'],['wall',0,10,7,2,'防风门槛']],
 [['lamp',7,6,1,1,'收件人的单烛'],['rope',9,8,3,1,'空信绳']],
 [fixture('unsigned-space','留出没有姓名的一格',8,7,[s('空格旁的纸','远窗的人有两位走到盐滩。第三盏灯没有核实，请保留这一格。'),spoken('玛拉','帆边两道针脚证明两位上岸。我不替第三个人填那只空格。','salt-survivors'),spoken('米拉','我的地图上也有一句“没见过”。没有证据时，留白可以是一桩完成的工作。','honest-margin')],'living-register')],
 [exit(2,6,'burial-cape',[22,11],'回墓坡')]);