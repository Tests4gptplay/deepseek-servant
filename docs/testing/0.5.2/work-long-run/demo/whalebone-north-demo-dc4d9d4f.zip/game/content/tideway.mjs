import { say as s, feature as f, exit, person, object, flag } from './parts.mjs';

export const tideway = {
  id:'lower-tide',name:'白崖港 · 潮脚检修廊',act:1,width:25,height:17,biome:'tidal',ground:'wood',
  solids:[[0,0,1,17],[3,0,7,2],[14,0,5,3],[2,8,6,3],[0,14,17,3],[19,11,6,6]],
  features:[f('water',0,14,25,3,'进潮槽'),f('water',19,11,6,6,'外港'),f('pier',1,3,23,3,'检修架'),f('pier',9,5,4,9,'下潮尺'),f('building',3,0,7,2,'排水站'),f('building',14,0,5,3,'旧闸房'),f('crate',2,8,6,3,'压索块'),f('sign',14,6,1,2,'双层潮尺')],
  entities:[
    person('gauge-tender','修潮尺的小艇工·珀',6,5,[
      s('珀','看两道水痕。深色的旧了，发绿的才是前一场水。别拿你到这儿的时辰当一年的潮时。'),
      s('玛拉','港上那口钟，敲给谁听？'),
      s('珀','敲给听不见海面的人。你替我看闸，等下一潮，低处的小东西就会露出来。')
    ]),
    object('tide-bell','候潮铜钟',10,6,[
      s('铜钟边的木牌','移到护栏里等一潮。低潮可下尺脚，高水时可直接从上街去吊台。'),
      s('玛拉','把棺车掩稳，我看着水线。')
    ],{action:{type:'tide',id:'tide-read',value:'toggle'}}),
    object('meal-token-finder','格栅里发亮的铁片',10,12,[
      s('玛拉','一条缺尾巴的铁鱼，背上压着粥铺的禾字。'),
      s('珀','潮起又会把它吞进去。取下就带走吧。')
    ],{requires:['meal-open','tide:low'],action:{type:'item',id:'fish-token',value:1,set:'meal-token'},after:[s('格栅','盐垢上还留着一道鱼尾印。')]}),
    object('old-keel','潮尺背面的三排铜钉',15,9,[
      s('玛拉','第一排钉住补板，第二排是撑脚。第三排敲起来，里头空的。'),
      s('板背的铅笔字','「回来时倒数第二个小孩没哭，她在咬我的袖子。」'),
      s('玛拉','我从前咬坏过一件这样的蓝布衣服。可那人说，是炉钩挂破的。')
    ],{requires:['old-rhyme','tide:low'],action:flag('keel-name'),after:[s('补板','第三排还藏着那半根蓝线。玛拉把木片扣回原位。')]}),
    object('ratchet-chalk','滑轮工的白灰手印',19,6,[
      s('灰手印','先锁棺车后轮，再卸空筐。倒过来，满筐会沿坡往人群里跑。'),
      s('玛拉','我把这两句写在掌边。搬棺的人腾不出手翻册子。')
    ],{action:flag('brake-order')}),
    object('shell-crab','卡在潮网里的响壳蟹',17,12,[
      s('珀','听。它敲网是找出路。把那根倒钩挑起来，空出一块地方。')
    ],{action:{type:'battle',id:'bell-crab',value:'bell-crab'}})
  ],
  exits:[exit(1,4,'wharf-scale',[23,15],'上木梯回秤桥'),exit(12,2,'rope-market',[10,15],'上晒布巷'),exit(23,5,'coffin-hoist',[18,13],'过潮脚检修门',['tide:low'])]
};