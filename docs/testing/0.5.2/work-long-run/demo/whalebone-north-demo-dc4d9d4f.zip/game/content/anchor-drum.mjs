import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit} from './parts.mjs';
export const yard=region('anchor-yard','锚断之夜 · 铅线通红的转运场',6,'whale-city',30,19,'wood',
 [['water',0,0,30,3,'提前转身的鲸群'],['building',2,4,5,5,'工会罢锤房'],['building',11,3,5,4,'拉闸亭'],['crane',22,4,5,5,'南锚臂'],['crate',3,13,6,4,'用过的配重块'],['water',19,14,11,5,'倾翻的驳船位']],
 [['rope',6,9,18,1,'受力发亮的旧主索'],['lamp',10,10,1,1,'仓班求救灯'],['pier',12,10,6,4,'临时转向道']],
 [witness('bran-return','手上缠着验粮带的布兰',10,9,[s('布兰','我收到了内港的七结水深。鲸群早转两潮，今天重下锚至少能换一晚粮。松手的话，谁让前街的米不落水？'),s('瑟琳','四张可用的病床，不是六张。两家先过冬，不是全港。你不能拿没把握的四家换一条平不了的锚。'),s('布兰','我带你们下去。你们把反转的齿停住。开锚柄的人我自己来当。')],'bran-at-drum',['winter-proof']),
 fixture('mara-shoe','用殓舟垫铁卡主轴底座',17,10,[s('玛拉','停灵架不能拿来挡落棺，得垫它的脚。锚机一样。听着，我顶着，你绕正索。')],'shoe-held',['bran-at-drum']),
 person('yard-canteen','把药挂在内侧的工会厨娘',9,12,[s('厨娘','开釜一人一份。撑得住再往里，不然药连瓶子都会跟你弹出去。')],{action:{type:'rest'}})],
 [exit(2,9,'winter-ward',[17,8],'搭联络船回冬岸'),exit(27,10,'ratchet-loft',[3,7],'循固定底座的外梯上棘轮楼',['shoe-held']),exit(14,15,'flood-stair',[3,8],'沿倾斜的收粮坡下原港',['harbor-tilted'])]);
export const ratchet=region('ratchet-loft','锚断之夜 · 三齿棘轮楼',6,'whale-interior',25,17,'wood',
 [['wall',0,0,25,2,'吊轴井上壁'],['crane',4,3,5,4,'卷索盘'],['water',16,4,7,4,'冰水泄压口'],['crate',17,12,6,5,'棘轮笼']],
 [['rope',8,9,13,1,'上臂与副索'],['lamp',13,6,1,1,'米拉的避齿标线'],['pier',6,11,10,2,'水力泵廊']],
 [fixture('ivo-bridle','用活套换下副索死扣',8,9,[s('伊沃','旧扣咬在下端，越急越紧。我把两根交叉，从旁边孔放开，让下一班能从另一头脱身。')],'bridle-free',['shoe-held']),
 fixture('selene-vent','在低音消失前释放外槽',15,8,[s('瑟琳','先隔内阀，风琴闸已经替我们证明过。现在外水自己落下来。')],'drum-vent',['bridle-free','party:selene']),
 fixture('mira-chalk','沿副钩回路划三段齿纹',11,11,[s('米拉','白齿顶人，黑齿留缝，末段先向西反扫。我画的是应站的地方，不是告诉你们对着铁壳砸。')],'drum-chalk',['drum-vent','party:mira']),
 object('clutch-fight','三道啮齿仍在互推的锚机',18,9,[s('玛拉','滑板开始回抽。一个人守脚，其他人看标进位；布兰，等到最后再解。')],{requires:['drum-chalk','!clutch-still'],lockedText:'先沿活套、泄压口、三齿标线逐项查看。停下后由布兰接锚柄。',action:{type:'battle',id:'anchor-clutch',set:'clutch-still'}}),
 witness('bran-unpin','让布兰取出自己当年封的销',13,13,[s('布兰','我当年把这根销钉称为“最后一根缆”。我靠这句收过税，也担保过船。今天由我收回那句话。'),s('玛拉','他握住柄，我清开那条让人出去的槽。这是两个人的事。'),s('布兰','松了。北道给你，人我带到坡脚。')],'bran-unpinned',['clutch-still']),
 fixture('mara-floodgate','用对潮线放开撤离浮桥',5,10,[s('玛拉','开北侧。深槽潮标正中，先放坡脚的人过去。'),s('米拉','粮栈低梁碰到水了！来时能直走的拣货横街，回头要上木阶绕。')],'harbor-tilted',['bran-unpinned','north-chart'])],
 [exit(2,7,'anchor-yard',[26,10],'回转运场')]);