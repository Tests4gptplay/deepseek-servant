import {region,witness,fixture,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {mechanism} from './district.mjs';

export const potYard=region('running-pot','冬岸 · 借人下来的锅与走得上坡的饭',5,'winter-harbor',36,23,'stone',
 [['water',0,0,12,7,'低水时通到下码头七道浅台的泊岸'],['building',15,0,7,7,'冬岸运妇菇珍有一对门的厨房'],['crane',27,2,7,7,'瓷箍到北岸以后换的短吊柄'],['wall',2,16,12,7,'风盐使整锅很难直着上坡'],['building',24,17,12,6,'四个守晾屋的人暂时不能离岗']],
 [['path',3,9,30,3,'过第一道门后可以去接热锅或去借冬灶'],['hearth',14,12,1,1,'能收下分灶短锅的黑圆托'],['rope',22,14,6,1,'整锅走坡时用的低位接力绳']],
 [person('pot-winter-host','冬岸刚开头饭的菇珍',8,11,[s('菇珍','我在这北岸盛过二十年萝卜，从来不知道“欠着吃”的萝卜会自己游过来。你把带来这口饭的人领到门边再说。')]),
  fixture('pot-winter-loan','在下厨房替跟船陶工葛庐撑好北岸另起的一口小锅',15,11,[s('葛庐','我从梧宛那里学了只带一圈石箍。饭船留在你舅门前，窑口得自己煮。我坐第一班海船来，把她教的这一手传到北岸。'),s('菇珍','我们就在这儿先烧，盐市欠下的是工钱，没有变成一口从北方飞回去的锅。')],'pot-winter',['pot-low-berth','!grave-signed'],{action:{type:'flag',id:'pot-winter',set:'pot-winter-small'}}),
  mechanism('pot-winter-hoist','与坡厨房的换班工分三处把北到的沉饭锅送上晾屋',24,11,[s('葛庐','苇蜓那艘在上坝，饭现在能到窑。我随它的第一批粮来教你们，整锅送过这里，锅耳不能承全部重量。')],['pot-kiln-berth','!grave-signed'],'pot-winter-high','坡门低，能承重的是石座而非细锅耳，晾屋的孩子不能离门。怎样交饭？',['拖锅耳把锅滑过去','沿坡分开托底，把锅送到门边，让孩子自己拿勺','让孩子都放下窑火到下面排队'],1,'人和锅要在门槛边相遇。先看底托接班处。'),
  witness('pot-winter-high-set','等上坡的小工真正自己舀到一勺，再把满锅归还班房',29,13,[s('细沼','以前要我先去下头盛，人走出去火就熄。你们饭到这儿我才能自己拿。'),s('瑟琳','在我舅门边也有这个道理，可他现在得去上坡。冬天我们不说家里两头都安稳。')],'pot-winter',['pot-winter-high','!grave-signed'],{action:{type:'flag',id:'pot-winter',set:'pot-winter-lift'}}),
  fixture('pot-air-rattle','从旧声碗的一颗空孔叫到一直在后灶等待的小工',19,14,[s('小工','我听不见你们敲窗，倒听得到一枚籽在黏土里跑。碗还给你，我自己也要烧一只。')],'pot-rattle-home',['pot-ear-cup','pot-winter'])],
 [exit(3,11,'winter-court',[17,11],'回到当地人正在做饭的冬岸巷')]);

export const ridge=region('reed-dispatch','冬岸 · 从沙鞍与旧喉各来一班的芦泊',5,'winter-coast',38,23,'wood',
 [['boat',1,1,9,7,'走滑床来的重艇绑着两只小轮'],['wall',14,1,5,7,'有水支撑和没有水时痕色相反的溪坎'],['water',22,0,16,8,'只有里方自己带路才让船过的芦汊'],['building',0,16,12,7,'给邮工还船并留一晚睡处的收艇亭'],['crate',25,17,13,6,'泥里仍活着的冬蟹脱壳片']],
 [['pier',3,10,32,2,'木轮与手撑回艇实际抵达的两头'],['rope',10,14,19,1,'收到的粮包和邮袋从不同码头上来']],
 [witness('pan-winter-roll','在北边的砾脚替第一次通过舟床来的粮艇移开轮止',10,12,[s('似禾','我的腿沿鞍走，饭桌在艇里平着。我过来时榉叶还留在两坡中间，米拉，真要留到春天。'),s('米拉','春天也留。你把轮拉到自己能用的位置，白崖那边有水要倒坡，我现在得知道货要从哪边下。')],'pan-winter',['pan-rail-route','!grave-signed'],{action:{type:'flag',id:'pan-winter',set:'pan-winter-roller'}}),
  fixture('pan-winter-seat','在北方内汊留一支空橹，把最后一段交给实际领水的人',23,11,[s('粟殼','我来北湾第一次，比门舌还深，所以找了本地桂深来站前头。留白不能刻个粟家的专印就算了。'),s('桂深','既然你会让出那支橹，我带这趟重船。白崖要接船，叫他们看有谁站在首舷。')],'pan-winter',['pan-guest-route','!grave-signed'],{action:{type:'flag',id:'pan-winter',set:'pan-winter-lead'}}),
  witness('pan-note-kept','在凉亭旁让收信的小伙伴自己处理蹊泥的信',29,13,[spoken('任萤','封边的蟹牙还在。我拆给她看，没让门口排队的听见。','pan-letter-sealed'),spoken('任萤','我把半边歪字也抄给她，对，我们俩都爱把“北”写成两只脚。','pan-letter-read')],'pan-mail-met',['pan-mail-safe','pan-winter']),
  person('pan-reed-north','只捡退下来的壳给孩子看、收钱却很贵的花墨',18,14,[s('花墨','不是我跟你要三枚，是你跟我这只蟹住店要三枚。它活着，账怎么老找我。'),spoken('花墨','你蹲下来等过一只拖卵的脚。那你收钱确实比我有眼力。','pan-nursery')])],
 [exit(3,11,'winter-court',[23,12],'送完两处来货后回冬岸巷')]);

export const stair=region('fourth-landing','锚断之夜 · 斜在半楼上的第四口厨房',6,'tilted-harbor',43,25,'wood',
 [['water',0,0,17,7,'沿大门倒涌，把矮窗变成唯一水平的出口'],['building',19,0,8,7,'带窑工孩子进来避水的横厨房'],['crane',32,2,8,7,'门框外托着整口锅的底架'],['wall',0,18,13,7,'上游的空阶只能暂放一个转身盘'],['water',27,17,16,8,'只有能停住船的一层才可接下晾工']],
 [['pier',3,10,36,2,'炉门和船门因倾斜变成一高一低两层'],['rope',11,15,17,1,'把端饭小工自己能站的那块板送出来']],
 [witness('pan-evac-call','隔着一扇不能再推的窗问里面的人先要带谁出来',9,11,[s('细沼','我师傅在下层，我在上面。在这里喊所有人往高处走，她就停在身后的门里了。'),s('菇珍','我们是跟回白崖的支援粮筏上的，孩子下船避雨刚在这里坐稳。两种门别认反。')],'pot-tilt-seen',['harbor-tilted','!grave-signed']),
  fixture('pot-evac-low','把小锅挪离炉洞，将孩子的师傅从贴水的矮窗接到外廊',15,11,[s('菇珍','那圈石箍抬得开，手先伸进去，师傅自己跟我挪身。'),s('细沼的师傅','我腿能挪。替我把锅盖交给细沼，这样她知道是我先走。')],'pot-evacuated',['pot-tilt-seen','pot-winter-small','!grave-signed'],{action:{type:'flag',id:'pot-evacuated',set:'pot-lowered-cook'}}),
  fixture('pot-evac-high','利用冬岸已有的整锅底架，托孩子离开变成落口的高窗',21,11,[s('葛庐','托底，靠住她的脚再叫。冬岸那次门从前面接，这一次人从上头下来。'),s('细沼','我站稳。叫下面的师傅从炉台边听：我落下去自己开下层门。')],'pot-evacuated',['pot-tilt-seen','pot-winter-lift','!grave-signed'],{action:{type:'flag',id:'pot-evacuated',set:'pot-lifted-child'}}),
  fixture('pan-evac-runner','在斜坡槽拨回由榉叶旧鞍送来的双轮，供受伤厨工平躺过中阶',29,12,[s('似禾','米拉的船没跟来，轮和会推的手从那船上学过。放这里，她可以不弯腰过歪去的门。')],'pan-evacuated',['pot-tilt-seen','pan-winter-roller','!grave-signed'],{action:{type:'flag',id:'pan-evacuated',set:'pan-carried-cook'}}),
  witness('pan-evac-pole','把桂深迎到暗门，请她从艇头牵窄船到两位工人的脚下',35,11,[s('桂深','我在这里认水。若贴左边的柱，我带你们也上不去。孩子先把脚垂下来。'),s('米拉','这一条是她开过的，舵在她手上。我去下层把路让出来。')],'pan-evacuated',['pot-tilt-seen','pan-winter-lead','!grave-signed'],{action:{type:'flag',id:'pan-evacuated',set:'pan-ferried-pair'}})],
 [exit(3,11,'flood-stair',[10,12],'沿仍在救人的收粮坡退回旧锚场')]);

export const ash=region('after-the-spoon','安葬以后 · 连夜饭都要给人自己盛的渡屋',6,'winter-harbor',38,24,'wood',
 [['building',0,0,10,7,'下屋送壳勺和坡上收冬碗的人家'],['crate',14,2,5,5,'挂旧艇边木或还定钱荷包的墙洞'],['boat',26,1,10,7,'来来去去的居民摆渡船'],['water',0,17,13,7,'第二天仍有自己的内水和外水'],['building',24,17,14,7,'没有挤到墓地边的邮友小屋']],
 [['path',3,10,31,2,'从墓外搭街坊渡回仍有炊工的地方'],['lamp',15,13,1,1,'修壳店留给上门者的晚灯']],
 [person('pot-after-old','把昨天的勺收上来修裂口的旧匠人',8,11,[s('壳匠','有人来送别，有人来吃晚饭。我到现在只知道修勺。你那条老鹅招牌明天来，一天。')]),
  witness('pot-after-low','跟过夜船回来领锅的苇蜓，替她把已没名字的午饭牌还给窑街',15,11,[s('苇蜓','他说可以帮我再刻一块，我说窑口这一季的午钱已经交给别家了。舅还是能从下门端到他那碗。明天补夜饭，我还是来。'),spoken('细沼的师傅','这锅盖我带着绕过白崖低窗。今天亲自给它找个锅用。','pot-lowered-cook')],'pot-home-seen',['pot-low-berth','grave-signed']),
  fixture('pot-after-high','陪灰砚敲自己壳铺的门，等替他看冬店的姚耳开门',22,12,[s('灰砚','这屋钥匙不在我手里。她把那扇吱呀的窗修得好。小狗，你听是谁进门？'),s('姚耳','上坡的冬住处还是你的。桌上我接的活得我做完。你来里边坐，摆渡再开时，我送你回坡上。'),spoken('细沼','那回站在锅架上我没摔。我今天把米箱还给你。','pot-lifted-child')],'pot-home-seen',['pot-kiln-berth','grave-signed']),
  fixture('pan-after-wood','到渡屋踏一下留下的旧榉叶舷片，请来客用脚认叶脉',29,11,[s('米拉','上回躺里头拿衣服挡雨，想的全是能不能去下一座岛。现在每一艘不属于我的船都能越过那块鞍。我有时候还想把它拖下来。'),spoken('似禾','在白崖我们用两轮送出过一个人。你想它的时候，可以来找我坐下。','pan-carried-cook')],'pan-home-seen',['pan-rail-route','grave-signed']),
  witness('pan-after-blank','给看不懂空版的孩子领一次真正有主人的内门',33,13,[s('米拉','这块我把定钱退过。我每次再来还是得叫门。你今晚有没有空领我？'),s('粟殼','明晚。今晚我要回池里看看旧蟹绳。'),spoken('桂深','你在白崖也肯松那支橹。我明晚刚好换班，给你留一刻。','pan-ferried-pair')],'pan-home-seen',['pan-guest-route','grave-signed'])],
 [exit(3,11,'burial-cape',[15,11],'从渡屋回能看到两行碑的海坡')]);
