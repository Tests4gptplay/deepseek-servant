import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';

export const berth=(id,name,act,w,h,blocks,land,people,edges)=>region(id,name,act,'whale-interior',w,h,'wood',blocks,land,people,edges);
export const inTime=['!winter-welcome'];
export const invited=['heel-let-in',...inTime];
export const hall=berth('heel-hall','亮灯空城 · 两面灶门的折腰弄',2,39,26,
 [['building',0,0,10,8,'雁折家修木屐的铺子，侧窗仍在营业'],['wall',13,0,5,9,'原舱肋向右搁在灶楣'],['building',21,1,7,7,'挑干盐蛏的两户人家'],['wall',32,0,7,8,'整扇门向内压斜'],['water',0,18,13,8,'同一层旧黑水带顺舱皮往低处走'],['building',17,19,7,7,'一半是床头一半作地面的转角小室'],['crate',29,19,10,7,'木屐匠分清左右的斜底木']],
 [['path',3,11,32,3,'一条屋门高一条脚洞低的旧居通廊'],['heel-frame',6,9,4,2,'先看原门楣与黑水带的交点'],['heel-frame',26,10,4,2,'同一水带到了这扇门的把手上'],['heel-stair',14,14,4,2,'侧着伸出舱壁、如今不再朝上的阶']],
 [witness('heel-shopkeeper','替穿斜底屐的客人试跟的雁折',8,12,[s('雁折','这只屐要从脚跟刨，不能叫人把腿站直了来合我的鞋。小时候家里那扇门倒了，门把搁到我膝盖高。今天我想把它的手窝翻出来，给我娘做一根不磨虎口的把。'),
 s('玛拉','我随晏禾的送葬船来。这里有人记得他开过的船。我该怎样进？'),
 s('玛拉','站在谁的一边说？',[{text:'替你扶住门脚，家里的话由你决定给谁听',set:{'heel-private-ask':true,'heel-let-in':true}},{text:'请你在大家面前指出当年他救了谁',set:'heel-no-public'}]),
 spoken('雁折','把人叫齐就是作证了？我不当人证。你可以照原闸走。若你肯叫围观的人散开，又真把井嫂的床稳好，我才愿再谈修门。','heel-no-public'),
 spoken('雁折','你进来。先看左右灶门上的黑盐，不要踩躺下的那块门板，它下面有人煮汤。','heel-private-ask')],'heel-met',['ward-story',...inTime],{after:[s('雁折','住人的门我来开。路过我们的人可以照常去风琴闸。')]}),
 witness('heel-come-quiet','请门口看热闹的街坊散开，再把楔头交还井嫂',11,14,[s('邻人','我走了。她家里死过人，她还要坐在门口做鞋。'),
 s('雁折','你把井嫂的床垫实了，也没把她喊来帮你说好话。这回只进来帮我拆门，行。我要下梯时会叫你。')],'heel-let-in',['heel-no-public','bar-freed',...inTime]),
 fixture('heel-left-line','看左灶边门楣下烘黑的盐带',15,11,[s('伊沃','烟味在楣上，盐在下一掌。那年落水后，油渍把盐余下的花护住了。悬一颗纽扣，看它自然垂下。')],'heel-upper-salt',invited),
 fixture('heel-right-line','在另一户檐下和纽扣等高处摸同一道旧盐花',28,13,[s('玛拉','烟往上熏，水带却斜着切过门把。用那枚垂扣当直，水面并没歪，是两家的地板换过方向。'),
 s('雁折','白地板上三颗灰钉去高脚洞；盐一直咬到门把底下的是长床边。我的脚小时候走上面，我哥留在下面。')],'heel-leveled',['heel-upper-salt',...invited]),
 person('heel-nut-ear','给左右木屐刻不同耳朵的淘岚',22,14,[s('淘岚','脚趾冻了我也能穿对屐：左耳圆、右耳缺。鞋做得一样齐整，摸起来就全是右脚。'),spoken('淘岚','你瞧水带不是为了把两只鞋都垫一样高。底本来就不一样。','heel-leveled')]),
 person('heel-clam-stove','把蛏壳晒在窗扇上的藻婶',32,14,[s('藻婶','上层借我家的窗晒壳，下层借我家的灶烟烘衣。大家都在，别一进来就压着嗓子给活人守丧。')])],
 [exit(3,12,'crib-hold',[19,8],'回仍有人过日子的铺床巷'),exit(32,11,'heel-high-sill',[4,11],'顺白地板的三枚灰钉去曾经的孩子高窗',['heel-leveled',...inTime]),exit(23,16,'heel-low-turn',[4,12],'沿浸到门把的黑盐下长床回转间',['heel-leveled',...inTime])]);
