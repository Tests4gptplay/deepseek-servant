import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {tidePost} from './district.mjs';

export const mouth=region('lee-mouth','冬岸 · 碎浪门',5,'winter-coast',29,19,'stone',
 [['water',0,0,29,4,'风卷白顶海'],['wall',3,5,4,5,'歪碎浪牙'],['wall',17,4,5,4,'迎风岩'],['building',1,13,6,5,'雪蓑驿棚'],['water',21,13,8,6,'暗涌口']],
 [['pier',6,10,17,2,'冬季悬桥'],['rope',12,6,1,8,'迎风布带'],['lamp',22,9,1,1,'废口笛']],
 [fixture('outer-wind','从碎浪外牙解下打横的布',11,8,[s('伊沃','船头向岸，风还是从耳后打进领口。在这儿停，夜里外浪会回头推船。'),s('米拉','我把没有遮挡这一格记下来。下一个样本必须同一方向。')],'wind-exposed'),
 witness('wave-host','拾波骨的拜蓝',9,11,[s('拜蓝','你们从南港来，风小时这里像样极了。上回抢救淡水桶，盖子全朝悬崖飞。先试外牙，再去内侧风带。')],'winter-welcome'),
 tidePost('mouth-clock',20,11)],
 [exit(2,9,'wreck-slope',[21,12],'回北标搁船坡'),exit(25,9,'lee-ridge',[2,8],'上背风脊'),exit(12,16,'winter-court',[3,10],'绕背脊走石墙去冬村')]);
export const ridge=region('lee-ridge','冬岸 · 两侧风带',5,'winter-coast',22,16,'stone',
 [['wall',1,1,6,4,'高覆冰檐'],['wall',12,1,8,3,'鱼骨石屏'],['water',0,12,8,4,'回风积冰'],['crate',15,10,4,4,'冬村收绳器']],
 [['rope',6,8,9,1,'与外牙等高的鱼线布'],['lamp',13,6,1,1,'看风灯']],
 [fixture('inner-wind','把同一块布绑到背脊等高桩',10,8,[s('伊沃','簇带垂下来，灯的火头直立。位置和高度有记录。'),s('瑟琳','这能说明这里挡同一阵风，不能证明整岸每夜安稳。留根替绳给下个月的人。')],'lee-proved',['wind-exposed']),
 fixture('porch-chain','把看风铃转向内门',14,9,[s('伊沃','风向变了先响住户的内门。旧港连近远两个人都没给钥匙，我想从这座门补起。')],'winter-bell',['lee-proved','remote-lit']),
 person('ice-dyer','给网坠染色的乌栾',7,7,[s('乌栾','白线是给回家的鱼船，黑线留给没看懂的人。你画问号也行，别把一阵无风画成房屋。')])],
 [exit(1,8,'lee-mouth',[24,9],'下脊回碎浪门'),exit(20,8,'winter-court',[3,6],'下干燥鱼市'),exit(13,14,'fresh-gallery',[3,7],'沿内崖进入融雪涵洞',['lee-proved'])]);
export const water=region('fresh-gallery','冬岸 · 双水芯涵洞',5,'winter-interior',24,17,'stone',
 [['wall',0,0,24,2,'冰窟岩顶'],['water',3,3,6,4,'低泉盐水眼'],['water',15,3,7,5,'雪层岩缝'],['crate',16,12,6,5,'空陶滤罐']],
 [['pier',2,8,20,2,'抽检木桥'],['rope',10,5,1,7,'旧盐水尺'],['lamp',12,10,1,1,'白布晾样灯']],
 [fixture('salt-wick','在下游白泉留第一根棉芯',8,8,[s('瑟琳','滚一圈有细盐，让水进嘴会更渴。港口的人见到白水就说能喝，在这儿会被它骗到第二天。')],'wick-salt'),
 fixture('clear-runnel','绕岩屏接上游滴水',18,9,[s('玛拉','同样一段棉芯，另一端晒干不见盐，石缝在旧潮线以上。'),s('瑟琳','我担保今天取到淡水。把半罐留原处，让下一班复尝。')],'fresh-proved',['wick-salt']),
 fixture('cistern-seal','给空陶罐封布让病人能喝',13,12,[s('玛拉','盖沿垫布，挑担时不再溅进旧井水。每罐只刻两个刻口：清洗、灌满。')],'water-casks',['fresh-proved','west-stairs'])],
 [exit(2,7,'lee-ridge',[12,14],'回背风坡'),exit(22,10,'winter-court',[19,8],'穿运罐巷到冬院')]);