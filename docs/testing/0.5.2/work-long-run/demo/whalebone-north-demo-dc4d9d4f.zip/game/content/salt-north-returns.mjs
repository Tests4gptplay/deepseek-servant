import {fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,flag} from './parts.mjs';
import {setting} from './registry-parts.mjs';

export const saltFamily=[
 witness('family-refuses','在门后把原票收起来的沙荷',6,9,[s('瑟琳','娘，秤上我已经听清。你愿不愿把做过的事写给不识字的工友？'),s('沙荷','现在不愿。有人看见我的签名就说三袋都是我吃的。你真要帮忙，先去无字凭窗。仲寻自己会告诉你他要什么。'),s('玛拉','拒绝就是今天的答复。图上只记屋门朝里，不记门里有谁。'),s('沙荷','再来的时候，拿他试摸过的那块边板。我的名字不能离开我的手。')],'ticket-mother-heard',['ticket-date']),
 person('family-invites','请沙荷亲手挑出能流转的板面',19,8,[s('沙荷','这道窄边，我闭着眼睛也能认。仲寻说得对：念一遍给他听，不等于他能自己拿去算。'),s('瑟琳','你仍然可以只留家里。持张板不等于应了供证。'),s('沙荷','原票留家里。副板我愿给轮饭的人，只是后续怎么办，得有人肯担。你能陪我走哪条？',[
 {text:'在家保留实票，补领靠手中边板',set:'family-held'},{text:'让灶头公开批次合数，名字由家里收着',set:'batch-posted'}])],{requires:['board-proved','!board-mislaid'],action:flag('family-choice'),after:[spoken('沙荷','有事得带板来敲门。我今天有力气验，不保证明天也有。','family-held'),spoken('沙荷','贴的是批次。我只准你报十二个实袋，不准你拿我家当一袋。','batch-posted')]}),
 setting('family-revises','从冬岸回来，沙荷重新决定下一轮的副板',13,10,[s('沙荷','他们真能用那两条边了。这一轮我愿意把上一批合数放到窗外，但不许把旧签从家里拿走。'),s('瑟琳','去冬岸前你说的另一套办法还记着。这是你今天亲口答的，不能倒改当时。')],['family-held','board-winter'],{'family-later-public':true})];
export const saltLanding=[
 witness('board-steward','请配餐水手闭眼分出领单和退件',15,9,[s('配餐水手','宽口朝天，窄口贴袖。我摸到两齿是退，三齿是领。刚才那位替我报数字的人，现在可以把手收回去了。'),s('仲寻','他验过了，写“能验”，不写“人人能验”。下一港也得有人自己摸。'),spoken('瑟琳','弹簧柜里只留合计，原票还在我家。','batch-posted'),spoken('瑟琳','谁要看有名的原票，得亲自去敲家门。','family-held')],'board-at-sea',['board-consented'])];
export const saltWinter=[
 witness('board-winter','让冬岸勾婶用无字副板分一轮暖饭',14,11,[s('勾婶','一只窄口是中途下船，两窄口是仓里退件。第一晚我差点给退件又发一碗。现在我会把缺口贴着哪边碗沿。'),s('瑟琳','要是我不在，下一班也能拿自己那面算？'),s('勾婶','我把两只错碗一块传给下班。你母亲该拿她自己的回执，别让我替她决定继续公开多少。'),spoken('勾婶','公开的是批，不是人。今晚两只锅都按同一批次报数。','batch-posted'),spoken('勾婶','我们按住户手中的齿板兑，漏一户就留一枚空楔。','family-held')],'board-winter',['board-at-sea','family-share'])];
export const chartBoat=[
 witness('boat-copy','由押船学徒接下副本及独立的更正格',14,8,[s('学徒','我的本子没原纸的浮铅，那边的原本也听不见我的浪声。我量错自己落格；上岸拿师父的图也能提出异议。'),s('米拉','你若只写“核清”，我还要回来问。把哪一个水深留下。')],'boat-received',['original-ashore','shore-received']),
 witness('boat-original','把原图锁入船头两股传话绳之间',10,11,[s('白瑾','原图我收了。两绳里只断一根，另一根也能把岸上的修正传到艇艉。图湿了，由我押船的分账赔。'),s('米拉','你比我熟这一片，不代表你得替我承担旧图上所有空白。原签应放回我自己那一栏。')],'boat-received',['original-afloat','shore-received'])];
export const chartGrave=[
 witness('chart-returns','安葬后开启有双签的首张改图回信',15,11,[spoken('班枝的信','原图留岸的第一个月，涨潮过了墙脚。高架救了纸，可夜班提修改要等开门。我们让两家轮流拿钥匙。','original-ashore'),spoken('白瑾的信','原图随船过冬。我在二十三日添了第二个暗沙口，岸办先按副本停了两班船才等到复核。停的那两班从我份里折。','original-afloat'),s('米拉','纸袋里两张图，没有一张被叫作最后一张。我现在看见斜刻时，会先问哪双手量过。'),s('玛拉','我也会先问那艘船回过几次，再让名字落到碑上。')],'chart-returned',['boat-received','grave-signed'])];
