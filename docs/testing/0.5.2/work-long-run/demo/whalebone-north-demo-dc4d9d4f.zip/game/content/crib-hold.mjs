import {say as s,person,object,flag,exit} from './parts.mjs';
import {district,tidePost} from './district.mjs';
export const hold=district('crib-hold','亮灯空城 · 舱底铺床巷',2,27,18,'wood',
 [['building',4,0,5,4,'窄房修补铺'],['building',13,0,3,3,'竖床位'],['building',20,0,7,5,'旧药库'],['crate',3,9,4,3,'缝纫台'],['building',18,12,6,6,'侧舱病铺']],
 [['path',0,5,26,3,'抬担架走廊'],['lamp',12,8,1,1,'床头蜡灯'],['water',0,14,10,3,'探水槽']],
 [person('bar-midwife','隔门说话的井嫂',9,6,[s('井嫂','码头上的水是从脚底上来的，屋顶的水是从裂缝往下淋。靠脊的人先下舱，用挡水的鼓腹把产床围住。'),s('玛拉','是你拆的闩？'),s('井嫂','右床脚，裹着布。先垫新楔子再拿，不然你救了门，我这边会摔个人。')],{action:flag('ward-story')}),
 object('underbed-bar','右床脚的横闩',14,8,[s('玛拉','托床，抽旧闩，把三指楔推进去。站在我脚印上，帮我听这床摇不摇。'),s('井嫂','不摇。我给你作证，人是自己搬下来的。')],{requires:['bed-wedge','ward-story'],action:flag('bar-freed'),after:[s('井嫂','门闩拿走了，床腿用的是晒房给的新楔。')] }),
 object('bronze-wick','纺机底的旧灯芯管',6,13,[s('乔的字','灯心烧短时这里先褪色。铜管口磨掉的半圈，配得上舅舅带回来的旧罩。')],{requires:['lamp-vow'],action:flag('wick-traced')}),
 object('stitches-wall','夹墙里没收的针筒',10,11,[s('纱婆','你敲三长，我替你递最后一短。水退时听得清，后面真有一间从没画在总图里的补帆室。')],{requires:['seam-knock','tide:low'],action:flag('seam-open')}),
 tidePost('hold-gauge',16,7),
 object('covered-cot','井嫂匀出的平铺',20,8,[s('井嫂','想睡的人把眼皮放下来就是。有潮响我会用匙敲盆。')],{action:{type:'rest'}})],
 [exit(2,5,'counterlift',[15,13],'低水转筐回屋顶',['tide:low']),exit(17,3,'dry-court',[25,10],'沿高廊上晒衣院'),exit(25,9,'organ-lock',[2,9],'带横闩入风琴闸',['bar-freed']),exit(11,15,'seam-cell',[5,6],'退潮钻过补帆夹墙',['seam-open','tide:low'])]);
