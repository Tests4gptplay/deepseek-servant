import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit,flag} from './parts.mjs';
import {setting} from './registry-parts.mjs';
import {tidePost} from './district.mjs';

export const boiler=region('boiler-stair','白崖 · 公洗梯的夜蒸锅',1,'harbor',30,21,'stone',
 [['building',1,1,7,5,'箱铺和白天熨领的棚'],['wall',12,0,4,7,'接雨和潮水分开的双砖槽'],['water',20,0,10,7,'海水沿石阶向北上涌'],['wall',1,14,8,6,'潮湿货布的大熨台'],['crate',19,14,9,6,'公灶楼下收被褥的传台']],
 [['stairs',9,6,4,8,'石阶朝货驳逐级降低'],['hearth',4,15,2,1,'伸着湿布夹的暖灶'],['rope',4,13,8,1,'晾在蒸锅外的被毡'],['path',4,9,22,2,'两侧印着木鞋底的石坡'],['rope',13,12,8,1,'挂着三只试水杯的粗麻绳'],['lamp',18,8,1,1,'给盲夜工找气口的标灯']],
 [witness('drum-washer','夜洗班的老乡·粉葛',8,9,[s('粉葛','嚯！倒一锅好衣烫成硬片！他们说我们买错皂角，你把胳膊伸出来，烟一冒全是海腥。'),s('玛拉','烟不是海水，得找东西试。有哪一缸洗出来不扎人？'),s('粉葛','灶下面两条管共一根外包皮。开小管，药房的绷带洗得软；开大管，工人能赶在早班前把整床毡煮干净。先别说开哪头。')],'washer-asks',['vigil-finished'],{after:[spoken('粉葛','你选的慢管，半包细布救了病人的皮。剩下的床毡我和老崔轮洗，多了一晚。','wash-bandages'),spoken('粉葛','大锅把工人全副冬毡救回来了。绷带不进这儿，改让药房收东井的细水。','wash-blankets'),s('粉葛','能开多少算多少，回来告诉我哪一缸不腥。')]}),
 fixture('wash-top-cup','摸靠楼檐的三只杯底',13,8,[s('杯底的水线','最靠海的杯边粗，居中的杯口落着白粉，贴楼的一只只在背雨的一侧有水迹。'),s('粉葛','你觉得哪只淡？别尝给病人用的水，我这儿还有从药房讨来的皂角。下道槽也拿一份。')],'upper-cup',['washer-asks']),
 tidePost('wash-tide',16,10),
 person('wash-baby','抱着过长旧毡的夜班爹·卷树',11,12,[s('卷树','我们小的不是怕盐，是怕半夜爹还没回去。谁要是再对我讲一遍勤快生财，我就把这二十斤湿毡挂他脖子上。'),spoken('卷树','毡暖不暖她自己会踢。你摸背上，无汗就行。','wash-blankets')])],
 [exit(3,9,'shift-square',[25,8],'沿箱铺回三班场'),exit(26,10,'laundry-pit',[3,9],'跟着包在同一麻皮里的管子下坡',['upper-cup'])]);
export const pit=region('laundry-pit','白崖 · 石斛房下的渗水井',1,'harbor-interior',27,18,'stone',
 [['wall',0,0,27,2,'上沿常年白干的涵洞'],['water',2,2,6,5,'沉着黑砂的海槽'],['wall',13,2,7,5,'靠岩面才见草根的清井墙'],['wall',19,13,8,5,'拉不动时可松回的翻斗水门']],
 [['path',3,8,20,2,'东西两根水管交叉的低台'],['pier',9,5,3,8,'能走到水门外耳的短木桥'],['crate',20,14,2,1,'灶工沿井壁排的干草袋'],['rope',12,11,10,1,'两端可重新挂接的试水绳']],
 [witness('wash-soapmaker','剖皂角的残齿药工·旻子',8,9,[s('旻子','别指着白的叫盐。我们烧贝壳补土，也白。皂角在海水里趴着，在淡水里立沫；从各自的出口洗这根绳，手才知道。'),s('玛拉','高水先堵了哪边，低水从哪边漏出来。我要带两种沫回去。')],'soap-given',['upper-cup']),
 tidePost('pit-tide',11,9),
 setting('wash-west','把试绳解开扣到西井的黑砂槽',7,10,[s('旻子','草渣顺着外潮进来，到涨潮时试它。绳头松不开也能在东耳重挂。')],['soap-given'],{'sample-sea':true,'sample-rain':false}),
 setting('wash-east','把同一根试绳改扣东面的草根出水嘴',17,9,[s('旻子','退水时岩缝里才有一线水。不要舀积在井底的。')],['soap-given'],{'sample-sea':false,'sample-rain':true}),
 fixture('seawash-foam','取涨潮时西槽的浮沫',8,11,[s('玛拉','皂沫一会就塌成星点。拿到檐上杯底对一对；单看白色，看不出哪条管反接了。')],'salty-foam',['sample-sea','tide:high'],{lockedText:'西槽要等水漫过黑砂，再把试绳挂回西耳。楼上楼下都可等潮。'}),
 fixture('rainwash-foam','取退潮时井壁新出的半绳水',17,11,[s('旻子','沫站得住。不是我舌头灵。我缺三颗门牙，尝起来天下水都一样苦。')],'fresh-foam',['sample-rain','tide:low'],{lockedText:'东缝须露出草根方可试。若流不到试绳，去东边重新挂接。'}),
 person('wash-choice','让两个当班人定今夜的出水口',13,10,[s('粉葛','我亲自试过，两边的人都等着。慢管洗药布，大管煮毡。明早我还站着，肯认其中一头晚了一班。',[{text:'接细管，先把已拆封的药布洗净',set:'wash-bandages'},{text:'接整锅，先把夜班全床毡赶在起工前洗好',set:'wash-blankets'}]),s('旻子','我给另一头留一份真话，轮不到的别瞒。')],{requires:['salty-foam','fresh-foam'],action:flag('wash-sorted'),after:[s('旻子','在第三班粮趸找两位等衣的人。说煮过了没有用，要拿到身上才叫一件事。')]})],
 [exit(3,10,'boiler-stair',[25,10],'携两头试绳回洗梯')]);
export const washReceipt=witness('wash-actual','第三班亲手收细布或暖毡的人',19,9,[spoken('卷树','大锅很快，那些毡我一床一床卷。不是谁凭钱认领，是哪家从哪铺起身就还给哪家。','wash-blankets'),spoken('旻子','给我五寸布，我现场试一试。上个月我拿硬布包手，三天连疤一块揭下来。这次小指能透过来。','wash-bandages'),s('粉葛','明天要是别班说我们偷懒，把我的湿围裙丢给他们。')],'wash-handed',['wash-sorted','berth-fixed']);
