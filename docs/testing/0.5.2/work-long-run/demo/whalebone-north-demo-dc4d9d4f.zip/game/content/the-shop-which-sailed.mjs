import {say as s,person,exit} from './parts.mjs';
import {fixture,witness,spoken} from './voyage-parts.mjs';
import {mechanism,tidePost} from './district.mjs';
import {setting} from './registry-parts.mjs';

export const westCase={
 'west-lamp':[
  witness('drawer-two-stories','在西窗收绳处把沿街来寻药铺的两位证人分开听',6,8,[s('卖酸李的段峭','那天航门都关了，我还在旧街给短芹送过梅子。她屋里碾子照旧吱得叫人牙酸。我敢说，这家铺没走。'),s('从盐市来的歧米','我爹那时还不认识我娘，在运粮驳上接过一整家蓝脸药铺，十二个抽屉一个不缺。要是没走，他背的是谁家的铺？'),s('伊沃','当年有人报“店到了”，我给原街的那户划了圈。屋顶那边在等放航，我没回去看过那户的手。'),s('玛拉','我们从说有碾声的那间屋子往下走，再从有东西上船的地方走回来。两个人都能再问，不必现在选谁撒谎。')],'drawer-open',['light-replay','!harbor-truth']),
  person('drawer-west-index','剥着第三只酸梅仍没想起收钱的段峭',12,12,[s('段峭','要再问那人，晒衣院东墙脚坐着我姐姐，窄房的旧药库里是短芹自己。赶粮船的在外排班那面披屋下换袜。你见着件东西，带回去问活人。'),spoken('段峭','她肯留你看碾心，就问她磨到哪一边会低头。生意人有些顺手的动作，说名字倒不一定记得。','drawer-open'),spoken('歧米','我现在在盐市的票作给人抄短笺。别在我爹背后问我，你跟我说就得。','harbor-truth')]),
  witness('drawer-ivo-names','回到伊沃当年画圈的位置，分开说什么上了船、谁没被问到',15,7,[spoken('伊沃','我们确实推着上半柜走过了。我原先说“全铺过去了”，可那碾心还在我手上磨出一圈灰。','drawer-land-proof'),spoken('伊沃','水上运的是会浮的上半柜。短芹没在里头，我去摸过原石的阴面。','drawer-water-proof'),s('歧米','别说我爹编话。他接的是门脸和十二抽。'),s('伊沃','我关的是求救航门，仍准货物贴着侧舷通行。我把“铺具已运”当作“住户已迁”，没有回去问短芹。划圈的手是我的。远门那盏没有回报的灯仍然没有回报，不能拿她去填。'),s('玛拉','把空碾和有人守着的那户都交还给盐市。抵岸的物件替不了抵岸的人。')],'drawer-ivo-spoke',['drawer-proved','!harbor-truth'])],
 'dry-court':[
  witness('drawer-plum-witness','从东墙晒衣绳背面走到分酸梅的邻居面前',15,9,[s('老陶匾','那天碾子响了半刻，我亲眼看见短芹左手捏着梅核。卖梅的偷偷多抓一把，她正要骂，屋里的灯影就往门外去。'),s('玛拉','你看见她走出去了吗？'),s('老陶匾','我看见那块蓝门脸往外去。她还在里头骂我，足足骂完一句。你要叫我再说十遍，我还是只说这两样。')],'drawer-home-voice',['drawer-open','!harbor-truth'],{after:[s('老陶匾','人还在里头，蓝门脸已经出去了。旧药库在铺床巷，过里面的窄门往右找石碾。')]}),
  person('drawer-plum-seller','数篮底被孩子先舔过的梅子',21,11,[s('小贩','鹅吃梅不吐核，人吃梅得吐。你要证明你是人吗？买一粒。'),spoken('老陶匾','我坐这儿。口供是我的，问第二遍也不加钱。','drawer-open'),spoken('老陶匾','要再听我自己说，那夜蓝门脸出了院，她在里面还骂完一句。我没有看见人跟它出门。','harbor-truth'),spoken('小贩','短芹托人带回一块抽屉拉手，摸过就知道哪一味货没到了。','drawer-shop-back'),spoken('老陶匾','那孩子跟潮班走，回来给我捎了咸的。天下究竟谁腌酸梅还肯加盐。','drawer-wage-back')])],
 'crib-hold':[
  witness('drawer-short-parsley','进原旧药库蹲到碾台左侧，请短芹磨一次孙女嫌苦的海茴籽',9,9,[s('短芹','谁爱往凉糖里添这味，我跟他没完。你闻到的是我这边磨的香籽，孙女在外头卖的是甜的。'),s('伊沃','你说那夜你留在了这里。'),s('短芹','我是进过你们港的船仓，可我进的是下一年。那晚开不开门是你的差事，在不在家你倒可以问我。摸一下这块石头的内圈，别摸还转的边。')],'drawer-grinder-met',['drawer-open','!harbor-truth'],{after:[s('短芹','地脚在左，门脸在右。去晒衣院问老陶匾，把箱子和在里头做活的人分开。')]}),
  fixture('drawer-heel','从阴面绕到地脚，沿石碾心绕过有一截不响的半月缺',18,10,[s('石碾','半月里光滑，外边一条圆痕一直切到地板下面。石心长在下座；蓝抽柜的榫脚落在另一排浅槽里。'),s('短芹','磨到月缺，我就低头给它添一把。你从外头看见我低头，以为人跟柜子一起沉下去。'),s('玛拉','是两个实物。现在要试一试，当时封着航门，其中哪样还真能过。')],'drawer-fixed-base',['drawer-grinder-met']),
  person('drawer-counter-child','爱给药柜各个空格起人名的孩子',24,8,[s('小簪','大抽叫狗，二抽叫提头，三抽没名字。外婆把芝麻藏三抽，我不给它告诉别人。'),spoken('小簪','梅贩婆坐晒衣院。问门脸何时过的，外排披屋舅舅那只袜子还没拧干。','drawer-open')]),
  setting('drawer-try-land','将蓝柜空架顺着穿舱的窄轮放低，准备试反提梯',15,7,[s('伊沃','地脚没上车。我们让空柜自己过两道门，车尾若过不去就退回来换水路。')],['drawer-fixed-base','drawer-home-voice','!drawer-proved'],{'drawer-land-mode':true,'drawer-water-mode':false,'drawer-floated':false,'drawer-high-sight':false}),
  setting('drawer-try-water','把空柜拉回旧药库外侧的侧舷口，去试驳船吃水',21,11,[s('歧米','我爹接东西先摸它的底。小艇上不能趴着摸，涨到舷口才看得见柜底有没有石心。你也能回来换梯。')],['drawer-fixed-base','drawer-home-voice','!drawer-proved'],{'drawer-land-mode':false,'drawer-water-mode':true,'drawer-land-pass':false,'drawer-cart-clue':false}),
  fixture('drawer-float-it','在水高到药库外沿时把空柜横移上实际的过舷坡',6,12,[s('玛拉','柜子浮起，碾轴仍在地板下面。低一点就会磕到篷头，高起来才肯从侧舷出去。')],'drawer-floated',['drawer-water-mode','tide:high','!drawer-proved'])],
 'counterlift':[
  fixture('drawer-cross-lip','从原反提踏台下面摸到三条短轮印和一块没有磨动过的石皮',9,9,[s('掌梯人片耐','当夜我挪开过横筐。深槽里三道轮痕，只在内角消失。你要是拿整家店来，第四个角总要撞一下。'),s('伊沃','让一半先转过来，另一半留在能退回去的位置。')],'drawer-cart-clue',['drawer-land-mode','lift-proved','!drawer-proved']),
  mechanism('drawer-turn-upper','自己推柜角过反提井，学会只让上半柜通过窄口',18,10,[s('片耐','把车放回去不罚钱。问药库里的人，地脚长在哪一侧。')],['drawer-land-mode','drawer-cart-clue','drawer-fixed-base','!drawer-proved'],'drawer-land-pass','窄门只擦过三个短轮。怎样也不拖走地上那圈月缺？',['连下面石座一起推上井口，让四角硬挤过去','从柜外侧向旧门横推，让碾心去撞窄头','留石心在屋里，只把蓝抽柜的窄边先转过门框'],2,'不响的一齿在地上，不能抬走。三轮在柜脚，狭处容短边先转。',[s('片耐','擦到原来那一小块蓝。能过去的是十二只抽屉上面那张脸，不是地脚。')])],
 'whale-roofs':[
  fixture('drawer-look-down','回原钩铃屋脊，弯腰看上半柜从晒衣院后出、原屋的人仍绕石心低头',18,10,[s('段峭','我就站你这片瓦上面。柜头出了院子，她还在原屋，一下、两下地低头磨。'),s('伊沃','这两件事真能同时发生。我当年闭门后没回到屋顶来核它。')],'drawer-land-proof',['drawer-land-mode','drawer-land-pass','!drawer-proved'],{action:{type:'flag',id:'drawer-land-proof',set:'drawer-proved'}})],
 'outside-row':[
  witness('drawer-sailor','在披屋远端找仍把干袜踩在湿鞋里的驳船工',18,8,[s('驳船工关薏','十二只蓝抽全给我接过。有药铺两个字。我没有接过哪个女人上船；我眼睛在柜子下面，两只手都托着它。'),s('伊沃','你看得见柜底？'),s('关薏','涨到我鼻头这高度，就看得见哪处在渗。退下去，舷边压到原来的水印，就该把它放下。')],'drawer-cargo-voice',['drawer-open','!harbor-truth'],{after:[s('关薏','问我几遍都一样。高点看底，低点找船上沾过柜脚的蓝。')]}),
  fixture('drawer-catch-corner','从过舷坡接到蓝柜的盐白底，分清哪一边留下了空槽',24,10,[s('玛拉','两边榫槽都是轻的。我的手能往柜底中间穿过去，石心若在这里，手腕就要顶住。'),s('歧米','这高度从岸上看，外面就是整扇蓝脸。')],'drawer-high-sight',['drawer-floated','drawer-water-mode','drawer-cargo-voice','tide:high','!drawer-proved']),
  tidePost('drawer-outer-gauge',18,12),
  fixture('drawer-blue-sill','等水落到底沿，踩上干出的货汊，找到只同上柜相合的两个蓝脚印',21,11,[s('歧米','左右脚蓝斑偏在一角。我家的船壁就这么高，没装过一块到地板下才收住的碾轴。'),s('玛拉','柜子过去、磨药的人留下，两边的证词都能原样安放。')],'drawer-water-proof',['drawer-water-mode','drawer-high-sight','drawer-fixed-base','tide:low','!drawer-proved'],{action:{type:'flag',id:'drawer-water-proof',set:'drawer-proved'}})]
};
export const drawerWestExits={
 'crib-hold':[exit(3,7,'outside-row',[23,10],'满潮随上半柜越过旧药库的过舷货坡',['drawer-floated','drawer-water-mode','tide:high'])],
 'outside-row':[exit(27,9,'crib-hold',[5,12],'从潮边空下来的窄货坡回到原药库',['drawer-floated','drawer-water-mode','tide:low'])]
};
