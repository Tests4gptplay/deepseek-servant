import {fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {origin} from './the-sleeve-and-the-spray.mjs';
import {beam} from './the-grey-broadside.mjs';
import {blind} from './the-sheltered-backbearing.mjs';
import {landing} from './the-blue-spat-at-scoring-rock.mjs';

export const scoreMaps=[origin,beam,blind,landing];
const extra={
 'deep-sluice':[
  witness('score-regular','照旧航的夜班领船人蒲垛',18,10,[s('蒲垛','北边有一双母女各管一张梭。我们原红标能通，可大船不能为一小片苗架折返。随原班，就把灰篆轻艇的鼻位让给别人。'),
  s('米拉','让我先想想。需不需要去，得由我自己走到哪条船上表明。')],'score-heard-ordinary',['north-chart','!score-surveyed','!winter-welcome']),
  fixture('score-book-old','回到原红标班船，让出本次观测艇的鼻位',15,10,[s('蒲垛','你脚踩回红标班船，小艇就能换人。'),s('米拉','灰艇先让别人。我们只为亲走的原线说话。')],'score-regular-chosen',['score-heard-ordinary','!score-surveyed','!winter-welcome'],{after:[s('蒲垛','鼻位已经给别人。粮船原红标仍在。')]})],
 'scorerock-origin':[
  fixture('score-mother-rope','船尾下第一条麻须母绳',24,14,[s('葛芮','先把有苗的软枝并在旧麻旁，让它自己粘；捏那条透明的丝，它便再也系不住。'),
  s('玛拉','我扶浮弓，不扶壳。一只，两只……小蓝粒没跟着弓离开，都在底下一点一点张开。'),
  s('葛芮','我先在这儿过这一夜。你替我去看她造的东西。告诉她，我没叫她把梭拆了。')],'score-mother-fixed',['score-return-order','!winter-welcome'])],
 'lee-mouth':[
  witness('score-winter-transfer','冬口接艇的槿陶',18,10,[s('槿陶','我想先试过我的东西，再给我娘看。我在前面划；她要真来了，让她坐我不惯用的那半边。'),
  s('葛芮','我过来了。你把缆松给我？'),s('槿陶','缆我松。你肯空着手坐一趟就成。她从没坐过我的船。')],'score-mother-arrived',['winter-welcome','score-spat-freed']),
  person('score-follow-on','冬岸靠桩的左手梭艇',15,10,[s('槿陶','这条船贴岸走。没赶上头班也能走下一班，旧红标照样有人守，不会因为谁没来就没有明早。'),
  spoken('槿陶','蒲垛带的那一班我认得；他只走原灯，别问他挡石里面的水。','score-regular-chosen'),
  spoken('槿陶','你实测过可通的角度。船有没有回去托住苗，仍是另一回事。',['score-surveyed','!score-mother-fixed','!score-mother-arrived'])])],
 'winter-court':[
  witness('score-blue-fingers','槿陶与滴水的旧浮梳',18,8,[s('槿陶','手边的梭你可以摸。你回去了，是吗？听说你们从水里把小壳托动，没拿手去掐它。'),
  s('玛拉','你娘留在那儿等第一夜。她说，没叫你把梭拆了。'),s('槿陶','那我明年春天就能用她的蓝壳磨漆了。第一趟我照样带了邻居，连笨梭卡多久都有人跟我笑。')],'score-return-echo',['score-mother-fixed','winter-welcome']),
  fixture('score-left-stroke','槿陶的左手纬梭',24,8,[s('槿陶','我右脚抵住艇鼻，左手从海侧向里回梭。娘，先别帮我扳过去。'),
  s('葛芮','我当了三十年舵手，还不知道空着的手往哪儿放。'),s('槿陶','搁腿上就行。船是向右歪，我知道。'),
  s('米拉','头一趟整匹布偏了三指。母亲没有拆，女儿也没有假装肩头没发酸。')],'score-forward-echo',['score-mother-arrived','winter-welcome']),
  witness('score-share-lines','槿陶掌纹里的两道方位',21,8,[s('米拉','横过和回望，哪张你都自己拿。旧图背面的东西在你娘手上。'),
  s('槿陶','够了。那道朱线是我画的，九岁差点拿它剪一朵小花。头一回有人肯留我画错的一笔。')],'score-daughter-chart',['score-permission','winter-welcome']),
  person('score-dry-fringe','在四炉院晾第一匹斜布的槿陶',12,8,[s('槿陶','新织的布先给这里晾。旧红标的船也能接我的活，不必先捎来一家人的故事。'),
  spoken('槿陶','你走了蒲垛的原路，肯说没亲测。谢谢，就用这条旧航给我送梭。','score-regular-chosen'),
  spoken('槿陶','没走过石背？有人是为了粮船来的。我这条左手梭随你看。',['!score-surveyed','!score-regular-chosen']),
  spoken('槿陶','你自己走过新线，却没有替我们做完那桩事。我喜欢你会把这两句分开说。',['score-surveyed','!score-mother-fixed','!score-mother-arrived'])])]
};
const hint='从旧图的趾窝看见一次白喷。横测要锁住双桨；走石背要放浮弓、转身看船尾。两条都能回，抵冬岸见到拜蓝后海上的工作已换班。';
export function withScore(map){
 const additions=(extra[map.id]||[]).map(e=>e.requires?{...e,lockedText:hint}:e);
 let ents=map.entities;
 if(map.id.startsWith('scorerock-'))ents=ents.map(e=>({...e,lockedText:e.lockedText||hint}));
 const entrances=map.id==='deep-sluice'?[{...exit(18,6,'scorerock-origin',[4,11],'从深槽转入葛芮的正船原观测位',['north-chart','party:mira','!score-regular-chosen','!winter-welcome']),lockedText:'须有米拉同船。若已随原红标，或在冬岸见过拜蓝，这班小艇已换工。'}]:[];
 if(!additions.length&&!entrances.length&&ents===map.entities)return map;
 return {...map,entities:[...ents,...additions],exits:[...map.exits,...entrances]};
}
const arcs=[
 ['how-one-line-was-true','九岁时从正船看到的那一条线','side',['score-invited','score-first-crest','score-surveyed','score-price','score-job-chosen']],
 ['a-chart-of-two-views','留在两道方位之间的一根头发','hidden',['score-beam-sailed','score-lee-sailed','score-permission','score-daughter-chart']]
];
export const scoreQuests=Object.fromEntries(arcs.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
