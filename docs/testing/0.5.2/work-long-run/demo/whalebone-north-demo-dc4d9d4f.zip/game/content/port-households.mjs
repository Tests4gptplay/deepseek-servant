import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit,object,flag} from './parts.mjs';

export const portDesk=region('port-desk','白崖 · 二班过秤台',1,'harbor',23,16,'wood',
 [['building',1,1,6,4,'临运交割室'],['crate',10,1,5,4,'待核工时的小箱'],['water',15,10,8,6,'绕过鲸尾的岸水'],['building',2,11,5,5,'乙班洗手棚']],
 [['pier',2,7,18,2,'高低两层相会的签台'],['lamp',15,6,1,1,'第二班蓝灯']],
 [witness('shift-receipt','从渡口回来收班的邝二',11,8,[spoken('邝二','井口有红卡舌压痕，底端有轮轴上来的黑泥。两边都做过活，表上给两班各记一次。','port-counter-way'),spoken('邝二','檐灯照见担纸的人过来。棚主留得干衣孔，制船人也拿到了人手单。两头的活该分开记。','port-roof-way'),s('玛拉','我签送到时辰。不能替没在场的人签领过。')],'shift-receipted',['shift-handed']),
 person('change-runner','换班后仍在擦手的栀婶',8,9,[s('栀婶','手上的黑不是我搬过的货。我守取物柜，一班过后光数人的归还签，就能袖口洗半天。')])],
 [exit(2,8,'counter-gantry',[14,8],'沿已修的上层回井',['port-counter-way']),exit(3,9,'pallet-drain',[19,9],'低台回配重房',['port-counter-way']),exit(14,5,'awning-rafters',[22,7],'沿已通雨檐回帽坊',['port-roof-way']),exit(20,8,'trim-yard',[3,9],'携工时签进肋木场',['shift-receipted']),exit(9,13,'late-canteen',[3,8],'随第三班去夜灶',['berth-fixed'])]);

export const wash=region('mourning-wash','白崖 · 洗麻屋与烟槽',1,'harbor-interior',22,16,'stone',
 [['building',1,1,6,4,'还家衣的白柜'],['water',11,2,7,5,'洗灰的冷槽'],['crate',16,10,6,5,'遇难后余下的衣料']],
 [['rope',4,7,13,1,'不写姓名的晾绳'],['lamp',9,9,1,1,'补衣人用的矮灯']],
 [witness('cloth-mender','守布柜的黎婵',8,7,[s('黎婵','你要找砚叔的弟弟，别给我一个死人的年纪。我想知道他下工把袖子往哪一侧拧。'),s('玛拉','往里拧。你搓洗时外层烟渍还在，内折有一条油线。'),s('黎婵','认对衣，不等于替他家认领该怎样下葬。拿我的灯去看干痕。')],'cloth-matched',['cloth-offered']),
 fixture('smoke-fold','展开袖口，用灯从里面照油线',13,8,[s('玛拉','油线朝左拐，旧伤在手背。烟渍是公炉熏上的，不是遇难那天的灰。给家属让出说话的地方。')],'cloth-fold',['cloth-matched']),
 person('ash-girl','用淘米水褪墨的学徒',6,9,[s('学徒','我早晨数衣查霉，最晚给送走孩子的人留热水。谁的衣比谁的白，手摸不出来，得问过人。')])],
 [exit(2,7,'shift-square',[19,15],'回三班场'),exit(19,8,'mourning-room',[3,7],'带已辨衣袖去家属隔间',['cloth-fold'])]);
export const family=region('mourning-room','白崖 · 炉灰边的家属隔间',1,'harbor-interior',18,14,'wood',
 [['building',0,0,5,4,'带遮帘的小睡间'],['crate',10,2,5,4,'早年攒下的鞋楦'],['water',12,10,6,4,'洗碗沟']],
 [['lamp',7,6,1,1,'没有被带到宿舍的油灯'],['rope',3,8,7,1,'晒小孩夹衣的低绳']],
 [witness('grief-sister','砚叔的嫂子·逢珠',8,7,[s('逢珠','要我原谅招临工的人？别从这句话说起。等三年的是我，吃过赔饭的是孩子。我能要欠薪，也能不让孩子名字上港报。'),s('玛拉','我带你的原话。你愿意我们做哪一份？'),s('逢珠','两种我都肯。你若公开，我去签自己的名。你若留家里，就替我把木扣带到停船人常看的小台。')],'cloth-account',['cloth-fold']),
 person('choose-cloth','给逢珠递交或收存衣袖',11,8,[s('玛拉','你说，我来做。',[{text:'暂收私处，帮她留一处安静的纪念',set:'cloth-private'},{text:'陪她去登记欠工，凭她自选的名字',set:'clothes-public'}]),s('逢珠','不必替我说我肯原谅。把这句也记上。')],{requires:['cloth-account'],action:flag('cloth-choice'),after:[spoken('逢珠','木扣钉到看海的小台，别贴通报。','cloth-private'),spoken('逢珠','她去取账凭，我签逢珠，不代孩子署名。','clothes-public')]}),
 person('hush-brother','正在熨平儿童短褂的砚叔',5,9,[s('砚叔','我自己的丧事不一定在我规定的地方。杵这儿熨一件褂，胜过替她在门口挡十个人。')])],
 [exit(2,7,'mourning-wash',[18,8],'将洗灯送回白柜'),exit(15,8,'mourning-loft',[13,7],'上欠工夹账或海窗小台',['cloth-choice'])]);
export const loft=region('mourning-loft','白崖 · 欠工夹账与海窗',1,'harbor-interior',19,13,'wood',
 [['wall',0,0,19,2,'海风窗'],['crate',3,3,4,3,'事故招工换班册'],['crate',12,9,7,4,'拒绝公开的家属匣']],
 [['lamp',10,5,1,1,'对外通告灯'],['rope',5,8,8,1,'沉重书匣的系绳']],
 [fixture('inner-memento','在不署名海窗钉一枚木扣',15,7,[s('砚叔','我早上守了两次潮，没人来问我他叫什么。这对我嫂子刚好。')],'mourning-kept',['cloth-private'],{action:{type:'flag',id:'mourning-kept',set:'cloth-return'}}),
 witness('pay-witness','由逢珠亲自签押欠工单',7,7,[s('逢珠','雇了三晚，册上两晚。我签自己的名，要第三晚工钱。孩子姓什么，与你们下工无关。'),s('凯芽','我拿原账副本。领钱和扣帽不是一回事，今天我能说这句了。')],'pay-entered',['clothes-public'],{action:{type:'flag',id:'pay-entered',set:'cloth-return'}})],
 [exit(2,8,'haul-office',[11,12],'回蓝门取账'),exit(14,7,'mourning-room',[14,8],'回逢珠家中')]);