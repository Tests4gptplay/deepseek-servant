import {berth} from './the-door-that-became-a-floor.mjs';
import {fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {mechanism} from './district.mjs';

const night=['harbor-tilted','!base-safe'];
export const flood=berth('heel-flooded-hall','锚断之夜 · 水从另外一面回到原灶门',6,39,26,
 [['building',0,0,10,8,'仍在营业的木屐铺，门把搬进内侧'],['wall',13,0,5,9,'原舱肋向左吃住新来的一股斜力'],['building',21,1,7,7,'银蛏两户拆下底层灶口'],['wall',32,0,7,8,'浑水正从左右盐带之间穿过'],['water',0,18,13,8,'原黑盐带下的活水向今天的上游爬'],['building',17,19,7,7,'旧兄妹家里仍有一条归家人走的内侧'],['crate',29,19,10,7,'从手边送出的一双斜底屐']],
 [['path',3,11,32,3,'原来的灶弄现在能走到新水肩'],['heel-frame',6,9,4,2,'活水从旧盐的另一头抬起'],['heel-frame',26,10,4,2,'右灶门保留旧凹或引向新坡'],['heel-stair',14,14,4,2,'脚背上真正发冷的外阶']],
 [person('heel-current-neighbor','紧一边锅盖的藻婶',10,12,[s('藻婶','鱼汤还热。我拿这个盖子去坡口的人家换一只干枕。宽窄两路都归住户开，不是来看看的人走两遍就多出一条。'),
 spoken('藻婶','旧门已经做成宽坡。去压住中段那根担臂，小车才敢真进去。','heel-ramp-fitted'),
 spoken('藻婶','当下还能走的是原疏散坡，家属若愿进内廊，敲自家里门。','heel-room-fitted'),
 spoken('藻婶','留了个打算却没上木工台？那就照眼前的公坡过。',['heel-order','!heel-ramp-fitted','!heel-room-fitted']),
 spoken('藻婶','没进过旧屋也能帮忙，把锅盖送到有人要去的普通坡口。',['!heel-met'])]),
 witness('heel-sit-first','请来人自己试下宽坡的第一截',22,12,[s('春汤','脚刚才崴了。我可以坐滑板，别把我按平。我姐姐在后面扶。'),
 s('玛拉','你说停，伊沃就把活套放掉。就顺着能自己退的方向开。')],'heel-riders-asked',['heel-ramp-fitted',...night]),
 witness('heel-knock-from-in','站在外面，等雁折母亲从内手窝接起门',25,14,[s('柳珏','我不带你们全街进去。我儿子丘沚的门高，如今我能自己勾住了。要陪的在我身后半步就好。'),
 s('瑟琳','公坡仍开着。去送人和陪你进屋，不占同一道口。')],'heel-kin-knocked',['heel-room-fitted',...night])],
 [exit(3,12,'flood-stair',[22,12],'从普通疏散坡回收粮阶'),exit(32,11,'heel-broad-ramp',[4,11],'亲走用旧舱门铺成的接人宽坡',['heel-riders-asked',...night]),
 exit(23,16,'heel-quiet-return',[4,12],'应内门的邀请走回家属可达的夹角屋',['heel-kin-knocked',...night])]);

export const ramp=berth('heel-broad-ramp','锚断之夜 · 旧门如今容得下一辆车',6,35,22,
 [['water',0,0,35,5,'活水把原高窗下面的短钩泡白'],['wall',5,3,5,6,'新坡先沿高侧靠住实肋'],['crate',15,1,7,7,'从旧整门拆成的可退宽坡'],['building',26,3,9,6,'坡口备干毯的现住户'],['water',0,17,13,5,'不能再塞进担架的旧回弯'],['wall',24,17,11,5,'这一条内侧没有留下可观的原门把']],
 [['pier',3,10,28,3,'滑板旁边始终留一人宽的退位'],['heel-skid',13,12,4,2,'回低床的弯形在活水里变成放担点'],['rope',18,15,9,1,'让坐着的人自己能松的把手']],
 [fixture('heel-stage-ramp','从两只湿轮之间扶起退位楔',9,11,[s('春汤','这是不是还要让我躺？'),s('玛拉','不躺。我让窄轮子退半圈，宽轮子沿门背走。你姐姐站得下。'),
 s('伊沃','退手留在你脚边，前面有人伸手按着你，你自己松它。')],'heel-ramp-staged',['heel-riders-asked',...night]),
 mechanism('heel-steer-live','沿两处水痕选活水里可退的一侧',17,13,[s('瑟琳','黑盐是十七年前的。今天浪尖正从它下面顶起来；踩脏的宽轮印在新水上边。')],['heel-ramp-staged',...night],'heel-carry-line','坐着的春汤要在转角停一下。她姐姐要跟，每人该在哪里？',
 ['顺新湿印走高肩，把可退位留给本人和她姐姐','循最黑的旧盐带直接滑下去','为腾坡让姐姐走另一条，再从背后把坐的人推过去'],0,'新水和旧盐有交点。自己的退手与姐姐都要能留在宽坡高肩。',[s('春汤','我扶住了。现在松半圈，我自己坐到末端去。')]),
 witness('heel-rider-ends','在宽坡末端从春汤本人手里接回活套',27,12,[s('春汤','我在这头。你们没有把我从姐姐手里换成一件要赶快搬完的东西。'),
 s('雁折','旧门上的拇指窝走过两只车轮。今晚它不是可以摸出哥哥旧手的那面了。我知道我同意过什么。')],'heel-ramp-walked',['heel-carry-line',...night])],
 [exit(3,11,'heel-flooded-hall',[31,11],'循宽坡边的同伴踏板回两灶门')]);
