import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {setting} from './registry-parts.mjs';

export const tallow=region('tallow-street','冬岸 · 芯蜡市和背烟弄',5,'winter-village',34,22,'stone',
 [['building',1,2,6,5,'獾油作与挂勺窗'],['building',12,1,7,5,'岑艾的旧帆铺'],['building',23,2,9,5,'两座熏房共用的烟门'],['water',0,15,8,7,'雪水滩'],['crate',15,16,6,5,'装夜煤的棚'],['building',26,15,8,7,'修胎骨的细木铺']],
 [['path',1,9,30,3,'从市秤穿过两灶的背烟街'],['rope',8,7,16,1,'朝风口挂短旗'],['lamp',21,11,1,1,'烟门外端可观察的灯头']],
 [witness('smoke-bread','拿熏鱼当冬粮的井梁',8,10,[s('井梁','北风把油烟推进四炉院，家家都说把自家窗堵上。我住最低，四家堵住的烟明天会从我灶里出来。'),s('伊沃','这条街开了两只烟门，眼前怎么只见一根绳？'),s('井梁','第二根在蜡屋后头，风大的早晨它贴着屋顶。你一人站缝外，一人到背烟弄，灯头绿不绿，得两头看。')],'two-flues',['lee-proved']),
 person('scraper','刮烛床的白予',14,9,[s('白予','少问烛多长。今天鸡油灯一点就冒黑，说明炉膛在吃自己吐出来的气。烟墙上也有昨晚的手印，你别拿白布擦了。'),spoken('白予','后来换上柳条闸，我给三家都留下不必捅烟囱的夜晚。可烟房少出一架鱼，我仍欠井梁一个早班。','flue-shore'),spoken('白予','炉屋改烧后院储炭，我那桌蜡先凉了。明天起得早，还是比屋里咳一夜强。','flue-fish')]),
 fixture('street-candle','在背烟街点双色试烟芯',22,10,[s('玛拉','这根顶端裹盐，吸到回烟才带绿色。另一根是普通芯，熏鱼的油汽会让它变黄。两根要摆同一处。'),s('白予','熏房那股红火在外墙。蜡房后天窗有根细烟线。两天没有起风的时候，黄芯也会亮。')],'street-flame',['two-flues'])],
 [exit(2,9,'winter-court',[11,11],'去四炉院'),exit(31,10,'wick-throat',[3,8],'到蜡屋背后看另一个烟端'),exit(16,14,'kin-larder',[3,8],'进热席巷后面的饭签行')]);
export const wick=region('wick-throat','冬岸 · 两烟门通风间',5,'winter-interior',25,17,'wood',
 [['wall',0,0,25,3,'共墙的烟槽'],['crate',3,4,5,3,'粘着松蜡的梯脚'],['wall',14,4,5,3,'烟门转鼓'],['crate',17,12,8,5,'冬煤杯架']],
 [['rope',3,8,18,1,'两端带结的闸绳'],['lamp',14,10,1,1,'可返回街心观察的白芯']],
 [setting('flue-loop','关两侧门以试回烟',8,8,[s('伊沃','两线都紧了。屋里黄芯变绿，街外烟忽然干净。这是把脏东西全留在屋里的死法，适合试验，不适合过冬。')],['street-flame'],{'flue-back':true,'flue-east':false,'flue-west':false,'flue-reading':false}),
 setting('flue-east','收靠海回索，向煤棚排烟',11,9,[s('伊沃','海侧风挡住熏架。把这里的烟借煤棚顶走，作坊少一股热，不必灭院里的炉。')],['street-flame'],{'flue-back':false,'flue-east':true,'flue-west':false,'flue-reading':false}),
 setting('flue-west','放背岭绳，由鱼房高窗排烟',19,8,[s('瑟琳','背岭高窗出得去。把潮湿的旧芯留着，明早检查鱼屋屋梁到底有没有吃回烟。')],['street-flame'],{'flue-back':false,'flue-east':false,'flue-west':true,'flue-reading':false}),
 witness('wick-runner','在另一端点同样的盐芯',15,9,[s('白予','我从外墙把黑痕拓到旧纸。你回街心看这次烟是不是顶着人走，不看里面的烟色便不能签。')],'flue-reading',['street-flame'],{action:{type:'flag',id:'flue-reading'}})],
 [exit(2,8,'tallow-street',[30,10],'回街心看另一支芯')]);
export const flueOutcomes=[
 witness('clean-both','回到街灯检查煤棚与居院的两支芯',23,12,[s('井梁','居屋那根不绿了。煤棚工把生煤包扎起来，我的鱼能再熏一轮。他们冬天得借下坡上的干柴。'),s('玛拉','我见了里面和外面，缺的这捆柴先记在我带回去的粮船清单。')],'flue-fish',['flue-east','flue-reading'],{action:{type:'flag',id:'flue-fish',set:'hearth-trial'}}),
 witness('cool-fish','拿清芯与鱼房屋梁的潮样对照',18,12,[s('井梁','烟从鱼房高窗去了，四炉能烧。今早这架鱼却还湿着，要分到内湾先腌后运。'),s('瑟琳','我会把腌鱼用盐单列，不把烤干的数先记在大家碗上。')],'flue-shore',['flue-west','flue-reading'],{action:{type:'flag',id:'flue-shore',set:'hearth-trial'}}),
 person('smoke-mirror','隔墙上的旧小镜',12,12,[spoken('白予','屋里芯冒绿，街灯还黄。两边读数不同。把烟门全关会在屋里谋个晴天的假象。','flue-back'),s('白予','外面不冒烟还不够。我儿子在屋里守灶，今晚我在那里吃饭。')])];
