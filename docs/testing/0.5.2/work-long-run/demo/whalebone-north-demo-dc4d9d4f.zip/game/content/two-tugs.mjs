import {fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person} from './parts.mjs';
export const pierPeople=[
 witness('tug-lesson','泱阿在岸端试一次两声停步的约定',13,10,[s('泱阿','你还握着外索？第一短下我没松，第二短下你才准靠过来。我要是只动一回，大船也等得到我。'),s('伊沃','我等到它真的动完。不是当年那一声盖掉下一声。')],'tug-learned',['sill-guard-hand','north-ready']),
 fixture('wheel-wedge','在交到泱阿手里的空车轮下试一副斜木楔',16,8,[s('泱阿','那次我抓钥匙，你回来推车。今天我不回你的门。我把楔翻个面，试给你看，这样它离了锁也能自己在坡上停。'),s('伊沃','木楔跟车，不跟我的印。')],'wedge-learned',['sill-wheel-hand','north-ready'])
];
export const stairPeople=[
 witness('tug-pair','让织网母女依次靠两声拉索把窄板拉到自己门下',17,13,[s('织网女儿','我拉得轻。我妈扯一大把，你能分得开？'),s('伊沃','我只重复你给出的次数。你妈知道你应了才肯出去，我在那之后松。'),s('泱阿','这次两个人都叫过才走。她俩一起过水。')],'net-pair-arrived',['tug-learned','harbor-tilted']),
 fixture('wheel-on-slope','用北埠的单楔把有脚伤的磨工连车留稳',20,12,[s('磨工','木楔只咬后轮。这样我能自己把右腿挪直。你手撑一下下，别忙着先拉。'),s('伊沃','靠稳才收，我在里侧。你有钥匙，你出声我才推。')],'wheel-man-arrived',['wedge-learned','harbor-tilted'])
];
export const boatPeople=[person('old-answer-lands','当年吹过两声的泱阿回引航驳',13,10,[
 spoken('泱阿','织网母女都到了，我还是没等回舅舅。这回等到的，得跟当年没等到的分开。','net-pair-arrived'),
 spoken('泱阿','磨工把棉布自己绑回膝边。你把车还给他，我手里还能握着我的钥匙。','wheel-man-arrived'),
 {...s('泱阿','过水的普通窄板还在。没有在北埠试过，就让人自己跟着熟手走，不替他吹一声听不懂的哨。'),if:['!net-pair-arrived','!wheel-man-arrived']}
])];
