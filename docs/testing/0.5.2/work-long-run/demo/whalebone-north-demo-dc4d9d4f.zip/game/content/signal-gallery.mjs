import {say as s,feature as f,exit,person,object,flag} from './parts.mjs';
export const gallery={
 id:'signal-gallery',name:'白崖港 · 潮讯灯廊',act:1,width:30,height:17,ground:'wood',biome:'harbor',
 solids:[[0,0,30,2],[3,2,4,3],[9,11,5,5],[19,2,4,4],[24,12,6,5],[0,13,6,4]],
 features:[f('water',0,0,30,2,'下层潮渠'),f('building',3,2,4,3,'外讯房'),f('building',9,11,5,5,'换灯铺'),f('building',19,2,4,4,'内讯刻度亭'),f('pier',0,6,30,3,'架空灯廊'),f('lamp',7,6,1,1,'外钟'),f('lamp',19,6,1,1,'内钟'),f('rope',23,9,4,1,'上层出索口')],
 entities:[
  object('inner-buoy-score','蓝线内钟的记拍纸',17,6,[s('内钟记拍纸','外标第二拍后，内钟第四拍响；外标第六拍后，内钟第八拍响。外标先响不代表船头已进内门。'),s('玛拉','有人把这张纸抄成了两个外标。难怪看台和拖船互相骂。')],{action:flag('inner-ticks')}),
  object('signal-register','给拖船落牌的拍子盘',21,7,[s('拖船手','红灯不是停，蓝灯也不是走。你告诉我，外标第十拍响后，哪一拍船鼻才过内门？')],{requires:['outer-ticks','inner-ticks'],action:{type:'puzzle',id:'window-known',prompt:'选择内口实到的放船拍点。',options:['第十拍，外标首响时就放','第十二拍，等内口回声','第十四拍，等下一次外标响'],answer:1,value:true,hint:'前两组记录里内钟都比外标晚两拍；等到下一次外标会整整错过一班。'},after:[s('拖船手','十二。看见浮门那道水翻了吗？这条走得通。')]}),
  object('ink-trial','往返跑水的纸船窄槽',11,9,[s('吉','我拽着你的袖子，你闭上眼，别跟着外钟抬脚。纸鼻碰到蓝线我就捏一下。'),s('玛拉','第一回是四。再推一次……八。外钟第十，轮到我们是十二。'),s('吉','写我名字的那边朝上。下一个听不见钟的人也认得它。')],{requires:['pilot-ink','inner-ticks','work-slip'],action:flag('window-known'),after:[s('纸船','船鼻碰蓝线总比外浮标迟两拍。')]}),
  object('rope-counter','伊沃的上下对绳架',25,8,[s('伊沃','不让人试摔。你把腰带挂牢，我用空筐走一遍。上回有个人没告诉我，回绳也能拉人。')],{requires:['opposed-rope','berth-fixed'],action:{type:'puzzle',id:'ivo-line',prompt:'怎样把伊沃与空筐接成一套来回都受控的路？',options:['上绳接人、下绳反接空筐','人和筐都接上绳外侧','割去回绳，空筐自由落'],answer:0,value:true,hint:'绳耳磨痕朝向相反；人升时空筐须下降，回程还得有人能收住。'},after:[s('伊沃','空筐到底，人可以上。另一侧留个活环，我能原路接你。')]}),
  person('wickman','守内灯的汀孙',5,7,[s('汀孙','上廊看得到粮趸银亮的屋顶，看不到锅底。怕有人顺着灯以为，我们家家户户都吃上饭了。'),{who:'汀孙',if:'night-lamp',text:'我奶奶的长芯灯。一会儿站在屋顶能看见最西边那点红。'}])
 ],exits:[exit(1,7,'trim-yard',[26,7],'下肋木场'),exit(15,14,'ration-berth',[15,3],'沿高栈下粮趸'),exit(28,8,'upper-spar',[2,6],'由伊沃对绳升上屋桁',['ivo-line','berth-fixed'])]
};