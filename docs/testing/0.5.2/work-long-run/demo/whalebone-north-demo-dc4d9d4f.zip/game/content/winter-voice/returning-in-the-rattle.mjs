import {region,fixture,witness} from '../voyage-parts.mjs';
import {exit,person,say as s} from '../parts.mjs';
import {mechanism} from '../district.mjs';
const shared=['court-count','whalefall-early-log','!grave-signed'];
const other=(id,name,b,l,e,x)=>region(id,name,6,'tilted-port',34,22,'wood',b,l,e,x);
const bellQuay=other('whalefall-thwart','锚断之夜 · 钟脚下过小船',
 [['water',0,0,11,6,'旧粮船船侧漫过的冷水'],['wall',19,0,9,5,'已离开引桩的斜街门框'],['water',0,16,13,6,'失去上半截的救生筒'],['building',22,16,12,6,'握钉的人暂时吃饭的隔间']],
 [['pier',2,9,29,3,'只够担子转半身的狭面'],['voice-damped-step',6,6,8,3,'羊毛套浸湿的钟身、抱木和伸到岸脚的软缆'],['voice-watch',22,6,5,2,'母鲸向外的一道背和小鲸落后的气眼']],
 [witness('whalefall-waiting-oars','跟失去救生筒的两位木骨桨手重新分一班岗',7,11,[s('槐梢','钟在你脚下，我站这儿！旧救生筒上现在没有钟，不能让娃娃提着药箱游找我们。今夜谁留着听？'),s('洛洄','我在水下，妹在绳头。岸上还得多个人。'),s('伊沃','我来。腾出钩绳，别人递药。你脸冻白了就去屋里喝盐汤，等回来换。')],'whalefall-oar-watch',['whalefall-wool-set']),
  fixture('whalefall-heel-vibration','脱下铁跟，站到从钟抱木连出的第二块脚板上',14,12,[s('伊沃','前一响在脚尖，后一响在木桩背后。隔着皮靴两响挨在一起，赤脚能摸到一个很小的间隙。'),s('崖枝','母鲸下去了。你等最后一个静拍，别把船头压到后面那只身上。')],'whalefall-two-beats',['whalefall-oar-watch']),
  mechanism('whalefall-oars-gap','用岸上的停顿决定何时把船钩推出',20,11,[s('玛拉','脚下两响一空，左边先起重泡，后面一小泡。现在绳还没走紧，哪一拍递船？')],['whalefall-two-beats'],'whalefall-oars-free','哪一刻船头不会和幼鲸占同一条隙？',['第一响刚到，立刻推离岸桩','第二响后等小气眼越过桨端再推','回去敲三下铁，让母子都转身'],1,'盯住桨端的水纹。母鲸先过，末尾的小气眼随后越过船桨。',[s('崖枝','我看见泡沫从桨尾过了。你们推。')]),
  witness('whalefall-pass-the-chest','亲手把药盒递过横桨，等两位桨手自己报名字',27,11,[s('桨手渔臼','细口瓶我接，绳头她接。请记是两个人送到，不准把我的腿又算进担架位。'),s('伊沃','把这个空筒带回去给岸边。等走完这趟，还要想没钟的时候要怎么救人。')],'whalefall-cork-crossed',['whalefall-oars-free'])],
 [exit(2,10,'flood-stair',[18,12],'回淹水的石阶，改走普通疏散线'),exit(30,11,'safe-keel',[15,10],'跟送药的两桨小艇靠上引航驳',['court-count','whalefall-cork-crossed'])]);
const lampsQuay=other('whalefall-lamplighters','锚断之夜 · 一只看得见的空篮',
 [['water',0,0,9,7,'湾里窄鱼船穿过的外道'],['building',12,0,9,6,'失去整夜炉火后的熏棚'],['water',25,0,9,8,'低罩油灯错开才能看见的水'],['wall',2,16,8,6,'背鱼绕过的冷墙'],['building',21,16,13,6,'熏过青鳃鱼的三家共灶']],
 [['pier',2,9,29,3,'水上看似一盏灯的两座浮台'],['voice-smoke-rack',8,7,7,3,'没有炉火的网架还挂着去鳞的青鱼'],['voice-lamp',21,7,6,3,'旧汀两座带缺口的成对灯背']],
 [witness('whalefall-find-the-baskets','和没了熏炉的人挨家核对领过多少鱼',7,11,[s('寇仁','我说过，鱼不会因为借了油就在鱼市自己换到另一边。第二家那位出不来，她只有一条腿。'),s('米拉','第一家四尾，第三家五尾。中间的空篮还在原地，我去那户低窗下收。')],'whalefall-empty-basket',['whalefall-lantern-set']),
  fixture('whalefall-take-the-fish','从矮窗抬出两尾银脊鱼，请靠门的老妇亲自压住篮结',12,13,[s('乌娘','别往上拎我。我在自己门里活了一辈子，今天只答应借锅。吊篮给你走，留一个柄还得拿回来。'),s('玛拉','绳在你这边。想收回来，往下轻轻一拽。')],'whalefall-house-fish',['whalefall-empty-basket']),
  mechanism('whalefall-paired-beam','从船头对准貌似重合的两盏背灯',20,11,[s('米拉','高处的灯沿船头偏左，低处的灯罩有个朝海的口子。试哪条缝，能看见一盏也不会撞上鲸？')],['whalefall-house-fish'],'whalefall-true-beam','哪条缝同时看得到两盏灯的低沿？',['站到烟棚顶，直盯最高处','掀走前一盏的罩，照亮全湾','压低船头，在两灯重合的线以南收桨'],2,'高处看得到火芯，只有鱼篮那么高的地方能把两盏灯的缺口套成一个。',[s('寇仁','前头那只橹先收，我们这只篮还在往前走。')]),
  witness('whalefall-bring-the-fish','把一整篮鱼实交船上，接回老妇那只旧篮柄',27,11,[s('寇仁','给，空柄让她拿来挑锅盖。今晚共灶的鱼少熏了一夜，明日先给这几家吃鲜的。'),s('洛洄','小鲸从船底右边过去。这里的人欠着油，也认真把鱼带回来了。')],'whalefall-lamps-crossed',['whalefall-true-beam'])],
 [exit(2,10,'flood-stair',[18,13],'回淹水石阶的支柱，普通疏散线仍通'),exit(30,11,'safe-keel',[21,10],'跟载鱼的矮艇和两个实见灯口回到引航驳',['court-count','whalefall-lamps-crossed'])]);
export function withReturningWatch(world){
 const maps={...world.maps,[bellQuay.id]:bellQuay,[lampsQuay.id]:lampsQuay},flood=maps['flood-stair'],safe=maps['safe-keel'];
 maps[flood.id]={...flood,exits:[...flood.exits,exit(18,11,bellQuay.id,[3,10],'循过去冬岸实试过的绒钟找候在木桩旁的送药船',[...shared,'whalefall-wool-set']),exit(18,13,lampsQuay.id,[3,10],'看见过去亲手挂的双灯，去接借过鱼油的那几家',[...shared,'whalefall-lantern-set'])]};
 maps[safe.id]={...safe,entities:safe.entities.map(e=>e.id==='whalefall-shore-count'?{...e,x:15,y:11,requires:[...e.requires,'whalefall-cork-crossed','!grave-signed']}:e.id==='whalefall-shore-lamps'?{...e,x:21,y:10,requires:[...e.requires,'whalefall-lamps-crossed','!grave-signed']}:e),exits:[...safe.exits,exit(15,9,bellQuay.id,[29,11],'回看岸钟小船，交接后再循原路上岸',['whalefall-cork-crossed']),exit(21,9,lampsQuay.id,[29,11],'提着还来的篮柄回双灯见过的人家',['whalefall-lamps-crossed'])]};
 const grave=maps['burial-cape'];maps[grave.id]={...grave,entities:grave.entities.map(e=>e.id==='whalefall-last-knot'?{...e,x:18,y:9}:e)};
 return {...world,maps};
}
