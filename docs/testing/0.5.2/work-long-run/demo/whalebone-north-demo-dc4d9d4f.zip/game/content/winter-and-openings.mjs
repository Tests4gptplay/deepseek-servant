import {square,house} from './pelt-lane.mjs';
import {mouth,swell,calves,scree} from './antler-waters.mjs';
import {ramp,tow,hall,upper,lower} from './folded-theater.mjs';
import {booth,rack,cubby,cleat} from './paper-beasts.mjs';
import {bread,flour,hinge} from './bran-stoops.mjs';
import {plunge,sump,chair} from './chair-eye.mjs';
import {split,shoulder,skirt,dock} from './sheared-lintel.mjs';
import {mender,mealAfter,highAfter,lowAfter,wetChair,graveSeats,wetFeatures} from './stool-mender.mjs';
import {say as s,exit,object} from './parts.mjs';
export const openingMaps=[square,house,mouth,swell,calves,scree,ramp,tow,hall,upper,lower,booth,rack,cubby,bread,flour,hinge,plunge,sump,chair,split,shoulder,skirt,dock,mender];
export const openingGear=cleat;
const sideRoads={
 'false-saddle':[exit(25,10,'antler-swell',[25,12],'沿成年兽的旧石缝折回背湾',['saddle-back','swell-arc','tide:high']),exit(14,12,'calf-lichen',[27,11],'沿幼蹄细沟返回苔床',['saddle-back','calf-line','tide:low'])],
 'hinge-landing':[exit(10,14,'sheared-lintel',[12,13],'沿旧船班的公门回损失了一扇门的铺子',['public-first']),exit(14,14,'eave-shoulder',[25,11],'到刚刚能自己拐弯的住客身边',['eave-first']),exit(24,14,'skirt-cut',[25,11],'回到肯回身的小垛身边',['skirt-first'])],
 'winter-court':[exit(22,13,'pelt-lane',[4,13],'往冬岸长住户的皮窗街走，去看谁肯开过冬的门')],
 'anchor-yard':[exit(13,12,'bran-stoops',[4,12],'到晨班的三扇门找没吃饭的布兰',['winter-proof'])],
 'flood-stair':[exit(19,12,'hinge-landing',[30,13],'沿已接回众人的原门回去看看',['slant-placed']),exit(17,11,'slant-cobbles',[4,12],'回水已经压进白漆门里，沿窗坡回去找人',['harbor-tilted']),exit(21,10,'pelt-lane',[38,15],'安葬后随回北岸的老房主再去看住处',['grave-signed','concourse-agreed']),exit(20,11,'low-hinge',[24,12],'从修好一侧的路回低闩旧门和修凳住家',['grave-signed','slant-placed'])],
 'pelt-lane':[exit(39,15,'flood-stair',[19,11],'随岛上街坊回到白崖',['grave-signed','concourse-agreed'])],
 'low-hinge':[exit(25,12,'flood-stair',[21,11],'从安葬后再开的低街回白崖',['grave-signed','slant-placed']),exit(23,13,'stool-mender',[4,10],'找两朵紫花下自己谋生的隙青',['grave-signed','slant-placed'])]
};
const replies={
 'heel-refuse':'我仍住在这里。两条路都被自己家的人踩过以后，再问我搬不搬。',
 'stage-choose':'那一出已经挑好，回幕后的架上继续，就不叫小垛重新选。',
 'bran-bread':'两只饼已经分妥，我自己去那家门边说完。',
 'slant-refuse':'我知道怎么把狗叫回来。请朝膝闩那边绕，不要站在门口堵住它。',
 'split-price':'说好舍哪一件就舍那一件。你若回头，主人还在原来的膝门和皮篷处等你。',
 'hinge-no-name':'我在修竹凳的门边等你。下一趟别把我叫成另一个人的姓。'
};
const stages={
 'winter-proof':['concourse-agreed','过冬也得有愿意开门的旧住户。去四炉院东侧皮窗街，陪野檀和甫岸实际走过高院与低岸。'],
 'bran-return':['bran-home-visited','开锚以前，布兰还得跟送错饼的人说一句话。回三扇早餐门，摸哪户是两枚圆钉、一枚失帽。'],
 'cut-ramp':['slant-placed','港还在倒灌。旧锚已经解，先沿坡上白漆门进斜街找人，把真正住这一扇窗的人接回。']
};
const revisit={
 'anchor-yard':[object('bran-old-arrival','在工会门边看布兰以前自己回过锚机的旧靴印',12,13,[s('玛拉','他早已沿这排靴印去过锚场，潮再来一遍也不能把他当时的选择抹去。')],{requires:['bran-at-drum']})],
 'flood-stair':[object('wet-old-ramp','摸已经放过的旧收粮坡铰链，从原处继续向下',9,11,[s('伊沃','这道铰链已经被人放过。你原来从哪条路走下去，今日还能照常过。')],{requires:['tilt-sighted']})],
 'paper-beasts':[mealAfter],'moon-dorm':[highAfter],'net-dorm':[lowAfter],'ladle-cut':[wetChair]
};
export function withOpenings(map){
 const entities=map.entities.map(e=>{
  if(replies[e.id])return {...e,after:[s(e.dialogue.at(-1).who,replies[e.id])]};
  if(stages[e.id]){const [more,lockedText]=stages[e.id];return {...e,requires:[...(e.requires||[]),more],lockedText};}
  if(map.id==='burial-cape'&&graveSeats[e.id]){const [x,y]=graveSeats[e.id];return {...e,x,y};}
  return e;
 });
 const wet=map.id==='ladle-cut'?wetFeatures:[];
 return {...map,features:[...map.features,...wet],entities:[...entities,...(revisit[map.id]||[])],exits:[...map.exits,...(sideRoads[map.id]||[])]};
}
const lines=[
 ['doors-of-the-antler','冬港把能回来的门留给谁','main',['pelt-received','heel-consent','heel-radius','rut-taught','rut-high-back','rut-low-calves','herd-compared','ramp-passed','sill-passed','house-decided','concourse-agreed']],
 ['the-shrimp-bride','让当船长的球藻自己逃离虾戏','side',['play-heard','play-seen','play-picked','play-performed','play-finished']],
 ['the-heel-hook','白鞍背面留下的戏靴','hidden',['toe-clue','saddle-back','toe-paired','toe-found']],
 ['bran-brings-breakfast','送错的饼和认得住户的门','main',['bran-breakfast','bran-white-seen','bran-repaid','flour-not-door','bran-knows-door','bran-home-visited']],
 ['the-chair-by-the-window','白漆褪后谁能认得自己的门','main',['slant-heard','slant-marked','chair-known','chair-sent','chair-free','city-price','slope-port-open','city-localled','old-route-joined','slant-placed']],
 ['someone-without-a-surname','去修凳住家再找隙青','side',['slant-placed','mender-home','slant-home']],
 ['on-the-next-tide','回冬岸看下一家怎样走出门','side',['concourse-agreed','city-localled','pelt-home']]
];
export const openingQuests=Object.fromEntries(lines.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
