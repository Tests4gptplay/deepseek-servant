import {say as s,exit,person} from './parts.mjs';
import {witness,spoken} from './voyage-parts.mjs';
import {pages} from './registry-parts.mjs';
import {teahouse,sill} from './tea-family.mjs';
import {parlor,nextDay,lastDay,finalSills,lateTea} from './tea-parlor.mjs';
import {boiler,pit,washReceipt} from './boiler-stair.mjs';
import {common,cartHelp,bedHelp} from './bread-turn.mjs';
import {deck,bend,bay} from './listening-hull.mjs';
import {row,earLater} from './outside-row.mjs';
import {sun,glass,sunFinish} from './sun-ladle.mjs';
import {portPeople} from './port-house-voices.mjs';

export const streetMaps=[teahouse,sill,parlor,boiler,pit,common,deck,bend,bay,row,sun,glass];
const windows={
 'wake-court':[exit(16,7,'willow-tea',[5,8],'顺石膏脚印进溪雁的茶棚'),exit(19,7,'rain-parlor',[20,9],'走前街找旧礼院里等茶的人'),exit(22,7,'bread-turn',[4,10],'去双头街问面坊为什么关了一扇门')],
 'shift-square':[exit(25,7,'boiler-stair',[4,9],'循白汽找夜洗班的细管'),exit(19,7,'bread-turn',[27,10],'回面坊看看两条实际用的街')],
 'west-lamp':[exit(10,7,'voice-deck',[4,10],'沿坏陶管去常复的回声铺'),exit(13,7,'outside-row',[25,10],'从西窗走外排值班廊',['ear-proposed'])],
 'dry-court':[exit(16,7,'voice-deck',[4,11],'沿晒衣绳摸到旧艇声管')],
 'voice-deck':[exit(19,11,'outside-row',[4,11],'沿钱柜身后旧坡去外排亲验',['ear-proposed'])],
 'rain-parlor':[exit(5,10,'port-desk',[19,8],'由迎客低窗回早班秤台',['tea-at-dawn']),exit(22,11,'late-canteen',[16,8],'沿后巷回末班夜灶',['tea-at-dusk'])],
 'port-desk':[exit(19,7,'rain-parlor',[5,9],'陪末芝穿过已开的早窗小道',['tea-at-dawn'])],
 'late-canteen':[exit(16,7,'rain-parlor',[21,11],'挽住末芝从安静的后巷进院',['tea-at-dusk'])],
 'eight-landing':[exit(19,7,'sun-ladle',[4,9],'穿八户背阴小门去半日晒台',['beds-list'])]
};
const encounters={
 'shift-square':[bedHelp,person('tea-three-days','把三班和等候记在围裙上的柏姐',16,9,[s('柏姐','等不到人的时候我就开东门。哀客若同时来，先把桌脚让给摔疼腿的，谁的亲不比谁的少。'),spoken('柏姐','药布回来了你跟我说一声，夜里接伤的总忍着不问是谁拿给他。','wash-bandages'),spoken('柏姐','巷门一关，轮到自己喘气。我打麻布帘的时候才想起来，我也可以做这个决定。','tea-long-visit')])],
 'port-desk':[nextDay,cartHelp],'late-canteen':[lastDay],'ration-berth':[washReceipt],
 'salt-lane':[lateTea,witness('salt-sun-yard','在盐街鞋摊前再见田眠和榴平',19,9,[spoken('徒弟','我自己穿了第五眼，师傅没让我把它补直。给你看看这道斜线。','leather-fed'),spoken('榴平','新菜够分八户，旁边的徒弟还是来上课。师傅在窗外咬着葱包喊她，声音可真响。','leaves-fed'),s('米拉','门在阴面，从前我会在图上写“闲置”。我今天换个写法。')],'sun-in-market',['sun-delivered'])],
 'sun-ladle':sunFinish,'rain-parlor':finalSills,
 'winter-ward':[earLater,witness('wash-in-winter','冬铺摊开一床毡和一幅细布',13,9,[spoken('旻子','那一班软布生了个外号叫旻子皮。我听了直乐，我不要他们记得我崩了哪颗门牙。今天你抬手还有人能包。','wash-bandages'),spoken('卷树','娃都长到我皮护顶上了。第一床旧毡我带着，缝到这儿当冬岸的岸标，哪条小艇来都看得见。','wash-blankets')],'wash-in-cold',['wash-handed'])],
 'burial-cape':[witness('mara-at-own-tea','等父亲的墓土压实，给自己倒一碗热茶',13,11,[spoken('玛拉','渔柳没有领着所有人哭。她把热碗举起来，暖一暖窑工的手。我站在我父亲墓边也能给自己倒一碗。','tea-low-visit'),spoken('玛拉','月砻握着她自己的闩。她不欠任何人一次探看。我在这儿坐一个钟也好，歇够就回去，酒还在火边。','tea-long-visit'),s('伊沃','我坐下喝一口会不会碍事？'),s('玛拉','你又不穿着公差的靴子。过来，烫。')],'tea-home',['tea-crossed','grave-signed'])]
};
const gates={
 'foreman-count':['crumb-met','面坊附近两班当事人还在等。摆灯院东侧可达双头街。先约下一班，再到过秤台找伏岚或去三班场找亚稗。'],
 'ivo-admission':['ear-received','沿西窗旧陶管去问常复和菅葵。请从艇里与双墙后分别听，再到外排让需要用闸的人试开一次。']
};
export function withHouseStreets(map){
 const entities=map.entities.map(entity=>{
  const gate=gates[entity.id],extra=portPeople[entity.id];
  let e=gate?{...entity,requires:[...(entity.requires||[]),gate[0]],lockedText:gate[1]}:entity;
  if(extra){const key=e.after?.length?'after':'dialogue';e={...e,[key]:[...e[key],...pages(extra)]};}
  return e;
 });
 return {...map,entities:[...entities,...(encounters[map.id]||[])],exits:[...map.exits,...(windows[map.id]||[])]};
}
const arcs=[
 ['whose-bread','面坊门前的两条街','main',['crumb-asked','crumb-bed','crumb-cart','crumb-tested','crumb-booked','crumb-met']],
 ['a-kettle-for-one','给溪雁的人好好倒一杯','companion',['tea-family','cup-borrowed','cup-source','turn-proven','parlor-heard','tea-pledged','tea-received','tea-crossed','tea-home']],
 ['salt-in-a-quilt','洗衣工拿两股水来作证','side',['washer-asks','upper-cup','soap-given','salty-foam','fresh-foam','wash-sorted','wash-handed','wash-in-cold']],
 ['a-boat-that-answered','闭航以后还接谁的班','main',['ear-witness','ear-clue','ear-echo','ear-direct','ear-proposed','ear-closed','ear-received']],
 ['where-light-lands','替第五只鞋眼留一线光','side',['spoon-asked','sun-low','glass-asked','sun-proof','sun-shared','sun-delivered','sun-in-market']]
];
export const streetQuests=Object.fromEntries(arcs.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
