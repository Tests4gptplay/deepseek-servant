import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {setting} from './registry-parts.mjs';

export const parlor=region('rain-parlor','白崖 · 两扇门的旧礼院',1,'harbor-interior',26,18,'stone',
 [['wall',0,0,26,2,'看不见卧榻的高隔墙'],['wall',4,3,3,5,'只开上半扇的探身窗'],['crate',10,2,6,4,'横放两张矮凳的送别台'],['wall',19,12,6,5,'通伙计巷的帘后小门']],
 [['path',3,8,20,2,'能从院外走到花茶案又退回的双行路'],['lamp',12,7,1,1,'扫在手上的低芯灯'],['rope',6,12,12,1,'家属可收的晾花布帘'],['table',12,3,2,1,'靠家属侧的花茶长桌']],
 [witness('parlor-rule','给别人开过四十回礼院的杉姑',8,8,[s('杉姑','你们家的白事不归我排行次。我能从里面开矮窗，也能撤了前桌让一个伙计自己进小门。家里随时能叫停，你问那两个姑娘。'),s('月砻','我想看姐姐喝完她那碗茶。她忙了半日，我光顾着自己。'),s('渔柳','有酒就好。我站到现在脚也麻了。')],'parlor-heard',['turn-proven']),
 setting('offer-sill','让两姐妹试坐低窗边',14,8,[s('渔柳','能听见师傅的嗓子。看不见脸也认得，连我那壶苦茶她都肯喝。还可以换另一边试。')],['parlor-heard','!tea-pledged'],{'want-window':true,'want-alley':false}),
 setting('offer-alley','打开伙计巷的内门试走一遍',18,10,[s('月砻','门闩能攥在我手里。我愿意时才让下一位进来，活着的人也有喘口气的工夫。')],['parlor-heard','!tea-pledged'],{'want-window':false,'want-alley':true}),
 witness('ask-small-window','由渔柳点头约次日天亮的低窗',10,9,[s('渔柳','天亮后到过秤台，末芝在那里烧早水。把她带来，我开窗。到了我没抬手，你们就把茶搁下走。'),s('玛拉','我只答应把她请到，不会替你抬这只手。')],'tea-pledged',['want-window'],{action:{type:'flag',id:'tea-pledged',set:'window-booked'}}),
 witness('ask-long-alley','由月砻约离港前安静的伙计巷',16,11,[s('月砻','等第三班吃过饭。去大灶问末芝，她走路慢，找个人跟她一起。姐姐能留在椅子上，每次只进来一个。')],'tea-pledged',['want-alley'],{action:{type:'flag',id:'tea-pledged',set:'alley-booked'}}),
 person('parlor-widower','在院里缝假花的迟耘',7,13,[s('迟耘','我家那位嫌花活着好端端，剪下来做什么。我给她缝了一把。现在多缝两把，让借花的人能少付一个铜子。'),spoken('迟耘','最小的一朵给窗边，搁低些，她站不起来也能看。','window-booked'),spoken('迟耘','我把花别在门闩上。关门的时候花也跟着他们进去了。','alley-booked')])],
 [exit(3,9,'sill-walk',[26,10],'从小院回雨巷'),exit(21,9,'wake-court',[19,8],'从前街回守夜灯院')]);
export const nextDay=witness('daybreak-tea','早班秤工身边提碗的末芝',16,7,[
 s('末芝','老了眼睛还会撒谎。乍一看，茶棚有影子我就以为她还站着。碗我认得，我想去。'),
 s('玛拉','走吧。她女儿给你留了低窗。不抬手就把茶搁在外面。秤台通礼院的小道刚开，扶我胳膊。')],'tea-at-dawn',['window-booked','shift-receipted'],{lockedText:'两姐妹还未在礼院约低窗，或二班交工签还没到过秤台。'});
export const lastDay=witness('night-tea','第三班灶前扶碗的月砻和末芝',13,9,[
 s('月砻','不能左转。左门进去就是供茶的大棚，伙计们还在等。你挽着我，从后门一个一个来。'),
 s('末芝','怎么你反倒领我？我看着你学走的啊。'),s('月砻','那我把手放松一点，你想走多快就走多快，走出夜灶再绕进门。')],'tea-at-dusk',['alley-booked','berth-fixed'],{lockedText:'第三班到夜灶才开伙计巷的后门。两姐妹可先在旧礼院议定。'});
export const finalSills=[
 witness('tea-hand-lift','等渔柳在低窗前举起手再递茶',6,9,[s('渔柳','我在这里。过秤的声音盖住了我第一声。你不用抬那么高，我看得见。'),s('末芝','来时只想喊她一声溪雁。现在想把你这只手捂一会儿。'),s('玛拉','我在外头扶碗，窗由你开。')],'tea-low-visit',['tea-at-dawn'],{action:{type:'flag',id:'tea-low-visit',set:'tea-received'}}),
 witness('tea-back-latch','从巷内等月砻拉开后闩，再放一位伙计入内',20,11,[s('月砻','我转了两下。只进一个，别人都看得见门还开着。'),s('渔柳','我今天喝了三碗热的，娘的伙计把壶抢走替我守的。'),s('末芝','那我不喊她了。坐在她小姑娘旁边，喝完再去替她站一班。')],'tea-long-visit',['tea-at-dusk'],{action:{type:'flag',id:'tea-long-visit',set:'tea-received'}})
];
export const lateTea=witness('tea-in-salt','再见背茶匣的茶船伙计石耳',13,9,[spoken('石耳','盐市不开她家那种矮窗。我在锅盖上磨了个口，渔柳不用跟客人打招呼也能把头碗给我。','tea-low-visit'),spoken('石耳','她家后门让伙计一个一个进去。我回船也把睡铺帘改成内闩。头一回有人歇班不用在门上拴个铃。','tea-long-visit'),s('玛拉','那只豁口小碗呢？'),s('石耳','还在烧茶。你以为东西送过死者就停在那一天啦？')],'tea-crossed',['tea-received']);
