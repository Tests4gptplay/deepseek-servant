import {say as s,person,exit} from './parts.mjs';
import {fixture,witness,spoken} from './voyage-parts.mjs';
import {setting} from './registry-parts.mjs';

export const saltCase={
 'salt-lane':[
  person('drawer-skewer','一边剔枣核一边等船靠的岑蒜',9,9,[s('岑蒜','十二只蓝抽，票作有一半朝门，过仓棚有一半朝水。我舅在棚下串香饼，开饭他就把甜的一面转墙。'),spoken('岑蒜','找磨碾的人？回西窗往闸里走。找拿柜的人？从我这儿进票作，穿过窗下有两条车痕那口门。你不用记我舅的名字，跟着甜味去。','harbor-truth'),spoken('岑蒜','门楣搬回去了，留下的薄格另打了一套木条。四个工轮流修，还没哪个愿意把自己的手扎成筛子。','drawer-shop-back'),spoken('岑蒜','今日是歧米唱潮。她总把末尾唱低半声，我给听走神的人卖酸果。','drawer-wage-back')])],
 'ticket-works':[
  witness('drawer-salt-arrival','点开票作檐下的蓝抽，先闻留在榫眼最深处的一味海茴籽',12,8,[s('歧米','你看见的六只打开口就有墨味。后头六只朝过仓棚，粮工拿来装领粮人的小东西。有人把一只乳牙放在这里，来年找回，她孩子新牙都长了。'),spoken('伊沃','我亲自重走了西窗。关门的人是我，拿货抵住户的，也是我。','drawer-ivo-spoke'),s('玛拉','把货到的一面和人没到的一面拆开。我们还得问，如今正在用这十二个抽格的人为什么舍不得它。')],'drawer-salt-open',['harbor-truth','!party:selene']),
  witness('drawer-only-today','请歧米先讲她在盐市能拿得准的事，过去没有在场的部分留空',18,10,[s('歧米','你们来这里时伊沃已经说过关门那一夜。你没有带着我重走那条运柜路，别跟这里的人说你亲眼看见。'),s('伊沃','有件眼前能做的。旧柜长什么样、现在谁用它、谁有权说要不要它，我们到跟前去问。'),s('歧米','行。从柜子往里摸。有个地方只磨过上沿，没有石粉。')],'drawer-present-only',['drawer-salt-open','!drawer-ivo-spoke','!party:selene'],{action:{type:'flag',id:'drawer-present-only',set:'drawer-salt-scoped'}}),
  fixture('drawer-match-old-track','拿先前自己看过的柜底在票作低窗重对两只停过的脚',15,9,[s('歧米','这两处真是你们去过的，我能请你们讲。石碾下那条弯怎么磨出来，由我外婆自己说。')],'drawer-salt-scoped',['drawer-ivo-spoke','drawer-salt-open','!party:selene']),
  person('drawer-wax-apprentice','把港守误刻成一只没戴帽的墨鱼的小学徒',21,11,[s('小徒','不是偷懒。我画的港守本来会往身后喷墨。'),spoken('歧米','找蓝格的人走票作另一头的窄车门；找今天拿不到饭的人从公秤去寄宿院，再下粥阶。','drawer-salt-open')])],
 'transit-shed':[
  fixture('drawer-second-side','从仓棚一侧把后排六只柜抽一一推到底，再绕去看对面的留缝',9,9,[s('柜格','两排抽背靠背。上沿是旧海茴油，下沿全是工人反复碰过的薄盐。留缝下面能直接看见对面，没有过石碾。'),s('粮工胥瓦','让出去当然可以。你们把蓝柜一拔，我没地方放这班人的药布、乳牙和换班的铜子。我不能把钱和药布一起倒进面粉。'),s('瑟琳','柜子到了，家没有到。我们这一班拿了柜子，也拿了有人把它收回来才得付的功夫。')],'drawer-two-uses',['drawer-salt-scoped','!party:selene']),
  fixture('drawer-split-strips','亲自从卸货处带走第一排薄分条，给原要分类的私物分开位置',21,9,[s('胥瓦','铜子的格稍浅，手指背先探就不至于捞走别人的药布。我要的是有人真干这半班，不是港务厅写“照旧安置”。'),s('瑟琳','我领傍潮那半班，今夜我的测水穿巷少收一趟钱。这只药柜明早就跟主人走。')],'drawer-strips-in',['drawer-shop-choice','!drawer-settled']),
  fixture('drawer-cabinet-off','跟歧米从外船一格一格卸空蓝柜，再让短芹自己带它离开棚口',24,10,[s('短芹','第一抽是酸的，第二抽甜的，第三抽二十年前是给小孩儿的，我可没告诉你藏什么。'),s('胥瓦','我们接的六只空新格还很涩。我知道要找谁去刨，今早不用你们荣归了就都散伙。')],'drawer-shop-back',['drawer-strips-in','drawer-work-covered','!drawer-settled'],{action:{type:'flag',id:'drawer-shop-back',set:'drawer-settled'}}),
  fixture('drawer-leave-drawers','从货棚一侧让每一户从自己的格里认东西，蓝柜留给现在用它的粮班',6,12,[s('歧米','我外婆拿走灰石，留你们蓝抽。留是我们自己定，不是你们早有权拿。'),s('胥瓦','嗯。有一天她要磨东西，我带自己的手过去。留在我这儿的不能再叫“无人来领”。')],'drawer-custody',['drawer-job-choice','!drawer-settled'])],
 'ration-stair':[
  witness('drawer-eat-a-shift','从粥阶下来给正吃夜饭的两家各坐一会，让瑟琳开口说自家所占的一班',18,8,[spoken('瑟琳','昨天我拿家里第二张饭筹押过。今天不能再拿同一张给别人吃。我来找能拿到手的活。','witness-first'),spoken('瑟琳','我娘已经少了封票班。别给我写“瑟家补一班”四个字。哪天去、谁少拿一份工钱，我现在说。','ledger-first'),s('短芹','旧碾我没卖过，柜子我想要也有权要。可我外孙女倒愿意跑船，她不跟着我磨一辈子。'),s('歧米','我想跟船，也想她那摊生意还能开。要两样都给我，就得有另一个从这张桌上走开。她们没欠我两份。'),s('瑟琳','现成的只有一条上货路。我可以顶一班分格，让蓝柜回原店；也可以把我自己的一个有钱的报潮班让出来，柜留粮班。')],'drawer-two-homes',['drawer-two-uses','salt-priority','!party:selene']),
  witness('drawer-hear-family','把杯子留在当事人中间，听她们各自愿放下的那一件',12,10,[s('短芹','柜子回来，我自己摆，不能让粮班的三只药布滚在地上。柜子留那边，她的第一班要真能领到钱。'),s('歧米','把我名字写在班上之前，劳你们跟我走过那一程。你们要把柜子搬回来，也先带会下一班的手。'),s('玛拉','我们只有一组手。想从哪件事开始？',[{text:'腾出傍潮半班，帮两边搬好抽柜，让旧铺重新开门',set:'drawer-shop-choice'},{text:'把报潮的有薪船班让给歧米，她亲自跑完，蓝柜留给现用的人',set:'drawer-job-choice'}])],'drawer-house-picked',['drawer-two-homes','!party:selene'],{after:[s('歧米','我们挑过了，谁占哪一班，到现场看她是不是真去。')]}),
  witness('drawer-first-counter','同瑟琳坐进要替的傍潮半班，直到下一组人能自己摸到薄格',21,9,[s('瑟琳','我先在这儿。你去把空格那一边的药布拿来。'),s('胥瓦','哦，搓起来有麻味的格，铜子的在旁边。我那班人试得出来。'),s('歧米','我回去跟外婆到柜脚那头等，不用再指着盐市说整家店已经在那儿。')],'drawer-work-covered',['drawer-strips-in','!drawer-settled']),
  person('drawer-quiet-brother','舔掉饭勺柄上最后一粒盐的排班工',6,12,[s('排班工','我背盐背得厉害，可一家六个人我从来记不对哪个今天忌酸。我做爸的有时还得问做小孩儿的。'),spoken('排班工','要找蓝柜实物，穿回公议廊，去公秤后门那个货棚。她今天认的是一份工，不是领第二顿饭。','drawer-two-homes')])],
 'brine-weigh':[
  witness('drawer-selene-hands-over','走到公秤临水面，让瑟琳当众把自己报潮的半班与应领钱给歧米',15,9,[s('瑟琳','你报这个方向。我原来在这个半班拿的三枚小钱，你做完你拿。不许把我娘的名字写成代领。'),s('歧米','你能把船指给我看；你不能站我背后替我报。'),s('胥瓦','那就从货棚外侧登步船。这班往北行准备码头的家门送当天的第一口水，做得完就有人付。')],'drawer-paid-place',['drawer-custody','!drawer-settled'])],
 'north-pier':[
  witness('drawer-ride-the-watch','随歧米真的抵达北行码头，在两道系舟影分开时把报潮的位置让给她',15,11,[s('歧米','谁先靠？前面那条吃水浅，后面那船压着人家送过秤的石砣，不能凭着蓝不蓝来认。叫浅的先靠，深的再转。'),s('泊位童','她刚说的时候你们没从旁边纠正，那就按她的声音喊。你是有这一班，不是明天请你来问问。'),s('瑟琳','三枚到手。我的袖袋今天少了正好三枚。')],'drawer-wage-back',['drawer-paid-place','!drawer-settled'],{action:{type:'flag',id:'drawer-wage-back',set:'drawer-settled'}}),
  person('drawer-after-watch','装了两种酸梅、回程又得重新分开的短芹',9,11,[s('短芹','北风干，南风湿。你要说一筐都叫梅，你得自己吃。'),spoken('歧米','我这趟从自己挣的三枚钱里挑出一枚买酸的。外婆藏的甜籽又给小簪偷吃了。','drawer-wage-back'),spoken('胥瓦','我下班没抢到她的酸花糖，第二天我就早点去。那摊子现在总算真在她自己的地方。','drawer-shop-back'),spoken('短芹','你们上过北航才回来。盐市的这一班早就换过了，你可以坐下来吃，别把早过去的那一晚记到你自己身上。',['party:selene','!drawer-settled'])])],
 'crib-hold':[
  witness('drawer-grind-again','把已回来的上柜推到原石座旁，先让短芹坐到她一向低头的那面',24,10,[s('短芹','柜子靠墙，不要重新压在碾心上。放十七年人也得有地方伸膝。小簪你再偷芝麻就给我磨一下午。'),s('小簪','那我就偷一下午。')],'drawer-home-visit',['drawer-shop-back']),
  witness('drawer-grind-together','蓝抽留在粮班，短芹教孩子用原石给街坊磨各自的香籽',21,9,[s('短芹','不开原来的整铺了。这块石头还跟我在一处，你想用得先替我扫地。'),s('歧米','我有自己的工钱，回来买一杯。你可不能因为我是你外孙女给我盛得特别少。')],'drawer-home-visit',['drawer-wage-back'])]
};
export const drawerSaltExits={
 'transit-shed':[exit(27,11,'north-pier',[14,11],'随已交给歧米的付薪潮班亲走货驳，不走北航客道',['drawer-paid-place'])],
 'north-pier':[exit(18,12,'transit-shed',[26,11],'随今日报潮的回舱班回盐市货棚',['drawer-paid-place'])]
};
