import {fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,object} from './parts.mjs';

export const saltDepot=witness('north-rye-boat','看最后一锅或第一批春苗实际从船上卸下',19,9,[
 spoken('独粟','额外接的晚饭到了。掌篙的人预支了两班工，船先回港，人再睡。仓里住得下春种，他没有长出第三双手。','rye-seed-vote'),
 spoken('垄瓷','锅底真有半袋碎麦。腾出来的干舱下一潮挂苗架，占了接煤的床位。','rye-pot-vote'),
 spoken('石参','听证上先护住我的话，船晚走了一班。我可以不说船名，可不想没人看见那一班空船。','witness-first'),
 spoken('石参','明榜早，饭出得快，可作证的人还拎着旧罩，工钱留到下班才敢领。','ledger-first')],'rye-boats-done',['rye-received']);
export const saltWinter=witness('rye-winter-workers','到冬岸看到住暖阁的苗或换季种船',16,9,[
 spoken('汀籽','我留下活苗二十三丛，坏了六丛自己记。没有把阿娘腾的床说成白送全盐市一个冬天。','rye-seed-vote'),
 spoken('沙荷','来春借的种到了。我秋收的第一层给夕豆，哪怕打雹，也不能把她的一层悄悄写没。','rye-pot-vote'),
 s('瑟琳','我只问他吃饱没有，就当自己懂得一家人。今天哪盘再试，让他挑。')],'rye-winter',['rye-boats-done']);
export const saltGrave=witness('rye-last-harvest','读汀籽亲手寄来的苗穗或头份租',19,11,[
 spoken('汀籽','穗没齐，有二十颗闭着。我留了根，想等春天再算。娘回自己的床睡了，阁窗还给别家留一天。','rye-seed-vote'),
 spoken('汀籽','第一筐租已经给夕豆。我把空屉带回自己家，明年想种一种长不高的，免得好风先吹断它。','rye-pot-vote'),
 s('瑟琳','我不在他名字后面写家属二字。他有种田的名字，也有端碗吃饭的手。')],'rye-closed',['rye-winter','grave-signed']);
export const pearlPlant=witness('pearl-new-live','陪蕖末亲手把活贝放回有流的水槽',21,10,[
 s('蕖末','最小的壳张开了。我用指节听见一点水推出来。下货地点写我家的称呼，听起来不信的人可以再查黑钩。'),
 s('米拉','走的是你自己的船。工时我来贴，不能把你的日子赔成我画图好看的一个角。')],'pearl-living-done',['pearl-living'],{action:{type:'flag',id:'pearl-living-done',set:'wren-crossed'}});
export const pearlTeach=witness('pearl-new-watch','让另两只艇各从自己的前后舷照一遍',21,12,[
 s('扁蒲','第二条艇把白背画成小船，在黑岩边画岸石。她没照着我这船的角度抄。'),
 s('秦汐','今天该赶刻新海湾图的班，米拉空出来教这两双手。图晚印，摊位先把空角拿来挂衣。'),
 s('米拉','她们找得到回路，空两天值得。这两天是我自己答应的。')],'pearl-teaching-done',['pearl-teaching'],{action:{type:'flag',id:'pearl-teaching-done',set:'wren-crossed'}});
export const northWinter=witness('wren-winter','在冬岸同鹤青复核蕖末真正用过的路',19,9,[
 spoken('鹤青','苗在冬岸开出第一小格。我娘照自己的法子分三次换水，她说活贝爱水胜过爱图。','pearl-living-done'),
 spoken('扁蒲','两位艇手带回第三只初来的小艇。米拉画完勘误，我们也能写下次实量；没人跟我要她的墨签。','pearl-teaching-done'),
 spoken('米拉','迟工那幅帆也补过。若你当时不肯让我写误走，我今天会当复测值不了几文钱。','wren-drift'),
 s('蕖末','坏贝笼也扛来了，留来挂冬衣。以后长好贝，不能当原来没坏过。')],'wren-winter-seen',['wren-crossed','winter-proof']);
export const northGrave=witness('wren-final-letter','在头次航行的墓坡拆开两图主的退图函',16,11,[
 spoken('鹤青','新苗自己睁开了。春图留着会游的白背。画它没错，把它画成固定才错；我的图上也有需你改的地方。','pearl-living-done'),
 spoken('秦汐','学徒测出我记错的岬影，我们三人各签在亲测那行。晚印那两天的店租也补回了。','pearl-teaching-done'),
 s('米拉','我落第一刀刻黑点鱼，总怕手抖。现在有几双别人的手，知道哪一刀不该跟着我走。')],'wren-final',['wren-winter-seen','grave-signed']);
export const gristTreat=object('moth-warm-share','替夜班留住炉火后领取壁兆递来的药茶',13,9,[s('壁兆','自己尝，别连杯咽。这锅能开到天亮，我们还有力气送下面那份。')],{requires:['moth-guarded','moth-root'],action:{type:'item',id:'tonic',value:1,set:'moth-cold-account'}});
export const gristDebt=witness('moth-empty-kettle','给食舫两头的夜班送拆灶后的空壶',16,11,[s('独粟','今夜得我自己煮。我有明火，另一户可得用冷水等。那只壶放这儿，不会又变成一盏药茶。')],'moth-cold-account',['moth-bypass','moth-root']);
export const trawlFare=[
 object('trawl-fast-pay','留下整帆的快艇带来一碗热贝羹',16,9,[s('何旷','这一班没延，药师从热羹中取一份给你。余下的先喂三只刚回来的小艇。')],{requires:['trawl-routed','trawl-test'],action:{type:'item',id:'tonic',value:1,set:'trawl-repaid'}}),
 witness('trawl-slow-pay','替裁帆慢下来的艇把第一担贝沿陆路送到冬口',22,9,[s('秦汐','剩两幅帆，最末一担得陆上抬。你肯扶担，说实话，何旷的贝苗才不用替整条船赔错过的市。')],'trawl-repaid',['trawl-detour','trawl-test'])
];
