import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit,flag} from './parts.mjs';
import {mechanism} from './district.mjs';
import {setting} from './registry-parts.mjs';

export const weir=region('weir-sleeve','锚夜 · 锚轮停了仍会倒流的套闸',6,'flood-harbor',33,21,'stone',
 [['water',0,0,33,4,'压力高于街道的黑海槽'],['wall',3,4,4,4,'旧岭上来的上游砖'],['wall',15,2,3,6,'旧闸油颈'],['building',24,3,8,5,'闸壁背后的住户小窗'],['water',21,15,12,6,'倒灌会到人住街的沟']],
 [['pier',2,10,28,2,'两个踏板可独立返回'],['rope',8,13,14,1,'停锚仍绷紧的钢索'],['lamp',22,8,1,1,'小窗灯下的墨水痕']],
 [witness('weir-tender','把闸杯倒扣在耳后的税船水工·尔箬',9,10,[s('尔箬','铁停了，水没停。轴上能站人是你们四个的工，铜管后面那群人还在向我们清嗓。两端同时开会拿他们的地板当泄口。'),s('伊沃','我的旧签准许船走，这个签不能准许谁家进水。让我从活的一头读回来。')],'weir-called',['clutch-still']),
  fixture('weir-cup','在海侧用淬黑铜杯查回声',13,9,[s('尔箬','低一声在远端，近处的杯是干的。别让铁环响一下就开街口。')],'weir-sea',['weir-called']),
  setting('weir-both','试松两根踏索看里街浮片',18,10,[s('瑟琳','屋里那片浮叶翘向灶头——关回来。没用活人试，我们还来得及把路换到废引槽。')],['weir-called'],{'weir-dry':false,'weir-wrong':true}),
  setting('weir-outer','锁住住户侧脚踏，外槽改向早废的引水池',22,11,[s('伊沃','城市这只脚压到第二枚槽里，外端放半尺。两条索不要一起拉满。下街砖上该有人来回验。')],['weir-sea','ivo-line'],{'weir-dry':true,'weir-wrong':false}),
  person('weir-apprentice','用干茶叶量反流的崑芹',16,12,[s('崑芹','我从这里就能听见巷子有个婴儿哭，却看不见她。去年我凭耳朵就把水开错，赔了人家三只药罐。'),spoken('崑芹','铜杯还响，人住的那头没有再冒茶叶。我肯守踏索。','weir-proof')])],
 [exit(3,10,'ratchet-loft',[15,10],'回锚轮上层验停锚'),exit(28,10,'shale-gate',[4,9],'从套闸背后下屋脚读水线',['weir-called'])]);

export const gate=region('shale-gate','锚夜 · 泥线下曾经封航的檐门',6,'flood-harbor',31,21,'stone',
 [['building',1,1,6,6,'前港卫上锁的旧住室'],['water',12,0,6,8,'由套闸渗下的窄井'],['building',24,3,6,5,'旧票亭的外窗口'],['wall',0,15,11,6,'倾斜后顶住横弄的灰檐'],['water',21,15,10,6,'原外街的汊水']],
 [['path',2,9,25,3,'坐轮椅也能撤到内闸'],['lamp',10,8,1,1,'旧守灯员有钥匙的门洞'],['rope',14,12,11,1,'被困者这边也能抓住的外作索']],
 [fixture('shale-window','从活人窗沿捞回一片软叶',10,9,[s('窗后的人','叶软下去了，我家没有倒水。别敲玻璃，我在隔壁替孩子系衣带。')],'shale-read',['weir-dry','!weir-wrong']),
  mechanism('weir-head','在泥刻尺前逐项核停锚和水头',16,10,[s('瑟琳','轴已停是真的，晒药屋仍可能先淹。你拿两只杯跟屋里人对一次再给布兰信。')],['clutch-still','weir-sea','weir-dry','shale-read'],'weir-proof','哪一路可以接撤离索而不用居民堵门？',['城侧关、外槽半开，窗叶落回再通行','听到棘轮停就把城闸全部打开','把两槽封死，等水自己往低街走'],0,'靠海的杯仍响，屋脚浮叶得先落下。两个条件对应两处人看守的实物。',[s('尔箬','我把外槽标在铁的另一面，下一班不用看我脸色才碰水。')]),
  witness('old-blockade','把旧封航人古杬和临街住户都请到檐下',21,10,[s('古杬','门是我教你锁的。你把它重新交给我，我会走最短的灯室带走里间人。你也有理由不肯。'),s('临棘','你们两个十七年前都在里面。今天我在外边。把钥匙留给我们，我可以从外面开，但得把泡在水里那股绳捞起来。'),s('伊沃','我认得你们谁都不是一扇门。里面有要坐着走的人，外面四个修网的还没听见开门。')],'two-calls',['weir-proof']),
  person('right-to-open','伊沃把先开路的一端交到谁手里',14,11,[s('伊沃','我可以陪古杬亲自进灯室，把开锁留下的名字交给外面的人。也可以先把长索交临棘，让她从水街试门；古杬须搬板走慢道。另一边仍得找一班人回来接。',[
    {text:'陪古杬担名开内灯室，请外班稍候',set:'right-inside'},
    {text:'先把开门绳交临棘，亲接守灯班走慢道',set:'right-outside'}]),s('临棘','哪一个被你叫作“后来”，你就回来听那一个的脚步。')],{requires:['two-calls'],action:flag('right-given'),after:[s('古杬','里弄走守灯斜楼，外弄走灰礁水巷。先领到的一边能给后来的一边送信。')]}),
  person('shale-roofer','将斧头关进工具匣的陂莲',8,12,[s('陂莲','我不是因为船走才高兴，我家那口窗往上还有一层住人。关城侧时记得朝上喊。'),spoken('陂莲','临棘自己把绳头送到了靠垫旁。旧港卫的脚慢，他们又去接了一趟。','outside-returned'),spoken('陂莲','古杬回来时光着右脚，说要拿自己的鞋替外班修那道棱。','inside-returned')])],
 [exit(3,9,'weir-sleeve',[27,10],'上套闸重放回索'),exit(24,9,'lamp-ward',[4,9],'向里找掌灯班',['right-inside']),exit(26,11,'hauling-cut',[4,10],'跟临棘下低礁水巷',['right-outside'])]);
