import {berth} from './the-door-that-became-a-floor.mjs';
import {fixture,witness} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';

const night=['harbor-tilted','!base-safe'];
export const quiet=berth('heel-quiet-return','锚断之夜 · 仍能从里面开门的家人的廊',6,34,23,
 [['building',1,1,8,7,'昔日兄妹共住的半阁，保住了内侧开门面'],['wall',13,0,5,9,'外面涨水，门框右边仍留一个小转台'],['building',25,2,8,7,'靠墙的坐凳能让一人陪同'],['water',0,17,13,6,'外侧普通疏散坡的水声'],['crate',23,17,11,6,'居民自己晾的暖木屐']],
 [['path',3,10,27,2,'整扇未切的门里，折叠小坡可滚入一把有轮子的椅'],['heel-frame',12,10,4,2,'低凹把手在内侧，坐着的人也握得到'],['heel-stair',21,13,4,2,'给家属一位同伴的转身圈']],
 [fixture('heel-fold-knee','在新活水边把转台放平，留出轮椅的回转余地',9,12,[s('柳珏','昨夜我梦见他照旧来问借芝麻。我原以为到这里要先记起他最后一句，现在只想把门开到那里。'),
 s('玛拉','你来拉开，我把门脚的退楔摆到轮后。回头时我们让你先转，不会有人从后面推。')],'heel-quiet-pivot',['heel-kin-knocked',...night]),
 witness('heel-family-pass','顺柳珏转椅的方向走过今天的低门',17,12,[s('柳珏','别扶我的握把。单脚拨一下，轮子能转回我来时的方向。'),
 s('雁折','我妈今天第一次自己走进这屋，不是因为她肯把我哥托起我的那一刻讲给整城人。门把磨得光，已经够她握住。')],'heel-quiet-inside',['heel-quiet-pivot',...night]),
 witness('heel-return-handle','站在门外接回柳珏自己推出的暖木屐',27,13,[s('柳珏','丘沚右脚长半寸。我做过那么多年鞋，给自己儿子做的最后一双偏把左脚做长了。今天我还是觉得这事挺好笑。'),
 s('玛拉','我可以跟我父亲讲的许多话，以前总嫌该庄重，后来没来得及。你说的这一句归你。'),
 s('雁折','门还在。不能叫那辆大车走这里，外头有普通宽坡，我们也要去扶一次。')],'heel-quiet-walked',['heel-quiet-inside',...night]),
 person('heel-scratch-on-cup','把鞋楦削成杯垫的近邻',22,15,[s('近邻','谁想进来得问她们。要蹭水喝倒不用守出入的规矩，我家门边有只搪瓷碗。')])],
 [exit(3,12,'heel-flooded-hall',[22,16],'从家人门的回转平台回两灶弄')]);
