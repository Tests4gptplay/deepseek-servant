import {exit,say as s} from './parts.mjs';
import {fixture,witness,spoken} from './voyage-parts.mjs';
import {tidePost} from './district.mjs';
import {mouth,well} from './narrows-water.mjs';
import {share,crib,slip} from './narrows-ferry.mjs';
import {weir,gate} from './tilt-weir.mjs';
import {gallery,cut,loft} from './tilt-commons.mjs';
import {grate,wellMark,slipMark,coldGear,coldFoe} from './seed-grating.mjs';
import {needAir,terrace,oilshade,dryBundle,life} from './borrowed-breath.mjs';
import {wash,porch} from './braid-porch.mjs';

export const nightMaps=[mouth,well,share,crib,slip,grate,weir,gate,gallery,cut,loft,wash,porch];
export const nightGear=coldGear;
export const nightFoes={[coldFoe.id]:coldFoe};
const doorways={
 'moor-pocket':[exit(13,9,'shiver-bars',[4,11],'把满载小艇送进双舷影碎冰门',['moor-proved']),exit(10,13,'weighted-slip',[26,11],'回访夜渡的水罐和亲自到岸的人',['night-landed'])],
 'weighted-slip':[exit(26,12,'seed-grating',[4,10],'对照井钉与围裙，低水从背槽入内',['grate-nails','grate-apron','tide:low'])],
 'ratchet-loft':[exit(16,10,'weir-sleeve',[4,10],'棘轮已停，去套闸查活水与两道门',['clutch-still']),exit(11,13,'crossing-loft',[14,14],'沿已交回的摇铃索复查两班人',['both-bells'])],
 'safe-keel':[exit(13,11,'wash-sledge',[4,10],'扶殓舟上白崖洗帆间，为先送到的人整衣',['base-safe'])],
 'burial-cape':[exit(10,8,'braid-porch',[26,10],'由家属门回看帘后送别间',['base-safe'])]
};
const transfer=(id,name,x,y,lines,done,needs)=>witness(id,name,x,y,lines,done,needs,{action:{type:'flag',id:done,set:'night-relief'}});
const shoreJobs=[
 transfer('loft-pullers','接家船后替转仓班做第二次搬水',19,9,[s('燕西','当年我爹被写成免费抬担的邻居。这次把夜贴开到我手里，别只写大船开了。我送一罐上来，里面的人自己喝。'),s('瑟琳','我跟你回下层，慢的一班也到。')],'late-water-served',['both-shores','night-kin-first']),
 transfer('loft-dry-bunks','请转仓艇把等过一潮的家船人逐个接到干铺',14,10,[s('沙荷','第一趟给了燕西，她自己掌船回来接我们。把从水里拧出来的床单交给我。女儿，谁欠了工钱，别从我干泊的那一栏划。')],'late-kin-served',['both-shores','night-cart-first']),
 transfer('loft-older-route','由本埠夜桨班承担尚无夜渡记录的旧航次',23,12,[s('海杏','你带来的旧冬签没有写这班低灯。我数得见今晚到了两个队，不替旧冬多记一半路。我们本埠再划一趟，把最后一瓮送上岸。')],'local-relief-only',['both-shores','!night-landed'])
];
const lateWitness=witness('grate-home','请缺班的绪白在白崖自己交代晚归',20,9,[
 spoken('绪白','护住整幅篷那次，我哥还有余力替另一家留一盏灯。今晚我们两人坐一起，说以前他为什么看见空工位就生气。','grate-net-whole'),
 spoken('绪白','我用掉暖仓一床补帆，受凉的水工改去前廊。明晚我们替他接一班，不说只有救人没用屋。','grate-net-cut'),
 s('玛拉','你来替别人作证是你的事。你先把一只干袜子穿上。')],'grate-home',['grate-aboard','base-safe']);
const closing=witness('night-farewell','墓边接住已从夜渡和水巷送来的两只空碗',17,12,[
 spoken('璃岸','对家属只留了岑茴和她的手艺。街上没有牌号，可我明年回来找得到。','buried-with-name'),
 spoken('璃岸','留白的木牌就在亲友屋，人已经好好安葬。我要来，没人从纸上问我姓什么。','buried-in-care'),
 spoken('燕西','米船先靠，我班少睡，小舟最后还亲自交水。今后谁领夜补，谁就回去找还在路上的那一班。','late-water-served'),
 spoken('沙荷','我等的那趟粮船已过冬。燕西先到，她再把我接上。这一栏轮工写她，不记我女儿的人情。','late-kin-served'),
 spoken('海杏','旧航那一页没有我。今天两班在我的担架旁交过水，这一笔我自己来写。','local-relief-only'),
 spoken('筒青','古杬开过我们一回，我留下钥匙，外班听到我回去喊。旧港卫没有因此拿回那座门。','inside-returned'),
 spoken('临棘','灰礁这头的钥匙我保管到有人接下一班。回来带我们走的是两个人，不是那年的一道封航令。','outside-returned'),
 spoken('绮红','天亮了还能举灯，我没有从你们的船尾变成一行数字。','breath-home'),
 s('玛拉','我手上还有替人整衣留下的一道线印。两碗是给今天说过话的两家。父亲的两行都留着。')],'night-after-grave',['grave-signed','burial-disposition']);
const places={'split-cistern':[wellMark],'weighted-slip':[slipMark,tidePost('slip-grate-clock',12,13)],'crossing-loft':shoreJobs,'safe-keel':[lateWitness,needAir,life],'dry-court':[terrace],'salt-lane':[oilshade],'flood-stair':[dryBundle],'burial-cape':[closing]};
const gates={
 'winter-proof':['night-landed','两潮泊桩西有双舷影的夜渡。水罐、六尺船、担架与会自己答灯的人都要实际到岸。'],
 'bran-unpin':['both-bells','棘轮停了，水还在走。经套闸验窗叶、让屋里和低艇两班真实到楼，把两响交回来再解锚。'],
 'loft-bell':['night-relief','两班先后不同。按冬岸自己答应的船次真的补送水或干铺；若是旧冬签，到本埠夜桨边核实。'],
 'lower-coffin':['burial-disposition','引航驳的洗帆间还有先送到的一位。玛拉整衣，米拉署实见水线，再由家属决定帘后留名。']
};
const changes={
 'cover-letters':[['buried-with-name','玛拉','另外一位私簿上写岑茴。她的名字只去她家属的手里。'],['buried-in-care','玛拉','洗帆间那一位与辨清的遗物一同安葬，公开的名位依愿留白。'],['inside-returned','伊沃','低灯归筒青了。临棘等过一班，我记得回去的路。'],['outside-returned','伊沃','外面的活索由临棘试过，守灯的人也走过慢坡。']],
 'wave-host':[['night-chart','斑栎','退绳仍系在黑螺孔。只画蓝冰那幅我留下提醒自己。'],['night-landed','豆岚','我今后也负责推夜灯，坐着就能答。']],
 'winter-cook':[['night-kin-first','勾婶','转仓班今夜要背罐爬坡。水送到再开她们的夜贴。'],['night-cart-first','勾婶','先靠的是转仓小驳，家船从上铺的门拐进来。我给那头留冷粥。']],
 'reserve-oar':[['inside-returned','外班桨手','里面先走，我们等到筒青把低灯送回来。'],['outside-returned','旧灯手','水街先开门，古杬扶了慢坡的旧扶手。']],
 'mira-after':[['wash-map','米拉','我签的是找到她的这条弯。愿意把名字交给谁，从来不由我落笔。']]
};
export function withNightPassage(map){
 const entities=map.entities.map(original=>{
  let e=original;
  if(gates[e.id]){const [flag,tip]=gates[e.id];e={...e,requires:[...(e.requires||[]),flag],lockedText:tip};}
  if(changes[e.id]){const k=e.after?.length?'after':'dialogue';e={...e,[k]:[...e[k],...changes[e.id].map(([key,who,line])=>spoken(who,line,key))]};}
  return e;
 });
 return {...map,entities:[...entities,...(places[map.id]||[])],exits:[...map.exits,...(doorways[map.id]||[])]};
}
const arcs=[
 ['the-shifting-black-sill','一船真的能去的冬岸','main',['night-trial','black-sill','fixed-transit','night-chart','salt-drop','fresh-thread','night-water']],
 ['whose-second-oar','轮到哪一家背水','companion',['night-family','night-loader','night-promised','crib-turned','night-load-ready','night-true-stroke','night-landed','night-relief']],
 ['under-four-nails','四枚钉朝下的背风槽','hidden',['grate-nails','grate-apron','grate-heard','grate-clear','grate-aboard','grate-home']],
 ['the-door-he-closed','门开在哪一侧','main',['weir-called','weir-sea','shale-read','weir-proof','two-calls','right-given','both-shores','both-bells']],
 ['the-bed-after-the-roll','已经点过名的人也要照料','side',['borrowed-breath','breath-rigged','breath-home']],
 ['the-found-and-the-named','安葬不必等一张名字','main',['wash-brought','wash-lifted','wash-pairs','wash-laid','wash-map','tag-returned','braid-known','burial-disposition','night-after-grave']]
];
export const nightQuests=Object.fromEntries(arcs.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
