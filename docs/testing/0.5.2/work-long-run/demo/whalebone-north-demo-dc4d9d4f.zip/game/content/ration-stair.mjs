import {region,fixture,witness} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {setting} from './registry-parts.mjs';

export const steps=region('ration-stair','盐市 · 轮到谁的粥阶',3,'salt-market',27,17,'stone',
 [['water',0,0,27,3,'洗桶渠'],['building',1,4,5,3,'两家共用的直灶'],['crate',11,4,4,3,'没有烧开的第三锅'],['building',17,12,9,5,'退班家属的灶间']],
 [['path',2,8,22,2,'并排走人的桶阶'],['rope',8,10,10,1,'代领时握的粗索']],
 [witness('foreman-bowl','管空碗的代领人·祁陶',8,8,[s('祁陶','别叫我善人。我替脚慢的人领，另外几家就要等我的桶回来。'),s('瑟琳','你愿替我母亲到门口说一句吗？'),s('祁陶','半年前她替我修了桶箍，这个人情我认。要我签看过十五袋，我没看过。让大家今晚有粥，我再来听你。')],'kettle-count',['testimony-lodged']),
 witness('oar-mate','换潮船的出粮人·罗褐',17,8,[s('罗褐','病人没赶上亲自领票。怕认出筝，我们少烧半班。这锅盐泥沉了，得有人把淡水送上来。'),s('玛拉','我可以掌吊桶。锅里的每一瓢最后是谁点头？'),s('罗褐','在这里吃的人。你在轴上出力，我在锅边负责，这两句都写。')],'water-permit',['kettle-count','witness-first']),
 witness('relief-mate','来退母亲饭筹的荆童',12,9,[s('荆童','先放粮的时候大家都领到了。我姨也回来过，身上盖章的蛤粉吓人。她说谁拿她的姓名本来算赊账都不成。'),s('瑟琳','那就不把你的姨填成证人。今天少的那个封票班，你愿意陪我另找一个肯顶手的匠吗？'),s('荆童','肯。拉舅舅来的话，工钱付给他自己，别记成还我家的债。')],'shift-permit',['kettle-count','ledger-first']),
 fixture('bucket-bearing','手压翻斗把池底盐水泄回渠里',21,10,[s('玛拉','第一桶是底盐，须倒向黑渠。清水过了木沿，才翻进直灶。'),s('罗褐','你把井桶留在下阶，我来把饭端上去。长路上不要跟别人说我们等得心甘情愿。')],'water-raised',['water-permit']),
 fixture('salt-relief-receipt','按本人名字给顶班匠开本班饭筹',7,11,[s('祁陶','两栏别合：夜班钱付匠人，粮票仍归原来的家。筝愿回印房就让她回，不用证明清白来挣这张票。'),s('瑟琳','把我先垫的半班销掉。让我母亲自己决定是否留在这里。')],'relieved-shift',['shift-permit']),
 witness('ration-close-private','等桶回来的病船家属',13,7,[s('家属','这锅晚半天，只够我两口吃，没剩给船帮。明早我会再来。'),s('瑟琳','把今天漏的一户也刻在灶边，我去北岸会带着这份欠账。')],'water-account',['water-raised'],{action:{type:'flag',id:'water-account',set:'ration-resolved'}}),
 witness('ration-close-public','仍来领工钱的封票工',19,9,[s('封票工','米到了，这是米的事。人愿不愿回班，是她的事。我替一天，不拿她的长班。'),s('祁陶','把这张替班收条贴在工棚里面，窗外看不见她家的名字。')],'shift-account',['relieved-shift'],{action:{type:'flag',id:'shift-account',set:'ration-resolved'}})],
 [exit(2,8,'salt-dorm',[5,9],'回寄宿院问家人'),exit(25,8,'petition-hall',[13,9],'从空桶阶进公议廊'),exit(15,12,'blind-window',[13,8],'进无字凭窗')]);

export const windowHall=region('blind-window','盐市 · 摸得懂的领粮窗',3,'salt-interior',21,15,'wood',
 [['building',0,0,7,4,'装着签名本的锁柜'],['crate',11,1,8,4,'空碗托架'],['building',15,10,6,5,'供收回原件的黑布屏']],
 [['path',2,7,15,2,'两条不会在街口相遇的窗道'],['lamp',8,5,1,1,'照木边的短灯']],
 [witness('board-owner','不识印文的代班匠·仲寻',8,7,[s('仲寻','你有两张纸，长得一样。我凭什么知道食堂会拿哪一张？'),s('瑟琳','我可以把名字念给你。'),s('仲寻','你上船以后呢？给我一块能摸的留存板。我的手在场的时候，你可以把眼睛合上。')],'board-offer',['ticket-mother-heard']),
 fixture('board-test','闭眼摸收粮齿和兑讫的留边',11,7,[s('仲寻','窄宽窄是领粮，窄窄宽是交班。我把一边切乱，你重摸一遍。'),s('玛拉','两个薄口挨着，收回的副票。原来我认反了。'),s('仲寻','现在给你刻第一板。可报户数，不能报原名；要保留谁的名字由当事人选。')],'board-proved',['board-offer','pressure-rules']),
 setting('public-tray','先把无名副板递向街口公窗',5,8,[s('收板人','这是给谁看？这面右边两齿，是退件，我不能当作收件挂出去。没亮名；去内窗拿回。')],['board-proved','!board-consented'],{'board-mislaid':true,'board-in-hand':false}),
 setting('back-tray','从内窗退件口收回副板',14,9,[s('仲寻','你没有替她添名字。把这一笔失败也刻在板背，新做的人就知道公窗并非无名件的落点。')],['board-mislaid'],{'board-mislaid':false,'board-in-hand':true,'board-recovered':true}),
 fixture('maker-copy','留一道空边给当事人认板',9,9,[s('玛拉','新板留在柜内。街口的副板还在退件格，就先去拿回来，一件不能挂两处。')],'board-held',['board-proved','!board-mislaid']),
 witness('board-letter','出件人当面选择副板怎么流转',13,7,[s('仲寻','筝的答复到了，原板归她，副板只写批次。拿去给船上配餐的人试试，若连哪个月都摸不对，就带回重刻。'),s('瑟琳','我们能把用错过的两面都留下吗？'),s('仲寻','能，留错板是为了纠正后来的人，不是叫你羞愧。')],'board-consented',['board-held','family-choice','!board-mislaid'])],
 [exit(2,7,'ticket-works',[14,12],'回票作'),exit(14,8,'ration-stair',[14,12],'沿副窗下粥阶')]);
