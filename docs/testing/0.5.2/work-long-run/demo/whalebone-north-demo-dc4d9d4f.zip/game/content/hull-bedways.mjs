import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit,object} from './parts.mjs';
import {tidePost} from './district.mjs';
export const loom=region('loom-run','鲸城 · 三户连通的织架夹层',2,'whale-interior',28,17,'wood',
 [['wall',0,0,28,3,'侧舱低梁'],['crate',5,4,6,4,'租屋人装的老织架'],['crate',15,9,5,4,'天窗纱卷'],['water',0,13,9,4,'未补回的地板']],
 [['rope',10,6,13,1,'吊床穿过的两只活环'],['pier',2,9,12,2,'能托空床的承台'],['lamp',22,7,1,1,'七号门不灭的小灯']],
 [fixture('lift-testframe','将半坠试袋挂到高廊的空床',12,8,[s('徐照','人进去前先让空床过。我父亲试吊时肩有旧伤，不能再替一整条街证明没问题。'),s('玛拉','我拉这端，井梨来看。只有她点头，才动右床。')],'high-cot',['peg-sent','bed-permission'],{action:{type:'flag',id:'high-cot',set:'sled-tried'}}),
 person('loom-widow','一直把梭子握在左手的棉酥',22,8,[s('棉酥','七门哪来的“遗属”？人消失了，房租还按两个人收。先把我的那半只床还给我，再谈上哪贡花。'),spoken('棉酥','那份证词她自己定了去处。谁也没拿它当这只床下个月的租钱。','speaker-return')])],
 [exit(2,8,'eight-landing',[29,13],'下夹层回八户街'),exit(4,7,'sleeve-room',[19,8],'过刘家上窗'),exit(24,8,'bed-jetty',[3,7],'沿试过的顶绳到床码头',['high-cot']),exit(14,14,'net-heron',[3,8],'探被舱鸟堵住的护网走廊')]);
export const water=region('water-steps','鲸城 · 从湿墙穿过的踏水室',2,'underdeck',24,18,'wood',
 [['water',0,0,24,3,'舱底夜潮'],['water',4,4,7,5,'曾淹没床脚的方井'],['wall',15,3,5,5,'隔浪短墙'],['crate',15,12,7,6,'等载空架的几块木筏']],
 [['pier',2,9,18,2,'看得到旧水线的踏板'],['rope',11,7,1,7,'换潮记号绳'],['lamp',9,11,1,1,'贴墙龛']],
 [fixture('old-high-water','用手比过吊床底的水色',7,9,[s('井梨','这痕比褥底高一指。那晚往低处搬，因为最下铺有隔浪，反而不淋。别在报告上写“全城慌着逃”。')],'bed-waterline',['bed-permission']),
 tidePost('bed-clock',11,11),
 fixture('float-dummy','涨潮时从窄门将空架推上小筏',14,9,[s('伊沃','半坠绳松一段，水升时空架贴着短墙走，不擦产床。'),s('井梨','这段我看到了。你们推的是空架，取得的是我的答复。')],'float-cot',['bed-waterline','peg-sent','tide:high'],{action:{type:'flag',id:'float-cot',set:'sled-tried'}})],
 [exit(2,7,'cradle-room',[19,8],'回药灶隔扇'),exit(21,9,'bed-jetty',[16,8],'随涨水从湿墙入床码头',['float-cot','tide:high'])]);
export const jetty=region('bed-jetty','鲸城 · 旧产床的交接码头',2,'whale-interior',21,15,'wood',
 [['crate',2,1,5,5,'能转弯的空架'],['wall',11,1,7,4,'先让病人站稳的软壁'],['water',13,10,8,5,'可撤回的侧筏']],
 [['pier',2,7,16,2,'两路空床试交板'],['rope',7,9,5,1,'止晃布套']],
 [witness('cot-steward','留一块空板给人坐的井梨',10,7,[spoken('井梨','你从高廊把架放低了，我手伸得到回绳。现在能让我自己说什么时候它算床。','high-cot'),spoken('井梨','水筏停了，你还站在踏板上等我的答复。那我自己把白布系上。','float-cot'),s('井梨','右床可以用楔换闩，左床先留。我签自己的名字，另外七户不跟着我按指印。')],'beds-countersigned',['sled-tried','bed-permission']),
 person('empty-peg-child','把试布折成方块的小汾',7,8,[s('小汾','方块给没睡着的人拿手里揉。洗完我还得一块一块查有没有针脚扎脸。')])],
 [exit(2,7,'loom-run',[23,8],'循高钩回夹层',['high-cot']),exit(17,8,'water-steps',[20,9],'回涨潮筏口',['float-cot','tide:high']),exit(9,12,'crib-hold',[12,9],'带井梨的签回铺床巷',['beds-countersigned'])]);