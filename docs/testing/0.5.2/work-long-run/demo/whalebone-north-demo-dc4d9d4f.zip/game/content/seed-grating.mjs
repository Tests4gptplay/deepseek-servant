import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,object,exit} from './parts.mjs';
import {tidePost} from './district.mjs';
import {setting} from './registry-parts.mjs';

export const wellMark=fixture('salted-grating','察看双井外壁四枚向下磨亮的短钉',19,12,[s('卯丝','下边原是渔排背风槽。钉头同向，冬天还有人从底下拽过一条担架带。另一头在听铁环的岸门。')],'grate-nails',['well-heard']);
export const slipMark=fixture('slip-apron','翻看夜渡岸环积着草籽的旧围裙',18,11,[s('斑栎','人来回扯动才会在背面沾草籽。低水时，听低灯下方有没有一声活咳；有就把井边四枚钉对到横梁下。')],'grate-apron',['night-true-stroke']);
export const grate=region('seed-grating','冬岸 · 两条担架带之间的背风槽',5,'north-interior',26,19,'stone',
 [['water',0,0,26,4,'只有低水能从岸门进入的兜水'],['wall',4,4,5,4,'生着四排短钉的岸岩'],['boat',16,2,9,6,'冻在网下的运种小艇'],['crate',17,14,9,5,'可留作引流的破泥箱']],
 [['pier',2,9,21,2,'靠着井和岸环的后槽'],['rope',8,12,11,1,'被掉班人从里系紧的担架带']],
 [witness('grate-shipmate','靠在绞网梁下的缺勤船员·绪白',9,9,[s('绪白','我在下面捡泡水的春籽，把脚扭在架脚。上面有我哥的下一班，他以为我又请假。我说不出药名，只想上去让他自己认。'),s('瑟琳','门只开一掌，好在能退。冰鳅占着槽，当作你的错才真没救。')],'grate-heard'),
  object('grate-lining','领卯丝镶井调水时用的温瓷内衬',13,9,[s('卯丝','热罐碎瓷夹在领口。换到队伍装备栏才有用。瑟琳已经验过双水芯，可以用退盐术把冰壳劝开。')],{requires:['grate-heard'],action:{type:'item',id:'glaze-torque',value:1}}),
  object('grate-eel','引开吃冰上的软壳鳅，为整艇保留篷布',18,10,[s('绪白','背鳍暗下去就会擦过整个前舷，见到冰壳抬起再发潮。别把网勒进它身上。')],{requires:['grate-heard','!grate-clear','!grate-baffle'],action:{type:'battle',id:'mudskate',set:['grate-clear','grate-net-whole']}}),
  setting('grate-frame','把破泥箱垫在两块冰之间等空潮',15,12,[s('伊沃','我能把箱拉回来，没走之前没有人欠我们一张帆。要引它穿过去，就得割开自己那道顶篷。')],['grate-heard','!grate-clear','tide:low'],{'grate-baffle':true}),
  setting('grate-unframe','退篷前先撤下刚垫的箱',12,11,[s('绪白','泥箱退出来了。人还能在干处等下一潮。')],['grate-baffle','!grate-clear'],{'grate-baffle':false}),
  fixture('grate-open-net','涨水放出旧篷，让冰鳅带过暗槽',20,11,[s('绪白','篷布割开一臂长，回港我们的艇要靠暖仓过夜，空出一床给我把毛毯补完。')],'grate-net-cut',['grate-baffle','!grate-clear','tide:high'],{action:{type:'flag',id:'grate-net-cut',set:'grate-clear'}}),
  tidePost('grate-clock',7,12),
  witness('grate-aboard','让绪白扶自己的两条带从舱口出来',21,9,[s('绪白','我的脚够得到低灯。让我自己喊我哥，别用“船员一名”替我说。'),s('斑栎','我听见他骂了一声。那是脚扭了的人登舷，不是搁空铁环。')],'grate-aboard',['grate-clear'])],
 [exit(3,10,'weighted-slip',[25,12],'让带篓从低门上到听铃处')]);
export const coldGear={'glaze-torque':{name:'双井温瓷护领',slot:'charm',resists:{cold:.26,tide:.1}}};
export const coldFoe={id:'mudskate',name:'护着幼鳅的覆冰鳍',enemy:'冰泥鳅',level:8,hp:84,attack:5,resistances:{tide:1.26,iron:.92,light:1.08},
 phases:[{fromHp:84,tell:'鳍冰从两端相向扣紧，前舷一齐下沉。',moves:[{name:'拱槽',kind:'shell',element:'cold',counter:'skill',power:1.15},{name:'挤船缘',kind:'ram',element:'tide',counter:'guard',power:1.15}]},{fromHp:39,tell:'小鳅露出一线软背，大鳅开始向背风口侧滑。',moves:[{name:'穿篷',kind:'rush',element:'cold',counter:'dodge',power:1.2},{name:'擦舷',kind:'whirl',element:'tide',counter:'dodge',power:1.12}]}],
 rewards:{xp:28,label:'母鳅和小鳅都出了网口；整张篷留给今夜的人。'}};
