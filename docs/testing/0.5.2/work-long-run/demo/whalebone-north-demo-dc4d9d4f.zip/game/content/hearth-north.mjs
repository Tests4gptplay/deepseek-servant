import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit} from './parts.mjs';
import {mechanism,tidePost} from './district.mjs';
import {setting} from './registry-parts.mjs';

export const ash=region('ash-sound','北航线 · 被外潮咬去两级的夜炉岸',4,'north-coast',33,21,'stone',
 [['water',0,0,33,5,'报潮的两道鳗涌'],['building',2,4,8,4,'矮炉睡屋和一扇旋窗'],['wall',15,3,5,5,'托住送汤吊架的岸基'],['boat',24,4,8,4,'候退泥的夜工运艇'],['water',0,15,11,6,'破石阶下的东泥湾'],['crate',23,16,10,5,'灯油木箱和安全索']],
 [['path',3,9,27,2,'从北埠到探深桩的生火小径'],['pier',11,12,14,1,'可卸一段的窄梯'],['lamp',19,9,1,1,'低炉窗下的碗灯']],
 [witness('ash-grand','用围巾裹着罐颈的夜炉主人陶鹊',8,9,[s('陶鹊','我正式住这儿了。厨房在路边，四户夜工过路都能坐，不会拽着睡屋陪我挨喷嚏。代价是水一涨门口就得坏两级。乌笋上次骂得有道理。')],'ash-home',['kitchen-shore']),
  fixture('ash-heel','退水时俯身摸两道像油又不沾手的滑沟',13,10,[s('米拉','旧阶每一级向外斜，汤罐提在里手会挤人。直着下水的两道是划痕，不是盐霜。能把扶绳移到稳的那一侧。')],'ash-heel',['ash-home','tide:low']),
  mechanism('ash-carry','给冬季的短梯装一副过手罐架',21,10,[s('陶鹊','挂得稳我就敢给走得慢的人留热饭。不然门口看着最宽那天偏要摔。')],['ash-heel'],'ash-frame','石阶向海斜，滑沟朝外。热罐和扶手怎样过人才不必放弃其中一件？',['把罐提在挤人那一侧，两人平排下','将罐固定在滑沟外边，靠岸一侧留给空手握扶绳','把扶绳拆了，抱紧罐一步跳过'],1,'检查哪边给鞋底留着不朝海的一条干棱。罐架与扶人的手可以分开。',[s('陶鹊','我烧到一半也能把罐挂稳。头一位来的是修鞋匠井雁，他总算肯试这两级。')]),
  witness('ash-eat','陪井雁端到吊架底下，他自己试一遍回程',25,11,[s('井雁','我左膝弯不得。今天坐在吊架下能把脚伸直了。冬夜若撤离，给我同一种边绳；别把我重新数成一只碗。')],'hearth-north',['ash-frame']),
  tidePost('ash-clock',10,12)],
 [exit(3,10,'north-pier',[7,8],'走北埠的炭砖人行道'),exit(29,10,'lead-sound',[6,10],'沿挂过真热罐的石阶去测深桩',['hearth-north'])]);

export const skiff=region('spoon-skiff','北航线 · 从不系住睡屋的摆艇',4,'north-coast',32,20,'wood',
 [['water',0,0,32,5,'潮汊两片不同方向的顺鳞纹'],['boat',3,4,7,4,'里层备菜小艇'],['building',14,3,6,5,'不碰船侧的炭炉罩'],['wall',24,3,7,5,'收春网的黑石嘴'],['water',0,15,13,5,'艇尾的浅鹅卵底'],['crate',23,15,9,5,'下班的凉汤罐']],
 [['pier',2,9,27,2,'摆艇的热饭走板'],['rope',10,12,12,1,'进网槽和出网槽不能缠住的双缆']],
 [witness('skiff-grand','在小艇上把凉汤煨第二回的陶鹊',8,10,[s('陶鹊','我的家灶还在原楼，勺已经归苑芜。我选择在这条艇上做汤，北岸工刚好能吃上热的。排班多了，我有三天没有抱过外孙。'),s('伊沃','艇边接人的最后一段让我来，留起灶头。')],'skiff-watched',['kitchen-crew']),
  object('skiff-spare-cork','在北摆艇的备用篓领仍未到手的软木缆腕',14,11,[s('陶鹊','河荠留的那副还在随船的备用篓。开船时没来得及从家门拿就来我这里。领过一回，篓子给下一人留着。')],{requires:['skiff-watched','!cork-given'],action:{type:'item',id:'cork-wrist',value:1,set:'cork-given'}}),
  fixture('skiff-cross','把两瓣软木插回绳套，再沿麻芯摸到相反的水纹',12,9,[s('伊沃','潮往外抽，峡里还有一股向岸回的暖水。捏着不沉的软木，就能把退绳抛给水里站不稳的人。穿在腕上的那圈能替我挡回索的打击。')],'skiff-cross',['skiff-watched','cork-given','ivo-line']),
  object('skiff-fish','护开挡住病工跳板的一群涡鳍针鱼',18,11,[s('陶鹊','它们追舱底落下的碎卵，不追人。把鱼群从活的退绳上牵开就够，我不想用它们烧汤。')],{requires:['skiff-cross','!skiff-quiet'],action:{type:'battle',id:'spin-smelt',set:['skiff-quiet','skiff-whole']}}),
  setting('skiff-cloth','退潮把晒汤的旧细纱伸入背水沟',16,12,[s('伊沃','碎卵从正沟进，闻见有味的纱，鱼就会顺暖水自己走。收纱前仍能抽回，没把东西套在鱼身上。')],['skiff-cross','!skiff-quiet','tide:low'],{'skiff-thread':true}),
  fixture('skiff-spare','等水涨起，松开细纱放鱼群跟着卵香离艇',22,10,[s('陶鹊','鱼走了，这面汤纱以后不能再用来滤人的饭。把工钱记我头上。')],'skiff-cloth-spent',['skiff-thread','tide:high','!skiff-quiet'],{action:{type:'flag',id:'skiff-cloth-spent',set:'skiff-quiet'}}),
  witness('skiff-lad','给小桨手寄西腾一个可以自己收索的座位',25,11,[s('寄西','我敢独自收这根。撤离的时候俺也去上桨，不会让锅边的老人一头顾着船，一头还拉着我。')],'hearth-north',['skiff-quiet']),
  tidePost('skiff-clock',10,12)],
 [exit(3,10,'north-pier',[7,9],'摆艇退回北埠'),exit(28,10,'lead-sound',[7,10],'跟亲自收过索的小桨手过测深唇',['hearth-north'])]);

export const bend=region('ladle-cut','锚断之夜 · 锅檐已低过窗根的水街',6,'whale-city',33,22,'wood',
 [['water',0,0,33,5,'沿原厨烟道倒灌的潮水'],['building',1,4,8,4,'歪灶上方的保温小间'],['wall',15,2,5,6,'石岸炉架复原的高唇'],['boat',24,4,8,4,'可平进低窗的短摆艇'],['water',0,15,12,7,'过去摆桌如今走艇的湿巷'],['crate',24,16,9,6,'倾倒到屋边的餐凳']],
 [['pier',3,9,27,2,'沿老灶边缘临放的窄板'],['rope',8,13,15,1,'退潮仍能握住的过手索']],
 [fixture('bend-jar','搬空井雁见过的岸罐架，用它托住他自己的卧板',9,10,[s('井雁','你记得我那次怎么下两级。罐放到一边，我的脚就不用冒险踩在潮水里。把扶手朝我右边，下一位得用左边。')],'bend-bed',['ash-frame','hearth-north']),
  witness('bend-carry','玛拉从炉架另一头把井雁的卧板接到进港船上',16,11,[s('井雁','我还有一口热水没喝，算我欠这间炉子。帮我把鞋放在脚边，别先替我扔。')],'hearth-final',['bend-bed'],{action:{type:'flag',id:'hearth-final',set:'hearth-bed-arrived'}}),
  fixture('bend-pole','伊沃交出艇尾的短篙，让寄西顶住浸水的厨房门',19,9,[s('寄西','这支我在北边用过，它会浮。我撑着，不要站在我的腿上找踏板。')],'bend-spoon',['skiff-quiet','hearth-north','ivo-line']),
  witness('bend-first','寄西把苑芜和邻家灶工从窗口送到引航驳',24,11,[s('苑芜','我往巷里扔一只桌腿想叫他救我；儿子似地伸过来的原来是泱阿的学徒，他还认得我的碎面围腰。'),s('寄西','船归我撑，汤我喝第二碗。')],'hearth-final',['bend-spoon'],{action:{type:'flag',id:'hearth-final',set:'hearth-crew-arrived'}}),
  person('bend-neighbor','把椅背当晒架的乌笋',11,12,[s('乌笋','落在海里的餐桌，本来还欠我三顿饭。'),
   spoken('乌笋','热架让了人，今夜的饭真就凉了。好，人过来了，我还会生火。','hearth-bed-arrived'),spoken('乌笋','我当年不同意撤了旧厨，这条船却真的回来接了灯下的人。不同意那句话，我还留一半。','hearth-crew-arrived')])],
 [exit(3,10,'flood-stair',[23,12],'沿窗后的干扶手退回撤离坡'),exit(29,10,'safe-keel',[12,9],'把刚到的人送到安全引航驳',['hearth-final'])]);
export const school={id:'spin-smelt',name:'守卵的涡鳍针鱼群',enemy:'涡鳍针鱼',hp:66,attack:5,level:6,resistances:{tide:1.1,light:.95},
 phases:[{fromHp:66,tell:'鱼背排成一道银边，艇侧跟着抽低。',moves:[{name:'并肩抢水',kind:'ram',element:'tide',counter:'guard',power:1.12},{name:'过缆',kind:'rush',element:'tide',counter:'dodge',power:1.08}]},{fromHp:30,tell:'银边断成两行，各自贴着摆艇找回水。',moves:[{name:'散鳞回旋',kind:'whirl',element:'tide',counter:'dodge',power:1.09},{name:'群鳍合口',kind:'shell',element:'tide',counter:'skill',power:1.05}]}],rewards:{xp:23,label:'鱼群找回背水沟，次日摆艇继续接岸工。'}};
