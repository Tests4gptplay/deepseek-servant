import {say as s,feature as f,exit,person,object,flag} from './parts.mjs';
export const berth={
 id:'ration-berth',name:'白崖港 · 粮船公趸',act:1,width:28,height:19,ground:'wood',biome:'harbor',
 solids:[[0,0,12,3],[19,0,9,3],[1,5,6,4],[20,6,7,4],[6,13,6,4],[19,15,9,4]],
 features:[f('water',0,0,12,3,'堤内水'),f('water',19,15,9,4,'粮趸驳口'),f('boat',20,6,7,4,'青旗粮驳'),f('building',1,5,6,4,'见证账房'),f('crate',6,13,6,4,'八桶干粮'),f('pier',12,2,5,14,'挑夫长板'),f('lamp',17,5,1,1,'靠岸运单灯')],
 entities:[
  object('grain-serial','装货板上的四十八个孔',10,6,[s('装货板','急单四十八袋。三班各十二袋，今晚能过三十六袋。红牌十二袋去病舍；白牌十二袋给第二班热食；余下二十四给三个街区的公共灶。'),s('玛拉','不是谁多领一袋的问题。一整班和一整间病舍，有一个得再等一潮。')],{action:flag('hold-count')}),
  person('bran-allocation','港务官·布兰',15,8,[s('布兰','我想听你说哪十二袋等，不想听你说它们都能过。十二拍是门开的时候，十六拍再好看也抬不回一个没睡的人。'),s('玛拉','街灶的二十四先留住。剩一班，把决定写上我的名字。',[
    {text:'先送热食，让守夜工班按点交班',set:'crew-first'},{text:'先送干粮给病舍，让病船趁早开',set:'grain-first'}]),
    {who:'布兰',if:'crew-first',text:'红牌转下潮。病船停在内港，医官会在单上注明延误，是我的印。'},
    {who:'布兰',if:'grain-first',text:'白牌往后。晚班多抬一潮。把港务署的座椅全搬到码头，他们歇腿用。'},
    s('布兰','告诉等的人，不必说这是潮水选的。')
  ],{requires:['hold-count','work-slip','window-known'],action:flag('berth-fixed'),after:[{who:'布兰',if:'crew-first',text:'热食上船了。病船还泊在内港，我会守到下一潮。'},{who:'布兰',if:'grain-first',text:'医官已点完十二袋。看见岸上的椅子吗？那笔加班账写在我门口。'}]}),
  person('galley-girl','病船配膳的瑟琳',18,11,[s('瑟琳','算配给时最省纸的办法，就是只记肯开口的人。可病人连张嘴都难。'),{who:'瑟琳',if:'grain-first',text:'父亲等的那十二袋进舱了。我把空舱板留给补晚班的人当床。'},{who:'瑟琳',if:'crew-first',text:'病舍少这一潮，我得把粥多添水。你别走，帮我把这件事当面说清。'}]),
  person('sling-master','轮值拉筐人·盈姐',8,10,[s('盈姐','怕高的人不用爬空绳。把两只装足沙的筐放进船列，一只落到墨印，再把另一只升上来；你拽错方向，双筐都离不了板。'),s('伊沃','下眼走回股，上眼系人。拉过三回，手上也记得磨痕了。')],{requires:['berth-fixed','opposed-rope'],action:flag('ivo-line'),after:[s('盈姐','一端在屋桁，另一端留在你那头。绳路能去也能回来。')]}),
  object('shift-chair','港务署借出的木椅',13,11,[s('椅背','皮垫底下的人名被划掉过三回。'),{who:'工人',if:'grain-first',text:'刚歇到孩子睡着。能不能把我这把椅子搬近窗？我想等她醒了第一眼看见我。'},{who:'医官',if:'crew-first',text:'椅子借给病船，我坐这儿记每一个等下一潮的人。'}])
 ],exits:[exit(15,2,'signal-gallery',[15,13],'上潮讯高廊'),exit(2,14,'trim-yard',[20,13],'回压舱浮门',['hemp-crab'])]
};