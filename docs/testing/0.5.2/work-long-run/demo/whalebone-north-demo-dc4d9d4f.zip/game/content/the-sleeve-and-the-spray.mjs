import {region,fixture,witness} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';

export const room=(id,name,w,h,blocks,land,entities,exits)=>region(id,name,4,'north-sound',w,h,'wood',blocks,land,entities,exits);
const sea=['north-chart','party:mira','!winter-welcome'];
export const fresh=['score-chart-open','!score-job-chosen','!winter-welcome'];
export const origin=room('scorerock-origin','北航 · 长鳍艇留下的半幅正船图',35,22,
 [['water',0,0,35,5,'从船首向北看，三样东西在水天交线上重叠'],['boat',3,5,8,4,'短篷长鳍艇，小艇和舷外吊篮之间通一人'],['wall',19,3,5,5,'带两道齿的缺肩岩'],['building',27,4,7,4,'造浮弓的小棚'],['water',0,17,13,5,'验过可折回的南岔'],['crate',25,16,8,6,'葛芮的蓝贝苗架和女儿留下的旧梭']],
 [['pier',3,10,28,2,'白灰的原观测足印'],['rope',10,14,11,1,'能将红袖浮弓松出两个船长的肩绳'],['lamp',17,9,1,1,'旧图把红袖、白喷、黑缝叠画在一根窄线上']],
 [witness('score-offer','艇主葛芮与半幅正船图',8,11,[
 s('葛芮','女儿槿陶一直想知道，我为什么把红袖印在石缝里。还在南水长鳍艇当舵时，每次经过这里，它就在缝里。那时我的眼没有坏。'),
 s('米拉','画的人眼睛可能是好的。从别的船头用它的人却能撞上石头。我想先站你当年站过的地方。'),
 s('葛芮','沿船板白灰去前鼻。你若不试也行，粮船仍走红标。我的苗架和女儿都等得起一句实话。')],'score-invited',sea),
 fixture('score-footprint','磨平的船首趾窝',16,10,[s('米拉','两只脚挤一道老缝，右舷油纸上的朱点就落在黑牙中间。低头看，朱墨井然不动，海上那东西却有绳系着。'),
 s('伊沃','近处是覆在浮弓上的红芦袖。再往北是石孔。黑牙比它俩都远。我们现在是正南看正北。')],'score-old-station',['score-invited','!winter-welcome']),
 fixture('score-first-spray','数到浪背翻身，在趾窝迎第一柱白喷',18,11,[s('喷孔','一撮白花从黑牙的割口里直起来，恰好托在红袖尖下。浪喘完，白先消失。'),
 s('米拉','这样看，旧图一笔也没画错。它错在纸上连我两只脚该站哪儿都没留。横渡不换浪，或钻到背面去看两个航向，都可以试。')],'score-first-crest',['score-old-station','!winter-welcome'],{action:{type:'flag',id:'score-first-crest',set:'score-chart-open'}}),
 person('score-ordinary-pass','原红标领船人',14,14,[s('领船人','大船左转仍是实测过的深槽。想随旧班走的在原红灯上归队。外面若有谁说人人得先试过这道石缝，叫他自己来开大船。')]),
 fixture('score-family-hull','浮弓里的一排蓝壳',24,12,[s('葛芮','新蓝贝只有一夜肯黏草绳。槿陶又请我陪她把冬岸第一架斜梭装上船。两头我都想亲手去。'),
 s('玛拉','你若问我是不是应当和孩子一起去，我恐怕答得太快。先把撞不得的这片石看清，到时候你来开口。')],'score-know-family',['score-invited','!winter-welcome'])],
 [exit(2,11,'deep-sluice',[18,8],'退回双影深槽，仍能循原红标航行'),exit(30,10,'scorerock-beam',[4,11],'贴灰缆向东横移，不换浪作横测',fresh),
  exit(22,14,'scorerock-blind',[4,12],'绕黑齿西侧驶入看不见白喷的背槽',fresh),exit(14,16,'scorerock-landing',[5,12],'循刚才亲测的北角抵达收苗滩',['score-surveyed','!winter-welcome'])]);

