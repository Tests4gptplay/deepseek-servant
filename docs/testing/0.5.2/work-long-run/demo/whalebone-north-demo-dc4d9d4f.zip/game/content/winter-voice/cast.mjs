import {region,fixture,witness,spoken} from '../voyage-parts.mjs';
import {exit,feature,person,object,say} from '../parts.mjs';
import {mechanism,tidePost} from '../district.mjs';
export {fixture,witness,spoken,exit,feature,person,object,say,mechanism,tidePost};
export function shore(id,name,width,height,ground,blocks,land,people,exits){
 return region(id,'冬岸 · '+name,5,'winter-coast',width,height,ground,blocks,land,people,exits);
}
export const beforeTurn=['winter-welcome','!harbor-tilted'];
export const listening=['whalefall-invited'];
