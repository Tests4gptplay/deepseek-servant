import {region,witness,fixture} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {mechanism} from './district.mjs';

export const tower=region('needle-turret','白崖港 · 炉东伸出半掌的补披角楼',1,'north-interior',29,21,'wood',
 [['wall',0,0,29,4,'一线炉烟在东窗外往上走'],['building',2,3,7,5,'仄苇挤得下前臂挤不下整盆的坐隔'],['crane',12,3,4,5,'侧进双孔针用的倾线架'],['crate',20,3,8,5,'洗剩的一匣白蛾和海草色布'],['wall',0,15,10,6,'熄灯以后还能摸着边走的矮梯']],
 [['path',3,9,22,2,'从锅后绕过火道才有的斜窗'],['lamp',16,12,1,1,'朝里的一层反青，朝外的一层反白']],
 [witness('keen-moth-lady','在侧光里向补披工借一只没有主人名字的练习袖',8,10,[s('仄苇','你爹买过两寸蓝，不是来补衣服。他逗一只海蛾，想知道它认不认出做出来的那只。'),s('玛拉','结果呢？'),s('仄苇','它们都飞走了。你想拿什么去证明？'),s('玛拉','自己的袖子。我不带别人的东西出去。')],'keen-practice',['keen-blue-hole','keen-blue-glint','!grave-signed']),
  fixture('keen-sleeve-face','在青窗背把自己的袖口翻到不反光的一面',16,10,[s('窗背','两颗眼不是一大一小，左边的有一道斜口。平对着灯看像是一整块。')],'keen-side-face',['keen-practice']),
  person('keen-dangling','只愿倒着坐的缩颈猫和借它下巴放线的工人',22,12,[s('补披工','这团不是线。它有意见。')])],
 [exit(3,10,'kettle-nook',[29,12],'回到能闻见锅边糊味的晚饭桌'),exit(25,12,'moth-eave',[4,10],'从角窗出去踩窄檐，两眼从侧面合用',['keen-side-face'])]);

export const eave=region('moth-eave','白崖港 · 侧着脚才看见的青蛾露台',1,'white-harbor',27,18,'wood',
 [['water',0,0,27,4,'侧墙外是一层斜海光'],['wall',2,3,6,5,'向窗背折回的抹白矮墙'],['crane',12,2,4,5,'穿线只许侧停的摇布盘'],['building',20,2,7,6,'背面熏黑的小披窗'],['crate',0,14,10,4,'晒光后可以带回家的练习布']],
 [['path',3,9,21,2,'人侧向走，针从敞口滑入'],['rope',11,12,9,1,'垂下来的布尾']],
 [mechanism('keen-two-eyes','在自己袖上练一遍双眼针，让软布贴住又能原手取回',12,10,[s('仄苇','右边那眼看着大。你再走半格，它就没了。')],['keen-side-face'],'keen-blue-thread','不刺穿别人衣料，怎样在旧针上暂系一根自己的线？',['先勾侧开口，再翻自己的袖缝穿第二眼','把两层衣同时钉死在盘上','抽掉家属原有的缝线才上新线'],0,'先到侧光处认开口。能从侧面脱出，才叫暂系。',[s('玛拉','可以临时扶住垂软的东西，再原样还给坐在床边的人。')]),
  fixture('keen-moth-back','在熏黑小窗上看一只真蛾、一只线影往相反方向动',20,11,[s('玛拉','他也没分出来哪只是做的。'),s('仄苇','分不出又怎么了？吃晚饭。')],'keen-moth-seen',['keen-blue-thread'])],
 [exit(3,10,'needle-turret',[24,12],'沿窗的烟黑边退回角楼')]);
