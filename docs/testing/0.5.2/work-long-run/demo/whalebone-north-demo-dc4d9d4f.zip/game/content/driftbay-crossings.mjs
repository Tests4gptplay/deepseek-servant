// Coordinates are measured along the playable ice, approach and return paths.
const near=(x,y,a,b,r)=>Math.abs(x-a)+Math.abs(y-b)<=r;
export const crossingSteps={
 scree:[
  {marks:['driftbay-scree'],when:()=>true},
  {marks:['driftbay-sand'],when:(x,y)=>x>=10&&x<=16&&y<=11},
  {marks:['driftbay-glare'],when:(x,y)=>near(x,y,22,12,2)}],
 roof:[
  {marks:['driftbay-crest'],when:(x,y,f)=>f['driftbay-sand']&&x<=10&&y<=6},
  {marks:['driftbay-turn'],when:(x,y,f)=>f['driftbay-crest']&&x>=17&&y>=7&&y<=11},
  {marks:['driftbay-lee','lee-proved'],when:(x,y,f)=>f['driftbay-turn']&&x<=12&&y>=12}],
 throat:[{marks:['driftbay-low-track'],when:(x,y)=>near(x,y,13,12,2)}],
 heights:[{marks:['driftbay-high-track'],when:(x,y)=>near(x,y,16,4,2)}],
 lens:[
  {marks:['driftbay-brine'],when:(x,y)=>x>=6&&x<=13&&y>=12},
  {marks:['driftbay-film'],when:(x,y,f)=>f['driftbay-brine']&&near(x,y,16,14,2)},
  {marks:['driftbay-fresh','fresh-proved'],when:(x,y,f)=>f['driftbay-film']&&x>=21&&y<=8}],
 cradle:[
  {marks:['driftbay-spooked'],clear:'driftbay-reedwalk',when:(x,y,f)=>near(x,y,15,7,2)&&!f['driftbay-pups']},
  {marks:['driftbay-reedwalk'],when:(x,y)=>near(x,y,14,15,2)},
  {marks:['driftbay-pups'],when:(x,y,f)=>f['driftbay-reedwalk']&&near(x,y,22,12,2)}]};
