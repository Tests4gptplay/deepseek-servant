import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit} from './parts.mjs';
import {setting} from './registry-parts.mjs';
import {mechanism,tidePost} from './district.mjs';

export const gearHint=fixture('float-pin-dark','在灰面漂的插销下发现一小块磨成虹色的旧镜鳞',19,12,[s('乌桅','有人往避风室运过反光片。西岩背的返标绳一定磨白，低潮在两样相对的地方摸，能找到门鼻。平时看海不要靠眼睛里最亮那盏。')],'prism-fleck',['egg-out']);
export const hide=region('silent-gimbal','北航线 · 藏在石背的手工分光室',4,'north-interior',26,18,'stone',
 [['wall',0,0,26,4,'有角度的灰岩屋顶'],['crate',3,4,5,4,'配火色而非配灯亮度的盒子'],['building',15,3,8,5,'早年制镜人用的矮磨榻'],['water',0,13,9,5,'低潮才肯放人的短入口'],['wall',19,13,7,5,'返标绳孔的岩背']],
 [['path',3,9,20,2,'转过一角才照到的磨街'],['lamp',13,8,1,1,'只映两片小光的干凳']],
 [witness('gimbal-hand','试用石背那把只照重影的短架',8,9,[s('米拉','磨架不是看更远，是要我看见同一盏灯的两片。蓝边属于石后，暖边随艇边的风晃。眼睛会给它们重合，镜子却肯分开。')],'prism-room'),
  object('gimbal-prism','从磨榻领一枚仍能转回的对光护镜',17,10,[s('制镜人的座右侧','光薄的时候用手挡住顶边。外艇横风会把人抛过索头，护镜夹轻、两耳合紧才好用。')],{requires:['prism-room'],action:{type:'item',id:'split-prism',value:1,set:'prism-found'}})],
 [exit(3,10,'edge-bleach',[18,12],'摸着磨白的石背绳返回')]);
export const prismGear={'split-prism':{name:'双缝对光护镜',slot:'charm',resists:{wind:.24,tide:.12}}};
export const shear=region('giant-seam','北航线 · 横风暂时打开的外石缝',4,'north-sound',35,22,'wood',
 [['water',0,0,35,5,'外海横风打碎的白水'],['wall',3,4,7,5,'推开回水的外岩肩'],['boat',15,3,7,6,'吃足两罐重砖的水车'],['crane',26,3,6,6,'可挂旧风帆的转轴'],['water',0,17,12,5,'剪羽海鸟伏翼的背浪巢'],['crate',24,16,11,6,'两罐暖砖不能被卸下的舱面']],
 [['pier',3,10,28,2,'外侧的迟浪在此压过甲板'],['rope',9,14,16,1,'货挡与供鸟离开的小缝各有一端']],
 [witness('seam-pilot','扯着一块旧橙皮帆的外口引艇禾乌',8,10,[s('禾乌','这船吃得重，浪不会把它扔回去。外石肩的剪羽鸟正护浮巢；要么跟着它第一回展翅把船稳在背浪，要么给它留条新避风汊。重船会晚一顿饭，暖砖能全带着。')],'seam-sighted',['fan-heavy']),
  fixture('seam-notch','顶风从艇头走到外石肩背后，压低一片短桅看远缺口',13,13,[s('米拉','近翼一抬就盖半扇天，远岩的缺口一直在它左边。脚下石脊背风，白喙在动，石缺没有向它挪。')],'wing-notch-seen',['seam-sighted','party:mira']),
  mechanism('seam-foil','把尾索转向真正的外肩，给浮鸟留开口',13,10,[s('禾乌','有风两只翼影叠在一处。看它背后的缺口，别等鸟先让。')],['wing-notch-seen'],'wing-fixed','鸟翼扫来时，舵底的实石口在哪里？',['沿翼影向右回扑','用石缺固定艇首，把近翼向左移过的距离让给浮巢','把整圈海鸟当作一面不动的白岩'],1,'回跑过外肩，近翼会遮天，远缺仍在外肩后方。空出移动的近景，不让船头追它。',[s('米拉','远缺还在。挡住一眨眼也没有离开。两边都可以自己过去。')]),
  object('seam-petrel','随展开的剪羽群稳住重艇，让浮巢顺过船侧',22,10,[s('禾乌','先看的不是喙，是翼尖。翅面竖起来，侧风就要反着压第二下了。')],{requires:['wing-fixed','!wing-through','!wing-baffle'],action:{type:'battle',id:'shearwings',set:['wing-through','wing-kept-sail']}}),
  setting('seam-orange','低水时把旧橙帆折成遮蔽巢口的内墙',18,12,[s('禾乌','帆先挡风，巢会自己朝静水滑。把它当临时墙就少一块保温布，想换法子现在可收。')],['wing-fixed','tide:low','!wing-through'],{'wing-baffle':true}),
  setting('seam-takeback','解开试挂的风墙，给海鸟和船各留原来的出口',14,13,[s('米拉','帆回到船上，我留下它原来投影的位置。换法子只损一小段等水的工夫。')],['wing-baffle','!wing-through'],{'wing-baffle':false}),
  fixture('seam-release','涨潮从外侧松开橙帆浮起鸟巢',26,11,[s('禾乌','巢跟着帆进侧湾了。今晚冷棚少一层外皮；回港要有人送它回巢边，不能把救过的东西扔在水面。')],'wing-offered',['wing-baffle','tide:high','!wing-through'],{action:{type:'flag',id:'wing-offered',set:'wing-through'}}),
  witness('seam-cost','禾乌把满载重艇推过外肩，岸上另派人替迟到班',27,13,[s('禾乌','两罐都在。外绕要多一班火，岸工借我的灯油见了底。到了冬岸，先把借灯的人接回来，不拿我的晚饭垫。')],'fan-sailed',['wing-through','fan-heavy','tide:high'],{action:{type:'flag',id:'fan-sailed',set:'fan-outside'}}),
  witness('seam-home-sail','在巢口把旧橙帆从雏鸟已经离开的浅沟直接收回艇边',23,13,[s('禾乌','先别扯。雏鸟已经自己从浅草里钻出，铁扣却还压着晒热的泥。先从压住的那端拿，我来温一温你手里的湿帆。')],'wing-cloth-regained',['grave-signed','wing-offered','fan-home','tide:low']),
  tidePost('seam-clock',10,13)],
 [exit(3,10,'fan-throat',[33,11],'随护尾绳退回可改载的扇喉'),exit(30,11,'pairs-jetty',[20,12],'靠满载的外档到另一处换桨口',['fan-outside'])]);

export const pairs=region('pairs-jetty','北航线 · 同一册海图的两处换桨口',4,'north-coast',31,21,'wood',
 [['water',0,0,31,5,'浅舌和重艇并不到同一束水'],['building',3,4,7,4,'轻艇先到的空暖间'],['wall',13,3,5,5,'隔开两岸的石齿'],['boat',22,3,8,5,'外档送砖的满船'],['crate',1,16,8,5,'待偿运力和借油的位置'],['water',22,16,9,5,'供两处换桨的静湾']],
 [['pier',3,9,24,2,'两道实际落脚处分开点过'],['rope',9,13,14,1,'吊回艇绳的转门']],
 [witness('pairs-light','呃禾把先到的轻艇交给真能到岸的人',10,10,[s('呃禾','小船和人先到，第二罐没到。给我留一小截吊架，让我们自己把欠下一趟的远船接回来。')],'fan-landed',['fan-inside']),
  witness('pairs-full','禾乌把第二只暖罐亲手交进迟班人的艇',21,10,[s('禾乌','岸工开的迟灯烧了一班油。暖砖到齐，灶房却得临时换一处点火。我的署证不能只说“可走”。')],'fan-landed',['fan-outside']),
  fixture('pairs-print','米拉把归路、两种载线和实试的限制并刻进首图',16,11,[s('米拉','我上一张错把风当水，以后这张也要给人挑。轻路等低、留一罐，重路需高、要接迟班；今天我只给亲历的那一条署行船，另一条列查证的限制。')],'fan-certified',['fan-landed'])],
 [exit(3,10,'fan-throat',[22,15],'回夹喉看修正箭和原错图'),exit(11,13,'net-tongue',[29,10],'上交到岸的低水轻艇',['fan-inside']),exit(21,13,'giant-seam',[29,11],'回满罐走过的外缝',['fan-outside'])]);
export const birds={id:'shearwings',name:'护着浮巢的剪羽群',enemy:'剪羽鹱',hp:176,level:8,attack:5,resistances:{light:1.28,impact:1.12,wind:.9},
 phases:[{fromHp:176,tell:'近翼遮住岩缺，第一股风压住外舷。',moves:[{name:'平翼截流',kind:'ram',element:'wind',counter:'guard',power:1.14},{name:'掠帆',kind:'rush',element:'wind',counter:'dodge',power:1.18}]},{fromHp:88,tell:'白羽裂成两层，反向的风从艇底抬起。',moves:[{name:'倒剪',kind:'whirl',element:'wind',counter:'dodge',power:1.2},{name:'护浮巢',kind:'shell',element:'tide',counter:'skill',power:1.12}]}],rewards:{xp:30,label:'巢和艇分开；橙帆留给冬岸的夜班。'}};
