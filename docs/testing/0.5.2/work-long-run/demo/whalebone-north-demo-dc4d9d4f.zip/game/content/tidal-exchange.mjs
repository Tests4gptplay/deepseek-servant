import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit} from './parts.mjs';
import {tidePost} from './district.mjs';

export const guild=region('tidal-exchange','北航 · 葵湾两岸图本交割所',4,'north-interior',26,17,'wood',
 [['building',0,0,7,5,'渔业互助柜的盐漆窗'],['crate',13,1,6,5,'曾付过赔偿的麻绳箱'],['building',19,11,7,6,'泄潮时锁起的船东文房']],
 [['path',2,8,21,2,'同一张桌的外埠与本埠两边'],['lamp',9,6,1,1,'把原笔划和复写影分开的两盏灯']],
 [witness('chart-claim','葵湾晒藻户·班枝',7,8,[s('班枝','九年前我用外婆的三扇席换过一张冬图。它把红冰画成能靠的岸。第一船藻翻在水里，别人怪我换错了席。'),s('米拉','谁在图上画了那条线？我想找他的真名。'),s('班枝','我不指望死人来还席。我要新图能找到谁改过，若不对，也能由我们驳回。那张湿席还挂在外井。')],'chart-claim',['north-chart']),
 witness('original-pledge','领航船东·白瑾',16,8,[s('白瑾','秋航的孩子在船上学用图，只有铅笔画在原纸上才看得出哪里会偏。原本留岸，孩子总看别人挑好的数。'),s('班枝','你走一个冬季，挂在我墙上的副本出错，我拿什么跟你核？'),s('伊沃','一份图带两条更正边，任何一方都能记。但这张沉船的指控还须查两次返航，别凭一张湿席处置一个人。')],'custody-debate',['chart-claim']),
 fixture('split-tracing','把外井拣来的湿席和锚销反拓放在同一透光板',11,10,[s('米拉','湿席斜切口和翻船那天的图线重合。可锚印是另一个年代，不能算作绘图人当年在场。'),s('班枝','他未必画过我家的图。我们是在答两个问题：旧锚是谁做的，那张图又该由谁负责纠错。')],'chart-separated',['custody-debate','lost-mat','maker-known']),
 person('custody-oath','两份改图权的交割契',13,8,[s('公证人','谁拿原图，就要冒雨保原字；另一方拿同尺副本，有权从本地提出改动。没在场的人不替他签。'),s('班枝','我的桌子夜里会漏水。我能做一只挂高的夹架，可我要付木料。'),s('白瑾','船上我能给两条独立传话绳，可被扣船时就谁都拿不到原图。两种险不同。'),s('公证人','谁实际拿走有铅痕的原本？',[{text:'原图挂岸上，船带双边副本',set:'original-ashore'},{text:'原图随船，岸办先收同尺副本',set:'original-afloat'}])],{requires:['chart-separated'],action:{type:'flag',id:'custody-chosen'},after:[s('公证人','句子已经选过。把两份各自送到一端，勾出谁有权更正；没人收下的契纸还不算履行。')]}),
 fixture('shore-rack','把原本夹上过潮不湿的高架',19,8,[s('班枝','签收原图。我卖掉一扇旧席换木料。下一次画错，不会只剩我家说没量过。')],'shore-received',['original-ashore']),
 fixture('shore-copy','把等尺复本交给岸办留班簿',8,10,[s('班枝','原本不在，我能拿到同尺比对，也可以闭门拒签下一张。请留下船上是谁持笔。')],'shore-received',['original-afloat'])],
 [exit(2,8,'red-beacon',[10,12],'回红标外门'),exit(23,8,'mat-inlet',[3,8],'到翻藻湾看实物')]);
export const inlet=region('mat-inlet','北航 · 海扇鱼守着的翻席湾',4,'north-sound',23,16,'stone',
 [['water',0,0,23,4,'幼鱼逐食的回潮带'],['crate',2,4,5,3,'暗槽里的藏席笼'],['wall',13,3,5,4,'钻石缝的卵床'],['water',17,11,6,5,'暗涌回窝']],
 [['pier',2,8,17,2,'过潮才松掉的晒席栈'],['rope',8,10,9,1,'隔出鱼群的漂绳']],
 [person('fan-warden','看产卵浅滩的帮工·央贝',8,8,[s('央贝','海扇鱼贴卵床摆身，顺它的尾纹退，比顶上去容易。你们来看丢的席，不是来拣鱼肉。'),s('白瑾','那年我答应赔三扇席，还了两扇就入冬。第三扇我带来了，你们认一认。')]),
 fixture('old-mat','从水线以上的横梁观察席角，记下旧线',11,8,[s('米拉','席经向东折，断边在手掌下先湿后干。翻船在落水段，不在当时抄图人画的满水段。'),s('班枝','这是我们家两宽一窄的编法，我认席。它能说明在哪边翻，不能说是谁命令靠岸。')],'lost-mat',['chart-claim']),
 tidePost('mat-gauge',13,9),
 fixture('float-slat','趁低潮把卵床外的引流席转半边',15,8,[s('央贝','小鱼在背光处转向，不用有人下到石缝里。把稀疏的一面立起来，留半幅能漏水。')],'fan-slat',['tide:low']),
 fixture('net-concession','从新开的明水口将旧笼顺水放走',18,9,[s('玛拉','卵床还在，人可以拖过席边的小板。给看滩人留着这条水道。')],'shoal-clear',['fan-slat']),
 object('fan-standoff','卵床旁护住扇面的三尾鱼',14,10,[s('央贝','向里合是硬顶，张向外是甩泥。它们只守有卵的这圈水。给拖席的人留一拍。')],{requires:['!shoal-clear'],lockedText:'鱼群回到了石缝；席路可通。',action:{type:'battle',id:'shoal-fans',set:'shoal-clear'}}),
 object('mat-guard','央贝留下的覆肩帆片',8,11,[s('央贝','三层席经朝不同方向，迎浪时能挡上一阵泥水。我们只收席，不取鱼鳞。')],{requires:['shoal-clear'],action:{type:'item',id:'mat-guard',value:1,set:'fan-gift'}})],
 [exit(2,8,'tidal-exchange',[22,8],'带完好断片回交割所')]);
export const fans={id:'shoal-fans',name:'卵床的三尾海扇',enemy:'海扇鱼',hp:49,attack:5,level:4,
 phases:[{fromHp:49,tell:'鱼口贴地，尾扇向内重叠；会隔着泥墙迎顶。',moves:[{name:'叠扇顶浪',kind:'ram',counter:'guard',power:1.4},{name:'甩开泥圈',kind:'whirl',counter:'dodge',power:1.1}]},{fromHp:23,tell:'两尾钻泥，一尾向外撑扇护住卵床。',moves:[{name:'半圆护泥',kind:'shell',counter:'skill',power:1.05},{name:'出水挪窝',kind:'rush',counter:'dodge',power:1.25}]}],
 rewards:{xp:19,label:'水口腾开。鱼群守卵，工人收席。'}};
