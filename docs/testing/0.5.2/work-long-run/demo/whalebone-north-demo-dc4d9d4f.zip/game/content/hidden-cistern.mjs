import {say as s,person,object,flag,exit} from './parts.mjs';
import {district} from './district.mjs';
export const seam=district('seam-cell','亮灯空城 · 补帆夹间',2,14,12,'wood',
 [['wall',0,0,14,2,'鲸腹内壁'],['crate',8,2,4,3,'旧帆架'],['water',0,9,7,3,'低潮针槽']],
 [['rope',2,4,5,1,'缝帆绳'],['lamp',9,7,1,1,'瓦罩小灯']],
 [object('old-sail-hems','一面有两组针脚的救生帆',8,6,[s('缝线穗','头九道针脚紧；另外两道有结痂的盐花。两名远艇乘客到盐滩时，借走这块帆裹身。'),s('玛拉','远艇不是全遇难，也没有全班获救。把两条船的伤口当成一道，谁也不会回来谢你。')],{action:flag('salt-survivors')}),
 object('bobbins-gear','送给新守窗人的防潮披肩',10,7,[s('夹间主人','我留了一件油布外衣配那副梯。别挂墙上，风口站着的人要用。')],{requires:['salt-survivors'],action:{type:'item',id:'oilskin',value:1}})],
 [exit(5,7,'crib-hold',[11,14],'循针筒洞回舱巷')]);
export const cistern=district('bell-cistern','亮灯空城 · 回音蓄水间',2,18,15,'wood',
 [['water',0,0,5,15,'外鳃水池'],['water',12,3,6,9,'沉铃洼'],['crate',7,8,2,2,'青铜支架']],
 [['pier',5,2,7,3,'脚手跳板'],['lamp',10,6,1,1,'听声哨']],
 [person('cistern-boy','抄水响的牧鳐童',6,7,[s('牧鳐童','它不是守藏物。小鳐长在空铃里，大钟一响，亲鳐就拿翼撞回声。你若站到外缘，它才分得清哪里是水。')]),
 object('trapped-ray','撑开闸叶的黑翼铃鳐',10,8,[s('伊沃','拿绳拦住它冲向青铜架的一面。别伤到铃里的幼鱼。')],{requires:['!echo-ray'],lockedText:'空铃在涨水里轻敲。亲鳐和幼鳐已经钻回外鳃，闸叶间留着空路。',action:{type:'battle',id:'echo-ray',value:'echo-ray'},after:[s('牧鳐童','闸井能开了。响铃取下来倒扣着，幼鱼等涨水自己就能走。')]}),
 object('echo-trace','静水里褪银的灯镜',6,11,[s('玛拉','镜面只刻了近、远两条线，可近线被年年擦过。会出事的那一面，太久没人照过。')],{requires:['echo-ray'],action:flag('spare-mirror')})],
 [exit(7,2,'organ-lock',[12,14],'回风琴闸')]);
