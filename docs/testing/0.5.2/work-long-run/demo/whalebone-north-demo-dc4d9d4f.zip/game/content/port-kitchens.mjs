import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit,flag} from './parts.mjs';
export const barge=region('meal-barge','白崖 · 三家合租的潮驳',1,'ration',26,16,'wood',
 [['water',0,0,26,3,'候鲸驳岸口'],['building',2,4,5,4,'婆孙的矮舱'],['building',10,3,4,3,'渔人夫妻的隔舱'],['crate',16,10,8,6,'暂给挑鱼人的租箱']],
 [['pier',1,8,22,2,'三家都借用的餐板'],['rope',6,11,8,1,'晾海菜的半绳']],
 [witness('tenant-vote','驳上同租的陆婆',9,8,[s('陆婆','广口碗用来给人生饭，窄口缸打鱼腌盐。按租箱计饭，卖鱼那家被算了三次，余下一老一小没人算。'),s('玛拉','我不替你们分。先量一船实际用过的勺，和岸上原票对上。'),s('陆婆','把我的浅勺带去。上面那道横口是病人吞不下时，轻轻倒到的位置。')],'tenant-ladle'),
 person('fish-wife','正把几片红鳃翻面的咸微',15,8,[s('咸微','铺户说这三只箱都是我的，真有那财力我还住船里？酱鱼一缸，旧帆一缸，剩的一缸是空的给裹衣睡的人。')]),
 fixture('live-berths','和船家分辨睡舱与盐箱',13,10,[s('米票背书','三个记租名、五个过夜人、两只实际米碗。给锅单的人不该坐仓门口猜。')],'real-berths',['tenant-ladle'])],
 [exit(2,8,'shift-square',[27,12],'回三班场上岸'),exit(22,8,'stove-gallery',[3,7],'借陆婆的浅勺去验锅',['real-berths'])]);
export const stove=region('stove-gallery','白崖 · 炖灶与烘饭隔层',1,'harbor-interior',24,17,'stone',
 [['building',0,0,6,4,'留冷餐的病灶'],['crate',8,2,5,4,'一次入锅的两斗干米'],['building',17,2,6,5,'打夜饭的工灶'],['water',15,13,9,4,'难推食车的湿院']],
 [['path',2,8,20,2,'从病灶到工灶的窄道'],['lamp',13,6,1,1,'换灶时用的灯']],
 [witness('stove-tender','靠敲锅沿辨饭稀稠的余绒',7,8,[s('余绒','一锅稠的顶夜工，一锅薄的喂病人，光分勺不算交班。夜里得有人洗第二口锅，锅翻不过来什么都白说。')],'pot-count',['real-berths']),
 fixture('cool-ladle','把船家浅勺贴在冷锅水印',13,8,[s('玛拉','两人共借一只勺，不能把舀过几次当几个人。水印退得慢，第二天还能复核。')],'stove-mark',['pot-count']),
 person('trade-shift','和余绒分掉一班守锅',19,9,[s('余绒','只够一班人：陆婆带锅送上船，岸上病灶就晚一刻；把热饭留在岸上，船家的夜工回来得啃冷鱼。',[{text:'先让锅上驳，我替船家提空桶',set:'pot-afloat'},{text:'守住病灶，岸上分出可以咽的薄饭',set:'pot-ashore'}]),s('玛拉','这个选择不会多出一口锅。明天另一个人可以冲我发火。')],{requires:['stove-mark'],action:flag('pot-chosen'),after:[spoken('余绒','第三班的下船人还等你一只空桶。','pot-afloat'),spoken('余绒','病灶的人还等你送船家一回冷饭。','pot-ashore')]})],
 [exit(2,7,'meal-barge',[21,8],'回寄租驳'),exit(21,9,'late-canteen',[3,6],'沿夜班锅道去交接',['pot-chosen','berth-fixed'])]);
export const canteen=region('late-canteen','白崖 · 吃第三顿的夜灶',1,'harbor-interior',24,15,'wood',
 [['building',1,1,6,4,'病灶等候室'],['crate',10,1,5,4,'没有挪走的空桶'],['building',17,9,7,6,'修锅铺']],
 [['lamp',7,6,1,1,'药食分开灯'],['path',2,8,18,2,'夜班分食长桌']],
 [witness('empty-bucket','让下船的快脚工接手提空桶',9,7,[s('快脚工','锅送上驳了。病灶晚到那半刻，你们跟我妈说实话，别说是潮晚。'),s('陆婆','我将我的吊饭筐改成跑夜线，日后你进鲸城还能遇见。')],'night-ferry',['pot-afloat','berth-fixed'],{action:{type:'flag',id:'night-ferry',set:'pot-closed'}}),
 witness('night-broth','把让给病灶的浅勺带到卧客身边',14,8,[s('余绒','他吞下了。陆婆的夜工今天得吃冷鱼，这是他们替这张床付的。'),s('咸微','我肯记是谁睡热铺，也盼下回别总算我一班。把这锅的浅匙寄给鲸城待产的人吧。')],'night-broth',['pot-ashore','berth-fixed'],{action:{type:'flag',id:'night-broth',set:'pot-closed'}}),
 person('cook-apprentice','轮着熬第三锅的阿泷',6,9,[s('阿泷','中午来的临工要油，夜里来的只想找一点不涩的绿菜。我把菜单折两道，谁下班摸到就知道该走哪张桌。')])],
 [exit(2,8,'port-desk',[8,13],'回二班交接台'),exit(2,6,'stove-gallery',[20,9],'回白日炖灶'),exit(19,7,'ration-berth',[12,10],'顺粮趸旁的小灶窗出街',['berth-fixed'])]);