import {region,witness,fixture,spoken} from './voyage-parts.mjs';
import {say as s,object,person,exit} from './parts.mjs';
import {tidePost} from './district.mjs';

export const active=['keelpot-open','!winter-welcome'];
export const flat=(id,title,w,h,ground,blocks,land,entities,edges)=>region(id,title,3,'salt-market',w,h,ground,blocks,land,entities,edges);
export function cargo(id,name,x,y,op,requires,signals=[]){
 return object('keelpot-'+id,name,x,y,[],{requires,action:{type:'keelpot-freight',op,id:'keelpot-'+id+'-worked',set:signals}});
}
export const yard=flat('keelpot-yard','盐市 · 青瓮与蚝苗同用的小斜埠',35,22,'stone',
 [['building',0,0,8,6,'咸青鱼铺的敞灶'],['building',12,0,5,5,'旧桶匠兼卖豆豉的矮间'],['water',22,0,13,6,'石埠内侧的候水湾'],['wall',0,15,7,7,'锁住码头的旧盐垛'],['water',12,17,23,5,'育苗床下一带沉水草']],
 [['path',1,8,32,3,'顺坡的双辙'],['kp-jar',5,5,2,2,'青布与赭布封口的两只鱼瓮'],['kp-crib',18,13,5,2,'两列用茅绳合在一起的蚝苗架'],['kp-boat',24,6,7,3,'浮着的双肋摆渡舟'],['kp-gauge',30,10,2,2,'刚好越过第二枚系耳的潮线']],
 [witness('keelpot-moorer','正在拆自己夜班饭包的摆渡人蒲岸',9,9,[
 s('蒲岸','吃一口再上工。你闻到的不是鱼坏了，是碗底昨晚的萝卜。我那舟两道肋，摆两只瓮，或者一副整苗架。上工的粮船已经系在对岸，摆过去我就换围裙，今天回不了第二趟。'),
 s('瑟琳','我家等粮的人不会乐意见我拖住你。可你替谁搬，不能由我娘的饭票定。'),
 s('蒲岸','先问两户肯怎样等。东西在起缆前随你装、随你卸。不是问谁的东西便宜。')],'keelpot-open',['harbor-truth','!winter-welcome']),
 fixture('keelpot-brine-tub','把清水碗和鱼缸的浓卤各抹一滴在青瓮边',5,8,[
 s('玛拉','一滴渗入粗胎，另一滴在瓮肩收成一圈白。淡水只会把这两瓮剖好的鱼泡软。'),
 s('商枣','你愿替灶班谈，我才肯把两瓮改腌。今天切片卖的钱当晚付盐商；等到明天卖腌鱼，那笔利我认，绝不是盐把鱼白变多了。')],'keelpot-brine-seen',active),
 witness('keelpot-kitchen','问商枣和搭伙的灶嫂能否再等一潮',4,11,[
 s('灶嫂','今晚的鱼汤可以换成豆子。得现在把我的那份灶火留出来煮卤。我同意改，不能在菜单上照记鱼。'),
 s('商枣','只要盐和两只实瓮都过埠，明早由我开坛。把赭布那口先给夜班，不能让买青布那口的人挑掉整层鱼皮。'),
 s('瑟琳','我原想催你们先去。你们肯等，是拿自己的利钱和今晚那口菜来等。')],'keelpot-fish-wait',['keelpot-brine-seen',...active]),
 fixture('keelpot-wet-rope','把湿茅结从干架放回潮沟，摸底层的凉意',17,13,[
 s('伊沃','两半苗盘各只有一幅担架宽。掀着走，细壳往干茅上磨。先浸透各自那条遮索，潮退才能分担。'),
 s('禾盏','大船能整副连水漂去外床。你若要它给饭瓮，我可以让两半盘先在内沟等；等过的幼苗赶不上外床头遍咸水。')],'keelpot-wet-seen',active),
 witness('keelpot-grower','问躬在育苗槽旁的禾盏肯不肯等',20,12,[
 s('禾盏','你把遮索浸透了。我肯等到退潮，拆成两盘，一趟肩上只能托一盘。到的是内沟，冬里要另清一次泥。若整架走，我到外床替你们看饭瓮有没有压到舷耳。'),
 s('玛拉','谁让我写这笔损失？'),s('禾盏','我。别写“盐市愿意等”，盐市又没有背。')],'keelpot-young-wait',['keelpot-wet-seen',...active]),
 cargo('pantry','鱼铺斜架 · 青瓮、赭瓮与回放的木座',7,8,'fish',active,['keelpot-on-shoulder']),
 cargo('lift','苗槽边的整架吊眼和分担索',22,12,'seed',active),
 cargo('cradle','摆渡舟的两道肋与两块垫木',25,9,'boat',active),
 cargo('cast','系船石上的最后一圈缆',29,9,'cast',active,['keelpot-launched','keelpot-fish-first','keelpot-seed-first']),
 tidePost('keelpot-yard-tide',29,12),
 person('keelpot-barrel-child','桶匠家拿豆豉换鱼尾的玄小帽',12,11,[s('玄小帽','我娘只吃鱼尾，说尾巴跟着鱼跑过的地方多。我爹说分明是买不起中段。她把锅铲递给他，两个人都笑了。'),spoken('玄小帽','今天我带豆豉来了，灶边真的挂了豆汤的勺。','keelpot-seed-first')])],
 [exit(2,9,'salt-lane',[25,8],'踏双辙回一街两水门',['!keelpot-on-shoulder']),exit(31,8,'keelpot-landing',[5,7],'上蒲岸的舟横过涨水口',['keelpot-launched','!keelpot-landed','tide:high']),exit(16,15,'keelpot-neck',[3,9],'踩露出的石鼻走低脚路',['tide:low'])]);
