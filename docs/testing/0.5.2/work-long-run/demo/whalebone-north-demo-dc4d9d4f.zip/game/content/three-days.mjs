import { court } from './wake-court.mjs';
import { wickHouse } from './wick-house.mjs';
import { yard } from './trim-yard.mjs';
import { gallery } from './signal-gallery.mjs';
import { berth } from './ration-berth.mjs';
import { upper } from './upper-spar.mjs';
import { roofs } from './whale-roofs.mjs';

export const portExtension=[court,wickHouse,yard,gallery,berth,upper,roofs];
export const departureQuests={
 'third-morning':{id:'third-morning',name:'留给下一潮的十二袋',kind:'main',startFlag:'coffin-aboard',endFlag:'early-castoff',stages:['coffin-aboard','vigil-finished','work-slip','window-known','berth-fixed','ivo-line','early-castoff']},
 'lit-empty-roof':{id:'lit-empty-roof',name:'有灯的空屋',kind:'main',startFlag:'early-castoff',endFlag:'roof-shelter',stages:['early-castoff','recent-wash','reverse-scuff','roof-shelter']}
};
export const netCrab={id:'hemp-crab',name:'浮门的灰甲蟹',enemy:'灰甲蟹',hp:32,attack:5,level:3,
 tell:'麻网忽松忽紧，灰甲冲向绞索时会撞紧浮门。',reward:'浮门近路',objective:'松开缠在灰甲上的麻网',
 phases:[{fromHp:32,tell:'灰甲顶住泡水的麻网',move:'顶门'},{fromHp:12,tell:'回股吸尽水，开始扭转',move:'旋索'}]};
