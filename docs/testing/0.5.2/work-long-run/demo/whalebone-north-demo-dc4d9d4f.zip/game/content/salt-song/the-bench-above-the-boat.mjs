import {say as s,person,exit} from '../parts.mjs';
import {region,witness,spoken} from '../voyage-parts.mjs';
export const station=(id,name,x,y,work,requires)=>({id,name,x,y,kind:'object',requires,action:{type:'salt-song',work}});
export const room=region('salt-song-room','盐市 · 听凳船上的回音阁',3,'salt-interior',30,19,'wood',
 [['wall',0,0,30,2,'船底翻作屋顶，旧龙骨反扣在梁上'],['building',2,2,6,4,'单间改成给唱词人歇脚的小厨'],['crate',12,2,5,3,'八只盛过螺肉的带盖陶罐'],['wall',23,2,6,5,'朝日晒壁的折面共鸣板'],['crate',1,14,6,4,'收好后会立起来的夜班睡凳'],['building',21,13,8,6,'檐下收着半艘结亲的小篷船']],
 [['lane',2,8,26,2,'唱词人从门后走到船首的过道'],['pier',10,6,12,1,'八块宽窄相间的脚音板'],['lamp',19,7,1,1,'把八个拍眼照在地板上的挑灯'],['rope',7,13,12,1,'拴起船凳后仍可摸到的低索']],
 [person('salt-song-room-cook','端着一小碟紫蒜的厨子乌犁',6,8,[s('乌犁','想坐哪儿就坐哪儿，别坐那叠被子。里面有个补觉的夜班。她翻身，我就把这盘蒜转半圈，挡着窗光。'),spoken('乌犁','昨夜有人把一整段唱进我剥蒜的手，我今天少剥了一碗。值。','salt-song-played')]),
 witness('salt-song-child','嘴里叼根薄木片的阿梢',19,9,[s('阿梢','我唱的是一条没见过井的鲸。它在井口等船，等了好久才知道井有底。你千万别把它改成真的沉船。'),s('瑟琳','我正想问能否拿这支歌给冬粮船招帮手。现在这话好像说早了。'),s('阿梢','早倒不早。我就是不肯。第三、第六，还有第八拍，你让我唱完那句“井底下没有帆”。')],'salt-song-word',['salt-song-open']),
 station('salt-song-score','在船凳上排八拍，给留在岸上的鲸合奏',13,9,'mix',['salt-song-heel','salt-song-reed','salt-song-word']),
 person('salt-song-householder','左耳贴在扶壁上的说书人方莳',22,10,[s('方莳','大场的好处是孩子能听见旁人先笑出来。小场的好处是我把手搁在桌上就能接上。要是每场都一个样，我何必造两种凳？'),spoken('方莳','油灯熄了。我记得有一声只有阿梢自己唱，连巧棠的脚也没去抢。','salt-song-played')])],
 [exit(2,9,'salt-dorm',[19,10],'趁邻船错开，踏回纤工院'),exit(26,9,'blind-window',[7,9],'走窄舷直达摸筹窗',['salt-song-heel'])]);
