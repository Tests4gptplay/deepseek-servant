import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit,object} from './parts.mjs';
import {tidePost} from './district.mjs';

export const lead=region('lead-sound','北航 · 着铅湾',4,'north-sound',27,18,'wood',
 [['water',0,0,27,4,'外湾蓝水'],['building',1,5,5,4,'试铅桥工棚'],['crate',13,4,3,4,'两艘船的配重'],['water',17,12,10,6,'沙洲回水'],['building',2,12,5,4,'铅皮铺']],
 [['pier',6,8,16,2,'垂线浮桥'],['rope',13,10,9,1,'十二结铅索'],['lamp',7,6,1,1,'零点白灯']],
 [fixture('lead-zero','在白灯脚擦净底蜡',8,8,[s('铅匠','同一把线，底头涂蜡。泥会沾，冰会划，岩砾会咬出洞。光看绳长，不知道量到什么。'),s('瑟琳','我的第一根铅垂从港签带来了。底蜡先擦白。')],'plumb-zero',['north-ready']),
 person('mira-first','抱着两卷纸的制图师',12,8,[s('米拉','这套祖传图画一条短北岸，那套新图画一条长北岸。有人把冻海的边也叫岸。我投过一个信箱问来历，信箱去年泡没了。'),s('玛拉','借我你那把歪尺。我宁愿让明天的人知道哪里量歪过。')]),
 tidePost('outer-tide',20,10),person('ledder','垫铅背的老沙手',8,11,[s('沙手','看肋背的白灯，先取石基；看红岸的墨缺，再取漂冰。别把会走的东西当两张图的同一头。'),spoken('沙手','有人先把公油挂上了。暮色以后，从红灯西槽还可抄近。','north-lampstock')])],
 [exit(1,10,'north-pier',[11,8],'沿来时舷板回盐市'),exit(24,8,'rib-survey',[2,8],'上古鲸肋的岸基',['plumb-zero']),exit(14,15,'ice-mark',[3,8],'西支转入浮冰坐标架',['plumb-zero']),exit(15,13,'false-shoal',[2,6],'顺乳白水色试入沙沟')]);
export const ribs=region('rib-survey','北航 · 四肋望架',4,'north-sound',25,16,'stone',
 [['water',0,0,25,3,'鲸骨灰潮'],['wall',5,3,3,5,'第一拱肋'],['wall',13,3,3,4,'第二拱肋'],['wall',19,9,3,5,'风化第四肋'],['building',2,11,5,4,'捞骨人的平棚']],
 [['rope',8,8,12,1,'垂直瞄准槽'],['lamp',15,6,1,1,'天际线与石基的交点']],
 [fixture('rib-heel','脚跟抵住磨平的肋根',8,9,[s('米拉','不要站骨架顶。顶端还在风里动，只有这根埋入石床。你踩到那个磨亮的脚窝，我去找白岬。')],'rib-fixed'),
 fixture('rib-sight','沿双缝瞄南侧白岬',17,8,[s('米拉','从脚窝看两道竖缝重合，白岬正切第二肋。今天往返再看，位置没变。这条线够我用墨。')],'bearing-stone',['rib-fixed']),
 witness('bone-kid','替祖母收晒钉的小乌',10,10,[s('小乌','每年搬家把船板留下，钉头用布封住；骨顶那道横线年年挪，只有肋根一直刺我的鞋底。')],'old-bone-mark')],
 [exit(1,8,'lead-sound',[23,8],'退回着铅湾'),exit(22,6,'ice-mark',[5,5],'沿拱脚背风道横过'),exit(20,14,'deep-sluice',[3,8],'从固定岸基下双线水槽',['bearing-stone','bearing-ice'])]);
export const ice=region('ice-mark','北航 · 浮冰尺架',4,'north-ice',20,18,'stone',
 [['water',0,0,20,2,'冰后暗水'],['crate',8,3,3,3,'滑动冰浮'],['water',12,9,8,5,'分浪断冰'],['building',2,11,5,4,'干绳房']],
 [['rope',4,6,11,1,'拴冰刻绳'],['lamp',14,5,1,1,'固定岩灯'],['pier',7,12,4,3,'移尺脚架']],
 [fixture('ice-pin','固定黑岩的针旗',6,7,[s('米拉','针旗插岩缝。把红绳放松一点，冰花朝东走时它会留下一道空白。')],'black-pin'),
 fixture('ice-sight','换到浮尺下端读第二个方位',14,7,[s('瑟琳','十分钟前浮冰白角在岩灯西面。没人移动岩灯，白角已经在东。'),s('米拉','那条“长北岸”只画过这块冰。我给会走的线点虚点。')],'bearing-ice',['black-pin']),
 tidePost('ice-tide',8,12)],
 [exit(2,8,'lead-sound',[14,14],'下西支回着铅湾'),exit(5,4,'rib-survey',[21,6],'绕拱骨回固定岸基'),exit(18,7,'false-shoal',[11,8],'退水时过露出的石泥沟',['tide:low'])]);