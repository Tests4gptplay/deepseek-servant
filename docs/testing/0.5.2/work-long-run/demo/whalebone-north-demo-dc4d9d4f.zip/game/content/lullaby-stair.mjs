import {region} from './voyage-parts.mjs';
import {person,object,exit} from './parts.mjs';
import {tell,speech} from './lullaby-lane.mjs';
export const arcade=region('lullaby-roof-arcade','亮灯的空城 · 在屋檐下翻面的灶街',2,'whale-city',30,20,'wood',
 [['building',0,1,6,6,'艉檐搭起来的两灶'],['building',9,1,6,5,'廊里面的鱼油屋'],['building',19,1,8,4,'冬被仍垂着的长屋'],['building',3,15,6,5,'挨着旧暖炉的房'],['water',14,17,16,3,'船深处透上来的蓝光']],
 [['pier',2,9,24,3,'屋背原为晒面的檐道'],['lull-cloths',9,13,5,1,'刚才挑起一角的床帘'],['lull-fryer',18,8,3,2,'一早把油泼到檐外的小灶']],
 [person('lullaby-awning','把碎饼藏在帽沿的栗芽',6,10,[tell('栗芽','你走北横板过来，是哥哥的夜班把最后两截板留住了。他天天说要去别的港做主厨，到夜里还是去搬炭。','crew-plank'),tell('栗芽','南边驳子先接病人。娘总念船上的头一锅要软，哥哥偏爱把边烙到发脆。你坐那条船来的？','ward-skiff-ready'),
 tell('栗芽','你去过我娘窗下。哥哥一早托人告诉我，有人愿意退半步等她自己说话。','lullaby-port-asked'),tell('栗芽','今早收到有热气的一锅。她留在灶上没送你，果然没有托人补一句话。','lullaby-port-quiet'),tell('栗芽','港钟都响了，我站的是这边的船。父亲的棺，我看见。岸上的灶窗我看不见，你也不用替我编。','!lullaby-port-choice'),
 speech('栗芽','跟我。我不是想去看棺盖。我怕我等了半天，一见她女儿，脱口只会喊她爹的名。','roof-own-name')],{action:{type:'flag',id:'lullaby-child-led'}}),
 person('lullaby-sleeper','替夜班把油布从脚边卷起的人',13,12,[speech('换班人','一锅里有软有脆，谁说这只锅只给会咬的人使？我留着半边没牙呢。','roof-chew'),tell('伊沃','睡吧，我认得楼梯。'),tell('换班人','你认得的是往外拦人的那面。让我家那丫头领下去。')]),
 object('lullaby-blue-pan','昼灯下明明空着的一张折凳',20,8,[tell('玛拉','凳面一边发黑。一只手托病人，一只手没空把锅拿开，才会烧出这种半月。'),tell('栗芽','我娘坐那上面剔刺。我坐它时总是背朝门。等会别替我搬。')])],
 [exit(2,10,'whale-roofs',[12,8],'沿屋檐回原钩铃屋脊'),exit(26,8,'lullaby-double-stair',[4,8],'顺栗芽走过的悬灶廊下到双层楼梯',['lullaby-roof-led'])]);
const station=(id,name,x,y,mode,lines)=>object('lullaby-'+id,name,x,y,lines,{action:{type:'lullaby-crossing',mode,set:['lullaby-'+mode,'lullaby-choice']}});
export const stairs=region('lullaby-double-stair','亮灯的空城 · 让一步也能走到的双层灶梯',2,'winter-interior',32,21,'wood',
 [['building',1,1,8,4,'挂着葬舟旧缆的冷窗'],['building',13,1,6,5,'有扶手的上廊灶室'],['building',24,1,7,5,'换手的候人间'],['wall',6,10,11,2,'隔开高低两段的船腰'],['wall',21,10,10,2,'楼梯下方挡潮的横梁'],['building',3,17,8,4,'留给背担架人的歇脚处'],['building',21,17,7,3,'不向外开的厨门']],
 [['pier',2,7,28,2,'玛拉扶白布的一端'],['pier',3,14,25,2,'伊沃能与来人并肩走的低廊'],['lull-banister',7,10,10,1,'绳下不见人的矮栏'],['lull-banister',21,10,8,1,'外廊最响的脚板'],['lull-cloths',23,6,4,1,'能替当事人遮一掌的幕帘']],
 [object('lullaby-two-ends','听清两人约定怎样换到另一头',7,8,[tell('伊沃','你在楼上扶车，我在楼下。想听哪边，就换到那一头；另一人会在刚才站住的地方等。'),tell('玛拉','若栗芽想问，先给问话人留一块不受挤的低廊。若她愿意自己走，就把围看的人请上远台，西边窄路交给我。')]),
 object('lullaby-bare-metal','低廊能挡住来人目光的立柱',20,14,[speech('伊沃','这一根栏杆只能挡人，挡不住话。我站在这里，先让孩子自己问。','ivo-screen')]),
 object('lullaby-distant','从远台引围看的人去看返潮',10,15,[speech('伊沃','我去引他们看回潮。有人会问，我就说我没听见；我确实没听见。','ivo-far')]),
 station('sill-ask','玛拉走到东窗，陪栗芽把要问的那一句说完',25,8,'accompany',[tell('玛拉','栗芽开口前，我可以坐在她看的地方。伊沃要在楼下的近柱护一条干净的过道。')]),
 station('sill-quiet','玛拉从西边放亮的窄处经过，给栗芽留门',10,7,'apart',[tell('玛拉','这里听不到全句。我可以把车推远，去找仍在下层等的人。伊沃要先把围看的人引到远台。')])],
 [exit(3,8,'lullaby-roof-arcade',[25,8],'回悬灶廊，商量后也能再来'),exit(28,8,'lullaby-clay-hob',[3,9],'沿上灶梯进晒盘间听当事人的后话',['lullaby-choice']),
 exit(6,15,'lullaby-clay-hob',[6,12],'从低廊侧门进同一晒盘间',['lullaby-choice'])]);
