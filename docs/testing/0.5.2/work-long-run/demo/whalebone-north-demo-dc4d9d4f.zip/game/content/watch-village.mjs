import {region as second,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit,flag} from './parts.mjs';
export const quarter=second('bell-quarter','次航 · 失踪灯手住过的背窗街',4,'harbor',28,18,'stone',
 [['building',1,1,6,5,'门上有三颗小钉的旧宅'],['building',12,1,6,6,'只听得见短铃的小面屋'],['water',22,2,6,5,'遥望白崖的过桥口'],['crate',3,13,7,5,'留给修窗人的冬煤']],
 [['path',2,8,23,3,'声音能传，灯光照不到的街'],['lamp',15,10,1,1,'仍向不同方向的两根灯臂']],
 [witness('night-baker','第一次肯开后门的饼娘兰青',9,8,[s('兰青','我说过远窗没亮，有人写成远窗没人。那晚我贴着面墙听短铃三拍，知道近窗里有人求接；长铃响前，跑过去的人在我脚边留了一袋炭。'),s('沅籽','那袋炭的主人是灯手？'),s('兰青','我卖饼不认脚印。炭袋背上缝了补丁，你去扶架上找另一半，我能认针。')],'watch-baker',['watch-paint-order','watch-bells']),
 fixture('winter-knot','沿扶架摸炭袋补丁反面的第六针',17,9,[s('玛拉','第六针是两股不同颜色。旧窗里的暗布也有这道针，他们提前准备过遮光。'),s('兰青','夜里把近窗暂遮，远方向外臂就能看到另一种闪号。有人试图让还没回来的船认出最远的那道口。'),s('沅籽','我记起他为什么叫我别从凳子上下来：他需要有人站在里面，把罩松开。')],'watch-signal',['watch-baker']),
 person('lamp-statement','选择让哪一份有来源的线索进新航册',13,11,[s('沅籽','窗变成同色是灾后补漆。我记得一声长响，却没看见他最后去了哪条船。要不要公开那幅夹层图？我的脸不该跟在后面。'),s('玛拉','一份实物在这里，你可以给学徒发无名操作图，也可以只让家人保管原听记。公开哪一份，都不给失踪者编一个靠岸日。',[
 {text:'由值灯学徒领无名操作图',set:'watch-school'},{text:'原听记退给家里，仅公示漆层日期',set:'watch-kin'}])],{requires:['watch-signal'],action:flag('watch-stated'),after:[s('沅籽','你们的首航把谁回来、谁造锚写过了。我的次航只回答这扇窗到底什么时候变成了同色。')]})],
 [exit(2,8,'lamp-back',[13,13],'按旧测线回后窗'),exit(14,9,'ferrule-shed',[17,8],'带灯舌回棚'),exit(24,10,'next-bell',[3,8],'到下一代自己点灯的小礁',['watch-stated'])]);
export const lastBell=second('next-bell','次航 · 岬外小礁的下一班',6,'winter-coast',18,13,'stone',
 [['water',0,0,18,3,'灯下两条不同的航槽'],['wall',4,3,4,4,'刻着当班日的碑'],['crate',11,9,7,4,'只收旧物不收传说的木柜']],
 [['path',2,7,13,2,'站到外面才看得清的红窗']],
 [witness('new-hand','把余下的班交给亲手打开窗的人',9,8,[spoken('学徒','我有操作图，也知道上面为什么没有小孩的脸。关一窗再开回去，别人能从外面纠正我。','watch-school'),spoken('沅籽','我带原听记回家。墙上只写哪一天补的漆。灯手没回来的那一格，我还能自己决定什么时候开。','watch-kin'),s('玛拉','上次来这里有人落葬。今天我看着你自己迈下那张矮凳，在白天点一盏小灯。')],'watch-second-end',['watch-stated'])],
 [exit(2,8,'bell-quarter',[23,10],'回后街再翻原听记')]);
