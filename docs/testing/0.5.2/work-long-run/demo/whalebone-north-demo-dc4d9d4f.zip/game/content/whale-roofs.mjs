import {say as s,feature as f,exit,person,object,flag} from './parts.mjs';
export const roofs={
 id:'whale-roofs',name:'亮灯的空城 · 钩铃屋脊',act:2,width:30,height:19,ground:'wood',biome:'whale-city',
 solids:[[0,0,30,2],[7,3,5,3],[18,3,6,3],[2,10,6,4],[11,14,7,5],[26,10,4,8]],
 features:[f('water',0,0,30,2,'鲸背外的晨海'),f('building',7,3,5,3,'背脊伙房'),f('building',18,3,6,3,'灯道矮楼'),f('building',2,10,6,4,'关窗报潮站'),f('building',11,14,7,5,'补网人家'),f('pier',5,7,20,2,'小屋相接的雨檐'),f('rope',19,10,5,1,'倒转的井绳'),f('lamp',15,7,1,1,'无人应的炉灯')],
 entities:[
  object('warm-sleeves','还在滴水的袖套',9,8,[s('玛拉','水还温的。左袖只缝半圈，正好让断过腕子的人套进去。'),s('伊沃','屋里最后一个人不是夺路逃的，还顾得上替隔壁收衣。')],{action:flag('recent-wash')}),
  object('reverse-groove','天井挑梁上的反向索痕',20,9,[s('伊沃','靠海的槽是平日放粮。靠屋的浅槽，刚才有人往上提了空篮，再把重的东西放到底。'),{who:'玛拉',if:'keel-name',text:'补船那三排铜钉的空板背，也能看见一来一回的刮痕。你们都不是只走了一趟。'},s('玛拉','底下还有人。先别砸锁，让我去听。')],{action:flag('reverse-scuff')}),
  object('under-roof-knock','透灰尘的排烟窗',15,11,[s('窗下的声音','别踩左边的瓦！我把里面的木闩拆了垫床，那一片没有东西托！'),s('玛拉','把孩子抱到窗边来。我们在屋顶，没人会从海里抢你们的粮。'),s('窗下的声音','我不怕你抢。我怕你开窗，下面那层蓄住的水往这边灌。把左边的转梯先找回来。'),s('伊沃','在这儿留根绳，让他们一抬头就知道屋顶还有人。')],{requires:['recent-wash','reverse-scuff'],action:flag('roof-shelter'),after:[s('玛拉','湿袖、返索和那声回话都在。亮着灯的鲸城里，有人把日子往下面搬了。')]})
 ],exits:[exit(14,11,'counterlift',[2,8],'循排烟窗下的声音进反提梯井',['roof-shelter']),exit(4,5,'upper-spar',[24,6],'循北屋脊横板回追行屋桁',['crew-plank']),exit(24,13,'upper-spar',[20,12],'由南檐护航驳折返',['ward-skiff-ready'])]
};