import {quay,transit} from './from-the-clockmakers-quay.mjs';
import {cellar,water,landing} from './the-three-watches-and-the-dark-water.mjs';
import {say as s,person,exit} from '../parts.mjs';
import {witness,spoken} from '../voyage-parts.mjs';
const newMaps=[quay,transit,cellar,water,landing];
const returnNote=witness('star-port-landing','水没过扶手时照旧能报时的米娘',26,11,[
 s('米娘','扶手头的圆窝已经没在水里。你要是只盯原灯，得隔一整架吊车才能看见我。'),
 spoken('粟铅','准钟随粮船，我留渡屋。现在渠水把表针淹了，倒是你的铜线横在上层，接上了两拨人的半刻。','star-clock-grain'),
 spoken('粟铅','准钟留夜渡，我去了粮船。你们那条暗船第三趟才显出人脸，米娘一刻没白等。','star-clock-ferry'),
 s('伊沃','各报一声。一个人报的时辰，总得有人在另一头接得住。')],'star-clock-late',['star-clock-settled','clutch-still']);
export function theDarkCrossing(world){
 const maps={...world.maps};for(const m of newMaps){if(maps[m.id])throw Error(m.id);maps[m.id]=m;}
 const ring=maps['pilot-ring'];maps[ring.id]={...ring,exits:[...ring.exits,{...exit(8,13,quay.id,[3,11],'带一只还走着的钟，随白篷摆船去星历台',['north-chart']),lockedText:'米拉须先在双影深槽实核北图。试船、退缆与原航都照常。'}],
 entities:[...ring.entities,person('star-boat-basket','盖住船钟的白布篷',6,12,[s('篷下的人','响了才卸。摆要是停在路上，谁还能说哪岸的点卯早了。'),spoken('篷下的人','钟归钟，站在这边从天上报时的是谁，我今夜认出声音来了。','star-clock-settled')])]};
 const gulf=maps['flood-stair'];maps[gulf.id]={...gulf,entities:[...gulf.entities,returnNote]};
 const order=['star-clock-offer','star-clock-log','star-clock-plumb','star-clock-sighted','star-clock-tested','star-clock-oars','star-clock-crossed','star-clock-settled'];
 const q={id:'the-star-that-does-not-keep-ship-time',name:'那颗星不照船钟走',kind:'side',stages:order,startFlag:order[0],endFlag:order.at(-1)};
 const secret={id:'a-fingerprint-on-green-glass',name:'桌底下也有人看星',kind:'hidden',stages:['star-clock-quiet','star-clock-glass'],startFlag:'star-clock-quiet',endFlag:'star-clock-glass'};
 return {...world,maps,quests:{...world.quests,[q.id]:q,[secret.id]:secret},equipment:{...world.equipment,'star-seam-rule':{name:'不带表针的铜星圈',slot:'charm',resists:{light:.20,wind:.13},context:'米娘在青玻璃台卸下指星轮的旧铜内圈'}}};
}
