const furniture={
 'heel-hall':[
 ['heel-workbench',6,13,3,1,'门口摆着右长左短的一对半成木屐'],['heel-pantry',20,9,3,1,'藻婶晾蛏和煨汤的小灶'],['heel-plumb',25,11,1,1,'斜门旁从软绳自然垂下的一枚纽扣']],
 'heel-high-sill':[
 ['heel-loft',5,9,4,1,'旧半阁留下的吊铺与三根灰钉'],['heel-plumb',21,10,1,1,'窗洞旁的直引绳与倾斜木杆'],['heel-workbench',16,16,2,1,'住户自己修靴的低凳']],
 'heel-low-turn':[
 ['heel-pantry',5,10,3,1,'晚饭还在炉上煨的低灶'],['heel-longbed',9,12,4,1,'先撞肋、转尾后才能出门的旧床长架'],['heel-stain',23,10,4,1,'先沉左端的深色水带和半月痕']],
 'heel-folded-room':[
 ['heel-loft',6,11,3,1,'妹妹的旧半阁，挂着一双小漆屐'],['heel-workbench',14,11,4,1,'凹把、新屐和刨薄的木卷'],['heel-pantry',22,12,3,1,'哥哥旧灶旁还有人借用的芝麻罐']],
 'heel-flooded-hall':[
 ['heel-workbench',6,13,3,1,'本次潮水已推到木屐铺的低腿'],['heel-pantry',20,9,3,1,'离了水口的锅盖与关掉的灶'],['heel-stain',25,11,4,1,'新湿线亮，旧盐线黑'],['heel-water',11,15,9,1,'沿原街的另一肩流过的新水']],
 'heel-broad-ramp':[
 ['heel-lane',6,10,14,2,'旧整门割成的双轨和一条可退的伴行肩'],['heel-longbed',22,10,4,1,'可坐人、带本人退手的双轮滑板'],['heel-water',8,15,10,1,'宽坡脚的新水']],
 'heel-quiet-return':[
 ['heel-lane-quiet',5,10,13,2,'整门内侧的低位回廊，在尽头留下转轮的圆圈'],['heel-workbench',21,12,3,1,'仍按原样留着的左右木屐'],['heel-lantern',13,14,2,1,'家属能自己拨开的内灯和一只轮椅扶把']]
};
export function furnishHeel(map){
 const marks=furniture[map.id];if(!marks)return map;
 const added=marks.map(([kind,x,y,w,h,label])=>({kind,x,y,w,h,label}));
 return {...map,features:[...map.features,...added]};
}
