import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {mechanism,tidePost} from './district.mjs';
import {setting} from './registry-parts.mjs';

export const gallery=region('lamp-ward','锚夜 · 旧守灯班的反面走廊',6,'whale-interior',27,19,'wood',
 [['wall',0,0,27,4,'转身后朝下的一排齿窗'],['crate',3,4,5,4,'守灯人放鞋的格架'],['building',16,3,7,5,'检票灯的背面'],['wall',17,14,10,5,'老人能借肩的缓扶墙']],
 [['path',2,9,22,2,'从内锁背面向外降的走廊'],['lamp',11,8,1,1,'只有地面能看见的红孔']],
 [witness('inside-watcher','等古杬说出是谁关过锁的筒青',9,9,[s('筒青','原来你们给老港卫留了钥匙。行，把谁开的、谁关过的都当着我说，然后把灯放到我脚边。高过肩的灯照不到坐着的人。'),s('古杬','旧命令是我教出去的。今天这把钥匙借到这道门为止。'),s('伊沃','我也签，钥匙交你验，回来还要去见临棘。')],'inside-agreed',['right-inside']),
  fixture('lamp-two-holes','请筒青用矮凳看两个不同方向的灯孔',14,10,[s('筒青','坐下来才看见方窗里有第二排圆孔。先放低才能把圆孔当出口；先转灯，人会走向有坡的墙。')],'lamp-low-read',['inside-agreed']),
  mechanism('lamp-withdraw','从座位复验开内门的三步',20,9,[s('筒青','第一道门由我开，你们三个人去外面把管索握稳。')],['lamp-low-read','ivo-line'],'inside-door','哪一组动作能使等候者亲眼看见下一道门？',['旋灯、抬灯、开旧锁','降至方孔、向圆孔转、由里抽闩','由港卫在外面开锁再让大家举手'],1,'低灯须先入方孔。坐在矮处的人看到圆孔才自己抽闩。',[s('古杬','有人抱着空枕先出去了。门不能交给我再锁。')]),
  person('lamp-rest','用两种声音喊孩子名字的吟冬',11,12,[s('吟冬','我小声叫是因为孩子就在身边。大声叫是给外面不肯走的人听，叫他知道还有别人。'),spoken('吟冬','现在换家属在门里喊，旧钥匙收在她膝上。','inside-door')])],
 [exit(3,9,'shale-gate',[23,9],'回封航灰檐'),exit(23,10,'crossing-loft',[4,9],'陪掌灯者到高处再为外班找肩',['inside-door'])]);

export const cut=region('hauling-cut','锚夜 · 翻网人共用的灰礁水巷',6,'flood-harbor',34,23,'stone',
 [['water',0,0,34,4,'两条互相抵消的水弯'],['building',3,4,5,4,'跟着涌水拍门的药铺'],['wall',16,2,3,6,'吃得住绳的花灰礁'],['boat',24,3,8,5,'卡进窄巷的翻网艇'],['water',22,16,12,7,'旧篱下的扇形洼地']],
 [['pier',2,10,29,2,'石上两个远近不同的绳眼'],['rope',8,13,15,1,'必须从外端抽开的门绳'],['lamp',19,8,1,1,'给低艇留的有罩青灯']],
 [witness('cut-caller','坐在翻网艇上捞松绳的临棘',10,10,[s('临棘','先别扯，扯紧我这头就够不到。我不是要你替我下水；你让水停一会儿，我把艇里的软绳穿进外孔。'),s('伊沃','当初封门我听见四下，我写的是风声。我不用把这只绳握死以证悔意。')],'cut-asked',['right-outside']),
  tidePost('cut-clock',13,11),
  fixture('cut-eye','退潮时从外艇看灰色海螺的正眼',18,9,[s('临棘','上眼磨损在右肩。真承力的下眼沾着活螺，石贴水还能看见。用一根空绳先穿我手心。')],'cut-depth',['cut-asked','tide:low']),
  setting('cut-lock-test','把外绳锁死再轻触空艇试力',16,12,[s('伊沃','艇鼻向墙，临棘的手也被带离门。松开重穿；不让人站在受力这边。')],['cut-asked'],{'cut-free':false,'cut-tight':true}),
  setting('cut-soft','从下眼穿回外艇，岸端只留活索',22,10,[s('临棘','这次是我把自己的绳头送出，不是岸上把我拉向墙。')],['cut-depth'],{'cut-free':true,'cut-tight':false}),
  fixture('cut-board','用白崖留下的两段夜班船板接低口',24,12,[s('夜班工','第一夜没烧的板现在有了裂，横纹那边搭内台，另一块倒着拼。临棘不必等涨潮才能带出去四个人。')],'used-first-plank',['crew-plank','cut-free','!cut-tight'],{action:{type:'flag',id:'used-first-plank',set:'cut-ready'}}),
  fixture('cut-float','等满潮浮高，带着短篙从回水口横过',28,11,[s('临棘','没有额外的板就走这头。两人先上内台，剩下的待水自己到他们脚边。盐铺晚了一班开炉，船上四个人都在。')],'used-later-float',['cut-free','!cut-tight','tide:high'],{action:{type:'flag',id:'used-later-float',set:'cut-ready'}}),
  person('cut-classmate','攥着半截甜芦的呼莳',9,12,[s('呼莳','大人叫“最后一艇”，临棘还在岸上。我就咬芦杆，不替她说“都齐”。'),spoken('呼莳','她上了内台来问我甜不甜。甜不甜是我的答话，这一回是她自己答到了。','cut-ready')])],
 [exit(3,10,'shale-gate',[25,11],'上灰檐查谁尚未出门'),exit(30,10,'crossing-loft',[25,10],'随临棘到外班实到平台',['cut-ready'])]);

export const loft=region('crossing-loft','锚夜 · 二班都得走到的过铃楼',6,'flood-harbor',30,21,'wood',
 [['building',2,2,7,6,'没有门扇的守候处'],['wall',14,1,3,6,'给水位留白的验铃尺'],['boat',21,3,8,5,'为第二班特意留下的空备用艇'],['crate',18,15,12,6,'补船板钉和归还的钥匙']],
 [['pier',2,9,25,3,'高侧下来的平坦交接道'],['rope',8,13,13,1,'外班自己投来的软索']],
 [witness('inside-return','筒青把灯给临棘，再亲自等外艇回来',10,9,[s('筒青','我们先到了，外面的烟棚进了半掌水。我的那双鞋算借木匠的，把临棘整头接过来再提谢。'),spoken('临棘','冬天我会照豆岚的低灯。打过两次信号，她不替我把此刻这声答了。','night-landed'),s('临棘','四个人，最后是我。里面先走，不是我从名单掉下去。')],'inside-returned',['inside-door'],{action:{type:'flag',id:'inside-returned',set:'both-shores'}}),
  witness('outside-return','给古杬留慢坡，并等他把旧钥匙交还',21,10,[s('古杬','我走了鱼油的慢坡，磨掉一只鞋底，门童扶了我一只胳膊。今晚照明归她，我知道了。'),s('伊沃','长绳先给了临棘，不等于旧班上的人该淹。我回来接人，也让人问我当年那张封条。'),s('筒青','人和灯都到了。没有人把锁还给古杬。')],'outside-returned',['cut-ready'],{action:{type:'flag',id:'outside-returned',set:'both-shores'}}),
  fixture('loft-bell','把不再需要占用的两端摇铃交给布兰',16,11,[s('布兰','先听见双铃，才敢把插销抽出。夜渡的每一个人，碰过索的人，还有没肯交名字的人，我都得替他们留一条回路。')],'both-bells',['both-shores','weir-proof']),
  person('pulley-sitter','把橹截短给孩子学的海杏',12,12,[s('海杏','有人把鸣金当作全撤完了。我等船沿贴我的短篙，让小个子先跨，才知道船来了。'),spoken('海杏','能吃早饭的是两班，我得把锅加水，不是挂两面光旗。','both-bells')])],
 [exit(3,9,'lamp-ward',[22,10],'随内班回查灯室',['inside-door']),exit(26,10,'hauling-cut',[29,10],'随外班回查灰礁',['cut-ready']),exit(15,14,'ratchet-loft',[15,10],'带两班的实响回棘轮和锚销',['both-bells'])]);
