import {region,fixture,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {mechanism} from './district.mjs';
import {setting} from './registry-parts.mjs';

export const baths=region('lung-baths','白崖港 · 鲸肩底下的热浴筏',1,'harbor-interior',29,19,'wood',
 [['water',0,0,29,4,'鲸肩一次甩开的绿水'],['building',3,3,5,4,'换衣角和干衣架'],['water',12,3,6,5,'泡着暖管的池眼'],['crate',21,4,6,4,'石井绞下的冷水砖'],['water',0,14,11,5,'贴着石锚脚的潮汊'],['wall',21,14,8,5,'不动的岸基']],
 [['pier',3,9,23,2,'仅一头系住的浴筏'],['rope',10,12,10,1,'托盘的两条绳在此分手']],
 [fixture('bath-bare','赤手摸系在鲸肩的湿结',8,9,[s('浴工','海一推，两头跟着晃的叫筏；一头又往沉处拧的才牵着鲸。你看，那结上刚冒了一串泡。')],'bowl-wet-knot',['flank-deep']),
  fixture('bath-hard','摸同一只锡盘架上不动的冷环',15,10,[s('玛拉','这边冷，下面很硬。绳子拉到石头就不再缩；不能让两根绳同时咬死这只盘。')],'bowl-rock-ring',['breath-seen']),
  setting('bath-pinch','先把两端绳扣都压在同一格试一试',12,11,[s('木架','锡盘翻起三指，压住的下绳已经吱响，手柄仍能退回。')],['bowl-wet-knot'],{'bath-slack':false}),
  setting('bath-spare','抽松鲸侧半圈，岸绳留在铁牙里',18,11,[s('浴工','盘还是歪，木板却不再撕你的手。下一口气来得及等。')],['bowl-wet-knot','bowl-rock-ring'],{'bath-slack':true}),
  mechanism('bath-send','借筏的上浮把烫盘递入岸槽',22,10,[s('玛拉','一只手在岸，那只手不肯跟着鲸退半步。我的手可以。')],['bath-slack','flank-deep'],'bath-plate','鲸向下浅潜、浴筏浮到门口。哪样能先送盘又不会把两端绷住？',['让肩绳有余量，沿岸绳推盘，最后放自己的手','把两头拉死，等鲸不再呼吸','随浪把满盘抛向岸上的人'],0,'手里摸到的冷环从没动。会往下拧的绳必须能放。',[s('浴工','有人接住。斜过一次的汤还是汤，我拿它烫葱。')]),
  fixture('bath-hand','把不再吃力的盘沿送到对岸手心',24,11,[s('灶徒','盘沿结着一点汤皮。这一碗我来端，你松手。')],'bath-handed',['bath-plate'],{action:{type:'flag',id:'bath-handed',set:'flank-arrived'}}),
  person('bath-toe','趁水浅找脚趾甲的澡客',10,12,[s('澡客','我把丢的钱夹在袜里，丢的袜挂在脚盆边。如今两样有一样还在漂，别告诉我媳妇。'),spoken('澡客','我认错了，是葱皮。我媳妇给的钱还在她那。','bath-plate')])],
 [exit(3,10,'blow-stoop',[9,13],'踩退筏回鲸肩稳趾'),exit(25,10,'tin-quay',[4,10],'沿岸绳上固定的锡场')]);

export const bucket=region('bucket-gable','白崖港 · 斗篮齐檐的高灶顶',1,'whale-city',31,20,'wood',
 [['building',0,0,11,7,'长屋下烧煮的三座灶'],['crane',16,2,5,6,'斗篮偏心轴'],['wall',23,2,8,6,'不晃的石山墙'],['water',2,14,11,6,'檐外一罩雾水'],['crate',22,14,9,6,'干火绒和铁套']],
 [['pier',3,8,25,3,'吊篮口的两层护脚边'],['rope',8,12,14,1,'通往石墙的短系索']],
 [fixture('bucket-ash','看锅烟在拱肩那一刻擦过哪条檐',9,9,[s('灶婆','旧烟黑得发亮，是常年烧出来的。这道新烟蹭到檐底往右的一面，另一面还干净。两条不能混着看。')],'bucket-ash',['flank-raised']),
  fixture('bucket-plumb','用炊勺吊在两个压花钩间比一比',17,10,[s('玛拉','勺垂在偏心轴下，靠岸的钩恰能兜住。靠鲸那钩原本是风大时收空篮用的。')],'bucket-plumb',['breath-seen']),
  mechanism('bucket-rig','把斗篮的两格套钩回到送货位',22,10,[s('灶婆','别碰我那罐糖，我正在给一颗蛀牙做最后一顿饭。')],['bucket-ash','bucket-plumb','flank-raised'],'bucket-rigged','新烟朝右，勺尖正落在岸侧钩。有人接盘的篮门应该开向哪里？',['套在鲸侧再把勺绑死','抽掉两边的销一起往下坐','把活篮套岸侧，肩板一回落就让鲸端松开'],2,'吊篮门只有一扇。空篮收鲸侧，重篮看勺尖停在哪个钩下。',[s('玛拉','门齐了，仍要我手把东西递给那边。')]),
  fixture('bucket-send','用一只隔热手套把锡盘交给固定檐上的人',25,11,[s('灶徒','接到了！纸封没烫脱。我刚才一急举的是右手，你就知道我左边手背起了泡。')],'bucket-plate',['bucket-rigged'],{action:{type:'flag',id:'bucket-plate',set:'flank-arrived'}}),
  person('lid-boy','嚼冷草根的斛耳',13,12,[s('斛耳','我给勺子起名字。短的叫今天，长的叫够不着。你刚摸的是够不着的娘。'),spoken('斛耳','新名字？烫得起泡那个肯定是今天的爹。','bucket-plate')])],
 [exit(3,9,'blow-stoop',[27,11],'退回鲸肩气阶'),exit(27,10,'tin-quay',[26,9],'走山檐的固定石台')]);
