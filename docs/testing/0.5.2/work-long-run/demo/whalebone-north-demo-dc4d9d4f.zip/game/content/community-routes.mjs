import {fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,exit,object,person,flag} from './parts.mjs';
const links={
 'wake-court':{exits:[exit(21,11,'shift-square',[2,10],'寻二班交接去三班场',['vigil-finished']),exit(26,9,'trim-yard',[4,8],'沿已经核过的旧港工道回木场',['berth-fixed'])],
 entities:[object('absent-night-bell','头日守班的木铃托',13,9,[s('托铃小工','第一道铃给送棺人。过了守夜，第二道铃转给蓝门三班场，再过一潮才开第三道灶。')],{requires:['!shift-receipted'],lockedText:'铃托已交接。二班工在过秤台，夜灶开放后去粮趸找同班。'})]},
 'trim-yard':{exits:[exit(3,8,'port-desk',[19,8],'沿二班过秤台回社区',['shift-receipted'])]},
 'ration-berth':{exits:[exit(13,10,'late-canteen',[18,7],'循夜班锅香进第三灶',['berth-fixed'])]},
 'dry-court':{exits:[exit(7,10,'eight-landing',[2,11],'过拱门沿八户双街'),exit(22,11,'net-heron',[17,10],'沿清过的通风网登舷台',['net-open'])]},
 'crib-hold':{exits:[exit(12,10,'bed-jetty',[9,11],'回查产床的交接签',['beds-countersigned']),exit(8,8,'meal-barge',[16,8],'乘已跑通的夜饭驳回港',['ferry-fed'])],
 entities:[person('bar-after-move','已换木楔的床架',15,8,[s('井嫂','旧闩已经拿走，右床不晃。现在有空再去问这八户怎样决定搬床。先前做过的事不需要重来。')],{requires:['bar-freed']})]},
 'meal-barge':{exits:[exit(16,7,'crib-hold',[8,9],'随夜饭驳送锅进鲸城',['ferry-fed'])]},
 'west-lamp':{exits:[exit(7,11,'shutter-school',[18,7],'从旧灯的门廊进反开课房',['gate-safe'])]},
 'testimony-room':{entities:[witness('report-back','由迟荻自己收回遮脸帘',8,10,[spoken('迟荻','现任灯手签收了，我同意到这里为止。下次换人不能把我的同意自动算到下个人身上。','speaker-sealed'),spoken('迟荻','一个学徒能从外边开灯。这样就够了，教具不能写我的姓。','speaker-lesson'),s('伊沃','我的记录只负责记我关过什么，不拿你的名字填空。'),s('玛拉','你也不必因为他救过我，就原谅他造过的东西。')],'speaker-return',['speaker-action'])]},
 'salt-dorm':{entities:[witness('pay-outside','在盐市寄宿院兑还第三晚欠薪',11,10,[s('凯芽','你陪逢珠取的那张欠工单还有蜡印。我把盐市拆马的钱匣挪一栏，少的工班按她原名补，店里管不了谁是她的孩子。'),s('瑟琳','这钱是干过活该拿的。别再记到抚恤一栏，让家属每回都得先说一段悲伤。')],'pay-restored',['pay-entered','ticket-date'])]},
 'red-beacon':{entities:[fixture('outside-lesson','让远标学徒在屋外独立开一次窗',11,11,[s('学徒','迟荻只要我会打开，不肯让我公开名单。我在红标上自己走一遍。'),s('伊沃','好。这盏灯可以先回答你，然后才回答我。')],'lesson-crossed',['speaker-return','speaker-lesson','remote-lit']),
 witness('keeper-seals','由独立收件人盖回执而保留名字',14,12,[s('灯手','当班收过，没有抄送到港报。你看看这个封蜡，找不到回信人的门牌。'),s('米拉','地图上不画陌生人的床位，也不能把她的沉默当成同意。')],'sealed-crossed',['speaker-return','speaker-sealed','remote-lit'])]},
 'winter-ward':{entities:[object('heated-spoon','船家留下的第二把浅匙',10,8,[s('勾婶','鲸城试过这一口的吞咽量。换到冬岸，老人也能喝，夜里咳起来放心些。')],{requires:['broth-received','bed-count'],action:{type:'item',id:'tonic',value:1,set:'supper-in-winter'}})]},
 'burial-cape':{entities:[fixture('private-button','陪逢珠将海窗木扣放回家里',16,12,[s('逢珠','我把木扣带回去，原地的钉孔可以留空。你没有把他的身价刻在晏禾的墓碑上，这一点我记着。')],'button-home',['mourning-kept','grave-signed']),
 witness('paid-lantern','把停工簿交回家属',11,10,[s('逢珠','第三晚工钱已经兑齐。葬他的时候，我们自己从家里的钱匣买的灯，不欠港务署。')],'wage-home',['pay-restored','grave-signed'])]}
};
export function withPortChapters(map){
 const extra=links[map.id];if(!extra)return map;
 const exits=map.exits.map(e=>map.id==='wake-court'&&e.to==='trim-yard'?{...e,requires:[...e.requires,'shift-receipted'],lockedText:'二班工在临工房等签。摆灯院的东门可达三班交接场。'}:e);
 const entities=map.entities.map(e=>map.id==='crib-hold'&&e.id==='underbed-bar'?{...e,requires:[...e.requires,'beds-countersigned'],lockedText:'拿走床脚横闩前，请去晒衣院后面的八户双街。井梨要亲眼试过空架才肯签。'}:e);
 return {...map,exits:[...exits,...(extra.exits||[])],entities:[...entities,...(extra.entities||[])]};
}
