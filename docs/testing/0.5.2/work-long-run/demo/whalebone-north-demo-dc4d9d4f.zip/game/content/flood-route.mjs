import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit} from './parts.mjs';

export const flood=region('flood-stair','锚断之夜 · 被水切开的收粮坡',6,'flood-harbor',30,20,'stone',
 [['building',1,1,6,4,'殓棚的反窗'],['building',11,1,5,5,'从背侧看的公秤房'],['building',22,2,6,5,'熄灯缉粮栈'],['water',9,7,12,4,'没顶的原横向车道'],['water',0,15,16,5,'下潮脚彻底进水'],['crate',23,14,7,6,'脱靴的两辆翻车']],
 [['rope',6,7,1,7,'绕水去高门的导绳'],['pier',7,12,17,2,'新放下的平潮长板'],['lamp',22,10,1,1,'各组集合铃']],
 [fixture('cut-ramp','检查被水分成两段的旧车痕',7,10,[s('玛拉','第一天两辆车能并排过，今天横街的中央是水。我把靠秤房的门框填上绳，带人从背面上街。')],'tilt-sighted',['harbor-tilted']),
 person('reserve-oar','留到最后回船的短桨工',16,12,[s('桨工','别以为我在数名字不出力。板上少一个，我得划回去找一个。'),spoken('桨工','西窗组已找到冬岸的吊罐床。那名婴儿用的是她自己的围裙。','beds-arrived'),spoken('桨工','工匠那船的两支桨都带过来了。我把最后一盏公灯送去修索铺。','workers-arrived')])],
 [exit(2,8,'anchor-yard',[13,15],'沿机房扶手返锚场'),exit(8,7,'wharf-scale',[18,11],'从殓棚背面回到原秤桥',['tilt-sighted']),exit(24,11,'wake-court',[6,10],'从高灯门回原摆灯院',['base-group']),exit(21,16,'safe-keel',[3,8],'从新高桩渡冬岸',['court-count']),exit(6,13,'dry-court',[11,13],'沿西窗已修长梯接担架',['west-stairs','court-count']),exit(22,8,'salt-lane',[21,9],'从署名公灯回盐市抄手住处',['north-lampstock','court-count'])]);
export const keel=region('safe-keel','撤离 · 顺新海图的引航驳',6,'north-sound',26,17,'wood',
 [['water',0,0,26,3,'刚开启的北航槽'],['crate',4,4,5,4,'首户的个人行李'],['building',15,4,6,4,'浮驳药柜'],['water',18,12,8,5,'担架舟的靠边水位']],
 [['pier',2,8,21,2,'舷外分流板'],['rope',9,12,8,1,'对岸接船索'],['lamp',13,7,1,1,'满员旗']],
 [witness('count-first','将旧秤桥头两家的木环交到岸上',11,9,[s('桨工','青、白两个环。凳上和担架转角各留一寸。一家走船尾，一家在船首，人数吻合。'),s('瑟琳','四炉院只肯先给这两家盖章，算得少是为了冬天也能活下来。')],'base-safe',['court-count','north-chart','winter-proof']),
 fixture('salt-workers-berth','把铅字工的油灯挂进修索铺棚',16,10,[s('仓守','我们从盐市签了自己的名，今天带着粮仓的灯和两支备用桨给船厂用。岸上按人的名字给床，不按票给。')],'workers-arrived',['workers-aboard','base-safe']),
 person('boat-tail','已经到岸的港工小女儿',7,9,[spoken('女孩','我娘的夜饭牌那盏灯照到了院外。我带那盒针到冬岸还给芬。','thread-child'),s('女孩','鞋落海里了一只。我会跟她说是哪一只，不让她躲到门背后去找。')]),
 object('land-rest','引航驳的系泊舱',9,11,[s('桨工','钩住靠岸环了。缓一缓，等心跳慢下来再把名单读一遍。')],{action:{type:'rest'}})],
 [exit(2,8,'flood-stair',[20,16],'沿原收粮坡逆向查漏'),exit(22,9,'lee-cutter',[3,8],'联络接担架的偏舷舟',['base-safe']),exit(13,14,'burial-cape',[3,9],'送棺回白崖朝北的墓坡',['base-safe'])]);
export const cutter=region('lee-cutter','撤离 · 碎浪门双舷小艇',6,'north-sound',19,14,'wood',
 [['water',0,0,19,3,'接驳湾'],['crate',4,4,4,2,'压平的横担架'],['building',12,3,4,3,'雨篷'],['water',13,10,6,4,'闸外水面']],
 [['pier',2,7,15,2,'双船缓冲廊'],['rope',9,10,3,1,'担架滚索']],
 [fixture('set-stretcher','把吊床平稳换到背风舷',9,7,[s('测缆员','你在盐市答应照顾证人，我答应你当班。近舷比远舷低，我先上去压平。'),s('井嫂','两个睡不着平铺的病人盖好；一到崖门，我要看对面也有人接。')],'beds-ferried',['stretchers-on','north-linesman']),
 person('hooded-child','抱着旧玻璃罩的乔',10,9,[spoken('乔','我不拿灯去照谁的罪。我只照着担架低头那一边，别让她们慌。','west-stairs'),s('乔','摇得头疼时，盯着对岸窗沿看。')])],
 [exit(2,8,'safe-keel',[21,9],'回主引航驳'),exit(16,7,'dry-court',[16,12],'沿西窗小艇返晒衣院',['west-stairs','court-count']),exit(12,11,'winter-ward',[11,9],'卸担架去冬岸横铺公屋',['beds-ferried'])]);