import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit} from './parts.mjs';
import {mechanism} from './district.mjs';
import {setting} from './registry-parts.mjs';

export const hearth=region('pot-round','白崖港 · 三楼共用一条烟道',1,'harbor-interior',30,21,'wood',
 [['building',1,1,6,5,'靠街面开窗的鲱鱼食铺'],['hearth',12,2,5,5,'三层炉眼露出不同火色'],['building',22,1,7,6,'祖孙卧铺和侧门'],['crate',1,15,8,5,'桌角夹在桶上方的两间小案'],['wall',21,16,9,5,'被锅烟熏黄的侧楼梯']],
 [['path',3,9,23,2,'转半圈从卧铺进厨房的环巷'],['rope',9,12,13,1,'一户户系到炉边的拉铃绳'],['lamp',18,8,1,1,'陶勺口悬住蜡头']],
 [witness('hearth-mother','炉前用拇指展平烫皱围腰的苑芜',8,9,[s('苑芜','我想把娘送到石岸上住。她烫了手，直到甩锅盖才叫出声。我也想自己掌这口灶，不能装成只是为她。'),s('玛拉','她知不知道你想掌勺？'),s('苑芜','只知道前半句。她说半句话是最重的一种锅盖。')],'hearth-asked'),
  witness('hearth-sparrow','把碎碗碰得叮叮响的荚儿',14,10,[s('荚儿','我外婆跟人说自己生日忘了，可她每年今天都留两片最肥的鱼皮。家里碗有八种缺口，我想把这块门风铃再挂起来。'),s('玛拉','我喜欢那个响，不用拿我的工钱来算。手给我，咱们磨碎口，做一副你们听着像自己家的。')],'shard-wish',['hearth-asked']),
  fixture('hearth-sand','在米糠盆里把碎釉摸到能闭眼穿线',10,12,[s('荚儿','蓝片中间那道裂，没磨平的时候像小鲫鱼嘴。'),s('玛拉','试线我用自己的袖角。若刮你手就还要磨。')],'shard-ground',['shard-wish']),
  mechanism('hearth-chimes','让碎碗风铃能响又不会越过炉火',19,11,[s('陶鹊','风吹脊背时饭桌会动，烟道固定在三楼的屋梁上。你把铃挂到哪头？我这身礼服可是才从晾衣绳上拿的。')],['shard-ground'],'grandma-birthday','线长时长片碰到锅盖，短片还没碰瓷。生日该听见什么？',['把长片拴在灶钩，与锅同落','短片穿外孔，长片收短挪到固定门梁','把裂口当系绳，猛拉三次'],1,'锅和桌随鲸身摆，门梁给两片共同的参照。一长一短可以打结调回来。',[s('陶鹊','是这声音。以前我儿子一推门铃先响，我知道该多煎一条。他走后这是我头一次想再煎。'),s('玛拉','鱼边别给我挑刺。我也会慢慢吃。')]),
  witness('hearth-try','让陶鹊先试她愿意过的那种日子',16,9,[s('陶鹊','你们问我怎么办，我有两桩想做的事。上岸开一口给夜工留汤的低炉，或让闺女接家灶，我去浅水摆艇给船工做饭。都要有一个真的试场，我不要在这桌上签余生。',[{text:'推一口试炉上老岸基，留下楼里的引火',set:'hearth-try-land'},{text:'替摆艇留活索，把家灶交回给女儿',set:'hearth-try-wake'}]),spoken('苑芜','你搬得回来，我才肯承认这次是由你自己挑的。','hearth-try-land'),spoken('荚儿','我跟娘睡。外婆也许会绊着那条毯，我给她留条窄的。','hearth-try-wake')],'hearth-trial',['grandma-birthday','!roof-shelter'],{after:[s('陶鹊','先把脚放上去才知道。我的锅不肯替我的腿表态。')]}),
  person('hearth-tenant','隔着半道墙回话的邻居乌笋',23,12,[s('乌笋','少一个灶，六家轮流熬夜。让我听一首生日曲就忘了这件事，办不到。那只预热砖分我，我可以试着干。'),spoken('乌笋','她留下了余火。我得早起一刻，少骂她两句又不是认输。','kitchen-shore'),spoken('乌笋','勺柄今天朝左了。苑芜摸得着，老太太用得不顺；看来这回真换了人。','kitchen-crew')])],
 [exit(3,10,'cup-eaves',[24,15],'从烟门回叠碗街'),exit(21,13,'tin-quay',[19,12],'穿走菜的小屋回锡场'),exit(26,10,'stove-lip',[4,10],'到锅脚、小艇同高的试灶船坞',['hearth-trial'])]);

export const lip=region('stove-lip','白崖港 · 小炉台与半水船坞',1,'harbor',32,20,'wood',
 [['water',0,0,32,4,'泊着三家人的窄缝水'],['boat',3,3,8,4,'陶鹊进出得了的小摆艇'],['crane',15,2,6,5,'可垫稳热炉的长臂'],['building',24,2,7,6,'有两道门的矮炉试间'],['crate',1,15,8,5,'留在原楼的引火格'],['water',23,15,9,5,'会擦到回索的水道']],
 [['pier',3,9,25,2,'船与岸各留两个来往的人位'],['rope',8,12,14,1,'小艇旧索与灶架的背风套']],
 [fixture('lip-ember','跟乌笋把余火从旧炉过到小砖箱',8,9,[s('乌笋','现在我能在她走后把三家晚汤煮开。她要抱孙女回来，请从大门进，不必去后厨赔笑。')],'stove-ember',['hearth-try-land']),
  setting('lip-foot','玛拉用两块木墩把烫锅车固定在低炉边',15,10,[s('玛拉','靠水那只轮先垫，炉能向前，人也能倒着走。她自己得摸到横把才叫试。')],['stove-ember'],{'stove-jacked':true}),
  witness('lip-light','陶鹊用半手掌把第一罐汤拨到岸工跟前',24,9,[s('陶鹊','行，手腕不痛，锅也不用擎过眉毛。我在北边石炉住一个冬季，苑芜掌睡屋的钥匙。我还能回去吃晚点的。')],'kitchen-shore',['stove-jacked'],{action:{type:'flag',id:'kitchen-shore',set:'hearth-moved'}}),
  fixture('lip-two-eyes','把艇缆牵过两只摸起来不同的缆眼',8,12,[s('苑芜','一个有屋梁的焦油，一个全是艇边的盐。家灶不能被我娘的一条摆船拉着北走。')],'stove-eyes',['hearth-try-wake']),
  mechanism('lip-releasable','在艇眼和屋梁之间抛一条能抽回的系法',18,10,[s('陶鹊','我的水手才半人高，别让她拔死结。')],['stove-eyes'],'stove-released','屋梁和小艇各有索眼，怎么让睡屋留在原处、摆艇能出海又靠得回来？',['主绳承在艇眼，另用能抽出的短套临搭屋梁','把屋梁和艇艏并成死扣一同受力','拆下两个索眼再把绳交给孩子'],0,'有盐的眼跟船，油眼跟屋。承住摆船的部分应当一直随摆船走。',[s('苑芜','我把家灶头一天的汤烧咸了。你笑吧，不用替我重烧。')]),
  witness('lip-board','扶陶鹊从新船下自己的第一勺汤',24,11,[s('陶鹊','上船是因为我喜欢那点风。厨房留给我闺女，我每三潮回来尝一口她的咸汤。别叫我接着替她舀。')],'kitchen-crew',['stove-released'],{action:{type:'flag',id:'kitchen-crew',set:'hearth-moved'}}),
  object('lip-cork','收下摆艇给下一名绳手的双瓣软木缆腕',20,12,[s('荚儿','外婆说这只护腕浸潮也能浮。得穿上手再用，不然就是口袋里一块木头。')],{requires:['kitchen-crew','!cork-given'],action:{type:'item',id:'cork-wrist',value:1,set:'cork-given'}})],
 [exit(3,10,'pot-round',[25,10],'循送火的双槽回原灶')]);
export const kettleGear={'cork-wrist':{name:'双瓣软木缆腕',slot:'charm',resists:{tide:.24,shock:.08}}};
