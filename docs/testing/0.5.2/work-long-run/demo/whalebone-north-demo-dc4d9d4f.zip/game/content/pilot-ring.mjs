import {region,fixture,witness} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {setting} from './registry-parts.mjs';
import {tidePost} from './district.mjs';

export const ring=region('pilot-ring','北航 · 上游双缆试船圈',4,'north-sound',28,18,'wood',
 [['water',0,0,28,3,'总往东偏的表水'],['crate',3,4,5,3,'绑浪木的短索'],['building',14,4,7,3,'朝着白肋的前后准门'],['water',16,13,12,5,'可回艇的短弯']],
 [['pier',2,8,23,2,'从艇艉望白肋的丁字桥'],['rope',7,10,13,1,'只放一侧的回转试缆']],
 [witness('pilot-injury','葵湾代舵·蔚铃',8,8,[s('蔚铃','三年前红冰挪了一船宽。照图走的人去走红冰右舷，干藻全翻到水里。画图的会赔藻吗？'),s('米拉','这条图署旧线连谁实测的都没留。我想先在边上画条虚线。'),s('蔚铃','我的船不是你的橡皮。空船试这两口门，看岸肋相叠还是分开；看过一口记一口，走错我给你留退缆。')],'pilot-brief',['near-shallow','hard-eight']),
 fixture('lock-transit','在上下两洞重合处留不可擦的船位刻痕',16,8,[s('伊沃','上洞看岩肋，下洞看黑桩，不看漂冰。现在二者齐。船从这里偏了多少，可以倒过来量。'),s('蔚铃','记住这道斜刻，立在艉楼的人才能用。一开船幕布就会遮住它。')],'relay-fix',['pilot-brief']),
 setting('helm-port','把试艇拖头缆移到左柱',11,9,[s('蔚铃','左缆领船进内弯。低水才能摸水下铁桩；涨上去，里面是回头流。')],['relay-fix'],{'helm-inner':true,'helm-outer':false}),
 setting('helm-starboard','把试艇拖头缆移到右柱',18,9,[s('蔚铃','外石的白鸟是涨水才贴面的浪尖。右缆吃力时别跟鸟影走，看准根上的刻道。')],['relay-fix'],{'helm-inner':false,'helm-outer':true}),
 tidePost('pilot-gauge',13,10),person('boat-table','船上三块刻板',21,10,[s('船板','低／左：内桩处现固定黑顶，六结下硬底。高／右：外井处岩线相合，九结见暗沙。其余反冲，把船头送往回弯。'),s('伊沃','不管选哪条，都由另一个地点的人回看我们留的刻痕。风转了还可以撤回。')])],
 [exit(2,8,'deep-sluice',[6,11],'退试船还旧桩，保留上次船位'),
 exit(24,7,'inner-stake',[3,8],'左缆擦低水内桩',['relay-fix','helm-inner','tide:low']),exit(25,9,'outer-spar',[3,8],'右缆顺涨水贴外井',['relay-fix','helm-outer','tide:high']),
 exit(22,12,'back-eddy',[3,7],'高水误压内弯，顺反冲撤退',['relay-fix','helm-inner','tide:high']),exit(12,14,'back-eddy',[11,7],'低水误贴外井，循返缆撤退',['relay-fix','helm-outer','tide:low'])]);
export const inner=region('inner-stake','北航 · 降潮才可摸到的内桩',4,'north-sound',20,14,'stone',
 [['water',0,0,20,3,'堤内纹浪'],['wall',5,3,4,4,'藏有歪孔的旧桩座'],['water',13,10,7,4,'退艇窄槽']],
 [['rope',4,8,12,1,'靠左才摸得到的旧船缆'],['lamp',11,6,1,1,'从船台来的细光']],
 [fixture('inner-observe','在内桩量缆重与返照',9,8,[s('瑟琳','第六结开始硬，提半掌再落，仍硬。这条给窄身浅吃水船，在低水开放。'),s('米拉','从这里返看，上洞还压着斜刻。若跟红冰走，看见的会是较亮的新刀痕。')],'relay-inner-read',['helm-inner','tide:low']),
 witness('inner-answer','请会落眼的艇师复核低水告示',13,8,[s('艇师','我看的是斜刻。给我一面带一个孔的旗，低水放小艇。若以后要载冬粮，另有主槽八结；别往我的水里挤。'),s('伊沃','听懂了。我把“六结”排在吃水限制旁边，不把这个旗挂到大船上。')],'relay-inside',['relay-inner-read'],{action:{type:'flag',id:'relay-inside',set:'relay-certified'}})],
 [exit(2,8,'pilot-ring',[23,7],'拉左缆返回试船圈'),exit(16,8,'back-eddy',[6,8],'主动撤回，保留内桩测记')]);
export const outer=region('outer-spar','北航 · 涨潮过浪的外井',4,'north-ice',20,14,'stone',
 [['water',0,0,20,3,'外海绿浪'],['wall',11,3,3,4,'朝向船台的石孔'],['water',15,10,5,4,'暗沙汊']],
 [['rope',2,8,14,1,'看鸟时会忽略的回光索'],['lamp',12,8,1,1,'跑过石孔的反灯']],
 [fixture('outer-observe','对岩孔放九结水铅，转身读岸边双标',8,8,[s('瑟琳','第九结是暗沙，提起还有一点细砂。入夜只给吃水许可的大船单向过，不能说全天有九结。'),s('米拉','从外井朝回看，岩孔挡住新的刀痕，旧斜痕仍亮。冰片慢慢从二者中间滑过，它没有当过岸。')],'relay-outer-read',['helm-outer','tide:high']),
 witness('outer-answer','请葵湾船工回读涨潮外井旗',13,9,[s('葵湾船工','两孔旗挂船头，我就押粮船等到满潮。等这一潮我少发一网鱼，后面的大船却有路。'),s('米拉','把押船人的姓留背面。下次涌浪没人肯押，他们就知道这格该空着。')],'relay-outside',['relay-outer-read'],{action:{type:'flag',id:'relay-outside',set:'relay-certified'}})],
 [exit(2,8,'pilot-ring',[24,9],'拉右缆回试船圈'),exit(16,8,'back-eddy',[8,8],'主动撤回，保留外井测记')]);
export const eddy=region('back-eddy','北航 · 留着退缆的反流兜',4,'north-sound',16,13,'wood',
 [['water',0,0,16,3,'弯外搁舟白泡'],['crate',4,3,4,3,'供回身的矮滚筒'],['water',11,9,5,4,'回汊']],
 [['pier',1,7,13,2,'两反向入水点共用的救生浮排']],
 [fixture('reverse-line','沿斜刻把艇转回两根导索之间',8,7,[s('伊沃','手指还摸得到上一道刻痕。把船头回到两缆中间，就能重新选柱；不用把硬底的旧铅刮掉。'),s('蔚铃','看清了没有？选了对的柱，潮错了也会到这儿。两者都对，才会到能返照的地方。')],'eddy-return',['relay-fix'])],
 [exit(2,7,'pilot-ring',[21,12],'回试艇圈重新比潮窗'),exit(5,9,'inner-stake',[15,8],'沿已量的内桩绳回短艇',['relay-inner-read']),exit(10,8,'outer-spar',[15,8],'沿已量的外井索回看石孔',['relay-outer-read'])]);
