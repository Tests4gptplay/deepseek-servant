import {region,witness,fixture,spoken} from '../voyage-parts.mjs';
import {person,exit,say as q} from '../parts.mjs';
import {house,loft} from './the-house-that-plays-after-supper.mjs';
const split=['twohand-heron-balanced','twohand-seal-balanced','twohand-met-owner','!twohand-show-done'];
const scrim=region('twohand-under-the-scrim','亮灯空城 · 影子照不到的长板凳',2,'whale-city',24,17,'wood',
 [['wall',0,0,9,4,'从背后看全是针脚的布墙'],['building',15,0,9,5,'最后一排身后堆着放下的凳子'],['water',0,13,7,4,'沉进清水的旧台唇'],['wall',15,13,9,4,'票边曾按过无数拇指']],
 [['path',2,7,19,3,'推小车的人也过得去'],['stage-screen',6,4,9,3,'小孩伸手就举得起的幕角'],['stage-bench',8,10,9,2,'有人坐着有人靠着的矮凳'],['stage-stop',17,6,3,2,'接近幕口的一只小环']],
 [witness('twohand-front-seat','问坐在头排的人愿意管什么、不愿意管什么',7,8,[q('阿簇','前排这位叫暖嵬。她来这儿是看戏。别在她手里塞一份夜班，好像看了你们的影子就活该守一晚。'),q('暖嵬','我带了凉水。幕布挤住我膝头，我愿意叫停；要我报哪根线断了我可不会。开演前问清楚，旁人就用不着站在我身后替我喊。')],'twohand-met-owner',['twohand-any-rehearsal']),
  person('twohand-quiet-row','将斗篷叠起来让别人挤她一条长凳的井珏',13,10,[q('井珏','我小时候总往后排躲，以为台上的鹤会把我当场吞了。今天我要坐前面。你看，边上有人还是得进进出出，那就别把凳子钉在地上。')]),
  witness('twohand-audience','将停拍的短套交到暖嵬能碰到的幕角',16,8,[q('玛拉','短套在你右手，没人能替你捏。我们收得到以后，什么都别做也行。'),q('暖嵬','那开演。等海豹钻进去，我要喝我的水。'),q('伊沃','短套真动了一下。我把两股都松开，没拿台词把它盖过去。'),q('越涟','我看见的是停了一会儿，好让前排喝完水。把那一下留在剧本里。')],'twohand-show-done',split,{action:{type:'flag',id:'twohand-show-done',set:'twohand-public-loop'}}),
  witness('twohand-back-to-back','请两名操手约好，让暖嵬坐在她选的位置看完全场',18,10,[q('暖嵬','我把水递给你。我今天不想管绳，可我想看那只鹤起来时腿是怎么弯的。'),q('伊沃','我站幕外能看见你俩。你不举手便照常，抬起锅盖我才停。'),q('越涟','要两个人都答应才算换班。这回别给漏掉的人添一句台词。'),q('阿簇','演完了。我拿歪了那条腿，她笑出来了。明天我还这么拿。')],'twohand-show-done',split,{action:{type:'flag',id:'twohand-show-done',set:'twohand-paired-watch'}}),
  fixture('twohand-before-night','把实演过的这一场写入停台簿，留下当班人的约定',19,8,[q('伊沃','我写的是亲眼见过的那个人怎么说停。下次她不来，这一行仍只管她那天，不管坐过同一条凳子的别人。')],'twohand-early-play',['twohand-show-done','!harbor-tilted']),
  fixture('twohand-after-night','把今天演过的散场写进新页，让旧夜的页边留白',19,9,[q('越涟','冬夜又不是只过了一回，今天也值一张新纸。那晚用过什么，愿意说的回来再说。')],'twohand-later-play',['twohand-show-done','harbor-tilted','!twohand-early-play'])],
 [exit(2,8,'twohand-supper-house',[14,14],'抬开幕底回豆羹铺'),exit(21,8,'twohand-puppet-loft',[27,11],'从看台的背光门回吊板')]);
export function withPuppetStage(world){
 const maps={...world.maps};
 for(const m of [house,loft,scrim])maps[m.id]=m;
 const add=(id,entities,exits=[])=>{const m=maps[id];maps[id]={...m,entities:[...m.entities,...entities],exits:[...m.exits,...exits]};};
 add('dry-court',[],[exit(12,7,house.id,[3,10],'从晒衣人挂出的布鹤影子进饭铺',['ivo-line'])]);
 add('safe-keel',[
  witness('twohand-keel-loop','靠着引航驳，等前排那只短套真的动一下',12,10,[q('暖嵬','我来守这只环。不是因为那天看了戏，是我半夜走过码头，知道这道门往哪边开。'),q('玛拉','绳实实在在动了。最后一张矮凳拆下去垫过低坎，下一艘船得自己再喊停。')],'twohand-night-choice',['base-safe','twohand-early-play','twohand-public-loop','!grave-signed']),
  witness('twohand-keel-pair','在两名守幕人之间站过一班，等双方看清才收绳',17,11,[q('曲度','我在坡顶举盖。越师傅在坡后，她手指张不开，便把锅底翻了个面。'),q('伊沃','两个不同的地方，两个真正见到了水的人。最后一班别省掉那个站得远的。')],'twohand-night-choice',['base-safe','twohand-early-play','twohand-paired-watch','!grave-signed'])]);
 add('burial-cape',[person('twohand-rag-after','在远离墓边的空台上收下一只补过两次的泥鹤',9,10,[q('阿簇','越师傅让问你想怎么看。'),q('玛拉','只要它能屈一次膝，再把脚放回原处。不要它替我道别。'),q('阿簇','行，我手上还留着那一根。')],{requires:['grave-signed','twohand-night-choice']})]);
 const quest={id:'twohand-supper',name:'幕后一人松手的时候',kind:'side',startFlag:'twohand-invited',endFlag:'twohand-show-done',stages:['twohand-invited','twohand-any-rehearsal','twohand-heron-balanced','twohand-seal-balanced','twohand-met-owner','twohand-show-done']};
 return {...world,maps,quests:{...world.quests,[quest.id]:quest}};
}
