import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit,flag} from './parts.mjs';
import {setting} from './registry-parts.mjs';
export const slope=region('under-berth','冬线深层 · 潮井尽头的旧验舱',6,'north-interior',24,16,'stone',
 [['wall',0,0,24,3,'雪后才露出的旧井顶'],['crate',3,4,6,3,'一半长出了盐花的冬检柜'],['water',16,3,8,5,'回撤的疗护水潭'],['crate',14,12,10,4,'两种隔潮带']],
 [['pier',2,8,20,2,'会将人送回引航驳的浮道'],['rope',7,10,11,1,'检修队的低索']],
 [witness('deep-caretaker','把水井锁在冬季的孚明',8,8,[s('孚明','外海深冬，每次回潮两股力。锚机退下来以后这个泵要自己过冬。有人得下去校它，但没人要为今天的粮去冒险。'),s('玛拉','井边铁带上全是高低不一的凹痕。'),s('孚明','一段留给用架势的人，另一段留给量潮的人。先试两种风针，再决定进去用手艺、用调节台或暂时回来。')],'deep-invited',['grave-signed']),
 person('deep-tool','从检修箱选一份能带入井的行装',13,8,[s('孚明','冬检工来一班借一份。潮透旧帆能挡第一阵穿舷水，压口夹能帮寻楔的人拆开抱死的硬壳。'),s('米拉','这井有退路，行装也能换。是谁的活，就留哪双手。',[
 {text:'领低温打浪的旧帆套',set:'deep-wrap-route'},{text:'领拆蓄水机壳的压口夹',set:'deep-clip-route'}])],{requires:['deep-invited'],action:flag('deep-kit'),after:[s('孚明','借得不顺手，就在旁边的公架换一份。野外手艺和装备也可自己调整。')]}),
 object('deep-wrap','在借还架登记旧帆套',18,9,[s('孚明','装到随身饰品，能抵一部分寒潮与震击；外缘的风还得自己看。')],{requires:['deep-kit'],action:{type:'item',id:'deep-wrap',value:1}}),
 object('deep-clip','在借还架登记压口夹',11,10,[s('孚明','装到武器栏，破壳后顺势撬一下。别让一副好夹子替你决定要不要抢攻。')],{requires:['deep-kit'],action:{type:'item',id:'deep-clip',value:1}})],
 [exit(2,8,'safe-keel',[11,12],'回引航驳整备'),exit(21,8,'ebb-engine',[3,8],'带检修行装下回潮试井',['deep-kit'])]);
export const cistern=region('ebb-engine','冬线深层 · 两股反潮的旧冷井',6,'north-interior',27,17,'stone',
 [['water',0,0,27,4,'冷脊绕回的透明井盖'],['wall',2,5,5,3,'低冷河窗'],['crate',12,4,5,3,'挂着铜偏针的冰台'],['water',19,12,8,5,'高水资格检验槽']],
 [['pier',2,9,21,2,'调压浮桥'],['rope',10,8,13,1,'沿内圈分开的两股反潮']],
 [setting('deep-wind-short','将细羽针压到内圈避风点',8,9,[s('伊沃','细羽贴内圈不肯翻。外边那层冰还在松，硬推闸轮会将全部压力压在抱箍上。')],['deep-kit'],{'inside-gauge':true,'outer-gauge':false}),
 setting('deep-wind-wide','把粗针移到看得见裂缝的外圈',16,8,[s('米拉','不是一阵力。内圈先静，外圈会抬两次，降回第三线时压力才小。')],['deep-kit'],{'inside-gauge':false,'outer-gauge':true}),
 fixture('deep-first','在内圈标定一处不返冲的回滩',11,10,[s('瑟琳','我把不动的地方留了一笔。换针后第一笔不擦，若两边都随风转，谁也找不到回处。')],'deep-inner',['inside-gauge']),
 fixture('deep-shunt','以两次实测为据走软旁通',18,9,[s('玛拉','外针抬第二下，内滩还稳。这段用旁通不必同硬壳顶。孚明帮我听着铃，我们放缓一拍。')],'deep-bypass',['outer-gauge','deep-inner'],{action:{type:'flag',id:'deep-bypass',set:'deep-checked'}}),
 object('deep-live','在动压下检校冻住的回水主机',15,10,[s('孚明','冰浮先向里卷，之后甩回。你能用隔潮术扛、用反标拆、或停手换软旁通。走哪条也不影响你安葬过的人。')],{requires:['deep-kit','!deep-checked'],action:{type:'battle',id:'double-ebb',set:'deep-checked'}}),
 witness('deep-pay','亲自交回两处铅数与偏移刻度',20,10,[s('孚明','旧泵能自己过冬了。哪天我不上船，这处井的工具仍借给来的人；学徒得在名册上留两处读数，不能只写自己赢过。')],'deep-receipt',['deep-checked'])],
 [exit(2,8,'under-berth',[20,8],'放压后回验舱')]);
export const eelPump={id:'double-ebb',name:'裂冰回水机',enemy:'冻死的回水套',level:13,hp:125,attack:7,resistances:{iron:.78,wind:1.17,tide:1.27,light:1.12},
 objective:'硬壳吸水、外缘甩浪、露出热脊三段。学过的潮术或标线、装备与守位能配合，仍可撤。',
 phases:[{fromHp:125,tell:'内外两层白霜同时下压，先守针座。',moves:[{name:'冻箍夹紧',kind:'shell',element:'cold',counter:'skill',power:1.05},{name:'一折涌入',kind:'ram',element:'tide',counter:'guard',power:1.2}]},{fromHp:76,tell:'末圈偏针颤两下，外浪先走。',moves:[{name:'横甩薄霜',kind:'whirl',element:'cold',counter:'dodge',power:1.35},{name:'回顶暗桩',kind:'ram',element:'shock',counter:'guard',power:1.15}]},{fromHp:31,tell:'蓝水退下露出红脊，热缝再关前可进一拍。',moves:[{name:'短压回脊',kind:'shell',element:'iron',counter:'skill',power:1.1},{name:'松箍反卷',kind:'rush',element:'wind',counter:'dodge',power:1.25}]}],
 rewards:{xp:41,repeatXp:0,label:'回水机吐出最后一线雾，往返两处检修窗都能打开了。'}};
export const winterGear={'deep-wrap':{name:'深冬隔潮旧帆',slot:'charm',resists:{cold:.32,shock:.20}},'deep-clip':{name:'验舱压口夹',slot:'weapon',power:3,break:7}};
