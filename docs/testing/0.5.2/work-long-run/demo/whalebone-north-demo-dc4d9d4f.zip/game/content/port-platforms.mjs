import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit} from './parts.mjs';
export const gantry=region('counter-gantry','白崖 · 砣架上层',1,'roofs',18,14,'wood',
 [['water',0,0,18,3,'能看到鲸尾的天井'],['crate',8,3,5,3,'悬装铅篮'],['wall',12,10,6,4,'库檐']],
 [['pier',2,7,13,2,'转角栈架'],['rope',6,5,2,1,'双卡舌'],['lamp',14,6,1,1,'上层标灯']],
 [fixture('gantry-pawl','站在外层挂回红卡舌',8,7,[s('盖遥','下面的人碰不着这根。卡舌往里挂，别往下推。你在上面我在下面才做得成。'),s('玛拉','舌回来以后，低槽的木担才不会被架子压住。')],'pawl-stayed',['outer-bank'])],
 [exit(2,7,'weight-well',[21,10],'下外架返双轮'),exit(15,8,'port-desk',[3,8],'上架送交两端配重回条',['port-counter-way'])]);
export const drain=region('pallet-drain','白崖 · 砣井底与巡水沟',1,'harbor-interior',23,15,'wood',
 [['wall',0,0,23,2,'载重横梁'],['water',4,4,6,3,'小人可涉的侧沟'],['crate',15,2,6,5,'压舱铁'],['water',14,11,9,4,'灌筐口']],
 [['pier',2,8,18,2,'低槽平板'],['rope',9,9,3,1,'井工的应答绳']],
 [fixture('low-pin','在井底把叉插进空出的内槽',11,8,[s('盖遥','上面红舌挂好，这里我敢把手放进去了。握住旧叉，我先拉一遍载重车。'),s('伊沃','车通过了。原来我们老说“放手”时，两层人的手还没见过面。')],'port-counter-way',['pawl-stayed','inner-bank','counter-tag'],{action:{type:'flag',id:'port-counter-way',set:'shift-handed'}}),
 person('mud-diver','巡沟人·小拨',6,8,[s('小拨','你要进井底学，先往地上扔石子听一声。汤汤响是木空了，实响才放大脚。')])],
 [exit(2,7,'weight-well',[14,15],'从内板回绞轮'),exit(20,9,'port-desk',[3,8],'抬着已试载的明细到交付桌',['port-counter-way'])]);
export const wet=region('wet-arcade','白崖 · 雨棚鞋底街',1,'harbor',28,19,'stone',
 [['building',1,1,5,5,'制雨帽坊'],['building',10,1,6,5,'伞肋铺'],['building',22,1,5,5,'走舷窗的借凳馆'],['water',0,13,10,6,'在低檐积起的雨池'],['crate',18,13,6,4,'码布架']],
 [['rope',7,7,15,1,'全街的雨帘'],['pier',10,9,13,2,'足音标记的小廊'],['lamp',7,10,1,1,'黄油纸灯']],
 [witness('rain-hatter','修油帽的成箩',8,8,[s('成箩','我不想扯掉整街棚子让你们送一张单。把绳端挪一个窗孔，水从第一间槽流到第二间；人可上去，货留下面。'),s('伊沃','我能给你系在窄屋的绳眼。几孔留给晾衣？'),s('成箩','一孔。住在这里的还要把衣晾干。')],'rain-accord',['shift-called']),
 fixture('rain-cup','抬起檐下吃水过重的竹斗',16,9,[s('玛拉','人托住斗，贝绳才松。先穿低窗的空眼，过去收在上檐。')],'rain-free',['rain-accord']),
 person('boot-vendor','雨帽坊隔壁卖鞋的袁声',12,11,[s('袁声','有人把鞋袜整双留下问路。下雨只干一只，另一只我替他抱了一天，落了墨点也舍不得刷。')])],
 [exit(2,8,'shift-square',[9,17],'回三班石场'),exit(24,8,'awning-rafters',[3,7],'托起雨斗穿第一扇窗',['rain-free']),exit(12,14,'rain-step',[3,7],'试走雨后下方假岔路')]);
export const rainStep=region('rain-step','白崖 · 雨帘后的空阶',1,'harbor',15,12,'stone',
 [['water',5,0,10,4,'被水封住的高档'],['wall',0,0,4,4,'后檐挡板'],['crate',10,8,5,4,'睡着小狗的鞋箱']],
 [['path',2,6,9,2,'回声误导的空台'],['rope',7,5,1,4,'跨回原路的扶手']],
 [fixture('false-spout','在低处听见另一头接水',7,7,[s('玛拉','看起来对着街门，前面雨水却落在空桶里，底板根本没搭。回上层，从两户之间的遮板绕。')],'rain-mistake')],
 [exit(2,7,'wet-arcade',[12,13],'扶着原扶手回到鞋底街')]);
export const rafters=region('awning-rafters','白崖 · 连户檐层',1,'north-roof',27,15,'wood',
 [['wall',2,1,7,4,'帽坊上部'],['wall',13,0,6,5,'伞肋屋脊'],['water',6,10,8,5,'两楼之间的垂井'],['building',20,9,7,6,'晾布住家']],
 [['rope',7,6,15,1,'能穿三户的顶绳'],['pier',3,7,18,2,'排水斜檐'],['lamp',18,5,1,1,'第二房窗灯']],
 [fixture('awning-loweye','从窗里把绳回穿低眼',9,7,[s('成箩','干活时别用牙。我递你锥针；你的绳头上加个布套，别人回家拔不伤手。')],'eye-low',['rain-free']),
 fixture('awning-higheye','从对面檐钩收紧顶眼',18,7,[s('伊沃','低眼承水，高眼让路。我把第三个眼空着，留衣晒在这里。'),s('成箩','交我看看……好，檐路打开半人宽。我带你从另一端下。')],'port-roof-way',['eye-low'],{action:{type:'flag',id:'port-roof-way',set:'shift-handed'}}),
 person('roof-owner','给幼女量衣的止妍',13,8,[s('止妍','港里说要“清出”檐边。可这一角的灰是孩子长高时蹭的。我点头，是因为你给我留了一孔。')])],
 [exit(2,7,'wet-arcade',[23,8],'从第一户落回鞋街'),exit(23,7,'port-desk',[14,6],'沿已通高绳落交付台',['port-roof-way'])]);