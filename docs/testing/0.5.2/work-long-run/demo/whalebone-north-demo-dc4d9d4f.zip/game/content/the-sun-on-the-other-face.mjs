import {region,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit} from './parts.mjs';
export const platform=(id,name,act,w,h,ground,blocks,features,entities,edges)=>region(id,name,act,'wind-quay',w,h,ground,blocks,features,entities,edges);
export function invitation(id,who,x,y,lines,req,after){
 return person('windloom-'+id+'-meet',who,x,y,lines,{requires:req,action:{type:'flag',id:'windloom-'+id+'-open',set:{['windloom-'+id+'-kept']:false,['windloom-'+id+'-scar']:false}},after});
}
export function collision(id,foe,name,x,y,lines,extra=[]){
 return object('windloom-'+id+'-fight',name,x,y,lines,{requires:['windloom-'+id+'-open','!windloom-'+id+'-done',...extra],action:{type:'battle',id:foe,set:'windloom-'+id+'-done'},
  after:[s('玛拉','把握到的风变过三面了。去看看同我们一起站过的人，问问他的手，也看看他还留着什么。')]});
}
export const windGear={
 'windloom-eyelet':{name:'缝帆人的斜眼铜顶针',slot:'charm',resists:{wind:.34,light:.12}},
 'windloom-felt':{name:'破幅折成的双层包边',slot:'charm',resists:{shock:.32,impact:.20}}
};
export const north=platform('windloom-drying-bluff','北航线 · 翻晒候风布的红脊坪',4,34,22,'stone',
 [['wall',0,0,8,6,'朝背风处弯的层板岩'],['building',11,0,7,5,'半敞的补帆间'],['wall',23,0,11,6,'起风时会投双影的石楞'],['water',0,16,10,6,'风线外的旧海蚀槽'],['building',14,17,7,5,'晒鱼油和洗刷子的油棚'],['wall',27,16,7,6,'海鸟磨圆的褐红石']],
 [['path',1,9,30,3,'过补帆坪的工人脚道'],['wl-frame',15,6,7,3,'斜着兜起上升风的红白分幅'],['wl-shadow',6,12,5,2,'先在地面翻过来的两重布影'],['wl-gear',23,10,4,2,'迎风挑杆、踏板和接网的三处座']],
 [invitation('north','从红布反面缝起的师傅霁葵',8,10,[
 s('霁葵','不许把剪子递给我。那只海鹫不是来吃人，给它让风它自己会飞。我徒弟拿着头一匹能署自己名字的布。我知道大家会先剪谁的。'),
 s('符荻','师傅，你先看我的袖口。我没抓着绳，是绳正拖着我。'),s('伊沃','我也有过站在能关窗的地方，却看不见窗底是谁的日子。你指我能站的地方。'),
 s('霁葵','木轴给压重的，网底接绳，潮手摸布哪一面还湿，图手去风口读第二重影。哪边有余手，哪边去接人。不要叫我和布里的人都等你们打完。')],['party:mira','!winter-welcome'],
 [s('符荻','海鹫还在坪边，要上就现在上；若要赶路，红标屋的正路一直都能走。')]),
 collision('north','windloom-kite','跨入海鹫和红帆之间的三座',18,10,[s('符荻','第一个人伸手摸风时，另外三个别都跟到她背后。沾鱼油的那一面才是反面，海鹫只认那层味道。')]),
 person('windloom-north-pupil','将手从袖子里伸出来的符荻',11,12,[
 spoken('符荻','你在我往石坎上滑的时候腾过一只手。红布还在，我能把名字缝在上面。师傅以为我想要的是不许人剪，我想要的是由我开口。','windloom-north-kept'),
 spoken('符荻','我的手在这儿。布缝自己裂开前，我用牙扯了一寸。那道毛边不用补，我想让人看见我那一刻怎么出来的。','windloom-north-scar'),
 s('霁葵','我收回那句不准动布。是我先把我的行当说成了你的规矩。冬岸的宽布起霜时，你站在正面好了，我去底下接。')],{requires:['windloom-north-done']}),
 object('windloom-north-thimble','接过符荻第一匹整幅上同批打的铜顶针',13,10,[s('符荻','它的眼斜一点，迎着风戴，手指不必和针一个方向。试着在整备里扣上，怕风时它比我说话好使。')],{requires:['windloom-north-kept'],action:{type:'item',id:'windloom-eyelet',value:1},after:[s('符荻','我自己的第一枚留衣襟里了。')]}),
 object('windloom-north-binding','霁葵用救过人的裂布给你卷一道包边',22,12,[s('霁葵','这是破的那寸。折两回能卸震，抹平它反而没用了。肯戴就留在腕上。')],{requires:['windloom-north-scar'],action:{type:'item',id:'windloom-felt',value:1},after:[s('霁葵','只有那一寸，再给你做的就不是这一道了。')]}),
 person('windloom-pitch-kid','给每块试布闻油味的采藤人井虫',5,12,[s('井虫','这块是小鱼油，那块是胡桃油。鸟能闻到正反面，大人老是非要我把字念出来。')])],
 [exit(2,10,'red-beacon',[9,6],'翻过红脊回仍点着的航标')]);
