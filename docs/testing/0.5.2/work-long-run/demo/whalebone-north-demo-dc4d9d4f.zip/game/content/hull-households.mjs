import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit} from './parts.mjs';
export const eight=region('eight-landing','鲸城 · 八户横铺的双街',2,'whale-city',36,24,'wood',
 [['building',1,1,5,6,'一门：缝镜袖的银家'],['building',9,1,5,6,'二门：管掌绳的刘家'],['building',18,1,5,6,'三门：煮薄荷汤的潜家'],['building',27,1,8,6,'四门：新添婴儿的井家'],['building',1,16,6,7,'五门：拉床架的回家'],['building',10,16,6,7,'六门：修篷的徐家'],['building',19,16,6,7,'七门：失船的棉家'],['building',28,16,7,7,'八门：借住两冬的苔家']],
 [['path',0,10,36,3,'人与小车能错身的中央街'],['rope',5,8,23,1,'八户谁都能拉的湿衣绳'],['lamp',17,13,1,1,'灶房点名灯']],
 [witness('beds-keeper','挨家敲门搬床的回玟',8,11,[s('回玟','港里的人说八铺挪到底仓。一家上面还要睡，另一家得有人照看呼吸。八铺不是一张铺，用一张门闩垫过的也不止一个床脚。'),s('玛拉','我先去问该挪哪一张。不替你们把整条街都说成躲灾。')],'beds-list'),
 person('eighth-tenant','靠鲸皮做脉枕的苔雨',28,12,[s('苔雨','别人说你是第八户，我以为要把锅都收起来。我们替鲸城补了两个冬天的皮，还不能把窗板叫自己家的吗？'),spoken('苔雨','量担架的绳和我们的绳一样旧。你们的冬院要是照约季季问，屋就能住出感情。','winter-proof')]),
 person('knitter-silver','破指套只给小孩用的银篁',12,10,[s('银篁','我做的袖套留半圈，断腕的人也能穿。有人把它说成谁撒手逃走，真是看衣比看人多。'),spoken('银篁','我的针尖用的是两个盐滩人换的，一边缝紧一边稀。你在夹墙见过。','salt-survivors')]),
 person('supper-runner','端空锅来的租驳媳妇',23,13,[s('咸微','夜饭舟能走时，我的贵重货是一只空桶。看看第三门的灶有没有洗干净，回程可以带温饭。')],{requires:['night-ferry'],lockedText:'这里留着一个挂锅位。等陆婆的夜饭舟开线，才有人从盐驳来借。',action:{type:'flag',id:'whale-pot-call'}})],
 [exit(1,11,'dry-court',[8,10],'上八户晒衣总院'),exit(8,7,'sleeve-room',[3,7],'进银家与刘家的通窗'),exit(24,8,'cradle-room',[3,8],'进两户照护的临水隔间'),exit(30,13,'loom-run',[3,8],'上六门和七门共用的夹层'),exit(15,15,'testimony-room',[3,7],'访船难遗属保存书札的屋')]);
export const sleeves=region('sleeve-room','鲸城 · 两户缝袖的通窗屋',2,'whale-interior',23,16,'wood',
 [['building',1,1,5,5,'银篁的半圈袖架'],['crate',10,2,5,4,'刘家留的铁绳坠'],['building',17,10,6,6,'为病手留下的矮台']],
 [['rope',6,7,12,1,'共用的双窗绳'],['lamp',12,10,1,1,'烫袖的旧铜片']],
 [fixture('sleeve-weight','在病手的空绳上绑半重布袋',10,8,[s('刘爹','旧床一边细一边重。全重压下，我这只手抽不出销。绑半包米试，看谁真的能把它提起来。'),s('伊沃','我来抬，你来放。能给我一条退绳吗？')],'bed-halfweight',['beds-list']),
 person('sleeves-boy','踩架子学穿线的刘粟',7,9,[s('刘粟','我不是不会穿，我是手不够长。新的吊圈给我低两掌，比发一张“人人都能上船”的纸管用。')]),
 fixture('coiling-peg','把半重试袋送过通窗',17,8,[s('玛拉','半坠试过，绳端的指扣能让病手自己松。把试袋交给井家验门。')],'peg-sent',['bed-halfweight'])],
 [exit(2,7,'eight-landing',[8,8],'回八户中街'),exit(20,8,'loom-run',[4,8],'循刘家上洞去夹层',['peg-sent'])]);
export const cradle=region('cradle-room','鲸城 · 温汤隔扇和产床',2,'whale-interior',23,16,'wood',
 [['building',1,1,5,5,'薄荷药汤灶'],['crate',10,2,4,5,'不可平躺的担床'],['building',17,10,6,6,'先让家属说话的隔扇']],
 [['lamp',9,7,1,1,'按水位养的弱火'],['rope',11,10,7,1,'扶人起身的矮杆']],
 [witness('which-cot','向隔扇内的井梨问床',8,8,[s('井梨','别搬左床。右床是我借用的，一点动静就会翘。要试你们的绳，用空架；产床不能在没问我时当砝码。'),s('玛拉','你能说停。即使井嫂愿意，你说停我也放回去。')],'bed-permission',['beds-list']),
 fixture('lining-bucket','用锅岸留下的浅匙喂第一口汤',13,8,[s('井梨','一锅汤不干净就浪费整张床。那边的船家今天吃了什么，能不能也写下？'),s('余绒','冷鱼。后天我亲自给她送回红米。')],'broth-received',['night-broth','bed-permission']),
 fixture('return-pot','从三门灶将装好的桶挂上夜驳',10,11,[s('潜叔','我连桶一起还。岸上欠病灶的半刻钟，我给他们守急班，看见船驳靠岸再关窗。')],'ferry-fed',['whale-pot-call','bed-permission'])],
 [exit(2,8,'eight-landing',[23,8],'回八户街'),exit(20,8,'water-steps',[3,7],'由药灶旁下临水走廊',['bed-permission'])]);