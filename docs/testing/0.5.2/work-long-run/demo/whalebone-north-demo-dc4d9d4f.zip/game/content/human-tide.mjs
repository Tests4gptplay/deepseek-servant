import {exit,object} from './parts.mjs';
import {spoken} from './voyage-parts.mjs';
import {stair,felt,sill} from './quiet-stair.mjs';
import {kettle,bed,porch,bench} from './quiet-room.mjs';
import {tower,eave} from './needle-corner.mjs';
import {mouth,blind,gullet,kin} from './crosswake-mouth.mjs';
import {brake,wrist,drain,heel} from './borrowed-current.mjs';
import {late,bunk,rail} from './late-moor.mjs';
import {hem,layby,home,loft} from './far-sleeves.mjs';

export const humanTideMaps=[stair,felt,sill,kettle,bed,porch,bench,tower,eave,mouth,blind,gullet,kin,brake,wrist,drain,heel,late,bunk,rail,hem,layby,home,loft];
const joins={
 'coffin-hoist':[exit(13,11,'moth-stairs',[4,12],'从棺车的蜜色卷篷去找认出父亲的烙饼人',['release'])],
 'moth-stairs':[exit(16,15,'seam-porch',[26,12],'随愿等下一拨的人再到双折廊',['keen-quiet-room']),exit(30,14,'bench-spit',[29,12],'跟禾泊沿已经收火的摊进看海座',['keen-open-bench'])],
 'west-lamp':[exit(12,10,'crosswake-mouth',[4,11],'绕西灯看不见的一侧回到两股旧求救船花交会的地方',['light-replay']),exit(14,10,'late-moor',[30,11],'从乔窗后到现在可以自行叫停的夜班船',['cross-work-shared'])],
 'salt-lane':[exit(18,11,'salt-sleeve',[4,11],'到擦盐围袖巷看亲属怎样让出一张可坐的凳')],
 'red-beacon':[exit(13,11,'twin-tails',[4,11],'在点亮远标以后，沿旧短渡的人实走北涌歇标口',['remote-lit','cross-work-shared'])],
 'wreck-slope':[exit(13,11,'twin-tails',[29,12],'沿已经从歇标口实走的北涌侧弯回去',['tail-ready','remote-lit'])],
 'burial-cape':[exit(11,11,'morrow-seat',[4,11],'沿街巷走回还在过日子的家，愿不愿来由自己决定',['grave-signed'])]
};
const gates={
 'embark':['keen-settled','棺车已在等。认出你父亲的禾泊还在蜜色卷篷旁，去蛾灯阶街，把白逡家愿意开的出门路做完。'],
 'ivo-admission':['cross-work-shared','乔的灯底册可以稍等。先由西灯的背水重走那道旧求救汊，与今天还在上班的人接回来。']
};
const marks={
 'loft-laundry':[
  {id:'loft-window-pillows',kind:'rope',x:9,y:8,w:3,h:1,label:'靠窗铺卷起的晾褥，青边朝里',sceneStates:[{until:'hem-loft-split',pose:'covered'},{from:'hem-loft-split',pose:'rolled-at-head'}]},
  {id:'loft-door-pillows',kind:'rope',x:17,y:10,w:2,h:1,label:'靠门铺的短晾褥，红边朝外'},
  {id:'loft-wick',kind:'lamp',x:14,y:9,w:1,h:1,label:'放在两个铺脚空处试风的灯芯'}],
 'deck-scour':[
  {id:'scow-cold-tin',kind:'crate',x:9,y:10,w:1,h:1,label:'踏舵阶上有缺口的冷饭筒',sceneStates:[{until:'hem-scow-working',pose:'lid-shut'},{from:'hem-scow-working',pose:'lid-beside'}]},
  {id:'scow-shift-stove',kind:'hearth',x:22,y:10,w:1,h:1,label:'靠近第二班洗布处的小暖灶'}],
 'coffin-hoist':[{id:'keen-amber-awning',kind:'rope',x:11,y:10,w:4,h:1,label:'蜜色篷尾朝家门，不朝吊棺架'}],
 'moth-stairs':[{id:'keen-folding-sun',kind:'lamp',x:32,y:13,w:1,h:1,label:'白天的圆晕，收市后只余弯钩',sceneStates:[{until:'keen-evening',pose:'awning-open'},{from:'keen-evening',pose:'shade-rolled'}]}],
 'mat-bed':[{id:'keen-empty-palm',kind:'pier',x:16,y:11,w:2,h:1,label:'掌下空着的一小弯，两端有托物'},{id:'keen-private-curtain',kind:'rope',x:22,y:10,w:1,h:2,label:'房主自己握着的帘绊'}],
 'bench-spit':[{id:'keen-last-pan',kind:'crate',x:20,y:13,w:2,h:1,label:'摊主自己停止加火的一炉',sceneStates:[{until:'keen-open-bench',pose:'pan-upright'},{from:'keen-open-bench',pose:'pan-resting'}]}],
 'crosswake-mouth':[{id:'cross-signal-pole',kind:'lamp',x:10,y:12,w:1,h:2,label:'灯罩悬在人的眼高之上，船上的人未必看得见'}],
 'cool-wrist':[{id:'cross-low-window',kind:'pier',x:20,y:12,w:2,h:1,label:'船客自己的低窗和能叫停的索端'}],
 'basket-drain':[{id:'cross-first-paper',kind:'pier',x:21,y:13,w:3,h:1,label:'短头能过、长头会卡的斜纸架',sceneStates:[{until:'cross-short-rack',pose:'broadside'},{from:'cross-short-rack',pose:'edge-first'}]}],
 'oar-bunk':[{id:'nap-aft-bed',kind:'pier',x:9,y:11,w:3,h:1,label:'靠水的低床'},{id:'nap-wall-bed',kind:'pier',x:18,y:11,w:3,h:1,label:'贴木肋、能由脚感到动静的另一张床'}]
};
const familiarPlaces={
 'loft-laundry':[
  object('loft-heel-light','蹲在两张铺的脚头，看两色褥边之间的灯芯',14,9,[
   spoken('聂溲','你瞧，青边是我的，红边是我小妹的。今晚要少哪一铺，你跟那一边说。','!hem-loft-split'),
   spoken('沙荷','褥子卷起塞到各自床头。我推布从中间走，灯舌一直朝窗外。','hem-loft-split'),
   spoken('聂溲','是少了两铺。我去我姐家借床，她蹬人。你们把钥匙留给我就成。','hem-loft-working')])],
 'deck-scour':[
  object('scow-cold-bite','坐到舵阶，摸饭筒上方已凉的铜耳',10,11,[
   spoken('槿石','底下那只碗团是午饭。想敲开它得用力，潮却不肯替我用力。','!hem-scow-working'),
   spoken('槿石','第二趟她拧，我空出两只手。饭还是凉的，我终于坐着吃到了碗底。','hem-scow-working'),
   spoken('沙荷','我把铜盖喷了口热气抹干。等明天，这又是他的饭筒。','hem-scow-working')])]
};
export function withHumanTide(map){
 const entities=map.entities.map(e=>{
   if(gates[e.id]){
     const [flag,lockedText]=gates[e.id];return {...e,requires:[...(e.requires||[]),flag],lockedText};
   }
   if(['sleeve-wait','sleeve-slide'].includes(e.id))return {...e,requires:[...e.requires,'!sleeve-place']};
   return e;
 });
 return {...map,entities:[...entities,...(familiarPlaces[map.id]||[])],exits:[...map.exits,...(joins[map.id]||[])],features:[...map.features,...(marks[map.id]||[])]};
}
const tracks=[
 ['hollow-of-a-hand','他习惯怎样托一只篓','main',['keen-called','keen-board','keen-wrap-tried','keen-corrected','keen-family-room','keen-evening','keen-meal','keen-hollow','keen-rest','keen-place','keen-settled']],
 ['moth-in-the-glass','穿自己袖子的双眼针','hidden',['keen-blue-hole','keen-blue-glint','keen-practice','keen-side-face','keen-blue-thread','keen-moth-seen']],
 ['true-second-wake','没等到的第二次船花','main',['cross-begun','cross-old-wave','cross-low-eye','cross-two-wakes','cross-side-sign','cross-chosen','cross-free','cross-work-shared']],
 ['whose-early-bell','有人想好好睡一觉','side',['nap-met','nap-water','nap-beam','nap-picked','nap-on-duty','nap-north']],
 ['salt-sleeve-seat','不挤进别人的卧室','side',['sleeve-help','sleeve-place','sleeve-done','sleeve-home']],
 ['after-the-last-wake','安葬过后各自开门','side',['grave-signed','cross-home']]
];
export const humanTideQuests=Object.fromEntries(tracks.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
