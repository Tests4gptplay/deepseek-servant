const move=(name,kind,counter,element,hint,power)=>({name,kind,counter,element,hint,power});
const phase=(fromHp,tell,...moves)=>({fromHp,tell,moves});
const twist=move('斜风压脊','ram','guard','wind','迎风口有横推，稳住踏板或换到护布内侧。',1.45);
const flick=move('贴角回扫','rush','dodge','wind','尾缝扬起之前离开它的直线，靠外缘让出风。',1.35);
const fold=move('双幅抱楔','shell','skill','impact','两幅夹紧时入轴调楔，普通连击会蹭着外层走。',1.0);
const churn=move('背面回卷','whirl','dodge','wind','回卷从每个人脚下过，侧移或用互护的岗位接应。',1.45);
const frost=move('霜膜闭齿','shell','skill','cold','白线沿两叶合拢，暖潮和找楔的职业能从里面松开。',1.12);
const loose=move('脱钩横架','rush','dodge','shock','单端翘起，避开横着扫过的脚位。',1.55);
export const windOpponents={
 'windloom-kite':{
  id:'windloom-kite',name:'北航日烘坪 · 钻入反面风的裂帆海鹫',enemy:'丝线勒进足羽的裂帆海鹫',hp:142,attack:11,level:13,windloom:{scene:'north',mid:95,end:42,neighbor:'被牵索拖近红布的学徒符荻'},
  objective:'让海鹫从布底找回风，护住实地同行的人。四种岗位都能用本职基本动作完成。',
  resistances:{iron:.86,wind:1.08,tide:1.16,light:1.23},reward:'海鹫飞离了风线。霁葵拿自己的午歇教四人认反面风。',rewards:{xp:52,repeatXp:0,items:{tonic:1}},
  phases:[phase(142,'海鹫贴布上方走直线，足下拖着细丝，风影在白面上发黑。',flick,twist),
  phase(95,'海鹫突然钻入布底，正面再看不到它。迎风边缩紧成一条硬褶。',fold,twist),
  phase(42,'足丝已经松了，双翅借回风上翻，地面只剩一圈转动的鸟影。',churn,flick)]},
 'windloom-rime':{
  id:'windloom-rime',name:'冬岸晒幅田 · 结冰的三叶抻绸架',enemy:'冻榫与回弹的三叶架',hp:174,attack:14,level:20,windloom:{scene:'winter',mid:109,end:48,neighbor:'在白布背面找不到出口的晒工袁叠'},
  objective:'把冻住的晒幅架降到人手能接的位置。看清三叶不是同时返身。',
  resistances:{iron:1.14,tide:1.22,light:.88,wind:.92},reward:'晒工把多的一份回暖盐膏放到干燥的踏脚边。',rewards:{xp:67,repeatXp:0,items:{'brine-dose':1}},
  phases:[phase(174,'霜在迎风叶先绷白，背面却还在滴水，第一下沿顺风脊滑走。',loose,twist),
  phase(109,'湿霜重心越过轮轴，两叶忽然合紧，将支架压向背风架。',frost,loose),
  phase(48,'下叶冻成弧，布角被风托起扫过脚下，外圈雪沫往内收。',churn,frost)]},
 'windloom-canopy':{
  id:'windloom-canopy',name:'锚断之夜 · 倒兜棚街的四面风翼',enemy:'受反向大风的整条晒帆廊',hp:226,attack:18,level:28,windloom:{scene:'harbor',mid:146,end:62,neighbor:'踏在向外翻的天窗边拉邻居的霁葵'},
  objective:'四人各掌一处，不让倒兜的遮棚把人拖向斜街。选择何时舍出自己的站位照顾旁人。',
  resistances:{iron:1.12,light:1.18,tide:1.04,wind:.78},reward:'棚子回到人能接住的高度。留下的布与当时肯伸手的人会各有去处。',rewards:{xp:84,repeatXp:0,items:{tonic:1}},
  phases:[phase(226,'港城倾斜，四面帆先从外角吃满。下风面压来一整片阴影。',twist,flick),
  phase(146,'风从天井底钻上来，向外拉的两翼突然夹向中轴，缝线变成背面。',fold,loose),
  phase(62,'重心跨过断角，两翼翻成反兜，白灰旋向每个人的靴面。',churn,twist)]}
};
