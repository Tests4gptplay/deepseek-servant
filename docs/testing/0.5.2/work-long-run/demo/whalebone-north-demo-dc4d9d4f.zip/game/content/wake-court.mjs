import {say as s,feature as f,exit,person,object,flag} from './parts.mjs';
export const court={
 id:'wake-court',name:'白崖港 · 摆灯院',act:1,width:29,height:20,ground:'stone',biome:'harbor',
 solids:[[1,1,5,5],[8,1,5,5],[15,0,6,5],[23,2,5,5],[2,14,7,4],[14,13,5,5],[24,13,4,4]],
 features:[f('building',1,1,5,5,'染坊'),f('building',8,1,5,5,'摆灯人家'),f('building',15,0,6,5,'邻舍连檐'),f('building',23,2,5,5,'港工宿舍'),f('building',2,14,7,4,'老面铺'),f('building',14,13,5,5,'伙房'),f('building',24,13,4,4,'西槽水房'),f('rope',7,9,5,1,'晾洗布带'),f('path',0,10,29,3,'穿院送行路'),f('lamp',12,7,1,1,'白纸灯')],
 entities:[
  person('lamp-neighbor','摆灯的寡妇·柏姐',10,7,[s('柏姐','白灯皮先浸水。干的遇风就裂，亲人还没走到桥头，灯先灭给谁看？'),s('玛拉','我给别家办过七十八次。轮到我，竟忘带一碗水。'),{who:'柏姐',if:'register-family',text:'簿上写着父亲。我借个碗给闺女，碗底别摔。'},{who:'柏姐',if:'register-white',text:'殓葬白记不收钱。你长途护送，我家留一盏贴你名字的灯。'}]),
  person('seamstress','屋檐下缝围裙的芬',18,7,[s('芬','一早进仓的人要把线缠在左腕。我老伴没腕子，给他缠在饭箩提手上。今天才发现连箩都借出去了。'),{who:'芬',if:'night-lamp',text:'老汀留的那盏长芯灯照着我的针。你晚上还找得到油布巷的后梯。'},{who:'芬',if:'crew-first',text:'他们准饭箩进头一船。他多半能按点下班，我总算能给这只提手量个准。'},{who:'芬',if:'grain-first',text:'他们先卸的八桶干粮。看见我家那只饭箩，请把它带去晚班的棚下。'}]),
  object('borrowed-garland','院门上缺一个口的花环',6,11,[s('玛拉','花没有从山坡采。是面铺门口发芽的老葱。'),s('芬','先碾碎根，叫走的人闻得见家里的锅。')]),
  person('yard-apprentice','背木屑的木匠学徒',22,10,[s('学徒','天亮要去配压舱块。每个工班只能干一潮，潮退下来得把他们当人放回屋里睡。'),s('玛拉','拿哪张牌去？'),s('学徒','门框上有朝海的三道刨花。那是木工场的路标。')])
 ],exits:[exit(1,11,'coffin-hoist',[20,11],'回送客吊台'),exit(11,6,'wick-house',[7,11],'进摆灯人的屋'),exit(27,10,'trim-yard',[2,8],'天亮后过木工场',['vigil-finished'])]
};