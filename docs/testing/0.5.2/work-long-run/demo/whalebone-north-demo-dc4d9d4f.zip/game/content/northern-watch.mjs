const nightFlag='north-watch-dark';
const changes={
 'red-beacon':[[9,7],[11,8],'换灯人','灯芯露出来，我能看清你的手，却看不见对岸的白骨。用罩留一线，我们陪粮艇走头更。','把小炉挪进石塔里。等东窗发白，再看见的是整排肋，不是自己的灯影。'],
 'fan-throat':[[17,10],[19,10],'送汤的见习舵手','让我捂住锅上的锡盖。远窗亮两次才是岸，锡盖一晃谁都像在叫我。','我想看着船回来。太阳起来，先看它的吃水，再决定把哪口罐送过去。']
};
export function withNorthernWatch(map){
 const setup=changes[map.id];if(!setup)return map;
 const [a,b,who,night,day]=setup;
 function post(suffix,at,title,text,dark){
  return {id:map.id+'-watch-'+suffix,kind:'object',name:title,x:at[0],y:at[1],
   requires:dark?['remote-lit']:['north-watch-dark'],lockedText:dark?'等两臂的灯都照到航道，再接头更。':'白班还在岸上。这只发亮的窗眼是给归船留的。',
   dialogue:[{who,text},{who:'米拉',text:dark?'潮的刻度还是那一道。只换看路的光，不替水作主。':'把昨夜看成一片的两道光也记在旁边。白天还会用到它。'}],
   action:{type:'flag',id:'north-watch-kept',value:true,set:{[nightFlag]:dark}}};
 }
 return {...map,entities:[...map.entities,post('evening',a,'合遮光罩，接北线夜更',night,true),post('morning',b,'等晨窗见白，换回日班',day,false)]};
}
