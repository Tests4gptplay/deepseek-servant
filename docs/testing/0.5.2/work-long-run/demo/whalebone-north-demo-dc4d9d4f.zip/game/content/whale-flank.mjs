import {pierPeople,stairPeople,boatPeople} from './two-tugs.mjs';
import {cups,stoop,tin} from './cup-eaves.mjs';
import {baths,bucket} from './rock-and-lung.mjs';
import {hearth,lip,kettleGear} from './three-hearths.mjs';
import {vane,transom,sill} from './whale-turn.mjs';
import {ash,skiff,bend,school} from './hearth-north.mjs';
import {say as s,exit,object,person} from './parts.mjs';
import {witness,spoken} from './voyage-parts.mjs';

export const flankMaps=[cups,stoop,tin,baths,bucket,hearth,lip,vane,transom,sill,ash,skiff,bend];
export const flankGear=kettleGear;
export const flankFoes={[school.id]:school};
const doors={
 'wake-court':[exit(24,9,'cup-eaves',[4,11],'穿晾绳院靠鲸一侧的矮洞，进叠碗街',['coffin-aboard'])],
 'whale-roofs':[exit(19,10,'dropped-vane',[4,10],'上风窗，查住户给底层留下的通路',['recent-wash'])],
 'north-pier':[exit(8,8,'ash-sound',[4,10],'走旧灶如今烧在北边的低岸栈',['kitchen-shore','north-ready']),exit(9,9,'spoon-skiff',[4,10],'随亲自改行的灶主搭做饭小摆艇',['kitchen-crew','north-ready'])],
 'lead-sound':[exit(7,9,'ash-sound',[28,10],'沿运罐架回石岸矮炉',['hearth-north','kitchen-shore']),exit(7,11,'spoon-skiff',[27,10],'循浮缆回给北航做饭的小摆艇',['hearth-north','kitchen-crew'])],
 'flood-stair':[exit(23,13,'ladle-cut',[4,10],'下倒灌的灶边旧街，找曾在北边实走那一家',['harbor-tilted','hearth-north'])],
 'safe-keel':[exit(12,8,'ladle-cut',[28,10],'由已过船的人领回倾灶边',['hearth-final'])]
};
const wetFloor=object('grave-cover-edge','俯身摸布罩哪一角还被压住',14,11,[
 spoken('玛拉','棺还没在这块地上落稳。两角的石粉都未动。','!coffin-home'),
 {...s('玛拉','左角的压面还是旧石粉。放过那张工图的人在哪里见过它？我可以先回忆我自己见过的手迹。'),if:['coffin-home','!epitaph-fault']},
 {...s('玛拉','右角的船边仍只有风沙。一只手从海里接过谁，我得有实见的痕才能刻。'),if:['coffin-home','!epitaph-rescue']},
 {...s('玛拉','左右两角都松，布可以揭起。'),if:['epitaph-fault','epitaph-rescue']}
]);
const kilnWorker=person('north-pan-empty','缩着右膝、爱问汤是不是够烫的井雁',10,9,[
 spoken('井雁','我过河坐的还是本埠冷板。陈家的锅没搬来，也没开北摆，我只好在自己的长凳底下垫块砖。这条大路一样走得通。','!hearth-moved'),
 spoken('井雁','锅搬到旧岸炉了，靠石岸能找到她。别把我的腿和汤锅都算在一只担的重量里。','kitchen-shore'),
 spoken('井雁','陶鹊在苇叶艇上。我走自己的慢路，把鱼头留给小摆船上的两个人。','kitchen-crew')]);
const lowFamily=person('flap-unmoved','城斜后把饭冲成糊的原灶住户',20,10,[
 spoken('灶工','这街的旧炉留在原处。锅来了半锅凉水，井雁坐大队的普通艇。没有另一路温饭，我分他一角冷饼。','!hearth-moved'),
 {...s('井雁','炉确实搬上岸，但北岸那架没有试过。我宁肯坐普通驳，不拿别人答应过的路当我已经走过。'),if:['kitchen-shore','!hearth-north']},
 {...s('乌笋','陶鹊的确上摆船了。北边那段艇没人试过，这一班我们在大堤等普通渡，没派寄西去冒险。'),if:['kitchen-crew','!hearth-north']},
 spoken('井雁','我在陶鹊岸炉学到扶手在右。今夜她把架让给我，我的鞋也到了驳上。','hearth-bed-arrived'),
 spoken('乌笋','寄西把摆艇撑回来，我趴着过窗还骂翻过的那锅汤。后来是我喊他来吃。','hearth-crew-arrived'),
 s('玛拉','愿意吃的先吃。嘴里还是水味的人，我给你们烤第二轮。')]);
const ridgeWind=object('ridge-wind-hand','检查背风脊上的空扎眼',11,9,[
 spoken('伊沃','手里没有迎风面同高的布样。内侧看起来不动也许只是今天风小。','!wind-exposed'),
 spoken('伊沃','外牙那一端已摸到，正好拿回来沿这处空扎眼比相同高度。','wind-exposed')]);
const drumTravel=object('anchor-latch-edge','侧耳听离港浮桥下的栓舌',7,10,[
 spoken('玛拉','索底还顶着闷响。先看副索和外槽的状态，别把人送上还会跳的桥。','!clutch-still'),
 {...s('布兰','棘轮已经停，门缝里水还走。灯响的人未到齐，我的销仍在。'),if:['clutch-still','!both-bells']},
 {...s('玛拉','两班答声都在，布兰还在守他自己的销，不要替他按桥托。'),if:['both-bells','!bran-unpinned']},
 spoken('玛拉','他已经抽销，桥下的刮磨声移开。我的手可以跟北航实测的水线对。','bran-unpinned')]);
const parting=witness('hearth-last-bowl','亲自尝家灶留给归港人的那一口',19,10,[
 spoken('陶鹊','井雁坐我做饭的木架回港。明春我要问他，几层阶他还愿意自己试，别替他定下。','hearth-bed-arrived'),
 spoken('苑芜','寄西说我做的汤太咸。妈也嫌了半辈子，今天却喝到底，这才像回了家。','hearth-crew-arrived'),
 s('玛拉','那串碎瓷门铃有人带回来。门推开时两片会碰一起，没人在门外我也听得见。')],'hearth-goodbye',['grave-signed','hearth-final']);
const places={'north-pier':[kilnWorker,...pierPeople],'flood-stair':stairPeople,'safe-keel':[lowFamily,...boatPeople],'burial-cape':[wetFloor,parting],'ratchet-loft':[drumTravel],'lee-ridge':[ridgeWind]};
const additions={'vigil-bowl':['flank-crossed','浅碗还在晃。晾院靠鲸的矮洞有人领路；先去叠碗街看住户怎样把热盘送回固定岸。'],'under-roof-knock':['sill-returned','窗后有人，但门闩移过。上晒台看吊灯与关窗的痕，再从腰窗和鞋厂底楼查谁给谁留了路。']};
const hints={
 'inner-wind':'背风的扎眼空着。碎浪门朝海那面还留着一块同高的风布；手上少了另一端，无法比较。',
 'porch-chain':'铃链是加给住户的。先比较内外风带，还要有人知道远窗如何答声。',
 'mara-floodgate':'浮桥舌仍顶在旧槽。旁边听栓口能辨锚机、水声、布兰手上那根销到了哪一步。',
 'ivo-bridle':'副索在主轴上弹。转运场的垫脚还没就位，先在那里摸底座。',
 'selene-vent':'外槽持续回灌。副索若仍死咬，放水会打到守脚的人。',
 'mira-chalk':'齿顶还溅冷水，外槽水音盖过擦痕。退回副索后看泄压口。',
 'engrave-slot':'石左角还有旧灰。棺须先落稳，造锚图也要有自己查过的依据。',
 'engrave-return':'石右角没有新划痕。等棺放稳，再拿亲自核过的返航证据到这边。',
 'cover-letters':'布被一侧或两侧的石角压住。在旁边摸布褶，左、右角会分别告诉你还缺哪边的实见。'
};
const exitTips={
 'anchor-yard>flood-stair':'收粮坡还正着，原浮桥仍吃劲。谁握销、谁扶浮桥要在棘轮楼一道一道实做。',
 'lee-ridge>fresh-gallery':'风布还没在这处扎眼实试，内崖转角没人敢带出下一班。',
 'safe-keel>burial-cape':'引航驳上仍有人没落稳。先找渡口亲自点到的人，把这趟船靠实。'
};
export function withFlank(map){
 const entities=map.entities.map(e=>{
  if(additions[e.id]){const [flag,lockedText]=additions[e.id];return {...e,requires:[...(e.requires||[]),flag],lockedText};}
  return hints[e.id]?{...e,lockedText:hints[e.id]}:e;
 });
 const exits=map.exits.map(e=>{const tip=exitTips[map.id+'>'+e.to];return tip?{...e,lockedText:tip}:e;});
 return {...map,entities:[...entities,...(places[map.id]||[])],exits:[...exits,...(doors[map.id]||[])]};
}
const arcs=[
 ['whose-ground','跟着鲸呼吸的回家路','main',['bowl-street','breath-seen','flank-arrived','flank-crossed']],
 ['shards-for-a-birthday','三家一炉与缺角的生日铃','side',['hearth-asked','shard-wish','grandma-birthday','hearth-trial','hearth-moved','hearth-north','hearth-final','hearth-goodbye']],
 ['the-window-was-shut','是人把窗合上，不是风','main',['vane-light','vane-last-meal','transom-grit','sill-wheel','vane-sequence','sill-account','sill-returned']]
];
export const flankQuests=Object.fromEntries(arcs.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
