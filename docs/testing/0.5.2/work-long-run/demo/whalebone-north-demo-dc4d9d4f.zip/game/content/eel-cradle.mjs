import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {setting} from './registry-parts.mjs';

export const spawnHint=witness('eel-hat','抱着一只倒戴筛帽的卷苗',12,12,[s('卷苗','你们忙你们的正事，我那篓小眼鳗没长到能过盐沫门。黑海草根下的短洞退水会露出来，我外公的筛帽可以交换着过水。')],'raised-eel-hole');
export const eels=region('eel-cradle','盐市 · 晚两潮才脱壳的小眼养篓',3,'salt-market',29,19,'stone',
 [['water',0,0,29,4,'只在退水后留下一段的小沟'],['wall',4,3,5,5,'荤草根抱住的石架'],['crate',13,2,5,6,'编着软毛边的幼鳗篓'],['building',22,2,6,6,'看篓人坐着就能下手的小棚'],['water',0,14,10,5,'涨潮回去的海草汊'],['wall',21,14,8,5,'有饭粒黏在底角的晒石']],
 [['path',3,9,23,2,'孩子能蹲下、长木篓能倒过来的石滩'],['rope',9,12,12,1,'两头能抬动的草篓绳']],
 [witness('eel-keeper','正把晒干小鱼一尾尾剥皮的月蒿',8,10,[s('月蒿','不是每条鱼都值得你去救。它自己会顺潮爬。那片草根被外布门压住了，鱼却不能替人抬布架。')],'eel-needs-space'),
  fixture('eel-feel','从篓外用手背摸清细口朝水还是朝泥',13,9,[s('卷苗','缩进来的倒刺先擦手背，不朝鳗。以前我给它放反，白忙了两潮。')],'eel-rim',['eel-needs-space']),
  setting('eel-curl','试把筛帽边折进根盘，确认没压住回水',18,10,[s('月蒿','根能晃，小眼能游，海草没被倒刺挑起来。下次我自己翻，不用天天等一位老师。')],['eel-rim'],{'eel-room':true}),
  witness('eel-school','看卷苗亲自把育篓换到背浪处',23,11,[s('卷苗','没有捞上来才对。我回头来要看见草动，不是想看碗里躺一排。')],'eel-safe',['eel-room']),
  person('eel-bread','把烤鱼末摁进饼里的阿崔',11,12,[s('阿崔','我不说海里哪种鱼好吃。肯给我留一张空的晒饼盘，我帮谁说话。'),spoken('阿崔','给小眼鳗省条水道，倒把我的烤盘还回来了，两桩各欢喜。','eel-safe')])],
 [exit(3,10,'wrack-bight',[19,15],'随露潮的草根倒回裙口汊')]);
