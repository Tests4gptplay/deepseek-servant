import {lift} from './counterlift.mjs';
import {dryCourt} from './dry-court.mjs';
import {hold} from './crib-hold.mjs';
import {organ} from './organ-lock.mjs';
import {west} from './west-lamp.mjs';
import {seam,cistern} from './hidden-cistern.mjs';
import {lane} from './salt-lane.mjs';
import {weigh,dorm} from './salt-scales.mjs';
import {vault,loft} from './salt-vault.mjs';
import {hall,northPier} from './salt-hearing.mjs';

export const holdSaltMaps=[lift,dryCourt,hold,organ,west,seam,cistern,lane,weigh,dorm,vault,loft,hall,northPier];
function quest(id,name,kind,stages){
  return {id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)};
}
const arcs=[
 quest('under-the-counterlift','反提梯底下的人','main',['roof-shelter','lift-proved','ward-story','bar-freed','gate-safe','light-replay','harbor-truth']),
 quest('west-glass','还灯','side',['lamp-vow','wick-traced','lamp-restored','west-stairs']),
 quest('sailed-by-hand','帆边上的第二行字','hidden',['seam-knock','seam-open','salt-survivors']),
 quest('salt-in-the-ticket','货票上的潮盐','main',['dry-standard','dry-factor','ticket-date','bins-seen','testimony-lodged','shortfall-proved','north-slate','north-ready'])
];
export const holdSaltQuests=Object.fromEntries(arcs.map(q=>[q.id,q]));
export const echoRay={
 id:'echo-ray',name:'闸井的双铃鳐',enemy:'护幼铃鳐',hp:42,attack:4,level:4,
 tell:'拖铃落底，面前的浅水骤退。',objective:'扑入死角让出幼鳐的退水格',
 phases:[
  {fromHp:42,tell:'胸鳍转白，两圈水纹往墙角挤。',moves:[
   {name:'合鳍顶缆',kind:'ram',power:1.7,counter:'guard',hint:'压脚下的索，迎着第一股短推。'},
   {name:'贴墙折冲',kind:'rush',power:1.45,counter:'dodge',hint:'留出墙角的浅水位，向外侧让步。'}]},
  {fromHp:20,tell:'护幼的铃音变细，一边腹鳍移回闸扇。',moves:[
   {name:'双翼护闸',kind:'shell',power:1.05,counter:'skill',hint:'绕开幼鱼，用回索牵开压在闸上的翼尖。'},
   {name:'离巢回旋',kind:'whirl',power:1.8,counter:'dodge',hint:'脚下水旋的圆心是空的，让前排散开。'}]}
 ],rewards:{xp:14,items:{tonic:1}}
};
