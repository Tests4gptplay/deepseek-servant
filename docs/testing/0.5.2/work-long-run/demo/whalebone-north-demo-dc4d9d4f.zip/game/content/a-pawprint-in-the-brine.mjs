import {scree,roof,pools} from './driftbay-ice.mjs';
import {throat,heights,lens} from './driftbay-tide.mjs';
import {bay,link,scrap,voice} from './driftbay-relief.mjs';
const cradle=bay('cradle','退水后才听得见的袖湾',28,20,[[5,11,7,7],[14,12,9,7],[23,10,6,8]],
 [[2,[2,11],[8,11]], [1,[8,11],[12,7],[17,7],[21,8],[24,9]], [1,[8,11],[12,15],[16,15],[19,13],[22,12],[24,9]]],
 [[9,11],[12,15],[16,15],[19,13],[22,12],[24,9]],
 [link(2,11,'driftbay-scree',[21,12],'沿反光断面回冰坡')],
 [scrap('watchden','在干芦后坐下，看小海獭上床',24,9,[['米拉','我以为它们每天游出湾，是来找那条淡水。今天潮从幼崽背后涨进来，它们却先上了这一层。'],['玛拉','它们把碎贝铺在水碰不到的高处。看，在吃的那只背后，最小的躺着，也能让肚皮离开冷水。'],['伊沃','我一直想在亮处给担架系绳。原来不用把人钉在亮处，得给换肩的人留一块能坐下的干地。把绳割两段，这样岸和憩处都有，没谁非等着被我放行。']],{requires:['driftbay-pups'],lockedText:'海獭在看人的亮影。退回湾口，绕到低处的枯芦背后，跟着一大一小两道湿印进来。',action:{type:'flag',id:'driftbay-den'}}),
 scrap('splitrope','取伊沃留给队伍的横托肩绳',20,12,[['伊沃','病人用外圈，我们走的人用里圈。母獭的窝别作标记，画到能坐下的那块石头为止。']],{requires:['driftbay-den'],lockedText:'有人还在芦后等那只最小的露面。',action:{type:'item',id:'shoulder-sling',value:1,set:'driftbay-gift'}})]);
const denWay=Object.assign(link(22,13,'driftbay-cradle',[3,11],'从三岔蚀孔钻到浪背的袖湾',['driftbay-lee','driftbay-fresh','tide:low']),{lockedText:'石面留着三岔蚀孔，最下那一支还在水里。先走过背风檐，再到最清的芦根看看水从哪边来。退潮时回来。'});
const roofReturn=voice('rest-stop','在冬院练习换肩的伊沃与米拉',6,9,[
 ['米拉','托绳停在芦窝外。往后谁借这条路，先能听清身后的两个人，再选要背病人还是领船。','driftbay-den'],
 ['伊沃','直线只给轻舟画。到了那道藏人的石檐，背人走的得多画一个能转身的弯。','driftbay-lee'],
 ['瑟琳','让孩子用小杯在上游接。船在湾口就停桨，别搅动贴着芦根出来的淡水。','driftbay-fresh'],
 ['玛拉','冬院里的干碗，端它的是哪只手，决定这条路要画到什么地方。']],{requires:['driftbay-lee']});
const additions={
 'lee-mouth':{exits:[link(7,10,'driftbay-scree',[3,12],'循湿沙反光下潮间冰坡，去找能背人走的岸')]},
 'fresh-gallery':{exits:[link(5,8,'driftbay-lens',[24,6],'推开陶罐后侧芦根，走到有咸甜两层水的井湾')]},
 'winter-court':{entities:[roofReturn]},'driftbay-scree':{exits:[denWay]}};
export const driftMaps=[scree,roof,pools,throat,heights,lens,cradle];
export function withDriftbay(m){const a=additions[m.id];if(!a)return m;
 return {...m,entities:[...m.entities,...(a.entities||[])],exits:[...m.exits,...(a.exits||[])]};}
export const driftGear={'shoulder-sling':{name:'两头能歇肩的横托绳',slot:'charm',resists:{wind:.15,tide:.1}}};
export const driftQuest={id:'follow-the-dry-belly',name:'躺着也能离开冷水的地方',kind:'hidden',startFlag:'driftbay-scree',endFlag:'driftbay-gift',stages:['driftbay-scree','driftbay-lee','driftbay-fresh','driftbay-pups','driftbay-den','driftbay-gift']};
