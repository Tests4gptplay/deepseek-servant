import {region,fixture,witness,spoken} from '../voyage-parts.mjs';
import {say as s,person,exit} from '../parts.mjs';
import {job} from './from-the-clockmakers-quay.mjs';
const room=(id,name,w,h,blocks,land,people,exits)=>region(id,name,4,'north-star-quay',w,h,'wood',blocks,land,people,exits);
export const cellar=room('pendulum-cellar','北航 · 错齿摆房和水玻璃架',26,18,
 [['wall',0,0,26,2,'石窖北壁'],['building',3,3,5,4,'油灯收在门后的水玻璃冷厨'],['crate',13,3,7,4,'两架摆锤不能互相碰到的隔板'],['water',19,13,7,5,'承铅的消振水池'],['wall',0,14,7,4,'楼下的悬石尾架']],
 [['lane',2,9,21,2,'拆开能平放最长轮轴的白板台'],['rope',9,7,1,5,'旧送时锤的牛筋悬簧'],['lamp',16,9,1,1,'和黄铜轮分色的绿罩灯']],
 [fixture('star-clock-tooth','把裂口留在两枚完齿之间',10,10,[s('粟铅','不许把裂口磨平。去了它，船抖一下，谁还能认出这颗轮是哪一只。'),s('玛拉','看见了。锥簧短过一条，慢签挂在空钉上。两个毛病，一个在当时的针，一个在每次走过这截齿的时候。'),s('米拉','把鞋盒里的两次旧读数都摆上。只修对今天一眼，三更以后还会把别人的小艇叫早。')],'star-clock-wheel',['star-clock-offer']),
 job('star-rate-bench','放上历次两面钟，修针和慢签',17,10,'clock',['star-clock-log','star-clock-sighted','star-clock-wheel']),
 person('star-lens-worker','用手背闻滑油的白庞',8,8,[s('白庞','破布能擦油，别擦右边那个黑指印。我的眼睛还小，老头子就是按着那处叫我听第一下的。'),spoken('白庞','三更没偏，轮也还带着裂。那就把旧东西接回活里去。这话我等了挺多年。','star-clock-tested')])],
 [exit(2,10,'star-clock-quay',[12,14],'带上走着的钟回装箱廊'),exit(20,8,'meridian-shutter',[22,12],'沿内梯回到真垂线')]);
export const water=room('night-oar-road','北航 · 灯影全收的回流泊道',33,22,
 [['water',0,0,33,5,'退潮的星与涨潮的星映在不同流槽'],['boat',2,5,8,4,'布篷里只留一盏罩灯的领渡艇'],['wall',14,4,6,4,'遮住红石远灯的黑色岸肩'],['building',25,5,6,4,'给过夜舵工留下的候明棚'],['water',0,17,33,5,'两股回流冲着不同的礁背走']],
 [['pier',2,10,28,2,'宽得下两副不同长短的桨'],['rope',9,13,13,1,'夜里借气泡读逆流的漂绳'],['lamp',24,9,1,1,'放在篷里的子午小灯']],
 [witness('star-oar-rule','双手一直抱着自家桨的米娘',8,11,[s('米娘','领三条船时，我敢举灯。轮到我自己接儿子放工，就叫我喝了酒。他们抄时刻的表准得很呀。'),s('粟铅','表带回来修过了。我押轮去饭铺那顿酒，你一口也没尝。要不要我让人传开去？'),s('米娘','先跟我走一回。夜渡不接张贴告示的人，接得住看不见我灯的人。回流把船横送一格的时候，先想下一桨。')],'star-clock-oars',['star-clock-tested']),
 job('star-crossing-helm','收桅灯，亲手划过无灯滩',19,11,'sail',['star-clock-oars']),
 person('star-night-fish','缝船眼的霜隙',26,12,[s('霜隙','亮点要是跟着你的桨游，那是水里的。天上的不会听你吩咐。我把一根银线缝在篷口，抬头就知道哪边向北。'),spoken('霜隙','你把桨放歪过，水自己把船托回了等你的位置。那处泥是我去年挖开的，倒也没白冻这两根手指。','star-clock-grounded')])],
 [exit(2,11,'star-clock-quay',[20,15],'找遮灯的阶沿回铅摆行'),exit(29,12,'mothglass-landing',[3,10],'沿亲自摸过的水槽靠到青玻璃台',['star-clock-crossed'])]);
export const landing=room('mothglass-landing','北航 · 一只钟停过的青玻璃台',27,19,
 [['water',0,0,27,4,'退到黑礁另一边的细潮'],['building',4,4,6,4,'磨砂玻璃的小值夜屋'],['wall',16,3,6,5,'三扇旧钟窗后的风岩'],['water',0,15,11,4,'送摆线的窄舟'],['crate',21,13,6,5,'粮船和夜渡只够装一只钟的空匣']],
 [['pier',2,9,22,2,'夜渡工和粮船领航人共用的玻璃台'],['lane',10,11,11,2,'孩子用茶灰描过的两条子午线'],['lamp',15,8,1,1,'早来的人亲自点的绿玻璃灯']],
 [job('star-fitted-box','在两张航桌前交付校过的钟',16,10,'give',['star-clock-crossed']),
 fixture('star-window-book','捧起窗龛里一片留有小手油印的青玻璃',19,12,[s('玛拉','我见过这个油印。十七年前，我躲在一张桌子下面，不敢问开船的是谁。有个人把带刻线的玻璃递下来，叫我让北星待在缝里。'),s('米娘','你那时只问了一句，好了没有。我说我不知道，还差一船。那片窗后来碎了，谁都没舍得丢。'),s('玛拉','我总以为那晚只剩一个大人记得方向。原来底下还有一个，怕得要死，也替你看了一会儿星。')],'star-clock-glass',['star-clock-settled','star-clock-quiet']),
 person('star-daughter-home','终于能在渡屋脱掉鞋的雾乔',8,9,[s('雾乔','我娘把两根断鞋带分开留。她说一根是我自己的，一根是她急着来接我不小心扯下来的。'),spoken('雾乔','她留钟领夜渡，我就把饭菜分两锅。她回来还要洗桨，热一份就够。','star-clock-ferry'),spoken('雾乔','粮船借走了钟。今晚我替娘用铜线看一回星。她没说小孩子别管。','star-clock-grain')])],
 [exit(2,10,'night-oar-road',[28,12],'由背水泊口回关灯的摆渡艇'),exit(22,11,'star-clock-quay',[22,15],'随领渡人原路送回钟匣',['star-clock-settled'])]);
