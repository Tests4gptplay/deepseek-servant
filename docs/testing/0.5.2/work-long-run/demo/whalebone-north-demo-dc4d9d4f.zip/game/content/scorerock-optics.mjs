// Survey coordinates are in boat lengths. The paper's cut is due north.
export const marks={sleeve:{x:0,north:4},vent:{x:0,north:12},cut:{x:0,north:16}};
export const stations={
  old:{x:0,north:0},beam:{x:3,north:0},inlet:{x:-2,north:6},mouth:{x:-2,north:8}
};
export function bearing(eye,mark,facing='north'){
  const direction=facing==='south'?-1:1;
  const range=(mark.north-eye.north)*direction;
  return range>0?(mark.x-eye.x)*direction/range:null;
}
export function sight(place,flags={}){
  const station=stations[place]||stations.old;
  const reverse=place==='inlet'&&!!flags['score-look-aft'];
  const facing=reverse?'south':'north';
  const sleeve={...marks.sleeve,x:flags['score-line-out']?2:0};
  const occluded=place==='inlet',spray=place==='mouth'||!!flags['score-first-crest']&&!flags['score-line-out'];
  return {facing,station,occluded,spray,
    sleeve:bearing(station,sleeve,facing),
    vent:bearing(station,marks.vent,facing),cut:bearing(station,marks.cut,facing)};
}
export function playerStation(map,s){
  if(map.id==='scorerock-origin')return 'old';
  if(map.id==='scorerock-beam')return s.x>=16?'beam':'old';
  if(map.id==='scorerock-blind')return s.x>=21?'mouth':'inlet';
  return null;
}
