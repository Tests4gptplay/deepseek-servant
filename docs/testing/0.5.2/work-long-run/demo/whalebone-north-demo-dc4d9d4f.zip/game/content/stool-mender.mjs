import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';

export const mender=region('stool-mender','白崖 · 窗边有两朵紫花的修凳住家',6,'north-interior',29,20,'wood',
 [['wall',0,0,29,4,'让晒竹抛下淡色影子的两面矮墙'],['building',2,3,8,5,'自己开两扇窗的修竹人家'],['crate',14,3,5,5,'装好的一把旧竹凳'],['building',22,4,7,5,'沉笛准备借人缝门的新工作间'],['wall',0,15,10,5,'退过海水以后慢慢干的里屋']],
 [['path',3,9,23,2,'先后两拨各能走进来的修凳过道'],['lamp',17,12,1,1,'不用亮灯也看得见的紫花穗']],
 [witness('mender-name','请隙青自己担起修凳的旧活，给问姓的人回话',10,10,[spoken('隙青','上回说叫隙青，你果然这样叫。你看这只凳脚，竹扎在里边，没人非得知道谁的姓才敢坐。','given-by-name'),spoken('隙青','你还记得紫花。它们没淹死。谁想给我套个错姓，我指他来这里先看我这个人。','given-by-house'),s('玛拉','倘若哪天你自己要找，再来叫我。')],'mender-home',['grave-signed','slant-placed']),
  fixture('mender-door','跟沉笛卸下原凳的横撑，把她损失的家门重新合上',19,11,[s('沉笛','铰链只剩一根，就做半扇吧，狗从下边钻进来，人把上半扇合上能睡。下回起水，我还会自己开。')],'slant-home',['mender-home','city-door-spent']),
  fixture('mender-awning','在原篷主的新缝摊和矾当把首块破篷折成干工作角',21,13,[s('矾当','这门给沉笛留下了。我也没有一季全晾着，长索拿来缝边，不再拿卖鞋做唯一一份活。')],'slant-home',['mender-home','city-awning-spent'])],
 [exit(3,10,'low-hinge',[23,12],'从修凳住家回沉笛的低闩门')]);
export const mealAfter=witness('play-after-winter','回到午场帮卧缨把变过的演法交给下一个孩子',19,12,[spoken('卧缨','我的月幕送去给两户住客当门了。小垛改成下午演，她把当船长的爷爷也画了进去。','ridge-rooms'),spoken('小垛','月亮布还在。奶奶去收网那一晚我自己演！记得来，我要卖可以当票的虾壳。','sill-rooms')],'play-home',['grave-signed','play-finished','concourse-agreed']);
export const highAfter=witness('moon-chair-return','旧房真有人上岸后回来，跟甫岸把外把手换到下一家的门',18,13,[s('甫岸','我在斜港转过车回来，手还有力。下家那位要扶左边，不要拿我右转那一道逼她。'),s('野檀','我原来的床还在。若你愿意来，先把门关上，我的猫爱往戏棚跑。')],'pelt-home',['grave-signed','eave-first','ridge-rooms']);
export const lowAfter=witness('netdorm-morning','跟小垛夜里把旧网收回，给下一群幼兽留下新一段空口',19,13,[s('小垛','上次是人等人，这次我等谁？一只、两只，腿最短的还没回来。'),s('野檀','你可以晚点收，我去帮你挂。明早是我的班。')],'pelt-home',['grave-signed','skirt-first','sill-rooms']);
export const wetChair=fixture('wet-chair-edge','站在乌筝身边的原格子，量椅背的两截水色',12,13,[s('玛拉','地板白，椅背从中间往下黑。坐凳的位置还没到窗，伸手过去的亮缝正是原来低窗的边。'),spoken('乌筝','人已经能自己返身，这把凳的靠背留在里头，外头那块平板给别人站。','hearth-final')],'wet-chair-read',['harbor-tilted']);
export const graveSeats={'mira-after':[7,6],'paid-lantern':[9,15],'chart-returns':[17,7],'cloth-next-winter':[22,9],'corrected-cart':[4,12],'mara-at-own-tea':[16,15],'rye-last-harvest':[23,12],'wren-final-letter':[11,5],'night-farewell':[18,14],'hearth-last-bowl':[8,8]};
export const wetFeatures=[
 {id:'ladle-chair-back',kind:'crate',x:10,y:11,w:1,h:2,label:'盐水黑到中腰的旧椅竖背',sceneStates:[{until:'hearth-final',pose:'half-submerged'},{from:'hearth-final',pose:'back-at-wall'}]},
 {id:'ladle-window-water',kind:'water',x:12,y:10,w:3,h:1,label:'贴低窗根的倒灌水线'},
 {id:'ladle-window-brace',kind:'rope',x:12,y:11,w:3,h:1,label:'横在椅边低窗的斜撑绳',sceneStates:[{until:'hearth-final',pose:'tied-low'},{from:'hearth-final',pose:'tied-to-home'}]},
 {id:'ladle-chair-seat',kind:'pier',x:10,y:13,w:2,h:1,label:'搭在窗前和干侧之间的一片旧坐板'}
];
