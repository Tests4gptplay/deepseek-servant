import {fixture} from './voyage-parts.mjs';
import {say as s,exit} from './parts.mjs';
import {mechanism} from './district.mjs';
import {setting} from './registry-parts.mjs';
import {room,fresh} from './the-sleeve-and-the-spray.mjs';

export const blind=room('scorerock-blind','北航 · 石颊遮白、船尾回看的逆向弯',33,21,
 [['water',0,0,33,4,'石颊以北才看得到喷口'],['wall',3,3,13,5,'在船头和远喷孔中间实实挡住视线的黑肩'],['wall',16,0,3,10,'西背槽的狭颈必须从南绕过'],['water',0,16,12,5,'红袖在石后看不见船头，只能回看'],['wall',23,16,5,5,'出齿后的正向观测台'],['boat',25,5,7,3,'航到嘴外才露出水筒的旧艇']],
 [['pier',3,11,26,2,'沿黑肩背面转过的船舷'],['rope',6,14,12,1,'把近袖松到落流下游两个船长'],['lamp',25,9,1,1,'岩嘴向北的短视线']],
 [fixture('score-hide-white','黑肩内弯的舵眼',8,11,[s('米拉','空气是亮的，白水却没了。前方是整张黑石颊，别照一柱此处看不见的水开。'),
 s('葛芮','我的弓该换水了。等下一浪时可以替我松眼上的绳，别呆看石头。')],'score-stone-blinds',fresh),
 setting('score-pay-out','用撑篙放下浮弓眼上的余绳',12,13,[s('玛拉','杆头上的麻眼滑走了，红袖离开旧水足足两船长。贝苗下面的水换了。'),
 s('葛芮','浮的是晒网袖，不是给大船标暗石的。要找它，转过身朝船尾看。')],['score-stone-blinds',...fresh],{'score-line-out':true,'score-look-aft':false},'先把艇送到石颊不见白的背面。'),
 setting('score-stern-look','转身由船尾重认下游红袖',15,12,[s('米拉','它在我左后方，正对着岸上晾绳的钩。船头看不见它，是因为我们已经驶过它。'),
 s('伊沃','听得到喷孔，背后看见红。别把听到和看到的东西在旧图上画到一处。')],['score-line-out','score-stone-blinds',...fresh],{'score-look-aft':true,'score-stern-found':true},'先在近侧放松浮弓，再回看。'),
 mechanism('score-mouth-reading','转出石嘴、重新朝北的窄窗',24,11,[s('槿陶留下的船刻','小艇拐出时，石面上的湿线由亮转暗。白喷在黑缝右侧出现；红袖已在船后。')],['score-stern-found','score-line-out',...fresh],'score-lee-fix','你已在浮弓北面，出嘴重新见白。怎样标出返向可用的一折？',
 ['直切喷孔，船后没见到的红袖当作已经移走','转回去追红袖直到白红重合，今后只画一条线','船尾定近袖，船首定远孔；保留绕过遮挡石颊的转角'],2,'在内弯看不见白，在船尾看不见远石。两条视线前后相背，折角需要画出来。',[s('米拉','去程向北看远孔，回来要看近袖的活绳；白喷不出时也有石颊可沿。')]),
 fixture('score-pass-mouth','扶舷从白喷右侧回到航行线',27,13,[s('葛芮','船尾过去了。你若没在背面替我换活水，今天这弓苗早就憋住。'),
 s('米拉','图上的黑缺我留个船身宽，给还要在石后喘一口气的人。')],'score-lee-sailed',['score-lee-fix',...fresh],{action:{type:'flag',id:'score-lee-sailed',set:'score-surveyed'}})],
 [exit(3,12,'scorerock-origin',[21,14],'以石颊为边沿回原观测船')]);
