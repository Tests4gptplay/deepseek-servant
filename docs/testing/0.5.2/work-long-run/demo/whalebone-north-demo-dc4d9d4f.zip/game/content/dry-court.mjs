import {say as s,person,object,flag,exit} from './parts.mjs';
import {district} from './district.mjs';
export const dryCourt=district('dry-court','亮灯空城 · 八户晒衣院',2,29,20,'stone',
 [['building',1,1,5,5,'三代人同住的东厢'],['building',8,2,5,4,'晒房'],['building',17,1,9,4,'针织长屋'],['building',3,13,6,5,'西窗接生房'],['building',19,13,6,6,'港卫旧铺']],
 [['rope',3,8,9,1,'齐胸晾绳'],['path',0,9,29,3,'送水车路'],['lamp',15,8,1,1,'封灯匣'],['pier',23,8,5,2,'外廊']],
 [person('lamp-nephew','背着熄灯罩的乔',9,7,[s('乔','那盏灯是我舅舅的。他给船打三下白光，我每次都回他两下。那晚我都回了，灯却没了。'),s('伊沃','是我关的。你不必把罩子给我。'),s('乔','我给你。你先去找里面烧短的那一截，再说该不该还。')],{action:flag('lamp-vow'),after:[{who:'乔',if:'west-stairs',text:'西窗新梯的踏板，我也钉了一枚。下次有人要问舅舅去哪里，我带他去看灯。'},s('乔','找装灯芯的青铜管，旧灯塔里还有名册。')]}),
 object('bed-wedge','窗框匠的楔木槽',15,11,[s('木匠','新楔宽三指，横闩宽两指。你垫上这个，床还在，人再也不用拿门闩去垫脚了。')],{action:flag('bed-wedge')}),
 person('dryhouse-twin','盖了三层毯子的晒布师',22,7,[s('晒布师','他们说屋子空了。我家锅盖还在屋檐上晒，锅却在船肚里熬药。城可以搬家，没必要先从地图上消失。')]),
 object('west-stair-fastener','接生房的西窗梯座',10,14,[s('伊沃','灯光照出一截旧圆孔。活环套窗框里侧，最短的踏板放低，让小孩自己够得着。'),s('乔','我钉这一枚。不用在上头刻我舅舅的名字。')],{requires:['lamp-restored','ivo-line'],action:flag('west-stairs'),after:[s('木匠','西窗现在能双向走。把它记在撤离图上，别只记谁钉的。')]})],
 [exit(1,8,'counterlift',[22,9],'上层平梯回反提井'),exit(26,10,'crib-hold',[17,4],'过高处晾廊下舱'),exit(10,15,'west-lamp',[3,8],'沿修好的西窗梯进灯塔',['west-stairs'])]);
