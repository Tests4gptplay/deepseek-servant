import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit,flag} from './parts.mjs';
import {tidePost} from './district.mjs';
import {setting} from './registry-parts.mjs';
export const leftDoor=fixture('left-net-eye','抬低水线下向左开的第二排网门',19,11,[s('蕖末','若只顺着痕走，会把网板压紧。我在里面扳过六次，得先让左边过一指，别的脚才肯动。')],'pearl-door',['pearl-twill','pearl-groove','tide:low'],{lockedText:'蕖末的旧网框和黑钩岩石肩各留一处同向的痕。水退时在第二排中找横移的左门。'});
export const bottom=region('lantern-trawl','北湾深层 · 老艇翻身见的藏网坞',4,'north-interior',28,19,'stone',
 [['water',0,0,28,5,'一潮后会起风的小海眼'],['wall',1,5,5,3,'托住半翻的旧船的黑梁'],['crate',12,3,5,4,'一套铅围和两块防寒衬'],['wall',22,13,6,6,'贝户能贴身退回的通风道']],
 [['pier',3,9,21,2,'低头能见苗网的检修跳板'],['rope',8,12,13,1,'能彻底松开的止返索'],['lamp',18,7,1,1,'辨认幼贝的酒色灯']],
 [witness('trawl-guide','把灯塞进酒壶里的补网匠·何旷',8,9,[s('何旷','我拿苗网给自己的祖母做吊床，她说我看谁都像一笼贝。别人的床我不再替她编。这只网挂在海眼边，冬压进来会把种苗摇醒，再放回也活不到开春。'),s('米拉','是我的错图把笼子下错了，这回得让你们过冬还有本事自己收网。'),s('何旷','可以赶开挤进来的铠潮兽，保住下一程的快艇。也可拆艇上三丈好帆，放它顺海眼出去，快艇这个冬天就跑贡货慢一班。二者都能让小贝活，不用杀它。')],'trawl-need',['pearl-door']),
 person('trawl-loan','让修网人按打算借用配重或护寒衣',15,9,[s('何旷','松柄短锚能振开硬背，旧油绒能护接浪的人。哪一套更用得上？从柜里拿要登记去向。',[{text:'领一件护住寒流的油绒帆衣',set:'trawl-parka-wanted'},{text:'领松柄短锚，破开硬背给种笼腾地方',set:'trawl-mallet-wanted'}])],{requires:['trawl-need'],action:flag('trawl-loaned'),after:[s('何旷','哪个答应借给你就领取哪个。没穿在身上，海眼可不认你的牌。')]}),
 object('trawl-parka','套过柜边的油绒帆衣',11,10,[s('米拉','扣子在侧腰，蹲下拉网时不压胸。')],{requires:['trawl-parka-wanted'],action:{type:'item',id:'trawl-parka',value:1,set:'trawl-rigged'}}),
 object('trawl-mallet','取下松柄装的短锚杵',19,10,[s('玛拉','碰硬背时柄先让半寸，不用把反震全交给手腕。')],{requires:['trawl-mallet-wanted'],action:{type:'item',id:'trawl-mallet',value:1,set:'trawl-rigged'}}),
 witness('lost-sail','征得运苗的秦汐同意，拆下一段整帆',14,12,[s('秦汐','开旁口要三丈。我肯剪，不是让你欠我一匹。帮我们把少跑的贡货担到陆路，冬岸的人会知道这一趟为何迟。')],'trawl-pledge',['trawl-rigged','!trawl-clear'])],
 [exit(3,10,'pearl-return',[18,11],'把网门移回贝郊一侧'),exit(23,9,'brine-spine',[3,9],'携工具进海眼边的翻身台',['trawl-rigged'])]);
export const spine=region('brine-spine','北湾深层 · 银脊挤网的回流台',4,'north-sound',29,18,'wood',
 [['water',0,0,29,5,'挤进细网的双侧回浪'],['wall',2,5,5,3,'旧艇翻脊留下的让力支架'],['crate',13,3,5,4,'还装着浅水贝苗的坠筐'],['water',18,13,11,5,'解开能朝外海退去的敞口']],
 [['pier',3,9,23,2,'可从两端退出的试压台'],['rope',8,12,13,1,'把旁口与快艇相连的新帆绳']],
 [tidePost('trawl-tide',8,9),
 setting('set-trawl-sail','在小流一侧先把旁帆探出半幅',14,9,[s('何旷','打成活结，潮未到还有退路。等新帆自己鼓腹再放全宽，不用拿手去提海兽的脊。')],['trawl-pledge','tide:low','!trawl-clear'],{'trawl-sail-up':true}),
 setting('drop-trawl-sail','临到放行前把旁帆收回快艇',10,11,[s('秦汐','扣还在。旁帆没有割断，可回去再议或按原配装赶开银脊。')],['trawl-sail-up','!trawl-clear'],{'trawl-sail-up':false}),
 fixture('let-trawl-run','涨水时放满旁帆，将银脊引回开海',20,10,[s('何旷','接住了。帆已裁去三丈，快艇这趟不能载重货，那一担贝留给我们送到冬岸。')],'trawl-detour',['trawl-sail-up','tide:high','!trawl-clear'],{action:{type:'flag',id:'trawl-detour',set:'trawl-clear'}}),
 object('trawl-beast','在白脊退色的瞬间松开种网',17,10,[s('米拉','先看背鳞方向。全亮时力还在壳外，第二次凉光返到腹面才有空。救的是被挤紧的网笼，最后留出海眼。')],{requires:['trawl-rigged','!trawl-clear','!trawl-sail-up'],action:{type:'battle',id:'brine-spine',set:['trawl-clear','trawl-routed']}}),
 witness('trawl-holder','由何旷验明第一笼开贝能吐水',23,11,[s('何旷','你们把头一笼下水，我站在这里等她们自己开。开了，数得清。把下面的亮粉倒回水里，里面还有下一季。')],'trawl-test',['trawl-clear'])],
 [exit(3,10,'lantern-trawl',[22,9],'顺软架退到旧坞')]);
export const trawlFoe={id:'brine-spine',name:'护潮的背光银脊',enemy:'银脊潮兽',level:7,hp:78,attack:5,resistances:{iron:.94,light:1.33,wind:1.16,tide:1.06},
 phases:[{fromHp:78,tell:'背面一片亮，第一道力贴着冷甲走。',moves:[{name:'冷背侧推',kind:'shell',element:'cold',counter:'skill',power:1.15},{name:'背浪转舷',kind:'ram',element:'tide',counter:'guard',power:1.2}]},{fromHp:37,tell:'两个白点移向腹面，外弧出现开口。',moves:[{name:'分网露腹',kind:'whirl',element:'wind',counter:'dodge',power:1.16},{name:'回湾浅扑',kind:'rush',element:'cold',counter:'dodge',power:1.22}]}],
 rewards:{xp:24,label:'银脊沿着开口回海，整船的引航帆还能继续用。'}};
export const trawlGear={'trawl-parka':{name:'护贝油绒帆衣内衬',slot:'charm',resists:{cold:.30}},'trawl-mallet':{name:'松柄短锚杵',slot:'weapon',power:4,break:6}};
