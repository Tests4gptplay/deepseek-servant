import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {setting} from './registry-parts.mjs';
import {mechanism} from './district.mjs';

export const yard=region('goose-foot-floor','倾港 · 要把粮队带回自己街院的鹅脚巷',6,'whale-city',45,29,'stone',
 [['building',0,0,11,8,'榷所侧门，鲸身一倾它便开向旧的窗下'],['building',15,0,10,10,'木鹅的身子被墙遮住，只看得见脚'],['wall',30,4,4,13,'原能从低处直看的鹬骨晒墙'],['crate',5,17,9,7,'老摊位让出门道仍留下半圈灶座'],['building',20,20,11,9,'家门朝里开、不能让人流堵住的廊院'],['water',35,20,10,9,'回头看见水绕过旧日低窗']],
 [['path',3,10,25,2,'街坊平日背着走也熟的旧队线'],['path',25,17,16,2,'拐下鹅脚斜影才见的上院入口'],['hearth',15,15,2,1,'三脚石灶的最短一足被水盖上'],['pier',35,12,6,1,'高窗下有能转身接人的平台']],
 [fixture('common-give-up-place','从队中走到原摊内，把摊布抽回来给排最后的老人露出自家门',8,12,[s('荚黎','叫他们散队没用。谁散了，谁明天从头排。'),s('前街的芋娣','我放掉今天的位置。我站到我爸的窗下喊，认识我家的跟我走。你看，我的鞋还在那里，摊主知道我走过。')],'common-place-spent',['common-street-choice']),
  fixture('common-low-foot','沿最短鹅脚走到闭着的低窗，亲眼看见芋娣父亲的水盆正倒灌',13,15,[s('瑟琳','这窗再往前就开进水里。芋娣爸，转过身看楼梯顶，我在那里接。'),s('窗里的老人','丫头你记错了。鹅长的那只脚朝菜院，短的那只是我的旧窗。')],'common-short-foot',['common-place-spent']),
  fixture('common-turn-shadow','绕开晒墙去它背面，看见原鹅尾的影子爬到另一个可走的高门',36,12,[s('米拉','影子倒了个个儿。街还在那儿，说“顺着鹅嘴”已经不是同一扇门。'),s('荚黎','昔日鹅脚短，眼下影子长。你说俏皮话也给我留点力气爬。')],'common-long-foot',['common-short-foot']),
  mechanism('common-face-home','请屋里人朝自家内院开门，给后面的人留出转弯空位',38,17,[s('芋娣','别在低窗伸手，站满了我爸就连他家的门也开不了。')],['common-long-foot'],'common-high-door','街院已经倾斜，屋里人要怎样和队尾相接？',['沿仍挂着鹅嘴的低窗再挤一次','退过原摊口，让他从内院自己开高门，再迎队尾','在门前排紧，等屋里人把门往外推开'],1,'灶的短足已经没进水，低窗外还有人。绕到长影的墙背，空出内院开门的半圆。',[s('芋娣的父亲','我穿上鞋了。这扇门我自己开。丫头，我出去你别替我把鞋带系成死结。')]),
  witness('common-yard-arrives','跟芋娣父女跨到院子另一口，等最后一个人穿过去',35,18,[s('芋娣','门口那只鞋还在，我少了一班粮。老头儿你脚上穿谁的？'),s('芋娣的父亲','你妈留下的。等干了，我把自己那双拿给站队尾的小子。'),s('玛拉','这一队的人从屋里、从窗边和旧摊位散开，在另一面重新见面。它们没有和那些小艇一同走。')],'common-landed-street',['common-high-door'],{action:{type:'flag',id:'common-landed-street',set:'common-neighbours-out'}})],
 [exit(3,12,'oven-shadow-square',[6,15],'由旧摊回鹅影坪'),exit(39,18,'flood-stair',[13,14],'从已打开的内院高门抵达收粮坡上段',['common-landed-street'])]);

export const fleet=region('hulls-not-in-line','倾港 · 住户自己决定何时跟行的水窝',6,'north-sound',47,28,'water',
 [['building',0,0,12,7,'从旱地看像是后墙的洗衣阳台'],['boat',15,1,12,6,'原先相邻而今不能并行的两艘家艇'],['wall',33,2,5,11,'鲸身转弯时遮住近艇的弧肋'],['water',0,18,12,10,'潮迹卷回一扇墙下'],['boat',20,20,8,8,'最后一艘家艇不愿帮人运官方的货'],['wall',38,19,9,9,'外湾线从这里折向收粮坡']],
 [['pier',3,9,32,3,'每个艇头朝向自己家门的旧码头'],['rope',13,14,13,1,'湾面先收窄、后让开船头的两次泡纹'],['path',28,16,15,2,'等艇头在弧肋外露出来才看得见的回水线']],
 [witness('common-first-skiff','在最后一户船头把空船还给船主，听她愿意在哪儿接下一户',10,11,[s('晏栖','我这艇末班该替官库趸货。官家要我自己接人，往后一个月的保货钱就拿不到了。'),s('水裁缝乔纾','那交给我开。不是替我决定把家搬走，你们给我一句，我能不能自己挑回来。'),s('布兰','那月的钱由我跟你结，不捆人。第一船先去看转角，第二船由乔纾说何时出。')],'common-charter-spent',['common-wake-choice']),
  setting('common-call-too-early','在只见泡沫的直岸招手，听回应是否其实还在自己身后',17,12,[s('远声','等！你叫的是我隔壁的院子，艇头还藏在转角。'),s('伊沃','同一声招手从两堵墙都返了回来。先回来找能认出是哪一户的角度。')],['common-charter-spent','!common-second-free'],{'common-echo-only':true,'common-in-view':false}),
  fixture('common-own-gunwale','亲自随首艇到弧肋背面，看见乔纾艇上晾的两只异色衣袖',40,14,[s('玛拉','一个蓝袖，一个没染完的白袖。我这边确实看见人了。'),s('乔纾','看见了便先别招。我得让隔壁那只小艇从我门前走过。那孩子想跟他娘去，不跟艇大的人去。')],'common-in-view',['common-charter-spent']),
  witness('common-other-family','去外侧让出一道回水，等原本被挡的小艇自己选随哪位亲人离开',30,17,[s('小艇上的缰儿','我跟我娘。她那边有一只耳朵都没挂正的小狗。'),s('晏栖','让他先。我不把三只船拴到一起，那样走的是一个人的方向。')],'common-second-free',['common-in-view']),
  witness('common-sleeves-turn','等乔纾自己将白袖收下来，从水窝外缘照应她走完转角',40,17,[s('乔纾','第一船先靠，我知道是谁在等我。回头的路不要拿铁牌封掉。'),s('简杏','我先把靠墙那只空艇送回去。以后她想回门环那里，还是她自己开。'),s('晏栖','粮过不来我得去找布兰结账。能靠在我边上说这句话的人活着，比他写在库房里好。')],'common-landed-wake',['common-second-free'],{action:{type:'flag',id:'common-landed-wake',set:'common-neighbours-out'}})],
 [exit(3,11,'oven-shadow-square',[37,18],'随可以回家的船回水窝'),exit(41,18,'flood-stair',[22,14],'随住户选的舟路抵达收粮坡外侧',['common-landed-wake'])]);
