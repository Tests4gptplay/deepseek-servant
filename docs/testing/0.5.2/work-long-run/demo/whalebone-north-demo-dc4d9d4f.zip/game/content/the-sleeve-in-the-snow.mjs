import {platform,invitation,collision} from './the-sun-on-the-other-face.mjs';
import {say as s,person,object,exit} from './parts.mjs';
import {spoken} from './voyage-parts.mjs';
export const winter=platform('windloom-rime-field','冬岸 · 晒幅架背后的霜白田',5,30,22,'stone',
 [['wall',0,0,7,5,'有铁色裂隙的霜坡'],['building',11,0,8,5,'卷布工的暖屋'],['water',24,0,6,6,'寒雾刚散的岛汊'],['wall',0,16,8,6,'发白的火山岩'],['building',15,17,7,5,'晒工熬麦汤的石灶间']],
 [['path',2,9,25,3,'冻土下不结壳的接手路'],['wl-frame',14,7,7,3,'轮座扣住有霜的三叶抻幅'],['wl-shadow',7,12,4,2,'雪上向针尖挑起的一条湿影'],['wl-gear',21,12,4,2,'晒工夜里也能摸清的三个凹位']],
 [invitation('winter','在白幅反面骂人的晒工袁叠',8,9,[
 s('袁叠','别朝布叫我的名字。冻着的缝会把声和影都送到另一面去。用手搁住那条湿影，往下找我。'),
 spoken('符荻','我的第一匹还整着。今天把它铺给你垫膝，踩脏了也由我认。','windloom-north-kept'),
 spoken('符荻','我那匹红的有道毛边，这回摸到毛边就知道自己在反面。你认我的手就行。','windloom-north-scar'),
 s('瑟琳','白处不一定冻硬，贴着水汽的一叶最沉。我先在中轴用手背摸，你站的那一叶留给你自己喊重不重。'),
 s('袁叠','行。我在这儿，不替另外一个人喊“可以走”。')],['party:mira','!harbor-tilted'],[s('袁叠','三叶霜架在吊布墙后。那一面过去也有路可回。')]),
 collision('winter','windloom-rime','走入三叶冻帆轮的实作距离',17,10,[s('米拉','先从左边斜过的三角影定哪叶已翻。反面还在滴水的那一叶会压回来；贴边的短手不是空着的人。')]),
 person('windloom-rimed-hands','晾开两只冻手套的袁叠',11,12,[
 spoken('袁叠','有人替我站过湿影最重那一下。我今天能戴着自己那只手套回暖房，先自己拧干，然后才借旁人。','windloom-winter-kept'),
 spoken('袁叠','第三叶回去前，是我把右手厚手套丢进缝里卡住的。手毫发没伤，接下来两班少一只手套不能碰湿布。我得去暖房管火，班钱比晒架少。','windloom-winter-scar'),
 s('霁葵','你先说愿不愿意改那两班，别让我们把照看你写成替你作主。'),
 s('袁叠','调班是我自己选。我会把还能握针的人请来。你们到斜港找我，看我在做哪件事。')],{requires:['windloom-winter-done']}),
 object('windloom-winter-lunch','晒工放在干石上的小盅，不需购买或磨经验',22,11,[s('袁叠','这盅给摸湿布的人。沿背风架走起来，有气再动协作技也不晚。')],{requires:['windloom-winter-done'],action:{type:'item',id:'brine-dose',value:1},after:[s('袁叠','灶底只余糊锅巴了，等来年我再熬。')]}),
 person('windloom-snow-count','背着红毛刷扫雪的草芝',5,12,[s('草芝','我把雪扫到阴面，春天它化得慢；你把毛刷往阳面搁，明早拿得动。')])],
 [exit(2,9,'lee-mouth',[9,7],'从背阴石脊回外海入口')]);
export const harbor=platform('windloom-slant-court','锚断之夜 · 倒兜四面布的晒帆廊',6,36,24,'wood',
 [['building',0,0,9,7,'被斜帆压住的长街作坊'],['wall',13,0,5,6,'四角攀住的长梁'],['building',23,0,9,5,'两层带天井的晒布工房'],['water',0,17,10,7,'歪进舷水的低端'],['building',16,18,7,6,'撤走孩子后的补帆小学徒屋'],['wall',29,17,7,7,'海面已从铜扶手下过来']],
 [['path',2,10,30,3,'从天井出去的高街'],['wl-frame',12,7,9,4,'旧晒帆棚被风兜成一面倒翼'],['wl-shadow',6,14,6,2,'港城斜落后的第四道影'],['wl-gear',26,11,4,2,'中轴、上风与接网的错层平台']],
 [invitation('harbor','半只脚踏在天窗外的霁葵',8,12,[
 s('霁葵','靠门那家有人还在天井。我是收租的，常说遮棚结实，今天它倒成了兜人的东西。我先出去把最远那边的人叫回来。'),
 spoken('符荻','师傅，把我亲手缝的红角剪了也行。你在北线接住的是我，红角没资格替我说不。','windloom-north-kept'),
 spoken('符荻','上回我用牙咬破的地方藏不到布里面去了。我站在这里，让你看得到我什么时候撒手。','windloom-north-scar'),
 spoken('袁叠','我能握湿索。冬岸那一下有人换过我，今天我能去最冷的角。','windloom-winter-kept'),
 spoken('袁叠','我在暖房换了班，右手空着。高处那根我攥不牢，我把人一个个从亮处带出去。','windloom-winter-scar'),
 s('玛拉','我原会把布往一个人的脸上盖。今天要把它往上抬，叫每个人自己选方向。')],['clutch-still','!grave-signed'],[s('霁葵','通往撤离船的原高道还开着；你若留下，我们就在此处一块做完。')]),
 collision('harbor','windloom-canopy','进入倒翼天井，应对风从三面翻来的变局',18,12,[s('伊沃','倒翼第一下吹向低沟，随后会从架底回冲。看见别人脚滑时先报是哪一个人。')]),
 person('windloom-canopy-owner','靠着没倒下的染墙说话的霁葵',24,13,[
 spoken('霁葵','我叫袁叠抬过脸，看见有人把本人的好脚位让出来。第一排工人自己出了廊，整扇晒帆也还挂着。下月还要交工，我想重新画下护人的脚位。','windloom-harbor-kept'),
 spoken('霁葵','那一下没等到人接，符荻先剪开了画着她名字的角。大家都出来了，作坊少了整整一季的遮风活。我会照付这季的工钱，不把坏账写在她手上。','windloom-harbor-scar'),
 s('符荻','我下次要把名字缝到人站着看得见的那面。')],{requires:['windloom-harbor-done']})],
 [exit(2,12,'flood-stair',[23,8],'回到布廊外原有的撤离石阶')]);
