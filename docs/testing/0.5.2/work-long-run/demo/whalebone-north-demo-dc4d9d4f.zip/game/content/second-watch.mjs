import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit,flag} from './parts.mjs';
import {setting} from './registry-parts.mjs';
import {quarter,lastBell} from './watch-village.mjs';
const second=region;
export const calendar=second('watch-calendar','次航 · 挂着两种年份的值灯屋',1,'harbor-interior',25,16,'wood',
 [['building',1,1,5,4,'现任灯手的家'],['wall',11,1,6,4,'上一航年的钟眼'],['crate',18,10,7,6,'还给家属的旧值灯袄']],
 [['path',2,8,18,2,'一年后的送灯小路'],['lamp',12,7,1,1,'不靠近海的暗灯']],
 [witness('enter-night-watch','跟曾在远窗里打下手的沅籽开夜班',8,8,[s('沅籽','我娘打你父亲船上下来时还不会抱我。十七年前那夜失踪的不是她，是把我裹起来带去远窗的人。你们在墓上已经写完的那两句，我不来改。'),s('玛拉','所以这次由你定从哪里看？'),s('沅籽','我只亲眼见过一道门的里面。你把那把新钥匙挂回去，站我当年的板凳上。灯还没亮，我们从黑里开工。')],'watch-entered',['afterwatch-open']),
 person('paper-back','前航之后留封的一张小纸',15,8,[spoken('沙荷的笔迹','公开账的人靠仓守的章拿到了灯油。讲旧灯时请说清，油多不等于开门的人多。','memory-public'),spoken('筝的笔迹','那夜有人愿陪我回家；没人因此多出过一双眼。如今你去查旧册，少替你看不见的人下结论。','memory-witness'),spoken('玛拉','前航我先列过责任。今天我把旧灯人留下的空行放在自己的两句后面。','memory-fault'),spoken('玛拉','前航我先说救回的人。今天我把他们当中谁能看见哪道窗也分开记。','memory-names'),s('沅籽','这是前一年留下的信。别带去当作旧日的证物。')])],
 [exit(21,8,'lamp-back',[3,8],'从沅籽当年的后门入检修夹层',['watch-entered'])]);
export const back=second('lamp-back','次航 · 旧漆后面的双窗夹层',2,'whale-interior',28,18,'wood',
 [['wall',0,0,28,3,'伊沃从来没见过的隔灯背板'],['crate',3,4,5,3,'检修工的湿木鞋'],['wall',12,3,6,4,'滴进煤油的白釉线'],['crate',20,12,8,6,'借光的三块小玻璃']],
 [['rope',3,8,20,1,'门里面才能松的压灯绳'],['lamp',15,9,1,1,'红漆内的蓝色月牙']],
 [witness('little-boots','在旧鞋架找沅籽小时候的脚位',8,8,[s('沅籽','我那时脚够不到地。鞋套在湿板凳外，脸正对着门的背面。你们齐腰的地方，是我当年的眼睛。'),s('玛拉','按这个高度，外面的人拉过一次绳，里面木片遮住了哪一道光？'),s('沅籽','我听到先三下短，再一声长。你得自己在两扇窗试，我不能把声音说成颜色。')],'watch-height',['watch-entered']),
 setting('peel-face','从门外平视红漆',13,8,[s('沅籽','这一层是后来过冬补的，亮得跟急灯似的。用它追我的夜班，时辰就会颠倒。')],['watch-height'],{'watch-inside':false,'watch-outside':true}),
 setting('peel-back','站上低凳侧照红漆背面',18,8,[s('玛拉','夹层里先是蓝，再是红。鼻间是鱼胶，不是那晚用的快干灯油。'),s('沅籽','先别剥下来。拿着低凳的视线去找门外另一片还没换过的玻璃。')],['watch-height'],{'watch-inside':true,'watch-outside':false}),
 fixture('label-lamp','给漆层标定先后，保留背面的木压痕',10,10,[s('米拉','外层红漆和内窗抢修单用的是同一季鱼胶。我把它画在第二天的边上，已经不能拿它指控关灯那一刻。')],'watch-paint-order',['watch-inside','watch-shard'])],
 [exit(2,8,'watch-calendar',[20,8],'回值灯屋翻前一年的信'),exit(24,8,'ferrule-shed',[3,8],'往漂落的废玻璃和旧铜铃棚',['watch-height']),exit(14,13,'bell-quarter',[3,8],'带漆层时序走向背窗街',['watch-paint-order'])]);
export const ferrule=second('ferrule-shed','次航 · 不会同时受光的修铃棚',3,'harbor-interior',22,15,'stone',
 [['wall',0,0,22,2,'带两条销痕的靠石'],['crate',4,3,5,4,'未磨平的蓝玻璃'],['building',13,2,7,5,'藏铃舌的褪色小柜']],
 [['path',2,8,17,2,'低凳高度的试灯尺'],['lamp',10,7,1,1,'照旧木销的侧灯']],
 [witness('blue-shard','请补网人从筐底取一片没换过的蓝玻璃',9,8,[s('补网人','有个男人抱着孩子从外面爬下来，衣领里夹了这个。我修窗时拿鱼胶补了另一片，这片是他女儿不让磨掉的。'),s('沅籽','我就是那个孩子。你还记得他怎么叫我吗？'),s('补网人','忘了。那天风比人名响。别拿我今天心软填上这个洞。')],'watch-shard',['watch-height']),
 fixture('two-strikers','把双铃舌按潮绳的长短分槽',15,9,[s('沅籽','短绳拉了三下，长的才接。铜面只有短舌朝上带刮口：第一下响在近窗，不是远窗也响过。'),s('玛拉','你失踪的那个人一直在外面，他该先收到哪一个声音？')],'watch-bells',['watch-shard'])],
 [exit(2,8,'lamp-back',[23,8],'退回低凳取漆层'),exit(18,8,'bell-quarter',[13,9],'循听见过的三个短音去后街',['watch-bells'])]);

export const watchMaps=[calendar,back,ferrule,quarter,lastBell].map(map=>({...map,campaign:'afterwatch'}));
