import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit,flag} from './parts.mjs';
import {setting} from './registry-parts.mjs';

export const common=region('bread-turn','白崖 · 面坊轮工的双头街',1,'harbor',32,21,'stone',
 [['building',0,0,7,6,'清晨出炉、晚上借门的双开面坊'],['wall',10,0,4,7,'人车分道的炉烟高脊'],['building',20,0,7,6,'天亮前要接小艇伤员的接诊窗'],['water',0,15,10,6,'挑炭人能走低边的卸煤河'],['crate',22,15,9,5,'面粉和木炭分开的雨篷']],
 [['path',3,9,25,3,'上边给担架、下边给送炭车的旧街'],['stairs',11,6,3,9,'并行的两级路坎'],['rope',16,13,11,1,'炭工皮带宽度的拉手索'],['hearth',2,3,2,1,'面饼发起的暖灶'],['crate',24,16,2,2,'码在潮线以上的炭袋'],['lamp',19,8,1,1,'天不亮也能看见面屑的白灯']],
 [witness('crumb-master','揉一半面团就出来的阿榆',8,9,[s('阿榆','别踩那一片白，我今天第一盆面！天亮有人从巷头抬来，我认得那只坏脚。也是这个钟点炭车进来，我们的门要一头腾给谁？'),s('玛拉','我要从这里送我父亲。你可以叫我改路。'),s('阿榆','改谁的路都要有人陪着走一遍。我把热面团分成两块，夹一道印，等你回来看看哪边干了。')],'crumb-asked',['coffin-aboard'],{after:[spoken('阿榆','你陪炭车走过积水边，第一炉烤晚了，一样有人买落温的麦包。','crumb-road'),spoken('阿榆','担架从短门进来没挤着炭簸，你们把它的费力绕路也讲给人听了。','crumb-bench'),s('阿榆','当班人的钱不能给我，饼也不好拿来替。')]}),
 witness('carry-brother','候着给妹妹换药的亚稗',17,10,[s('亚稗','她一抬起来就晕，不是不能走。我把面包切开不抹蜜，她闻见烤甜饼就难受。急的人站在这儿说话，你们总听不见。')],'crumb-bed',['crumb-asked']),
 witness('carry-coaler','膝弯夹着旧皮护的炭工伏岚',24,9,[s('伏岚','你在上面看我，觉得我比别人能扛。秤下来我不能比谁多扛一袋。走低边会湿一层炭，到时我的工账跟着轻。')],'crumb-cart',['crumb-asked']),
 setting('bread-prow','将两张面样放到同一扇暖炉口',12,10,[s('阿榆','同口烘当然一块儿干。街东窗漏风，河边地回潮，你总得带一张真正走出去。')],['crumb-asked'],{'crumb-tested':false}),
 setting('bread-width','用窄车走过低沿，认出发软的是水不是炉气',19,12,[s('伏岚','薄饼一掰就黏，轮子在最轻的地方打滑。退回来，记得谁跟你一起推过。')],['crumb-bed','crumb-cart'],{'crumb-tested':true}),
 person('bread-pledge','在面案约下次日两头的班',15,9,[s('阿榆','窗边通伤员，低边走煤。你可推炭车绕开一支担架，也可陪家属沿长雨棚去诊窗，炭车过短巷。哪边都要让出你的肩。',[{text:'我跟伏岚推车走低边，记下发潮的炭',set:'back-coal'},{text:'我陪亚稗过长雨棚，把短街给炭车',set:'back-cot'}]),s('玛拉','签谁就陪谁，逢人记得让出门。')],{requires:['crumb-tested'],lockedText:'当事人一个在诊窗前，一个在低沿。面样同放炉口量不出湿度，需推窄车过低街一趟。',action:flag('crumb-booked'),after:[s('阿榆','过了二班，到三班场的北肩找亚稗，或去过秤台找伏岚。摸到送达的面才算数。')]}),
 person('baker-swallow','把小面团搓成长脚鸟的萝豆',9,13,[s('萝豆','我不敢给阿姨送一整只。掐了头剩个圈，她戴手腕上，就用不着人记她吃没吃。'),spoken('萝豆','煤泥上的面鸟脚断了，我给它捏一条瘸脚。','crumb-road'),spoken('萝豆','雨棚的长椅上还有一粒荞麦，摸过去是干的。','crumb-bench')])],
 [exit(3,10,'wake-court',[22,8],'沿炉烟回摆灯院'),exit(28,10,'shift-square',[19,8],'从炉坊口进二班场',['vigil-finished'])]);
export const cartHelp=witness('crumb-trolley','同伏岚把低街炭筐扶上过秤台',13,9,[s('伏岚','把衣摆掀开，里层炭是湿的。你在秤边说清楚，有多少潮水不该算到我的工钱里。'),s('玛拉','浸水的三层另过筛。亏掉的那半篓我跟阿榆一道向租路的人记。'),s('伏岚','我不是请你讨情，这张是货损签。拿去叫他们自己算。')],'crumb-road',['back-coal','shift-receipted'],{action:{type:'flag',id:'crumb-road',set:'crumb-met'}});
export const bedHelp=witness('crumb-stretcher','用雨棚矮门把亚稗的妹妹送进诊窗',22,9,[s('亚稗','那条门槛不高，是我怕她晃。你的腰再低一个拳头。好，她自己说看得见里边的白墙了。'),s('苇孚','哥，你把蜜拎远点。我要闻刚出炉的面皮。人家门都给你挪了，你还板着张脸。'),s('玛拉','我回面坊说她亲口要的，不拿你的点头代她。')],'crumb-bench',['back-cot','shift-receipted'],{action:{type:'flag',id:'crumb-bench',set:'crumb-met'}});
