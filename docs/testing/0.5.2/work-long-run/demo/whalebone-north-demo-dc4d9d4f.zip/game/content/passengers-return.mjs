import {region,witness,fixture,spoken} from './voyage-parts.mjs';
import {say as s,exit,person} from './parts.mjs';

export const apron=region('boat-back-by-supper','冬岸 · 能看见去船却看不见归船的晚饭埠',5,'north-sound',42,26,'stone',
 [['water',0,0,42,5,'停泊的空艇都露着浅色腹带'],['building',2,5,9,4,'四张病床的背后墙'],['crate',17,4,6,5,'短途驳留下的两份口粮'],['boat',31,3,10,6,'试船梨青有一道旧磕痕'],['water',0,18,12,8,'通向落日那侧的散冰'],['building',27,19,15,7,'为了不烧过时把面揉成船形的作坊']],
 [['pier',3,10,34,2,'出发踏口在西，归来在烤炉的背风面'],['rope',9,15,22,1,'挂在房檐下、从海上会看丢的饭钟'],['hearth',29,13,2,1,'背海也能闻见的黑麦气']],
 [witness('return-proposal','跟立在出发影里的米船雇工和麦面师说清这次怎么验',9,10,[s('麦面师芮满','小船来过，知道啦。问题是我姑妈想回去。你能把她送回来吃晚饭吗？被人带到北边等一冬，不是同一回事。'),s('桨工晏栖','我姓晏，跟她家没人情。港务厅付我这半程，回去要是空船，前街还得挨饿。'),s('瑟琳','试一次真正往返。把梨青空着送过去，再放我们平常要运的东西，看她还进不进得了原口。'),s('玛拉','别等我回来才定输赢。带上人或粮，能让船再挨着这家的踏口，才算。')],'return-terms',['moor-proved','bed-count','!winter-proof']),
  fixture('return-push-light','站到原踏口放开空梨青，目送艇底划过店旗影',18,12,[s('伊沃','空的时候眼睛只要盯那面红旗。船底过了。你上来，要装的都还在船尾。')],'return-empty',['return-terms']),
  witness('return-feed','把余下的舱位装粮，让芮满亲手扒掉过宽的烤盘框',27,12,[s('芮满','姑妈，我少带你一个晚上。你若不肯住，这是我欠你的，不是你自己改的主意。'),s('荚黎','那就让我骂你。左口那袋不系死，前街的孩子会把牙咬在袋绳上。'),s('晏栖','粮走这一趟。我们给人留的那一席就空不出来了。')],'return-ration',['return-bogged','!return-party'],{action:{type:'flag',id:'return-ration',set:'return-party'}}),
  witness('return-riders','牵出自愿往返的两人，当面把赶不上这班的粮放回烤房',30,14,[s('荚黎','我只答应去看。不要在你们床脚上写我的姓。'),s('换班的小艇匠槐粒','同一条路，我想走两遍。一次是你送我，一次是我能自己回来。'),s('芮满','一舱面留这儿。我在港务厅有顿夜饭，撤掉我的，别去刮小孩的盆。')],'return-riders',['return-bogged','!return-party'],{action:{type:'flag',id:'return-riders',set:'return-party'}}),
  person('return-baker','把船形面包折了船头的麦面师',34,15,[s('芮满','当船吃从哪头咬，算船首还是船尾？'),spoken('荚黎','我从中间咬。省得有人逼我挑哪头是家。','return-riders'),spoken('晏栖','就给我没脑袋那条。没脑袋也该有饭吃。','return-ration')]),
  witness('return-taste','回到炉后各自认出归来的船和没能带上的东西',23,14,[spoken('前街的芋娣','还暖。我跟我妹分。明天在哪儿吃我不知道，今天这袋是真到我手里了。','return-ration-home'),spoken('荚黎','粮到了，我没搭上。看过你们的蓝水也不会替我爬自家楼梯。我要听他们打算怎样回去接人。','return-ration-home'),spoken('槐粒','我愿意带下一班过来。我不是替她报名。','return-riders-home'),spoken('荚黎','我自己回来，也自己说不搬。芮满，那顿夜饭不能再赊给你姑妈。','return-riders-home'),s('玛拉','这回船回来有人接着。去把原口那道搁痕也给布兰看，不能只给他看船。')],'return-crossed',['return-home'])],
 [exit(3,11,'winter-ward',[6,10],'穿烤房背墙回冬岸的病床边'),exit(35,12,'keel-in-shadow',[5,11],'踏上梨青去试红旗影下的归路',['return-empty']),exit(32,16,'keel-in-shadow',[30,17],'回低口看梨青先前停过的位置',['return-home'])]);

export const sound=region('keel-in-shadow','冬岸 · 红旗看得见却不能原样归航的小湾',5,'north-sound',44,27,'water',
 [['wall',0,0,12,6,'烤房西墙阴影只盖住空艇一半'],['wall',17,0,8,10,'原口下宽，落着两道深浅不同的磕印'],['water',34,0,10,8,'未转向的平水'],['wall',0,17,16,10,'风面对岸红旗整天都展得很直'],['wall',19,17,5,10,'把左侧短槽与右侧的弧门分开'],['boat',35,19,9,8,'漂泊的小船从不靠红旗寮的那一侧']],
 [['pier',3,10,32,2,'能走到空艇磕痕又可绕行到西面的短浅路'],['path',25,15,14,2,'岸在漂、烤炉烟的影子跟着屋跑'],['sign',29,13,1,1,'须看门口的人而不能只看一面旗']],
 [fixture('return-load','站到原口船尾接下两人重的试载，再从舷边看旧旗',12,11,[s('米拉','红旗还在我指尖。可我的靴尖碰底了。'),s('槐粒','我推你一次。你看，旗跟昨儿一样亮。船却在泥里。')],'return-loaded',['return-empty']),
  fixture('return-mud','在原红旗下面推一回真正坐浅的满载艇，跨下去看那条黑印',7,13,[s('晏栖','回来得比空艇低了一掌。肚子上多了这条泥。要有人说“空的既行，装了自会行”，我就把这半条裤子给他看。'),s('荚黎','用你自己的裤子。我不替你们交棉裤。'),s('玛拉','到埠上取真正要运的。只有一趟，自己开自己的价。')],'return-bogged',['return-loaded']),
  fixture('return-find-kid','从弧门边趴低，找到先前隔着盐面看不到的炉后半扇绿窗',29,12,[s('米拉','站着看见红旗，低下来看水面那块绿。不是海绿，窗子张开时才有。'),s('芮满','晾面要开下半扇，我欠潮婆子一口锅，见她只敢开上半扇。今天欠她第三天。')],'return-low-window',['return-party']),
  fixture('return-grain-way','沿低弧让船靠着绿窗黑影进来，逐袋递上炉后那个短阶',36,15,[s('前街的芋娣','我只够得着尾袋。给我，我回头递，你不必为了拿好看把我挤开。'),s('晏栖','六袋都登岸，今晚这家的炉工不用翻苔根。人座还空着没带来，说的时候把这句带上。')],'return-ration-home',['return-low-window','return-ration'],{action:{type:'flag',id:'return-ration-home',set:'return-home'}}),
  witness('return-pass-oar','在绿窗外把回港这半程的桨交给槐粒，等荚黎自己决定下哪一边',27,16,[s('槐粒','辨着了。烤房开下扇，水下有绿鱼。你们把手放膝头上，让我自己送她回去。'),s('荚黎','右脚先。别把我拽进冬岸家的队。我不是来登记的。我就是来看，回程我想坐朝娘家的那边。'),s('玛拉','她们两个人都回到她们说要下船的地方。前街这次没多一袋麦。')],'return-riders-home',['return-low-window','return-riders'],{action:{type:'flag',id:'return-riders-home',set:'return-home'}})],
 [exit(3,11,'boat-back-by-supper',[34,12],'从原踏口把搁船的位置带回去'),exit(37,16,'boat-back-by-supper',[22,14],'穿绿窗后的弯到烤炉背面',['return-home'])]);
