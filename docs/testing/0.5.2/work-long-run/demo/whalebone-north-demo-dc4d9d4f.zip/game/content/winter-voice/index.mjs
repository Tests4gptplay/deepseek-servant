import {porch} from './porch.mjs';
import {glass,keel} from './ice-and-keel.mjs';
import {mouth} from './shore-mouth.mjs';
import {bone} from './inside-the-bone.mjs';
import {person,witness,exit,say as s} from './cast.mjs';
const compare=witness('whalefall-agree','请水下和岸上的记录人把两组读数放到一张桌子上',15,12,[s('崖枝','拿冰钉去叫它，会把你的声音送回来。贴在空船上，是它自己从你身边过的。'),
 s('洛洄','昨夜没有人从浮台落水。老的在前，小的在后，偏有人在等救生船。换信号得和岸上预备着救人的一块做。')],'whalefall-two-readings',['whalefall-glass-known','whalefall-wood-known']);
const lastMeal=witness('whalefall-put-back-cup','把两只杯放回水边，让姐妹自己留下今晚的说法',19,12,[s('洛洄','今夜谁都没叫谁回来。我不指望明天三道涡还照样转。妹，把盐从水底递我。'),s('崖枝','你桌上的碟子被我拿来舀过水。先拿布擦干再盛，不然谁都吃上一口海。')],'whalefall-family-supper',['whalefall-watch-sent']);
const endWool=witness('whalefall-shore-count','听见泊岸木桩上传来绒钟，给后船把浅汊留空',19,12,[s('槐梢','钟留在木桩上，小的走过，后舱的人才递出第一个药包。我站到退潮才换靴。')],'whalefall-flood-account',['base-safe','whalefall-early-log','whalefall-wool-set']);
const endOil=witness('whalefall-shore-lamps','在疏散船边接住熏鱼家的两只余油筒',21,12,[s('寇仁','两盏灯还给你，底下剩一层凉皮。后船认准了叠在一处的亮圈，擦过去时看得见幼鲸换了哪一边呼气。')],'whalefall-flood-account',['base-safe','whalefall-early-log','whalefall-lantern-set']);
const stone=person('whalefall-last-knot','在墓坡听崖枝把一股空绳抖直',21,13,[s('崖枝','我没法整天上岸，他出殡的时候我只能在坡下。你准我把一头系在水里，水涨了就看得见来过。')],{requires:['grave-signed','whalefall-flood-account']});
export function withWinterVoices(world){
 const maps={...world.maps};
 const add=(id,extra,exits=[])=>{const m=maps[id];maps[id]={...m,entities:[...m.entities,...extra],exits:[...m.exits,...exits]};};
 for(const m of [porch,glass,keel,mouth,bone])maps[m.id]=m;
 add(porch.id,[compare,lastMeal]);add('lee-mouth',[],[exit(19,13,porch.id,[3,10],'绕着木灯去洛洄家的半张水桌',['winter-welcome'])]);
 add('safe-keel',[endWool,endOil]);add('burial-cape',[stone]);
 const quests={...world.quests,
  'whalefall-listening':{id:'whalefall-listening',name:'沿冰折返，从船底过去',kind:'side',startFlag:'whalefall-invited',endFlag:'whalefall-family-supper',stages:['whalefall-invited','whalefall-cups','whalefall-glass-known','whalefall-wood-known','whalefall-two-readings','whalefall-watch-sent','whalefall-family-supper']},
  'whalefall-empty-strand':{id:'whalefall-empty-strand',name:'五股绳里空着一股',kind:'hidden',startFlag:'whalefall-shed-clue',endFlag:'whalefall-owned-toggle',stages:['whalefall-shed-clue','whalefall-found-knots','whalefall-child-song','whalefall-owned-toggle']}};
 return {...world,maps,quests,equipment:{...world.equipment,'whalefall-bone-clasp':{name:'五股空心暖骨扣',slot:'charm',resists:{cold:.16,tide:.09}}}};
}
