import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {mechanism} from './district.mjs';

export const wash=region('wash-sledge','白崖北坡 · 殓舟靠过的洗帆间',6,'harbor-interior',29,20,'wood',
 [['building',0,0,8,7,'给家人留的后房'],['wall',12,1,4,6,'挡住外人目光的屏风'],['crate',20,3,8,5,'逐件包好而不出售的遗物'],['water',18,15,11,5,'浸过湿帆的浅渠']],
 [['path',2,9,24,2,'能平推篮床的走道'],['rope',8,12,13,1,'由见证人各持一面的收带'],['lamp',17,8,1,1,'每一名无名死者都分得到的灯']],
 [witness('wash-boat','请接船人把逝者真实来路交给玛拉',8,9,[s('接船人','刚送来的不是你养父。她死在涨水前，渔排在退潮后托起她。她左边袖口缝了鸟足，围巾里塞着别人的铜牌。不要拿牌猜姓名。'),s('玛拉','父亲可以在帘后等。我把人和来处并记，把围巾和铜牌先分开。想来认的人可以只认自己的那件。')],'wash-brought',['base-safe']),
  fixture('wash-gather','撤下浸海旧帆，亲手平托后颈与膝窝',13,9,[s('玛拉','指结还扣着一段湿草。把草和衣留在同一只包里，别把铜锈都擦掉；宽肩的短衣可以是别人借的。'),s('伊沃','让我把帘子合拢。有人认东西前，给她穿回干衣。')],'wash-lifted',['wash-brought']),
  fixture('wash-pair','把铜牌的倒纹和鸟足补线分到两屉',19,10,[s('米拉','牌背压得一边亮，绑带在右；袖口是左手往里打的两结。一个是遗物，一个还要找认得手艺的人。')],'wash-pairs',['wash-lifted']),
  mechanism('wash-order','玛拉在无人旁观的帘里定殓法',23,11,[s('玛拉','没有坐席的谁，我们也按有人会来找她的办法安放。我把这一趟运柩人该做的做完，再写自己的墓碑。')],['wash-pairs'],'wash-laid','两件标记相冲，先怎样安置这位乘船人？',['按铜牌先刻姓名，再请家属修正','保留各自位置、缝好干衣，两旁留出能复认的收带','将所有湿物晾成一堆，衣服等写好名再还'],1,'铜片可借，补线也要由活人核。先给她盖上干衣，再让活人分别认物。',[s('玛拉','我把她移到里间，不让待确定的名字挡住安葬。')]),
  witness('wash-map-sign','米拉把只亲见的一段北流签在舆图上',15,12,[spoken('米拉','我承认那次把白脊当岸，扁蒲因我迟工。这幅新图仍不写她离家时去了哪儿。','wren-drift'),spoken('米拉','两名艇手用反线领我们到了固定黑钩。图可以证明水向，不证明这人愿意去哪儿。','pearl-teaching-done'),s('米拉','我署自己的名字在“捞起于这条回水线”，姓名栏留给见过她的人。有人若问责任，也会找到我。')],'wash-map',['wash-laid','party:mira']),
  person('wash-cook','用湿布盖着出锅面包的劭芎',10,12,[s('劭芎','以前有人来认衣，我就烤一条硬边面包。能不能说出名字都可以吃。你拿一块放里间，别拿去压纸。'),spoken('劭芎','现在人被放稳了。外边还等的那两位，今晚也吃得到热的。','wash-map')])],
 [exit(3,10,'safe-keel',[12,11],'推空殓舟回引航驳'),exit(24,10,'braid-porch',[4,9],'去岸上等候的亲友屋核两份来路',['wash-map'])]);

export const porch=region('braid-porch','白崖北坡 · 不把人挂在公牌上的回廊',6,'winter-village',31,21,'stone',
 [['building',1,1,7,6,'绳鞋匠原来住过的低屋'],['building',13,1,5,6,'由来者自己开启的认领间'],['wall',22,3,8,5,'不公布姓名的低墙'],['crate',3,15,6,6,'各人分别领回的旧物']],
 [['path',2,9,26,2,'家属能选择停步的回廊'],['lamp',12,8,1,1,'挂在布帘里面的小灯']],
 [witness('braid-tag-owner','让遗失铜牌的陶工先自己来认',9,10,[s('卢盐','那是我的牌。我把围巾借给她，铜牌没拆。我活着。你们别给我娘一整夜丧信，也别叫她替那个人谢。'),s('玛拉','这枚还给你，登记哪一件作废。她是谁，是另一户可以选择回答的话。')],'tag-returned',['wash-map']),
  witness('braid-private','帘内问缝鸟足的亲友璃岸愿不愿留下名字',15,9,[s('璃岸','她叫岑茴。左手总把鸟足缝向内。只有同船的人和我认得这个结。你肯先把铜牌还了吗？倘若把我住处写公开，我宁愿只放那段草。'),s('玛拉','只向需要领物的家人开一扇门。她的衣我缝好了，你可以坐一会儿再答。')],'braid-known',['tag-returned']),
  fixture('braid-letter','持原退件背面的两行航记来求私下复认',19,10,[s('米拉','这一角有油水晕，北航那封退件第一次垫过她借的艇底。我不能替璃岸说“是”，只把两行实际来路交给她。'),s('璃岸','回水的篙印、鸟足结和我所见都合。我肯留岑茴在家属簿里，纸条的住处撕下来给我。')],'kin-name-permit',['braid-known','night-paper']),
  fixture('braid-seam','用独立带回的两道湿线请当班船员作证',21,12,[s('绪白','她把我从旧网里捞上来，不是用这面来换我替她说话。左侧内扣是她扯破后自己缝的，我认得那两种绳。'),s('璃岸','你们亲眼见过不同的事。我也有权只给家属留一个名字。')],'kin-grate-permit',['braid-known','grate-aboard']),
  witness('braid-name-from-chart','在帘内私簿收下璃岸同意的一行名字',11,12,[s('璃岸','只写岑茴、左袖与找到她的水线。请你别在街口挂那枚牌，我要自己带一束草去见她。')],'buried-with-name',['kin-name-permit','!burial-disposition'],{action:{type:'flag',id:'buried-with-name',set:'burial-disposition'}}),
  witness('braid-name-from-grate','由归来的船员护送家属签名',17,11,[s('璃岸','从舱底一块活着出来的证人我愿见。签岑茴，见证只写两份手艺，跟我到墓前的人不必报住址。')],'buried-seam-name',['kin-grate-permit','!burial-disposition'],{action:{type:'flag',id:'buried-seam-name',set:['burial-disposition','buried-with-name']}}),
  witness('braid-open-name','按璃岸意愿将公开墙留空，把物证与人相伴',24,10,[s('璃岸','把鸟足缝线安放好，留衣的地方告诉家属。我的姓不进街牌，我自己明年还来。'),s('玛拉','我写“退潮弯，干衣，身边有草”。空处留着，她已经安葬，不必为了我们心安借一个名字。')],'buried-in-care',['braid-known','!burial-disposition'],{action:{type:'flag',id:'buried-in-care',set:'burial-disposition'}}),
  person('braid-dyer','手上还有茶渍的称藕',8,12,[s('称藕','来问有没有人来的人很多。里面有人了，说没说名字我都把茶端进去。'),spoken('称藕','纸角封好了，街牌仍空，璃岸端一杯给卢盐也没有要他道歉。','burial-disposition')])],
 [exit(3,9,'wash-sledge',[23,10],'由亲友回廊回洗帆间'),exit(27,10,'burial-cape',[9,11],'与家属送别后回养父的棺车',['burial-disposition'])]);
