import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {mechanism,tidePost} from './district.mjs';
export const split=region('sheared-lintel','锚断之夜 · 只能损失一件东西的斜楣',6,'whale-city',37,23,'wood',
 [['water',0,0,37,5,'已经灌入下街的白港内潮'],['building',2,4,8,5,'还能拆门却得吹一冬风的原铺'],['crane',15,3,6,6,'铺面皮篷可以给人铺作半坡'],['building',26,3,9,6,'没有横门就无法锁住的铺后卧室'],['water',0,16,11,7,'脚下逐渐高过石脚的回滩'],['crate',25,16,12,7,'仍被自己的门拦在外面的鞋架']],
 [['path',3,10,30,2,'横楣有门板和幕索两种过法'],['rope',9,13,17,1,'由铺主自己挑肯舍的那一件']],
 [witness('split-price','问两铺主人谁还愿意开能过人的缺口',10,11,[s('沉笛','我的门能拆，当坡又平又硬，可我家猫狗以后再没法关住。那面皮篷若割了也成，另家这季的摊就淋雨。'),
  s('矾当','我和她一家开了十八年邻铺，哪有值不值得。你要用哪个，告诉那个主人，好叫他们自己下手。',[{text:'请沉笛自己拆掉原门，给最后过的人一面平坡',set:'city-door-spent'},{text:'请矾当割皮篷作软桥，留下沉笛的门',set:'city-awning-spent'}])],'city-price',['chair-free']),
  fixture('split-door','托住下铰链，等沉笛亲手拔出上门轴',18,11,[s('沉笛','这下狗可真没人关了。行，拿我这面门过，明天找块歪板子也比今天丢人强。')],'slope-port-open',['city-door-spent']),
  fixture('split-awning','与摊主站到两侧，等他从自家棚内解开皮膜背绳',26,11,[s('矾当','这边剪了就不回弹。借我你的踏脚，这一刀我来。以后雨天不卖鞋了，我倒能给坏篷的人缝边。')],'slope-port-open',['city-awning-spent']),
  person('split-mug','只想保住一只带耳杯的泥匠',21,13,[s('泥匠','我一开始拿了整套杯子，发现多拿一件就少一只手。现在一只、带耳，真够了。')])],
 [exit(3,11,'chair-eye',[29,12],'退回可自行逃出的椅窗'),exit(31,11,'eave-shoulder',[4,10],'按冬岸上屋实过的宽弯送人出高肩',['slope-port-open','ridge-rooms']),exit(25,14,'skirt-cut',[4,10],'按冬岸平口实过的让步送人下低檐',['slope-port-open','sill-rooms']),exit(13,13,'hinge-landing',[4,11],'未走新冬港的老船班沿城里原避船门接人',['slope-port-open','!sill-rooms','!ridge-rooms'])]);
export const shoulder=region('eave-shoulder','锚断之夜 · 上屋车能自己转轮的脊肩',6,'whale-city',31,19,'wood',
 [['wall',0,0,31,4,'住家新凉檐倾成的高肩'],['building',2,4,8,4,'在门口自己等旁人先过的角院'],['crane',14,3,5,5,'顶着塌檐的旧递幕车'],['building',23,3,8,6,'让出一道转车外弧的高排屋'],['water',0,15,11,4,'倾涌正在低处拐弯']],
 [['path',3,9,25,2,'需要住客自己掌角的高脊'],['rope',8,12,14,1,'预留给后面折返者的外侧']],
 [witness('eave-lead','让甫岸把高院那次转车的外把交给下一户',10,10,[s('甫岸','从冬岸回来我还会拐这个弯。你们先上，我给后头返身的人留门心。别以为走得慢就不会领人。')],'ridge-lead',['ridge-rooms']),
  fixture('eave-shoulder-mara','让玛拉从下侧用肩为已转向的住户托住横梁',16,12,[s('玛拉','先让自己的肩有地方退。甫岸，你那根外把可以回来接下一户了。'),s('甫岸','我来接。我不是车上的货。')],'eave-weight',['ridge-lead','clutch-still']),
  fixture('eave-back','退到外把弧外，把晚来的邻居从后肩领到正道',21,11,[s('晚到的扶箩','这一家又认得我的鞋了。我来替你扳外轮，让你也有工夫上去。')],'city-localled',['eave-weight'],{action:{type:'flag',id:'city-localled',set:'eave-first'}})],
 [exit(3,10,'sheared-lintel',[30,11],'绕回皮篷或旧门'),exit(26,11,'hinge-landing',[10,12],'随转过高肩的一班抵达',['city-localled'])]);
export const skirt=region('skirt-cut','锚断之夜 · 能自开自回的低檐交缝',6,'whale-city',32,19,'stone',
 [['water',0,0,32,4,'低檐夹缝里复涌的水'],['boat',2,3,9,5,'本来只能一肩肩过的破舟'],['crate',15,4,4,4,'可以把整袋子收起来的矮墙'],['building',24,3,8,6,'不该让新住户劈掉的旧后房'],['water',0,15,12,4,'侧面的旧幼兽口改成人的回身缝']],
 [['pier',3,9,26,2,'低檐净宽与冬岸实走的旧网路相近'],['rope',8,12,17,1,'不用把整个缝口封死的活绳']],
 [witness('skirt-wait','让小垛把急着上岸的老人引到凹处暂避，后面仍能过',10,10,[s('小垛','我在家那头见过。你先退进这个窝，你不是排最后，是后面的人现在没地方折身。')],'sill-lead',['sill-rooms']),
  fixture('skirt-ivo-loop','让伊沃从背檐搭一只下方能自己松开的绳套',15,12,[s('伊沃','我从前爱打死扣。把掌心留给要走的人，钩到这边自己能拆。'),s('小垛','我会解，你握住那个不动的环，松手时不要叫我等你。')],'skirt-loop',['sill-lead','bridle-free']),
  fixture('skirt-back','跟老翁从低檐里返身，把拐角留给脚背受伤的邻人',21,11,[s('老翁','我等够了，脚也没冻，就是这块旧檐泥得很。下一回换你停，我来回头接人。')],'city-localled',['skirt-loop'],{action:{type:'flag',id:'city-localled',set:'skirt-first'}})],
 [exit(3,10,'sheared-lintel',[24,14],'回到解过价钱的斜楣'),exit(26,11,'hinge-landing',[15,12],'随侧身回来的居民抵达',['city-localled'])]);
export const dock=region('hinge-landing','锚断之夜 · 先后两拨各能自己走的转门脚',6,'whale-city',39,23,'wood',
 [['water',0,0,39,5,'水一直通过，锚机已经停了'],['boat',2,3,9,6,'首港提前准备过的能平船'],['building',15,3,7,6,'保留一小段反向上坡的原住宅'],['crane',28,3,8,5,'用首港的快拆跳板撑起的井边台'],['crate',0,16,12,7,'有个凳脚印、没人说得出姓的住处'],['water',27,16,12,7,'最后几个人从浅边而非远方再回来']],
 [['pier',3,10,32,2,'从冬岸的生活门进入首港以前准备的实路'],['rope',8,14,22,1,'自选第一拨以后还能折返的分线']],
 [witness('hinge-public','随旧档原本的街坊自己攀过公用门，永远留一名关门的人',8,11,[s('早兰','我们没去那个冬岸的角院，膝门怎么开我仍记得。过一道就给下一家留一声，别抬人冒充救人。')],'city-localled',['slope-port-open','!ridge-rooms','!sill-rooms'],{action:{type:'flag',id:'city-localled',set:'public-first'}}),
  witness('hinge-boat','让首港保住的运铺船横过来，船长先接脚慢的人',15,11,[s('舟长','我在第一天留住的这条船吃水浅。沉笛在船里牵住狗，能自己下。我得等末班再回家。')],'old-route-joined',['city-localled','ward-skiff-ready'],{action:{type:'flag',id:'old-route-joined',set:'slant-boat'}}),
  fixture('hinge-board','用首港船员收下的快拆跳板，让街坊从后坡接到第二拨',24,11,[s('板工','你们当初留我的快板今天还有用。先下绳，后往上走，我是最后过的人也会自己收它。')],'old-route-joined',['city-localled','crew-plank'],{action:{type:'flag',id:'old-route-joined',set:'slant-board'}}),
  fixture('hinge-rope','只带旧公绳的船班用手扶索送最后一排回来',19,13,[s('早兰','没带原来那条船和板路也能慢着过，我跟我家人自己拉。')],'old-route-joined',['city-localled','!ward-skiff-ready','!crew-plank']),
  witness('hinge-no-name','蹲在干台找到被喊成另一个姓的那个人，听他要怎么称呼',30,12,[s('隙青','叫隙青就行。前船说我是面铺的弟弟，那人早走了。你问我要谁的姓，我现在给不来。'),s('玛拉','那先怎样找你？',[{text:'随你叫隙青，约在你自己挑的修竹凳处',set:'given-by-name'},{text:'先记住你门边开两朵紫花的地方，让你下轮再说',set:'given-by-house'}]),s('隙青','那副竹凳归我修。等有人敢把答案说准，来我的门边谈。')],'slant-placed',['old-route-joined'])],
 [exit(3,11,'slant-cobbles',[28,16],'回找人时认得的原斜街'),exit(33,11,'flood-stair',[19,11],'让沉笛自己和最后一拨人回主撤离坡',['slant-placed'])]);
