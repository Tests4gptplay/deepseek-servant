import {say as s,person,object,flag,exit} from './parts.mjs';
import {district,mechanism} from './district.mjs';
export const weigh=district('brine-weigh','盐市 · 干湿公秤屋',3,22,16,'stone',
 [['wall',0,0,22,2,'公秤墙'],['crate',3,3,5,3,'晾样木柜'],['building',15,2,6,4,'押尺间'],['crate',2,11,4,4,'湿筐架']],
 [['weighbeam',10,7,3,1,'双盘公秤'],['pier',7,11,11,2,'白线报数板']],
 [person('ruler-maker','刻尺人·陆翎',8,6,[s('陆翎','两只秤盘都卸空，再量同一袋：刚捞时十一，晒透后十。谁若拿十一当干重，纸上立刻就能多出粮。'),s('瑟琳','在秤角刻十。明天我母亲来也能照这格重算。')],{action:flag('dry-standard')}),
 mechanism('wet-sample','湿袋与干尺双盘',12,7,[s('玛拉','同船十二袋的湿总重一百三十二。先拿水分出来，别急着把它叫失窃。')],['dry-standard'],'dry-factor','按样袋的干湿比，十二袋有多少干粮？',['一百二十斤，十二斤是水','一百三十二斤，水已进账','一百零八斤，每袋扣两斤'],0,'每袋从十一降到十，十二袋合扣十二，不能再按一个车皮扣第二次。',[s('陆翎','白盘到一百二十正平。听见秤脚停响的声音了？')]),
 object('second-weigh','留给回访者的样袋',16,8,[s('陆翎','一百二十是实物。公票上若写十五袋，不要把多出的三袋也扣成水。')],{requires:['dry-factor']})],
 [exit(1,8,'salt-lane',[27,9],'回市口'),exit(20,8,'salt-dorm',[3,6],'沿不淹的屋后长堤'),exit(13,13,'seal-vault',[2,8],'进公共干仓坡道'),exit(15,10,'petition-hall',[3,7],'上秤旁听证廊')]);
export const dorm=district('salt-dorm','盐市 · 纤工寄宿院',3,25,19,'wood',
 [['building',2,1,5,3,'领薪处'],['building',10,1,5,4,'盐票柜'],['building',19,1,5,4,'平铺间'],['building',7,13,6,5,'病号伙房'],['water',17,14,8,5,'涨水船栏']],
 [['path',0,6,24,3,'端粥走廊'],['rope',15,9,4,1,'晒票簧'],['lamp',8,10,1,1,'护证灯']],
 [person('ticket-mother','瑟琳的母亲·沙荷',9,7,[s('沙荷','米袋是我点的。第七潮已经走了，账房叫我改成第八潮，好赶补给。我改了。今天当着孩子的面，我也只认这一次。'),{who:'沙荷',if:'grain-first',text:'病船及时来的十二袋让人活下来。我不想拿他们的名字盖住一张假票。'},{who:'沙荷',if:'crew-first',text:'那天稀粥熬到第三回，我数的不是粮，是床上还有几个人能吞。'}],{action:flag('ticket-date')}),
 person('witness-choice','拿着原票的装卸员·筝',15,8,[s('筝','原票往公堂一挂，库门得开，可他们会撵走拿票的人。你若先给我安个落脚处，库房有一潮能重新盖印。'),s('瑟琳','我肯押我家的供粮牌。玛拉，哪件先办？',[{text:'先护证人，走后廊安置筝',set:'witness-first'},{text:'先挂公账，赶在改印前开仓',set:'ledger-first'}])],{requires:['ticket-date','dry-factor'],action:flag('salt-priority'),after:[{who:'筝',if:'witness-first',text:'后廊门开着。你送我过去，我把日期亲手按在副本上。'},{who:'筝',if:'ledger-first',text:'我不签名。仓门半刻后就关，趁原蜡还在去拓。'}]})],
 [exit(2,6,'brine-weigh',[19,8],'回公秤堤'),exit(2,10,'salt-lane',[12,12],'涨潮乘舟回市口',['tide:high']),exit(22,8,'witness-loft',[3,7],'领证人进后廊药铺',['witness-first'])]);
