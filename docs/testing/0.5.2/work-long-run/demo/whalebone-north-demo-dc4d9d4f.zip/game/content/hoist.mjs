import { say as s, feature as f, exit, person, object, flag } from './parts.mjs';

export const hoist = {
  id:'coffin-hoist',name:'白崖港 · 送客吊台',act:1,width:24,height:18,biome:'harbor',ground:'wood',
  solids:[[0,0,24,2],[0,7,7,4],[9,2,5,3],[19,2,5,5],[0,15,16,3],[20,13,4,5]],
  features:[f('water',0,0,24,2,'鲸候泊水'),f('water',0,15,16,3,'旧水门'),f('building',0,7,7,4,'守台人的宿舍'),f('crate',9,2,5,3,'空筐架'),f('building',19,2,5,5,'拔索工棚'),f('pier',7,8,13,3,'葬车井架'),f('crane',15,8,2,3,'双筐吊台'),f('lamp',8,6,1,1,'候鲸灯')],
  entities:[
    person('ivo-watch','巡索人·伊沃',7,6,[
      s('伊沃','吊车上人的时候，没人坐得稳。先把它当床。'),
      s('玛拉','上回谁这么教你的？'),s('伊沃','一个脱下灯衣给孩子铺床的人。后来我把他的灯关了。你先搬，别看我。'),
      {who:'伊沃',text:'这个疤记得他。连补船的人都以为船该扔了，他偏说还得再回去一次。',if:'keel-name'}
    ]),
    object('rail-stencil','护栏内侧的检修摹图',10,8,[
      s('检修摹图','图一，先掰后轮的棘爪。图二，再卸空筐压石。护栏上两只灰手印正对这两个位置。')
    ],{action:flag('brake-order')}),
    object('chain-handle','双筐吊台的黄铜手柄',14,8,[
      s('伊沃','右手还托在棺侧？那就用左手。松逆了，整辆车会追着你跑。'),
      s('玛拉','把票夹牢。这回我自己来。')
    ],{requires:['release','brake-order'],action:{type:'puzzle',id:'lift-ready',prompt:'怎样把棺车平平送上吊台？',
      options:['直接放开两根缆索','先卸压石，再锁轮','先扣后轮，再卸压石'],answer:2,value:true,hint:'护栏摹图第一格画的是车轮，第二格才是空筐。'},
      after:[s('吊台','下层空筐上升，棺车与上层平台齐平。伊沃把绳结打在手够得到的一侧。')]}),
    person('embark','守台人·勒安',16,10,[
      s('勒安','进名单有两条路：活人上甲板，有名字的人绑铃。棺头朝哪儿？'),
      s('玛拉','朝岸，等到鲸背再转过来。他十七年没回来，先让他看看。'),
      {who:'勒安',text:'册子上有个「父」字。铃尾那一节白线，你来系。',if:'register-family'},
      {who:'勒安',text:'白记是殓葬人亲自护送的印。你上船，铃也交给你。',if:'register-white'},
      {who:'老汀',text:'看岸上，铺门的留夜灯还亮着。油是那碗饭换的。',if:'night-lamp'},
      s('伊沃','鲸灯全亮了。你听见甲板上有人应声吗？')
    ],{requires:['lift-ready'],action:flag('coffin-aboard'),after:[s('玛拉','吊铃已经绑好。港钟敲过集结头一天的第二遍。那条鲸还没走，尾鳍却一直摆着。')]})
  ],
  exits:[exit(21,11,'wake-court',[2,11],'从高台回院中守第一夜',['coffin-aboard']),exit(2,5,'rope-market',[23,9],'回上层修索街'),exit(18,14,'lower-tide',[22,5],'退潮时下检修门',['tide:low'])]
};
