import {shore,fixture,witness,exit,person,spoken,say as s,mechanism} from './cast.mjs';
const ready=['whalefall-two-readings','!whalefall-wool-set','!whalefall-lantern-set'];
export const mouth=shore('whalefall-mouth','小鲸从母亲尾后探头的湾口',36,23,'stone',
 [['water',0,0,12,7,'先到的深水拐角'],['water',17,0,19,7,'母鲸浮过两片碎冰的湾面'],['wall',0,17,11,6,'通饭桌的旧引堤'],['building',22,17,14,6,'熏鱼人在长风里避火的棚']],
 [['path',2,9,31,3,'停潮时仍能贴岸过人的风背'],['voice-bell',8,7,4,3,'旧救生筒下垂着扁钟和羊毛套'],['voice-lamp',23,8,4,3,'两盏有背罩的油灯朝向同一个岸站'],['voice-watch',29,5,4,3,'鲸背中间浮过的水沫与悬在矮木上的指绳']],
 [person('whalefall-stationer','递过铰钳的槐梢',14,11,[s('槐梢','湾外冒起三串泡的时候，浮台上有人，也有鲸。我不能再把两边都喊回来。试办法先把价钱讲清楚。'),
 s('槐梢','把钟搁上木桩，钟舌包湿毛，岸架便会抖，水里不起浪。钟得离开救生筒，人落水就靠我站一整夜。'),
 s('寇仁','或者把我的两份鱼油分别给两盏背灯。乘客见两灯重合就绕过幼鲸，但今天的鱼得分去各家灶上熏。你可以在栓紧前再走一圈。')]),
  fixture('whalefall-bell-test','试把钟按到木桩上，松手仍可改拿罩灯',10,11,[s('伊沃','我压住钟口，你借绳抖一次。灯舟上的人举起手，水面没有第二道圈。'),
  s('槐梢','我能守一夜，也能请人换。决定用它，把羊毛套栓牢就算数。')],'whalefall-bell-tried',ready),
  fixture('whalefall-lamp-test','举起两扇罩，走到光边对准岸站',24,11,[s('米拉','把远灯的缺口留给我，近灯往右。看，船上看见一盏，寒棚底下能看见两盏。'),
  s('寇仁','两盏都亮，油明天就分不够给鱼。我的名字可以写在借条上，鱼要有人背，不准只在簿子上搬。')],'whalefall-lamps-tried',ready),
  witness('whalefall-knot-wool','交出救生筒上的钟，亲手栓死毛套',12,13,[s('玛拉','绳头绕回木架。你响一声，我到末站接。'),s('槐梢','给我旧灯柄留个靠手的地方。我先守，到退潮换你妹妹。')],'whalefall-wool-set',[...ready,'whalefall-bell-tried']),
  witness('whalefall-share-oil','把两份鱼油实交岸站，挂上成对背灯',26,13,[s('寇仁','给，将烟鱼留在篮底的那面朝上，别把皮掀开。两筒鱼油都是我用指头拨出来的。'),s('米拉','两盏灯各照一个人站的地方。油快用完，两边得一起换。')],'whalefall-lantern-set',[...ready,'whalefall-lamps-tried']),
  fixture('whalefall-ring-on-land','站到离钟最远的岸桩，把脚心收到的低振传给候船人',31,10,[s('崖枝','绳绷起来了。我在水下只听见小鲸收回一口气。你在岸上抬手，我就让开身后这条水。')],'whalefall-watch-sent',['whalefall-wool-set']),
  fixture('whalefall-send-the-light','站到熏鱼棚的旧黑痕里，让两盏灯合成一个亮圈',29,14,[s('寇仁','烟棚的人背着鱼侧身过去，灯没挪。那条小鲸从我脚下擦了一下，水浮到鱼鳃上了。')],'whalefall-watch-sent',['whalefall-lantern-set']),
  witness('whalefall-before-the-list','在港城倾斜以前把当班人和活鲸去向记在外泊交接本',17,13,[s('瑟琳','这行只记亲眼看到的。浅水先给小的走，外泊靠岸，我们要借的是另一条水。'),s('槐梢','后日再走这条路，问点着灯的那家人。他们知道绳在哪。')],'whalefall-early-log',['whalefall-watch-sent','!harbor-tilted']),
  witness('whalefall-old-lesson','抄下倾港以后仍能教给新人的守湾办法',17,14,[s('玛拉','别把咱们今天做的事添进那一夜的名册。留一页空的，等下一次有人站岗，再给今天写日子。')],'whalefall-later-lesson',['whalefall-watch-sent','harbor-tilted','!whalefall-early-log'])],
 [exit(2,10,'whalefall-porch',[7,9],'收起风绳，回水上水下同吃的饭桌')]);
