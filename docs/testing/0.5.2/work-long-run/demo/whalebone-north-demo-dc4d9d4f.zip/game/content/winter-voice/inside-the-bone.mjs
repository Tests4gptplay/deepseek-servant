import {shore,fixture,object,exit,person,say as s} from './cast.mjs';
export const bone=shore('whalefall-bone','身体已经交还给水的老骨房',27,18,'stone',
 [['wall',0,0,6,5,'巨鲸颚骨末端的蜂窝孔'],['wall',10,0,7,4,'鲸颚骨合拢成不透光的拱'],['water',19,0,8,8,'被水带走的小骨锥'],['water',0,13,10,5,'涨潮会满的甲室'],['wall',18,13,9,5,'格着贝壳的旧感音腔']],
 [['path',2,7,21,3,'从五股绳梢弯入干处的路'],['voice-bone',5,5,8,3,'白骨深浅相间的横孔'],['voice-cord',16,8,5,1,'一高一低拴过许多代的指绳']],
 [fixture('whalefall-hollow-name','沿五股绳的空股揭开刻在颚骨背面的儿歌',10,9,[
  s('崖枝小时的手迹','一股给生我的水，一股给捞我的人。一股给被我误叫回来的鱼，一股给我不肯回的门。余下一股空着，留给后来的人自己上岸。'),
  s('洛洄','头回把鲸声喊错的时候，妹妹才十二，替我挨了一句“水里的人胳膊肘往海里拐”。我记得那个人的脸，不知道她留下了这句。'),
  s('崖枝','那一股原来想编给一个畏水的小孩。他后来搬去南边了。我把绳留着也有意思。')],'whalefall-child-song',['whalefall-found-knots']),
  object('whalefall-bone-toggle','收下崖枝让出的五股空心骨扣，给下一个入冷水的人穿戴',20,10,[s('崖枝','过水把衣襟交叠，用这两孔咬住绳。手发抖摸不出结的时候，空股摸得到。我自己手里还有一个。')],{requires:['whalefall-child-song','!whalefall-owned-toggle'],action:{type:'item',id:'whalefall-bone-clasp',value:1,set:'whalefall-owned-toggle'}}),
  person('whalefall-sand-kid','给空骨续画水尺的鹿粒',15,10,[s('鹿粒','上面那条刻的是我第一次自己把头伸到水下。码头老师说尺寸不对，我又没拿它量船。')])],
 [exit(2,8,'whalefall-keel',[6,13],'捉住干的一股绳返回艇腹，即使潮回也能出去')]);
