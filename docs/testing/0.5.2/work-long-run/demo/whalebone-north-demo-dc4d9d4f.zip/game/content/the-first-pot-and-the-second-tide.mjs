import {yard,cargo,flat,active} from './a-boat-with-two-ribs.mjs';
import {neck,side,snapper} from './the-click-beneath-the-stone.mjs';
import {say as s,exit,person} from './parts.mjs';
import {witness,spoken} from './voyage-parts.mjs';
import {tidePost} from './district.mjs';

const landing=flat('keelpot-landing','盐市 · 擀卤石与两层接苗槽',29,19,'wood',
 [['water',0,0,9,5,'摆渡舟从涨潮口靠岸'],['building',12,0,5,5,'接货人轮值的敞凉棚'],['water',20,0,9,5,'外海咸潮没过的育苗带'],['building',0,14,8,5,'盐瓮入土避热的卤窖'],['water',19,14,10,5,'背岸小水沟']],
 [['path',2,7,24,2,'高坡接货路'],['kp-boat',1,5,6,2,'侧靠岸坡的双肋舟'],['kp-crib',19,6,4,2,'向外潮扬起的整苗床'],['kp-jar',10,12,2,2,'入凉窖前的接瓮石'],['kp-ledge',19,11,4,2,'把湿盘放稳的内沟低沿']],
 [cargo('receipt','船底朝外的起货木踵',8,7,'land',['keelpot-launched',...active],['keelpot-landed']),
 cargo('unshoulder','低肩齐高的入窖与接盘台',18,11,'put',['keelpot-landed',...active],['keelpot-done']),
 tidePost('keelpot-landing-tide',14,10),
 person('keelpot-receiving','替两家把坡道扫干净的窖工照妹',11,8,[
 s('照妹','涨水卸的是整批，低水接的是一肩。空手过来的，把道让给能自己选停脚的人。'),
 spoken('照妹','青瓮开给今天的日班，赭瓮给当晚的灶。架子留下来，明天头潮我帮禾盏翻沟。','keelpot-fish-first'),
 spoken('照妹','外床今早接了整架。午灶只开豆汤，商枣那两瓮要进凉窖过夜，夜班的赭布别解错。','keelpot-seed-first')]),
 person('keelpot-gate-painter','补写潮痕的窈句',23,9,[s('窈句','不是水退了字就能看见。盐干要一阵，写早了毛笔顺着水爬。有时客人走了，字才干。')])],
 [exit(4,8,'keelpot-yard',[26,10],'沿不许肩担的上工绳桥回去',['!keelpot-on-shoulder']),exit(22,12,'keelpot-neck',[29,10],'从低肩沿回托篓石',['tide:low'])]);
const meal=person('keelpot-town-supper','灶口换勺的汀壳嫂',23,10,[
 spoken('汀壳嫂','鲜鱼那天青布卖给午班，赭布给夜车。内沟的两半苗日后要多清一遍。你来帮清？留条旧裤子，一脚下去到膝盖。','keelpot-fish-first'),
 spoken('汀壳嫂','第一夜我们真喝了豆汤。今早商枣把带鱼皮的那层分到夜班饭里，把多出来的腌汁带给没灶的人拌粥。','keelpot-seed-first'),
 spoken('汀壳嫂','成虾绕回老孔，小孩别踩原来那条短路。','keelpot-defended'),
 spoken('汀壳嫂','背汊清早还有水响，小虾钻到外沿去了。那三只空螺盖谁也没捡。','keelpot-sheltered')
],{requires:['keelpot-done'],lockedText:'锅勺挂在原位，灶班还没收到那两家都过了岸的回话。'});
const winter=witness('keelpot-winter-bowl','在冬岸敲开从盐市送来的一只旧卤盆',12,10,[
 spoken('禾盏的短笺','两半盘那年分在内沟。第一遍苗花比外沟稀，泥却好留。我把留下的壳送来教你们辨哪种泥能抓住新苗。不要写作丰收。','keelpot-fish-first'),
 spoken('商枣的口信','你们拿到的是过夜腌的薄鱼片。原本说的鲜鱼没有到。我家把那点利钱垫了；搅粥的空盆请捎回来，我没送盆。','keelpot-seed-first'),
 s('瑟琳','我前天还说“盐市送来了吃的”。现在能说清是谁少拿了钱，谁多蹚了一次泥。')],'keelpot-winter',['keelpot-done','winter-welcome']);
const stages=['keelpot-open','keelpot-launched','keelpot-landed','keelpot-cleared','keelpot-done'];
export const keelpotQuest={id:'a-boat-with-two-ribs',name:'一船两道肋',kind:'side',startFlag:stages[0],endFlag:stages.at(-1),stages};
export const keelpotMaps=[yard,neck,side,landing];
export {snapper};
export function withKeelpot(map){
 if(map.id==='salt-lane')return {...map,entities:[...map.entities,meal],exits:[...map.exits,exit(26,8,'keelpot-yard',[3,9],'沿双辙进青瓮与蚝苗共用的斜埠')]};
 if(map.id==='winter-ward')return {...map,entities:[...map.entities,winter]};
 return map;
}
