import {region,fixture,witness,spoken} from '../voyage-parts.mjs';
import {say as s,person,object,exit} from '../parts.mjs';
const room=(id,name,w,h,blocks,land,people,exits)=>region(id,name,4,'north-star-quay',w,h,'stone',blocks,land,people,exits);
export const job=(id,name,x,y,station,requires=[],kind='object')=>({id,name,x,y,kind,requires,action:{type:'star-clock',station}});
const back=exit(2,11,'pilot-ring',[8,12],'随白篷摆船回双缆试船圈');
export const quay=room('star-clock-quay','北航 · 铅摆行与封灯渡口',34,22,
 [['water',0,0,34,4,'悬在岸下的系钟船'],['building',3,5,6,4,'防撞钟匣铺与装箱廊'],['building',12,3,5,5,'屋脊刻着历年昼线的饭铺'],['building',25,4,7,6,'两家轮值的星历台门楼'],['water',0,17,10,5,'往回湾的两道浅浪'],['crate',25,16,7,5,'磕坏后拆去玻璃的粮艇钟箱']],
 [['pier',2,10,27,2,'黑松铺成的运钟船台'],['lane',11,12,14,2,'进门认铅坠的铺前街'],['rope',8,15,12,1,'夜里静音的绒结报时索'],['lamp',21,9,1,1,'伸一扇遮板便熄的登舟灯']],
 [witness('star-keeper-offer','给钟上弦的粟铅',9,11,[s('粟铅','停一停。谁的手最稳？不是给我抬箱子。帆布里面有一只走着的钟，我要听见它放上桌的那一响。'),s('玛拉','我左手托底。为什么不把摆停了？'),s('粟铅','停过，就说不清它究竟快了多久。昨晚米娘按钟开渡，前船说她晚两刻。她今天不肯再接人。'),s('米拉','先借我两样东西：一颗不听钟走的星，一枚真的随船走过的轮。')],'star-clock-offer'),
 fixture('star-clock-shoebox','打开系过船跟的旧鞋盒',18,14,[s('旧鞋盒','泥里嵌着一个圆窝和两截断鞋带。箱盖上抄着两行：第一更，岸刻四，船刻五。隔三更，岸刻七，船刻九。'),s('粟铅','我女儿在第一行旁画了一只歪靴。那晚她鞋带断了，单脚坐在桌下等我。不是后来按记性填的数。'),s('伊沃','一开头就快，再走还多快了一格。光挪针，毛病可还跟着人上船。')],'star-clock-log',['star-clock-offer']),
 person('star-kitchen','烧双穗茶的梧妹',14,9,[s('梧妹','别拿门框上最长那条当冬至。那是把晒咸豆的席边钉歪了。我娘留它在那儿，看谁会喝一口茶还顺手替她批历书。'),spoken('梧妹','批错班的是钟。我端茶去渡口的时候，米娘头一回肯坐在船沿上等天黑了。','star-clock-tested')]),
 person('star-courier','把塔门匙当坠佩的椒厘',23,12,[s('椒厘','门匙原该挂腰上。走起路来磕得铛铛响，夜班的耳朵遭不住，我给它垫了一截旧靴舌。'),spoken('椒厘','你看见了那颗红星？我偷偷给它起名叫粥里的枣，粟铅说不许这么写进海图。','star-clock-sighted')])],
 [back,exit(28,11,'meridian-shutter',[3,12],'登裂环天窗，向北认一颗真的过线星',['star-clock-offer']),exit(12,15,'pendulum-cellar',[3,10],'穿过装箱廊，下错齿摆房',['star-clock-offer']),exit(21,16,'night-oar-road',[3,11],'合上船灯，拿走准的钟出渡',['star-clock-tested'])]);
export const transit=room('meridian-shutter','北航 · 裂环天窗的子午石',29,20,
 [['wall',0,0,29,3,'高过人头的承冰墙'],['building',3,4,7,4,'开着窄缝的候星圆屋'],['wall',19,3,6,5,'能透夜风的双层黑石'],['water',0,16,11,4,'映着屋灯的低渠'],['crate',21,15,7,4,'压住窥筒的细石箱']],
 [['lane',2,11,24,2,'从南刻点到北石眼的铜经线'],['rope',14,6,1,7,'铅坠的真垂线'],['lamp',12,10,1,1,'只照刻度，灯罩闭口朝天']],
 [fixture('star-plumb-line','将铅坠放进铜刻线的凹口',12,12,[s('米拉','铅坠只认脚底下。把它沉在清水里，风吹不偏，地上的铜线也就有了真上真下。'),s('瑟琳','水盆里的星会晃，天窗里的不会。认那两粒白点中间偏红的一颗。你可以慢慢转，星台给读不见字的领航人也留了短长两刻。')],'star-clock-plumb',['star-clock-offer']),
 job('star-transit-wheel','握住指星轮，合上狭缝读中天',19,11,'sight',['star-clock-plumb']),
 person('star-terrace-watch','夜里负责把眼睛歇凉的逐苔',9,9,[s('逐苔','刚从亮房里出来，往往先认出水里那个假的。把眼睛从渠里移回天窗，等月边的白雾散一散。我会守着铜摆，不催你。'),spoken('逐苔','你转到重合才开口。我肯把给小艇领人的那半张星图交你。','star-clock-sighted')])],
 [exit(2,12,'star-clock-quay',[27,11],'回门楼下的铅摆行'),exit(23,12,'pendulum-cellar',[19,7],'由观测台内梯直接下摆房',['star-clock-plumb'])]);
