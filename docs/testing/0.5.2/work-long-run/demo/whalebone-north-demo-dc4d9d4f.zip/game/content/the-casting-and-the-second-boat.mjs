import {fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person} from './parts.mjs';

export const proof={
 'wreck-slope':[
  fixture('heel-short-home','把雀脚窗的双窝靠在回港短钩上',18,10,[s('米拉','两窝一深一浅，扣眼只容一只短钩；把长钩提上去，内侧先撞，绳收不到外窗。'),
  s('雁折的记号','短钩的这道白痕自己能和窗外磨口相合。'),
  s('玛拉','梅屿见过两趟船，雁折说的是第一趟的一双手。晏禾确实将她从高窗接走。谁造的锚，得向另一处材料去问。')],'heel-rescue-proved',['heel-short-trace','return-twice']),
  person('heel-who-stayed','坐在搁船坡缝船垫的温札',12,14,[s('温札','走低床那趟的人有的睡着，有的骂我把他裤腿卷到手腕上。别说所有人在一个窗里举起两只手等船。'),
  spoken('温札','我在船里看不见谁留在灶间，不能替丘沚家的人拿他的年岁作担保。','heel-low-trace')])],
 'stamp-shop':[
  fixture('heel-proof-against-sign','将旧灶门背面的偏肩蜡凹扣上已署名的反样',13,8,[s('印样师','凹面的短边先入，长边才贴到底。偏肩在杉木芯里，砸歪一扇门做不出藏在两层旧漆下面的暗纹。随船样纸照这款做，当年的署名你亲手翻正了。'),
  s('玛拉','签图的人是晏禾。偏肩在舟倾之前就已经做进样里。它要受他名字里的那一份责，哪怕这整条航路没有人肯给我作证。')],'heel-fault-proved',['heel-stock-trace','maker-known'])],
 'winter-court':[
  witness('heel-twin-lesson','在冬岸摆平一块空门扇，听雁折和母亲各选一件以后要用的东西',22,8,[s('雁折','我来冬岸是给她做一只不勒手的下坡把。你从两处带回来的事，不用再问我哪一件更真。'),
  s('柳珏','我的丘沚托过她。救我女儿的是晏禾。别让后来的船把那块偏肩从印样上捎走。'),
  s('瑟琳','这扇整门拆成宽坡，水涨时容得下一辆车加陪的人；留下整门作内廊，坐着也能回丘沚家。木头的长纹只有这一块。普通疏散坡始终能用。')],'heel-winter-permission',['winter-welcome','heel-family-grip','heel-rescue-proved','heel-fault-proved','!harbor-tilted']),
  witness('heel-wood-choice','让柳珏试过两个握把后，定下整扇门今晚的用途',16,8,[s('柳珏','若刨开，我今晚就不能摸回他贴着门织鞋的地方；若保留，那辆车须到外边原坡。我两边都试过。让街里人听清楚我们同意哪一件。'),
  s('玛拉','今晚怎样把手上的整木送回港？',[
  {text:'提议刨为今日可走的大坡，给车和同行者留面宽',set:'heel-plan-ramp'},
  {text:'保住原手窝，做从内侧可开、坐着能回去的家属廊',set:'heel-plan-room'}]),
  s('雁折','没走过的路就别当作给了谁。到横铺工具台，跟我一起把它做出来。')],'heel-order',['heel-winter-permission','!harbor-tilted'],{after:[s('柳珏','我已经试过，今夜的木不能分作两份。')]}),
  person('heel-regular-wing','修普通疏散坡上木屐的柳珏',10,8,[s('柳珏','城里还有一条大伙儿都能走的外坡。不管我家的兄妹门将来怎样，我总要给外坡上走的那些双脚修鞋。'),
  spoken('柳珏','我知道有人请阿折当众讲话。追着她问会让她躲开；你肯放下不问，也是把她当人。',['heel-no-public','!heel-let-in']),
  spoken('柳珏','你见过她被接上短钩。还有一整条低层，不是那只短钩带得走的。',['heel-rescue-proved','!heel-fault-proved']),
  spoken('柳珏','样上的字是你自己认的。旧窗托人那一夜我们还没一起走，不用添一段。',['heel-fault-proved','!heel-rescue-proved'])])],
 'winter-ward':[
  fixture('heel-cut-ramp','与雁折沿长纹起木，把两面门梃配成可退宽坡',13,8,[s('玛拉','第一刨出来，拇指窝少了一角。不要反过来抹平它，柳姨知道她今晚让出什么。'),
  s('雁折','我把剩下的开口贴在新把上，让我娘用眼睛看得到自己的拿法。宽轮和人的肩一块过，才算这笔木工。')],'heel-ramp-fitted',['heel-plan-ramp','!harbor-tilted']),
  fixture('heel-keep-jamb','和柳珏在老手窝里面装一截低位回转合叶',16,8,[s('柳珏','铰在里面，坐下时我也能把手绕过去。别替我把另一端挑高我要转不过。'),
  s('雁折','旧木纹一段没断。大车要走外面，我去那里留一盏真有人照看的灯。')],'heel-room-fitted',['heel-plan-room','!harbor-tilted'])]};
