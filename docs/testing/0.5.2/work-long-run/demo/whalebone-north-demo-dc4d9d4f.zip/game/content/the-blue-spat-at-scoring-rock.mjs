import {room} from './the-sleeve-and-the-spray.mjs';
import {fixture,witness} from './voyage-parts.mjs';
import {say as s,exit,person} from './parts.mjs';

export const landing=room('scorerock-landing','北航 · 蓝贝落丝的空水夜',36,24,
 [['water',0,0,36,5,'透光水里的细贝苗，触着麻须便伸足'],['wall',2,3,7,6,'别在岩槽里擦掉蓝贝的足丝'],['boat',15,3,8,6,'女儿从前用来穿梭打纬的窄底艇'],['building',27,4,8,5,'北滩空闲的编弓棚'],['water',0,17,14,7,'返向去葛家旧绳靠的外湾'],['crate',25,17,9,6,'带去冬岸的斜梭臂，擦亮一边才合左腕']],
 [['pier',3,11,29,2,'田里缺一环苗，岸上另一圈仍有老人打理'],['rope',11,15,12,1,'两股能分、同一双手不能立刻出现在两处'],['sign',24,10,1,1,'先返回母绳或先到冬岸，只能赶一个工作时辰']],
 [witness('score-first-job','葛芮的细齿浮弓',10,12,[s('葛芮','你看，蓝粒下头伸出一根头发样细丝。夜冷前搭回旧母绳，它就有地方活。若我现在返去，槿陶第一次装斜梭我便又不在场。'),
 s('米拉','我只听过你说她一直在等。她请你去做什么？'),
 s('葛芮','她左手打纬，把梭口改在外舷。我惯用右手，从前当她做反了，让她拆过。她只请我来坐第一趟，别教。海上不全是我干过的活。')],'score-price',['score-surveyed','!winter-welcome']),
 witness('score-work-order','返潮前的船头',18,12,[s('葛芮','母绳隔一道涌，回去早了，小贝还没伸足，回去晚了，船底会把苗的细丝拖断。留我旧滩，冬岸的第一梭就只归她；先送我到槿陶那儿，这一圈苗就让它跟海过冬。'),
 s('米拉','我把可回、可继续都量过了。你愿意同我们走哪段？',[
 {text:'借实测过的回线返旧滩，亲手把第一绺蓝苗续到母绳',set:'score-return-order'},
 {text:'先用这一趟送葛芮去冬岸，让她坐上女儿第一次打纬的艇',set:'score-forward-order'}]),
 s('葛芮','好。嘴里选了还不算，船头掉过去、手摸到那里，事才算做了。')],'score-job-chosen',['score-price','!winter-welcome'],{after:[s('葛芮','这一段先后不能再换。你若临时另走，也别把没做的写成做了。')]}),
 fixture('score-release-spat','解下新苗依附的小梳，送回满潮海草',24,13,[s('葛芮','蓝壳松了，海草自己会托住它。旧线今年少了一环，不是港里所有的贝都让我们放光了。'),
 s('米拉','我没有画过这条顺让的航线；以前纸上的一夜，究竟是谁在等我，从来看不出。')],'score-spat-freed',['score-forward-order','!winter-welcome']),
 witness('score-double-cut','葛芮摸两张湿图之间留下的窄缝',14,14,[s('葛芮','旧图是槿陶九岁在我膝头用手背蹭出来的。我那时只肯让她坐正中，不许她爬到舷边。图上才只有一条线。'),
 s('米拉','我能把两条新线送给她吗？'),
 s('葛芮','线可以送。那半幅纸的背面夹了孩子的一根头发，我想把它留着。')],'score-permission',['score-beam-sailed','score-lee-sailed','score-know-family','!winter-welcome']),
 person('score-hook-old','编弓棚里修钩的蓖十',28,12,[s('蓖十','我给钩子刻缺不刻名。小指一摸就晓得哪个槽能塞进发胀的老绳。旁人拿它们当记号，确也不是错。')])],
 [exit(3,12,'scorerock-origin',[15,15],'亲自掉头沿测过的回线到葛家旧母绳')]);
