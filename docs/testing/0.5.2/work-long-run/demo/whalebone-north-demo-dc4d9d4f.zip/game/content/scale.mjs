import { say, feature as f, exit, object } from './parts.mjs';
import { scalePeople } from './scale-people.mjs';

export const scale = {
  id:'wharf-scale', name:'白崖港 · 秤桥', act:1, width:26, height:18,
  biome:'harbor', ground:'stone',
  solids:[[1,1,6,4],[10,1,5,5],[20,1,5,5],[0,15,22,3],[15,9,2,2],[8,5,1,3]],
  features:[
    f('water',0,15,22,3,'装粮船坞'),f('building',1,1,6,4,'殓棚'),f('building',10,1,5,5,'公秤房'),
    f('building',20,1,5,5,'缉粮栈'),f('path',0,10,26,3,'双车道'),f('pier',22,12,4,6,'上层木梯'),
    f('sign',8,7,1,1,'两石空车'),f('crate',15,9,2,2,'盐袋'),f('lamp',19,9,1,1,'秤灯'),
    f('coffin-cart',6,11,3,1,'盖紧的白布送棺车'),f('weighbeam',15,7,3,1,'回皮秤梁'),
    f('rope',2,6,4,1,'住户晾绳'),f('crate',19,12,2,1,'港仓待点粮袋')
  ],
  entities:[...scalePeople,object('balance-arm','回皮秤',16,7,[
    say('秤牌','红针记车和棺的总重，白针要扣空车。'),
    say('玛拉','方才在车辕看见的火印，应该把游砣推到哪一道？')
  ],{requires:['procession','tare-seen'],action:{
    type:'puzzle',id:'weighed',prompt:'按车辕的火印给空车回皮。',
    options:['一道 · 扣一石','两道 · 扣二石','三道 · 扣三石'],answer:1,
    hint:'车辕左边的两道是皮重，右边一道记车轴号。',value:true
  },after:[say('秤手','横了。你看，棺底离着限线还有一掌。到我桌边来，给他留个名。')]})],
  exits:[exit(24,10,'rope-market',[2,10],'沿双车道往修索市街'),exit(24,16,'lower-tide',[2,4],'下潮脚木梯')]
};