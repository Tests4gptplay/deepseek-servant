import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {mechanism,tidePost} from './district.mjs';
export const plunge=region('slant-cobbles','锚断之夜 · 白门全湿以后仍能走通的斜街',6,'whale-city',44,27,'wood',
 [['water',0,0,44,6,'码头倒灌后漫过灰白门牌的街沟'],['building',2,5,8,5,'原面铺高扣早已淹没的白门'],['wall',15,3,7,5,'切向上方窄檐的泄水肩'],['building',29,4,10,6,'低闩住家还露出一边的窗钩'],['boat',0,19,14,8,'原来搁鞋现在能划船的沟底'],['water',29,19,15,8,'冬岸学的两种绕行在此受潮']],
 [['path',3,11,36,2,'由灌水嘴折返分两次摸得到的斜街'],['rope',9,16,24,1,'店家用脚踝拽住的回身绳']],
 [witness('slant-refuse','听见水从门内回响，让沉笛自己决定要不要走',10,12,[s('沉笛的声音','听见了。狗还在里屋，我不把它丢给潮。上次被背出来，我的鞋在屋里泡了一个月。别上来扛！'),
  s('伊沃','你要我们松手，还是先让狗过去？',[{text:'把门前腾开，她能叫狗回身就自己叫',set:'slant-space'},{text:'问她平时用哪块旧凳给狗上窗',set:'slant-dogstep'}]),s('沉笛','两颗帽，第三颗狗叼了。下边有深槽。你们要理会我的是门，不是白漆。')],'slant-heard',['harbor-tilted']),
  fixture('slant-remember','沿早餐时布兰实走过的凳槽，摸回矮钩两枚帽',19,12,[s('玛拉','早晨那饼就在这儿翻了面。沉笛门里是深槽，我从高处退半步，能摸到两颗帽。')],'slant-marked',['slant-heard','bran-home-visited']),
  fixture('slant-local','让旧航路的街坊带手沿台脚过来，亲自摸出两帽一缺的低钩',25,14,[s('早兰','你没有陪他送饼？把我的面筐搁下。沿两排细槽走回大凳那条粗槽，手摸前头的门拐，空中间那颗。')],'slant-marked',['slant-heard','!bran-home-visited']),
  person('slant-whistler','还在叼木笛找狗的小客人',34,14,[s('小客人','我没在吹警报。我一吹警报它就去抓铃，我只想让自家的狗听见我。')]),tidePost('slant-clock',15,15)],
 [exit(3,12,'flood-stair',[18,11],'退到不滞水的收粮坡'),exit(10,16,'pale-sump',[4,10],'穿白漆时误走的高扣门',['slant-heard']),exit(36,12,'chair-eye',[4,11],'随凳脚深沟摸到受困住户的真门',['slant-marked']),exit(29,16,'hinge-landing',[4,11],'走实已清出来的运人门',['slope-port-open'])]);
export const sump=region('pale-sump','锚断之夜 · 白漆错门和必要时的原路回退',6,'whale-city',29,20,'stone',
 [['water',0,0,29,5,'光在虚水面上把门抬高一截'],['crate',2,4,8,4,'已经散开的四角面筐'],['building',13,3,7,5,'窗根的钩在头顶不是膝侧'],['wall',22,3,7,6,'涨水退路压在旧面管后面'],['water',0,15,12,5,'没脚下台面的错误通道']],
 [['path',3,9,23,2,'到第三步必须倒退出去的石沟'],['rope',8,12,14,1,'摸到四角筐后有实体的短管']],
 [fixture('sump-square','伸手摸白门下原来不见的四个方角',9,10,[s('伊沃','是面筐。往下脚会空，往回摸木框。别让人进来。')],'sump-wrong'),
  fixture('sump-pipe','从面管背面开浮框的回身弯，随居民倒走到干脊',19,11,[s('早兰','搬开我的旧盖。你先松一侧，我能退回去。以后比着浅深找门，别跟着白亮的地方。')],'sump-released',['sump-wrong']),
  fixture('sump-cleat','让原戏班的逆齿靴扣抓住侧石，快一步推开浮框',15,12,[s('伊沃','脚外侧先挂，跟旧爬桅靴一模一样。有扣我能绕后先拉开，不必让另一人留在湿管边。')],'sump-released',['sump-wrong','toe-found'],{action:{type:'flag',id:'sump-released',set:'sump-short'}})],
 [exit(3,10,'slant-cobbles',[11,16],'从背管重回居民还能摸到的原街',['sump-released'])]);
export const chair=region('chair-eye','锚断之夜 · 两圆钉一缺帽的椅窗',6,'whale-city',35,23,'wood',
 [['water',0,0,35,6,'水线淹上门右侧半扇底窗'],['building',2,5,8,4,'不能用白门牌区别的椅窗'],['crate',13,6,3,3,'水上只剩竖背和两枚圆钉的矮凳'],['building',24,4,9,5,'沉笛的狗缩在第三根窗杠背后'],['boat',1,16,10,7,'把低窗当船门的斜插旧舟'],['water',23,17,12,6,'路已经转到窗内的廊底']],
 [['path',3,10,28,2,'沿椅背、墙脚和窗边侧身让开的肩宽'],['rope',11,14,13,1,'从低闩左边拉开才不锁死的深槽']],
 [fixture('chair-knees','从半沉矮凳和两枚钉的地方认准沉笛屋内的低窗',10,11,[s('玛拉','这边摸着是椅背，不是窗沿。钉头还干，窗根没了。把脚从门槛移开，剩下那条沟够人和狗穿一回。')],'chair-known',['slant-marked']),
  mechanism('chair-unseat','在屋里能自由退回时折开椅窗，把自己的位置让给狗',18,11,[s('沉笛','你隔水听见狗，它不一定在床上。别把凳子整个提走，我拿椅背撑脚才够着内窗。')],['chair-known'],'chair-sent','旧凳竖背露水，细窗线只够手钩。怎样让屋里的人自己回来？',['把整把凳子借走，向水里拉人','只翻松的凳面，保留竖背当脚踏，从侧边让一身','将门窗钉在一起，等人从屋顶跳'],1,'竖背和门钩是她自己能用的两处支点。别同时拿走。',[s('沉笛','沙獾！来！把爪搭我肩上。你们先从窗边让一让，我不是刚才还在等着被抱。')]),
  witness('chair-step','在狗跳过后退到她看得见的窗框外，让沉笛自己落脚',25,11,[spoken('沉笛','你让开的这半步正好。我用不上你的肩，帮我接一下狗绳。','slant-space'),spoken('沉笛','你问对凳子就够了。我的手留在上头，狗能从左边蹿出来。','slant-dogstep')],'chair-free',['chair-sent'])],
 [exit(3,11,'slant-cobbles',[35,12],'贴斜窗折返进过水街'),exit(30,12,'sheared-lintel',[4,11],'往切开或拆门的斜楣巷',['chair-free'])]);
