import {say as s,object,person} from './parts.mjs';

export function setting(id,name,x,y,dialogue,requires,changes,lockedText){
  return object(id,name,x,y,dialogue,{requires,lockedText,action:{type:'flag',id:id+'-used',set:changes}});
}
export function shiftPost(id,x,y,day){
 const opening=day?'晚班黑绳':'早班白绳',ending=day?'晚':'早';
 return setting(id,opening,x,y,[s('报班童','上一班在木牌背面刻井。把'+opening+'挂上横杆，轮到'+ending+'班的人在另一面报实物。'),s('玛拉','我能把牌翻回去复称。翻的是同一项卸货，不能让同一袋米跟着翻两遍。')],[],{'salt-day':!day,'salt-night':day});
}
export function pages(groups){
  return groups.flatMap(([when,lines])=>lines.map(([who,text])=>({...s(who,text),...(when?{if:when}:{})})));
}
