import {exit,object,say as s} from './parts.mjs';
import {witness,fixture,spoken} from './voyage-parts.mjs';
import {lane,house,bridge} from './pot-address.mjs';
import {ring,yard,loft,oven} from './winter-ring.mjs';
import {tongue,outside,inner} from './two-waters.mjs';
import {saddle,keel,ink,nursery} from './a-boat-or-a-blank.mjs';
import {potYard,ridge,stair,ash} from './different-doors.mjs';

export const basinMaps=[lane,house,bridge,ring,yard,loft,oven,tongue,outside,inner,saddle,keel,ink,nursery,potYard,ridge,stair,ash];
const links={
 'north-pier':[exit(6,9,'bread-underdoor',[4,11],'沿回娘家的早饭船走到用门板摆桌的冬船巷',['party:selene']),exit(11,9,'season-ring',[27,15],'跟已泊好的长匙号重走冬眼短渡',['pot-fixed'])],
 'season-ring':[exit(28,15,'north-pier',[8,9],'由停妥的灶船顺过一次冬泊回北行码头',['pot-fixed'])],
 'red-beacon':[exit(6,10,'silt-tongue',[4,11],'在木臂已外伸的时候去看侧滩哪一面真能通',['outer-arm']),
  exit(9,11,'keel-cradle',[33,13],'沿榉叶留下的永久舟床回砾鞍',['pan-rail-route']),exit(7,11,'pale-print',[31,12],'由实际领水人接入内水回到留白的那一面',['pan-guest-route'])],
 'keel-cradle':[exit(30,15,'wreck-slope',[8,10],'红窗复位后，真正从榉叶舟床向北滑进搁艇坡西端',['remote-lit','pan-rail-route'])],
 'pale-print':[exit(25,15,'wreck-slope',[18,12],'红窗复位后由领水人引艇穿内喉，进搁艇坡东坎',['remote-lit','pan-guest-route'])],
 'wreck-slope':[exit(7,10,'keel-cradle',[29,15],'由搁艇坡的西端回榉叶干鞍',['remote-lit','pan-rail-route']),exit(19,11,'pale-print',[24,15],'从搁艇坡东坎请领水人送回内喉',['remote-lit','pan-guest-route'])],
 'hidden-level':[exit(30,14,'breathing-scree',[26,12],'退潮找实际走过的护卵背滩回砾穹',['pan-scree-way','tide:low'])],
 'winter-court':[exit(16,11,'running-pot',[4,11],'看冬岸先到的饭锅怎样越过门槛'),exit(23,11,'reed-dispatch',[4,11],'走到芦泊等按北图新法抵达的人')],
 'flood-stair':[exit(11,12,'fourth-landing',[4,11],'沿锅架上的疏散绳进白崖第四层厨房',['harbor-tilted'])],
 'burial-cape':[exit(15,12,'after-the-spoon',[4,11],'从双碑外的渡口回仍归原住户的家门',['grave-signed'])]
};
const extra={
 'eelstep-house':[witness('pot-sign-side','在姚耳壳铺后窗问她愿意挂哪一面木招',21,14,[s('姚耳','鱼铺要鱼，舅父想的是那只会咬人的花鹅。他有他的手艺，老板也真出了一顿鱼钱。你跟我合画一面？'),s('瑟琳','你自己挑。我能扶住这东西，省得你一转它就往下掉。',[{text:'面街留认得出的鱼，木招背面只给来找灰砚的人看那只鹅',set:'pot-fish-face'},{text:'让鹅叼一条小鱼，挂到高窗，谁有闲心都看得懂两层',set:'pot-goose-face'}]),s('姚耳','选得好也得等它真挂到门上。')],'pot-sign-choice',['pot-stair-tried','!grave-signed'])],
 'bread-underdoor':[fixture('pot-sign-back','抬住店招给姚耳抠出背面鹅嘴，自己站街面确认鱼头朝门',25,14,[s('小杳','鱼在前面。鹅偷咬我手，就知道我走到店里了。')],'pot-sign-hung',['pot-fish-face','!grave-signed']),fixture('pot-sign-high','开高窗转动招牌，让鹅嘴里的鱼跟风照出两个影',32,14,[s('壳匠','那是鹅，跟买鱼的没争。'),s('铺伙计','是鱼。跟你也没争。')],'pot-sign-hung',['pot-goose-face','!grave-signed'])],
 'after-the-spoon':[witness('pot-sign-backhome','让从落眼那天就拌嘴的两家亲自挂回原招，任谁自己认',12,14,[spoken('小杳','我不认识那个字，可是把手伸到背后就知道是我舅那只鹅。','pot-fish-face'),spoken('铺伙计','有人认出是鱼进来，有人认出是鹅进来。买的都是鱼，够了。','pot-goose-face')],'pot-sign-after',['pot-sign-hung','grave-signed'])],
 'hidden-level':[witness('pan-girl-writes','等蹊泥自行决定让外人怎样帮忙送她那封信',24,14,[s('蹊泥','我写错了两行，任萤还是认得。如果你一路只替人把事情做得漂漂亮亮，她反倒认不出我。'),s('米拉','我可以什么也不看。也可以坐你旁边，让你告诉我要抄哪一行。',[{text:'留住封边，连错字也原样送到对方手上',set:'pan-letter-sealed'},{text:'按蹊泥点给我看的那一行亲自描下来，剩下不读',set:'pan-letter-read'}]),s('蹊泥','那你去我家门口压，门里有蟹，踩着了它要在你靴子里住一冬。')],'pan-mail-begun',['pan-girl-found','!grave-signed'],{after:[s('蹊泥','折歪那角我自己叠的。就那样放着。')]})],
 'silt-tongue':[fixture('pan-hold-seal','把蟹咬过的封边夹回寄信人的帽檐托，照原样送往冬岸',14,13,[s('蹊泥','谁要说封边坏了你就说，本来就有两枚牙。')],'pan-mail-safe',['pan-letter-sealed','!grave-signed']),
 fixture('pan-trace-wrong','在门前只描下蹊泥自己指的两只歪脚，合回看不见的那一页',22,12,[s('米拉','一脚长，一脚短。'),s('蹊泥','我从小就那样写北，她小时候就笑过我。你别拿尺替我量齐。')],'pan-mail-safe',['pan-letter-read','!grave-signed'])],
 'kiln-by-ear':[object('pot-cup-gift','苼罗真正送出的三瓣听籽坠',19,12,[s('苼罗','那只碗要留在孩子家门口。这枚挂坠是我多烧的一只，你带去潮口试。')],{requires:['pot-ear-cup'],action:{type:'item',id:'seed-bell',value:1,set:'pot-ear-gift'}})],
 'breathing-scree':[object('pan-curl-gift','蹊泥从旧网中剪下的弯棘套靴',22,13,[s('蹊泥','捡的是空壳。活着的还要换一轮。鞋绊朝上缝，石缝里能顺势让半步。')],{requires:['pan-nursery'],action:{type:'item',id:'scree-boot',value:1,set:'pan-shell-gift'}})]
};
const points={
 'bread-underdoor':[{id:'pot-table-door',kind:'pier',x:8,y:10,w:3,h:1,label:'带门钩的三户早饭桌'}],
 'eelstep-house':[{id:'pot-stair-corner',kind:'crate',x:16,y:12,w:1,h:1,label:'米箱撞过的内角'},{id:'pot-gray-handrail',kind:'rope',x:20,y:10,w:2,h:1,label:'必须让出的人行扶手'}],
 'bridge-draught':[{id:'pot-black-arch',kind:'wall',x:13,y:10,w:2,h:1,label:'篷角碰黑的近拱'},{id:'pot-blue-load',kind:'hearth',x:21,y:12,w:1,h:1,label:'不舍得倒的整锅船饭'}],
 'season-ring':[{id:'pot-outer-ring',kind:'post',x:14,y:13,w:1,h:1,label:'朝壳铺刻低水圈的冬柱'},{id:'pot-inner-ring',kind:'post',x:30,y:12,w:1,h:1,label:'朝窑街刻宽水圈的冬柱'}],
 'hidden-level':[{id:'pan-inside-level',kind:'rope',x:19,y:10,w:2,h:1,label:'在退海后依然顶到手边的漂邮件',sceneStates:[{until:'pan-pool-drained',pose:'boat-high'},{from:'pan-pool-drained',pose:'old-mud-visible'}]}],
 'outside-navel':[{id:'pan-sea-notch',kind:'sign',x:18,y:12,w:1,h:1,label:'只有外脐能见的贝带标杆'}],
 'keel-cradle':[{id:'pan-keel-scar',kind:'boat',x:17,y:12,w:3,h:1,label:'留在砾鞍、不能拖走的榉叶船肋',sceneStates:[{until:'pan-leaf-spent',pose:'hull'},{from:'pan-leaf-spent',pose:'cradle'}]}],
 'pale-print':[{id:'pan-empty-plate',kind:'crate',x:19,y:11,w:2,h:1,label:'外线还在、内盆已磨除的铜版',sceneStates:[{until:'pan-edge-worn',pose:'inked'},{from:'pan-edge-worn',pose:'scraped'}]}],
 'breathing-scree':[{id:'pan-eggs-wet',kind:'water',x:18,y:12,w:3,h:1,label:'吐水点沿弯拱一一错开的螺卵床'}]
};
const gates={'north-tally':['pot-fixed','瑟琳已经来了。她家的长匙号今天只能落一只冬眼。先从北埠西侧去门板摆桌的小巷，陪屋里人看两端。'],'arm-in':['pan-crossed','外臂已推。归航灯不能把外滩和内盆一并当成干路。去窗西的门舌埠，与米拉实际走通一条水。']};
export function withBasin(map){
 const entities=map.entities.map(e=>{
  if(gates[e.id]){const [flag,lockedText]=gates[e.id];return {...e,requires:[...(e.requires||[]),flag],lockedText};}
  if(e.id==='pan-bright-copy')return {...e,requires:[...e.requires,'!pan-edge-worn','!pan-crossed']};
  if(e.id==='pan-sand-away')return {...e,requires:[...e.requires,'!pan-edge-worn','!pan-crossed']};
  if(e.id==='pan-fill')return {...e,requires:[...e.requires,'!pan-crossed']};
  return e;
 });
 return {...map,entities:[...entities,...(extra[map.id]||[])],exits:[...map.exits,...(links[map.id]||[])],features:[...map.features,...(points[map.id]||[])]};
}
export const basinGear={'seed-bell':{name:'空眼听籽坠',slot:'charm',resists:{tide:.18,wind:.08}},'scree-boot':{name:'砾湾弯棘短靴',slot:'charm',resists:{tide:.14,wind:.14}}};
const paths=[
 ['where-the-pot-winters','一条灶船借给哪扇门','main',['pot-called','pot-home-height','pot-stair-tried','pot-other-end','pot-soot','pot-arch-clear','pot-side-chosen','pot-fixed']],
 ['the-goose-that-was-a-fish','鱼店想挂一只鹅','side',['pot-stair-tried','pot-sign-choice','pot-sign-hung','pot-sign-after']],
 ['oven-with-an-ear','草籽替门铃响','hidden',['pot-old-whorl','pot-ink-mud','pot-ear-met','pot-ear-cup','pot-ear-gift']],
 ['the-two-low-waters','两张曾经走对的北图','main',['pan-two-copies','pan-places','pan-out-down','pan-pool-drained','pan-both-true','pan-price','pan-choice','pan-crossed']],
 ['a-stamp-with-teeth','一封写错方向的私信','side',['pan-girl-found','pan-mail-begun','pan-mail-safe','pan-mail-met']],
 ['nursery-without-keels','等一枚活卵从砾背收进去','hidden',['pan-shell-sign','pan-fossil-sign','pan-breath-seen','pan-scree-way','pan-nursery','pan-shell-gift']],
 ['different-winter-doors','两道门各有一班冬饭','side',['pot-fixed','pot-winter','pot-evacuated','pot-home-seen']],
 ['who-leads-this-crossing','下一湾由谁来带路','side',['pan-crossed','pan-winter','pan-evacuated','pan-home-seen']]
];
export const basinQuests=Object.fromEntries(paths.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
