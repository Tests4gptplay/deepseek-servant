import {region,witness,fixture,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {mechanism,tidePost} from './district.mjs';
import {setting} from './registry-parts.mjs';

export const brake=region('bell-brake','灯亮的空城 · 早市过潮就收橹的正汊慢泊',2,'whale-city',34,22,'wood',
 [['water',0,0,34,5,'悬起半身的集市渡，只等一潮'],['crane',2,4,7,5,'必须两头的人都看见才许送的铜摆'],['building',13,3,7,5,'解渔篮绳便赶不上早市的卸筐栈'],['boat',25,3,8,6,'比短艇晚半拍的粮趸模型浮排'],['crate',0,16,11,6,'空回以后能拿来坐的鱼篮']],
 [['pier',3,9,28,3,'要从实船上移去一大筐才能让低侧窗口看见'],['rope',10,13,17,1,'停船的人握得到的低位回索']],
 [witness('cross-fish-call','陪寻夕去找愿意错过头班鱼市的船主',9,10,[s('船主聂腮','我不跟你们赌那盏灯。我这一回空着回去，回去跟谁说？'),s('寻夕','跟我说。周二的那一班我替你跑。今天先让医渡往里看看。'),s('船主聂腮','那就把我的鱼篓松下来。站在灯台上道谢我听不见。')],'cross-market-lost',['cross-hold-choice']),
  fixture('cross-clear-sight','伊沃从栈低处卸下整只渔篮，露出两边都见得到的一段手',18,10,[s('伊沃','船班少跑一潮，留出的地方刚好看得见人的腕子。你想叫停时，低着手就够。')],'cross-empty-frame',['cross-market-lost']),
  mechanism('cross-counter','分过两头的索力，用低窗和最迟的船尾共同决定放手',25,12,[s('寻夕','梁顶先响。我手在这里，浪还没走。')],['cross-empty-frame'],'cross-brake-ready','两边各有一个人能令船真停，哪端要保留余绳？',['先靠梁顶开灯，谁落后谁顺着追','将两端全拴死，让短渡和重趸同速','低窗斜绕留给短渡一掌，重趸落尾后让船主从另一端松开'],2,'船首和船尾不会同时下沉。短渡那一掌要等到他自己看清船尾才放。',[s('船主聂腮','我的手能收紧也能松。你没把我绑上去。')])],
 [exit(3,10,'fender-kin',[32,11],'回磨筐院仍能听见两头说话'),exit(29,12,'cool-wrist',[4,10],'跟短渡送到隔着一条浪的下首',['cross-brake-ready'])]);

export const wrist=region('cool-wrist','灯亮的空城 · 给等潮人留手的船头低窗',2,'whale-city',28,19,'wood',
 [['water',0,0,28,4,'从舷边先退，过柱脚才落的迟水'],['boat',2,3,7,5,'寻夕能自己俯身看船尾的矮窗'],['crane',13,2,4,6,'窄到能放回索、放不下一整手的斜扣'],['building',21,3,7,5,'晚班改作停泊巡看的短亭'],['crate',0,14,8,5,'赶不上鱼市以后坐足一潮的筐位']],
 [['pier',3,9,21,2,'在两只船都可以看清人手时保持停泊'],['lamp',17,11,1,1,'手下的绿光会被浪打出明灭']],
 [fixture('cross-wrist-stay','伊沃在近端兜住余索，等船主从远端自己看见第二阵水',10,10,[s('伊沃','我袖子湿了，这回不是叫你原谅。'),s('寻夕','把你湿袖子往旁边挪，我弟从底下看不见了。')],'cross-second-window',['cross-brake-ready']),
  witness('cross-boat-alone','让船客自己叫停再放手，送上两条船头分开的正汊',20,11,[s('寻夕','停。那半截鱼篮今天不在，我能看见你。现在过。'),s('聂腮','那班干货船走了。我会记得周二找你。'),s('伊沃','我也去，先把你那个空筐抬回冷窗。')],'cross-free',['cross-second-window','!harbor-truth','!grave-signed'],{action:{type:'flag',id:'cross-free',set:'cross-wrist-run'}})],
 [exit(3,10,'bell-brake',[28,12],'从低窗回到真的可叫停的索边'),exit(24,12,'late-moor',[4,11],'由刚刚落下去的迟水送到停船工的闸后',['cross-free'])]);

export const drain=region('basket-drain','灯亮的空城 · 会失一盘干鱼纸的低棚',2,'whale-city',34,22,'wood',
 [['wall',0,0,34,4,'一道旧水眼被晾鱼纸的人挡住多年'],['building',2,3,8,5,'能转两张干排，第三张移不出去的棚门'],['crate',14,3,6,5,'三排轻鱼纸，一上水就全部卷起'],['boat',25,3,8,6,'一只上空篓能在窄涡里原地转的老艇'],['water',0,16,12,6,'棚下比侧汊低半尺的反涡头']],
 [['path',3,9,28,2,'车轮必须从晒排短头绕出'],['rope',9,13,16,1,'水到之前能解、过后不能拉回的软篾']],
 [witness('cross-paper-owner','弦鲐叫来叠鱼纸的师傅，问晾过半日的活由谁来接',9,10,[s('纸师芹壶','第一排能折，第二排我抱上楼。第三排动了会烂，你们选的背水是我家这块。'),s('弦鲐','我的夹床给你晒够两日，过潮我跟你重新揉最下面那张。'),s('芹壶','你留着干活的手没有三只。我带这一张走，剩下两张真的让水进。')],'cross-shed-offered',['cross-float-choice']),
  setting('cross-paper-long','试从长面硬推过门的整排晾架',17,10,[s('芹壶','卡住了。别挤，取窄头。我还能自己托住湿边。')],['cross-shed-offered','!cross-short-rack'],{'cross-rack-blocked':true}),
  setting('cross-paper-short','退回两格，把窄头先送过歪门，给纸师留下可扶的一侧',22,12,[s('玛拉','站在水边的我们只见门宽，她站在坡上才看得见架尾。让她自己托。')],['cross-rack-blocked'],{'cross-short-rack':true,'cross-rack-blocked':false}),
  fixture('cross-let-water','伊沃放低槽首，只抱住带篓的一头，让背水穿过失去干排的棚下',26,12,[s('弦鲐','我剪的是自己家的旧束。别松另一头，水会把三个空篓全塞进你脚下。')],'cross-low-water',['cross-short-rack'])],
 [exit(3,10,'fender-kin',[28,15],'带着没干的手回磨筐院'),exit(29,13,'willow-heel',[4,10],'沿棚下刚过的一股水进退船湾',['cross-low-water'])]);

export const heel=region('willow-heel','灯亮的空城 · 能让小艇自己掉头的篓湾',2,'whale-city',29,20,'stone',
 [['water',0,0,29,4,'新的背汊把篓推到反方向'],['wall',2,3,7,5,'直着拖船会碰首的一对石鼻'],['boat',13,2,5,6,'只能用侧身水纹让开的窄底艇'],['crate',21,3,8,5,'能让单手抓住的两只细提把'],['water',0,15,10,5,'交过一只空篓又回给自己的回湾']],
 [['pier',3,9,23,2,'低侧回水与石鼻间宽一只空篓'],['rope',8,12,15,1,'由居民自己放松的艇尾短把']],
 [fixture('cross-float-test','把空篓放进两股水的交界，走到艇尾看它先碰哪只戏靴',9,10,[s('寻夕','篓先倒着漂。这不是倒驶，你的尾索放宽，水会自己推它侧身。'),s('弦鲐','现在我这只手就能换向。你们多给我三个帮手，反倒没法这样转。')],'cross-heel-line',['cross-low-water']),
  witness('cross-skip-turn','松自己的艇头索，等对方在船尾亲手倒过回弯',21,11,[s('弦鲐','我停，你就停。转过去。…好。'),s('伊沃','我在前头看不见你的手，我得待在你看得到的那一边。'),s('弦鲐','记住这件就够。我的舅还不在，我也没说你从此无债。')],'cross-free',['cross-heel-line','!harbor-truth','!grave-signed'],{action:{type:'flag',id:'cross-free',set:'cross-float-run'}})],
 [exit(3,10,'basket-drain',[28,13],'逆着一排浮篓回磨筐旧棚'),exit(25,12,'late-moor',[4,11],'走能从本船叫停的退船弯到闸后',['cross-free'])]);
