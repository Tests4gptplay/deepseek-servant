import {say as s,person,object,flag,exit} from './parts.mjs';
import {district,mechanism,tidePost} from './district.mjs';
export const lift=district('counterlift','亮灯空城 · 反提梯井',2,25,18,'wood',
 [['wall',0,0,25,2,'封水腹壁'],['building',2,3,5,4,'停梯暖房'],['water',10,4,4,7,'竖井'],['crate',18,3,4,4,'上舱配重'],['water',0,14,10,4,'溢水沟']],
 [['pier',7,9,15,2,'掌绳踏台'],['crane',15,7,2,2,'反提双筐'],['rope',10,11,7,1,'磨白的回股']],
 [person('lift-watch','打着赤脚的纱婆',6,9,[s('纱婆','那人说抬走了最后一只满筐，叫我们去追强盗。我亲手在筐底缝过补丁，筐往下走的时候，补丁朝哪你看得见。'),s('玛拉','把那件湿袖套给我，放在筐边认方向。')]),
 mechanism('lift-invert','着色反提轮',15,8,[s('伊沃','湿衣挂在上股，旧槽从海侧绕到屋侧。先用一只空筐验它是不是只能下不能回。')],['roof-shelter','recent-wash','reverse-scuff'],'lift-proved','空筐要落到底，再由原绳回到屋顶，怎样绕？',['两股同扣外钩','交叉回股，让湿袖那股逆行','割去回股，让筐沉底'],1,'同扣会让两筐同向，湿袖停在原层。回股磨痕在内侧。',[s('纱婆','下去的筐又上来了，湿袖现在在高钩。有人来回运过两趟，不是拖着整船走了。')]),
 tidePost('pit-clock',20,11),
 object('wall-knock','西墙的三长一短',4,12,[s('墙里','笃、笃、笃。隔一拍有个轻响。杜姨说这节奏是针线工停机，让夹墙里的人递回针筒。')],{action:flag('seam-knock')})],
 [exit(1,8,'whale-roofs',[14,10],'回排烟屋顶'),exit(23,9,'dry-court',[2,8],'上层平梯通晒衣院',['lift-proved']),exit(15,14,'crib-hold',[3,5],'低水转筐下底舱',['lift-proved','tide:low'])]);
