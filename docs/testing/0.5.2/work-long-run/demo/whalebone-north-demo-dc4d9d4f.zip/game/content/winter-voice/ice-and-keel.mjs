import {shore,fixture,witness,person,spoken,exit,say as s,mechanism,tidePost} from './cast.mjs';
export const glass=shore('whalefall-glass','能把同一声还两回的冰窗',32,21,'stone',
 [['water',0,0,8,5,'碎冰围住的声井'],['wall',11,0,6,6,'岸冰底下第二层斜面'],['water',22,0,10,6,'冰块间偶尔能看见冷水'],['wall',0,16,9,5,'向南倾的整排压冰石'],['building',21,15,11,6,'悬满渔灯碎片的旧棚']],
 [['path',2,8,27,3,'埋有细炭灰的干走道'],['voice-ice',7,6,7,3,'透过前片看见后片的两层蓝冰'],['voice-dial',19,9,4,2,'可以把两张冰影对齐的绳索刻度盘'],['voice-lamp',25,12,2,1,'顺风旋过半圈的低灯']],
 [fixture('whalefall-ice-near','涨水时敲近片的铜钉',9,10,[
  s('米拉','我夹住铜钉敲了一记。看碗沿：尖、尖。第二圈沿第一圈原来的位置回来。'),
  s('洛洄','我在水里听见两下，你在岸上只动了一次手。爹喊收席时，棚里喊他回来的，往往是他自己的鼻音。')],'whalefall-glass-high',['whalefall-cups','tide:high']),
  fixture('whalefall-ice-gap','退水时在同一瓣冰的缝里横放一把小勺',14,12,[
   s('瑟琳','水已经下去。勺子碰前片，碗里只留一圈，后片也只在空中嗡了一口气。我把潮封在这一寸，等你再敲。'),
   s('玛拉','昨夜喊了两声的人可以只是一个。还须看看不靠冰的地方收到了什么。')],'whalefall-glass-low',['whalefall-cups','tide:low']),
  mechanism('whalefall-read-glass','给两次记录间夹一层干毡，裁定冰里的第二声',21,10,[
   s('米拉','潮退过又涨回来，钉孔没挪，后面那瓣冰只在高水时搭进水里。用哪一对圈画它回来的样子？')],['whalefall-glass-high','whalefall-glass-low'],'whalefall-glass-known',
   '哪一种解释和两次动手的记录相合？',['两只鲸总在不同的地方说话','同一次敲击从浸水的后片返回','近片里的钟打到第二轮'],1,'干勺抵着同一根钉。退水时第二圈一同消失。回到铜钉还可以再敲。',[s('米拉','在图上画折返线。冰片翻面以后，就收不到这一下了。')]),
  tidePost('whalefall-glass-clock',17,11),
  person('whalefall-tin-mender','挑拣灯罩碎片的简穗',26,13,[s('简穗','罩上小半轮月亮，转到海上就只见一指宽的亮处。我的手被砸过，握不住剪子，只好叫别人剪最软的锡，我自己留最尖的玻璃。'),spoken('简穗','你收了两张不同的冰纹，我给你报一个数字：后片离钉四臂。今天四臂，明天可说不准。','whalefall-glass-known')])],
 [exit(2,10,'whalefall-porch',[27,10],'回半湿饭桌'),exit(28,11,'whalefall-keel',[22,11],'沿破冰石去抚木艇腹',['whalefall-cups'])]);
export const keel=shore('whalefall-keel','三瓣藤壶之间的抚木艇腹',31,20,'wood',
 [['water',0,0,9,6,'潮水浮起老船左腹'],['wall',12,0,4,5,'旧拖船的钙化绳索'],['water',20,0,11,6,'还在经过湾口的鲸群'],['water',0,15,8,5,'无灯的低潮缝'],['building',17,15,14,5,'从艇底露出的卷帆仓']],
 [['pier',2,8,25,3,'沿板缝卸下鞋钉的过道'],['voice-keel',6,5,7,3,'艇肚上的三瓣藤壶和没有铁箍的旧木'],['voice-cord',17,8,5,2,'向浅湾压低一头的蓝带'],['voice-keel',21,11,5,2,'船尾裂开的空心舵叶']],
 [fixture('whalefall-wood-chest','隔着整木听一道长息，让耳旁的铜钉静下来',9,10,[
  s('洛洄','把耳朵贴这里。我在水里把她经过的方向指给你。长——先压我的指节；短，再压指尖。第三下才轮到小的。'),
  s('玛拉','两道水纹没有沿旧圈回去。第二个漩往外边移了半只碗。')],'whalefall-wood-long',['whalefall-cups']),
  fixture('whalefall-wood-tail','在另一头松开艇尾的拖笼，听第三道小气息从背后越过去',21,12,[
   s('伊沃','笼子垂直时响一声。我把它拴平了，第三声还在，从屁股后头走到左舷。'),
   s('洛洄','幼鲸上来的时候绕了母亲的尾鳍。她身上没有鼓给我们敲。先听完她要去哪里。')],'whalefall-wood-short',['whalefall-wood-long']),
  mechanism('whalefall-read-wood','把两条不同长度的蓝带系在实际经过的两处',16,10,[s('瑟琳','冰口的回音回到原钉。此处把艇尾的笼放平，最后一息仍在移动。手伸哪边，让最后那只过？')],['whalefall-wood-long','whalefall-wood-short'],'whalefall-wood-known',
   '第三圈从艇后向左舷走。要给她留下哪条水？',['收起左舷拖笼，让开母鲸尾后','拦住前头的冰窗，等回音消失','敲空艇把所有鲸招到船边'],0,'小圈向左舷移动，退铃与解笼都没把它消掉。船上的人可以移开自己的东西。',[s('洛洄','我给你们记下母子两次过艇的时间。遇到下一条鲸，这张纸还得从头记。')]),
  fixture('whalefall-third-shell','退潮时沿最小一瓣藤壶摸到孩子打的五股结',7,12,[s('玛拉','不是谁落下的缆。小手把一根线编成五股，为的是在黑里也能找到头。尽头钻进了一块搁浅的鲸骨里。')],'whalefall-found-knots',['whalefall-shed-clue','whalefall-wood-short','tide:low']),
  tidePost('whalefall-keel-clock',13,12)],
 [exit(3,10,'whalefall-porch',[18,14],'沿湿梯回半湿饭桌'),exit(24,10,'whalefall-glass',[27,10],'沿破冰石回铜钉'),exit(6,14,'whalefall-bone',[3,8],'从五股绳空下的一股钻进退潮鲸骨',['whalefall-found-knots','tide:low'])]);
