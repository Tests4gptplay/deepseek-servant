import {fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s} from './parts.mjs';

export const needAir=witness('count-blanket','请卸下湿被的绮红自己呼灯',10,11,[s('绮红','我能抬手，腿要平放。他们把我算进到岸两家了：人到了，一条硬湿毯还裹着我，手迟早抬不动。谁能带干布过来，谁来听我自己答。'),s('玛拉','已到的人也要继续活。冬岸签上写过长梯和灯油，但不一定两个都在。')],'borrowed-breath',['base-safe']);
export const terrace=fixture('terrace-sled','沿修妥西窗长梯，请实到的测缆员送干床套',18,11,[s('测缆员','梯子在贴墙的一侧。两个人在半台换手，能把整张晒干的卧套水平送下去。你答应保护证人那班，我实际来划过船，现在还能抬。'),s('绮红的女儿','走原梯，我能自己带她的另一双鞋。')],'breath-sled',['borrowed-breath','west-stairs','north-linesman','beds-arrived','!breath-rigged'],{action:{type:'flag',id:'breath-sled',set:'breath-rigged'}});
export const oilshade=fixture('hooded-litter','请上岸的铅字工把公油送到遮风棚',13,11,[s('仓守','公灯架是之前签领的，不用去拆私人窗。倾过的字模空箱够长，我把灯托在箱尾，油纸烘暖，先送一层给她换。'),s('绮红的女儿','这张箱床轻，不会碰掉我娘手里的答灯。')],'breath-oil',['borrowed-breath','north-lampstock','workers-arrived','!breath-rigged'],{action:{type:'flag',id:'breath-oil',set:'breath-rigged'}});
export const dryBundle=fixture('slope-blanket','肩扛两卷干布沿高坡分次递送',12,11,[s('港工','没有整副梯，或者你想把那盏灯留给别人，都可以走干坡。我一手只能送一卷，另一个人的换衣要稍候。')],'breath-walk',['borrowed-breath','!breath-rigged'],{action:{type:'flag',id:'breath-walk',set:'breath-rigged'}});
export const life=witness('woman-lifts-light','让绮红在真正换衣后自己举一回灯',14,12,[spoken('绮红','梯上整套床褥过来，膝窝没折。我的鞋是我女儿一路拿来的。','breath-sled'),spoken('绮红','我看见灯箱被罩成橘黄。你们用公油烧了一班，油多了一次用途，钱还得照帐算。','breath-oil'),spoken('绮红','两条干布先后到，我在前廊多等了几个呼吸。不是图上有一道线，我就从没冷过。','breath-walk'),s('绮红','现在好些。我可以自己起灯，别人问我便由我回答。')],'breath-home',['breath-rigged']);
