import {fixture} from './voyage-parts.mjs';
import {say as s,exit} from './parts.mjs';
import {mechanism} from './district.mjs';
import {room,fresh} from './the-sleeve-and-the-spray.mjs';

export const beam=room('scorerock-beam','北航 · 保持船首朝北的三船横测',32,20,
 [['water',0,0,32,5,'前方红芦袖近，白浪喷孔远，最后是黑牙'],['wall',2,3,4,5,'西拴桩'],['wall',25,3,5,5,'东拴桩'],['water',0,16,14,4,'若让艇转头就不再是同一条横测线'],['boat',22,15,10,5,'靠灰缆横渡的四桨摆艇']],
 [['pier',2,10,27,2,'五格甲板代表半船；这边至那边十五格，三条船身长'],['rope',6,8,18,1,'两端各系一根横缆，船首不可转'],['sign',20,12,1,1,'东站记远近侧移']],
 [fixture('score-held-head','西站双桨的水刺',7,10,[s('伊沃','横过时两桨一收一放，别拧船头。你照后舷的灰缆，缆纹始终横着，黑牙就没绕你转。'),
 s('米拉','先把近袖套回和旧图同样的潮结，再在另一头取方位。若让浮弓自己先走两船长，这次比较就作不得准。')],'score-head-held',fresh,{action:{type:'flag',id:'score-head-held',set:{'score-line-out':false,'score-look-aft':false}}}),
 fixture('score-middle-splice','横渡途中的中缆活扣',13,10,[s('葛芮','左桨停一下，我给灰缆接一指。你若为等一柱白水全停住，船头早叫斜潮扭了。'),
 s('玛拉','我压住右桨。三截绳一道一道过去，岸上没人拖着我们赶数。')],'score-beam-cross',['score-head-held',...fresh]),
 mechanism('score-east-reading','东站上朝北的分度角',22,10,[s('米拉','再一柱白水。黑牙分口在最右；白喷蹭着它的左唇；近处红袖已移到更左。我刚才没有转头。')],['score-beam-cross','!score-line-out',...fresh],'score-beam-fix','保持船头朝北，眼睛向东横移了三船长。哪一样被推向左最多？',
 ['黑牙最远，所以向左跑得最多','近红袖；远白喷偏得少，黑牙最少','三样一起挪，旧图那条直线跟着挪就是新路'],1,'对照灰缆两端的船首方向。最近的袖离旧垂线最远，白喷还贴在牙唇。',[s('米拉','一条方位改画成三个距离。旧图没有假，只能从南面的一个眼位用。')]),
 fixture('score-two-bows','把两首位隔开的灰缆压在新图下',25,12,[s('玛拉','不照一根线切过去，先让红袖从左舷过，再认远牙右手那一口。'),
 s('葛芮','你们踩过我的旧脚，也踩了它没画的三船长，换我坐上你们的图。')],'score-beam-sailed',['score-beam-fix',...fresh],{action:{type:'flag',id:'score-beam-sailed',set:'score-surveyed'}})],
 [exit(3,11,'scorerock-origin',[29,10],'沿灰缆收两桨回旧趾窝')]);

