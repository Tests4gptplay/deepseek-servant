import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit} from './parts.mjs';
export const wool=region('wool-ferry','撤离 · 低沿衣渡与高窗宅',6,'flood-harbor',29,19,'wood',
 [['water',0,0,29,4,'向北拉的冬水'],['building',1,5,5,3,'小孩拿衣的低宅'],['crate',13,4,5,3,'随水回弹的两层摆衣架'],['building',22,4,7,4,'摆渡人的换衫铺'],['water',17,14,12,5,'供接机船转身的小埠']],
 [['pier',2,9,24,2,'穿暖衣后才上船的明水桥'],['rope',8,11,12,1,'过渡者自己可松的补袖带']],
 [witness('child-cloak','让搂着布兔的绣班阿存自己套袖',8,9,[s('阿存','我的布兔一只耳没棉，这件袖口也一面厚一面软。我能从这里先伸手还是一定要大人抱？'),s('玛拉','你可以只抱兔，我把厚缝朝外。'),s('阿存','那我先把脚伸过去。到对岸要帮我把另一只袜子洗一下，袜尖有个洞。')],'cloak-worn',['cloth-for-child','tilt-sighted']),
 witness('oar-cloak','让值后半班的摆渡人试两手都能放桨',20,9,[s('摆渡人','旧围巾掉下水，桨还在手上，没人敢替我去捡。我需要肩上能挂住、转身不拖的。'),s('寒麦','你先在临水的舷上转一圈。后头要过船，别为了试衣把门堵了。'),s('摆渡人','我做两个动作算一班。穿得住就带一个晚到的搭客返回去。')],'cloak-worn',['cloth-for-oars','tilt-sighted']),
 witness('cloth-landing','在对岸暂棚核对补丁在谁肩上',15,10,[spoken('岑艾','来的是绣班孩子。她脚上那只袜子的孔我从里面织好了，别说救过一个“无名孩子”，她叫阿存。','cloth-for-child'),spoken('岑艾','摆渡人自己穿过来的，尾舱还带了一位没赶上白班的锯工。让他说睡哪儿，我把长凳给他留平。','cloth-for-oars'),s('寒麦','回去可以告诉我哥哥，她们是自己走到床边的。把那件不合身的样布也给我留着。')],'cloak-arrived',['cloak-worn','base-safe']),
 witness('chart-shelter-door','打开换给挂网街老人的暖屋内门',11,11,[s('阮婆','我带这张旧席来，不会占别人孩子的床。小岩在街上改一块砖，我在这里借一夜火，两件事都有报答。'),s('米拉','我出了这间冬租，你不用给我的图署还人情。明春我回来请你帮我看二楼窗。')],'map-help-arrived',['chart-shelter','base-safe']),
 witness('chart-hoist-door','请低窗当班人从屋里拨响集合索',23,10,[s('小岩','高的那条由我拨，低的留给换班的人。谁说低窗就是危险户？看到我娘自己从窗里走出来吗？'),s('米拉','看见了，记在实走这一栏。我的旧图留着划掉的错号，方便下回有人问起。')],'map-help-arrived',['chart-hoist','base-safe'])],
 [exit(2,9,'flood-stair',[24,12],'回收粮坡'),exit(25,9,'safe-keel',[14,9],'随接人的引航驳进北岸')]);
export const bookEnds=[
 witness('cloth-next-winter','墓后听寒麦说那幅袖布的去向',20,10,[spoken('寒麦','阿存没把补衣当宝贝供。她穿破两只肘头，拿那块兔耳棉自己补过一次。','cloth-for-child'),spoken('寒麦','摆渡人穿它过了最后一船，把锯工那家带到有炉子的门里。往后他给班里人都加同样的翻袖。','cloth-for-oars'),s('玛拉','我替别人挽过那么多袖。今天我想学她补肘，不是再替她抻平。')],'cloak-home',['cloak-arrived','grave-signed']),
 witness('corrected-cart','墓坡转角交给米拉一份改正后运输的冬单',9,12,[spoken('小岩','阮婆住进暖屋以后还是要回自己的窗去掰网坠。我们按她走过的路添上低栏，给下一年想搬回去的人。','chart-shelter'),spoken('晞渠','响索那支夜班表给我看过。米拉出了一季工，不欠整辈子。我把她错过的三个门号压在新图底下。','chart-hoist'),s('米拉','我以为更正是擦掉自己的名字。今天我愿意让它留在旧版和新版之间。')],'cart-home',['map-help-arrived','grave-signed'])];
export const relief=[
 witness('bran-relief','等布兰本人把签过的冬粮账兑在岸上',18,9,[spoken('古杳','抵的泊股收进船账，我延了一冬的利。布兰在杂货门边押的椅子，明早他家人会来搬走。','berth-bond'),spoken('井梁','两班工的钱到手了。不是买我一句“当初就该这么办”；我明天还会跟他说，熏鱼要先留给镇上。','fish-bond'),s('布兰','粮船真靠了，我才把旧泊的章封起来。以后哪天远港真缺粮，得从头拿实数来谈。')],'bond-settled',['stores-backed','base-safe'])];
