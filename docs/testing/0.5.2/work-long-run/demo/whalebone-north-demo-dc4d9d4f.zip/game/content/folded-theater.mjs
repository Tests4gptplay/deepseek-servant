import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {mechanism,tidePost} from './district.mjs';
import {setting} from './registry-parts.mjs';
export const ramp=region('screen-slope','冬岸 · 老影车用过的开坡与倒挂的天幕',5,'north-interior',35,23,'wood',
 [['wall',0,0,35,4,'窄侧有两个直角的老坡'],['building',3,4,8,5,'挂小兽戏的高台'],['crane',16,3,5,6,'吊日月两片天幕的梁'],['building',26,3,8,6,'可以另给膝门的上层旧宅'],['crate',0,17,13,6,'推上去后不能再挂天幕的彩景'],['wall',24,16,11,7,'有木珠划痕的慢坡外弯']],
 [['path',3,10,28,2,'可以走慢、需要空出宽弯的影车道'],['rope',8,14,20,1,'拆开便永久少一幅影布的位置']],
 [witness('ramp-watch','陪甫岸自己把一台空景车从窄角推出去',9,11,[s('甫岸','别扶我，我拐不过你家所谓的直角。把画月亮那只脚卸掉，让我自己把外把手推过去。')],'ramp-tried',['herd-compared']),
  mechanism('ramp-splay','不卸屋梁，给景车外把拆出甫岸真能转过的角',18,11,[s('戏主卧缨','卸掉照月亮的侧架，这一出就只能在白天排。我要看到你们真能过再答应。')],['ramp-tried'],'ramp-passed','甫岸直着膝推车时，哪端的车辙将擦掉一指？',['留下内轮，把外把弧线踩出的斜角让出来','把室外台阶再堆高半级','缩短坐板，让甫岸收膝'],0,'外把划出一道弧。内轮过门容易，他的身体和外把要在同一边转。',[s('甫岸','我过了。让小垛倒着来接我，两辆车得各等一拍。')]),
  person('ramp-moon','给戏布上的旧月亮起名的灯婶',25,12,[s('灯婶','这次月亮叫馒头。上一块叫大饼。不能怪我没诗意，我排夜戏前不吃晚饭。')])],
 [exit(3,11,'heel-house',[28,12],'沿车坡回角院'),exit(30,12,'split-houselight',[4,11],'进可改成上院住间的天幕库',['ramp-passed'])]);
export const tow=region('curtain-tow','冬岸 · 脚平的低岸与晾网人归途',5,'winter-coast',36,23,'stone',
 [['water',0,0,36,5,'沉角兽向里露鼻的窄水盖'],['building',2,4,9,5,'旧网户的浅档棚'],['crane',15,3,6,6,'能收不能钉死的苔边网梃'],['boat',26,4,9,5,'让幼兽时缚在陆侧的平舟'],['water',0,17,12,6,'一涨就要让回给成兽的旧口'],['crate',24,16,12,7,'过夜暂时要把网转收的房']],
 [['pier',3,10,29,2,'和软膝同高、会被幼蹄切断的下岸'],['rope',9,13,19,1,'让开角群后还可以重新拉直的侧幕']],
 [fixture('curtain-moor','用小垛那条脚短的板车试出背岸不会卡轮的位子',9,11,[s('小垛','板能走。我把这一面全围起来，就不怕滚下去了。'),s('野檀','你自己再过一回。你围住的是小兽等它妈的地方。')],'sill-tried',['herd-compared']),
  setting('curtain-block','把网顺着浅岸全展成一面永久侧墙',16,11,[s('小垛','东西不掉，自己走不回去。上岸的那头一直在找出口。')],['sill-tried','!sill-passed'],{'sill-choked':true}),
  setting('curtain-gather','把网重新成束挂回房内，留出母兽的回口',18,13,[s('小垛','夹住网边就能放开。每次要多走一趟收网，这活轮到出院的人做。')],['sill-choked','!sill-passed'],{'sill-choked':false,'sill-clear':true}),
  witness('curtain-walk','与甫岸一起在收网的低口转过两台宽窄不同的车',26,11,[s('甫岸','我从里边出来，小垛从外边接上。这里没楼梯，我的腿喜欢。可谁晚睡收网？我跟野檀一人一天。')],'sill-passed',['sill-clear'])],
 [exit(3,11,'heel-house',[14,13],'贴干墙回膝门'),exit(31,11,'split-houselight',[21,15],'沿可轮流借的平岸进角院后门',['sill-passed'])]);
export const hall=region('split-houselight','冬岸 · 可以真开两种门的天幕库',5,'north-interior',38,24,'wood',
 [['wall',0,0,38,4,'被斜杆分成两间的旧库'],['building',2,4,8,5,'家人自己的膝门'],['crane',16,3,6,6,'把整面月幕压在侧门的老吊钩'],['building',28,3,8,6,'低岸一开就须夜里有人收网的房'],['crate',0,17,13,7,'用余景临时隔出来的过冬处'],['wall',25,17,13,7,'从上和下都能打开的角窗']],
 [['path',3,10,30,2,'两边都能回的后厅'],['rope',10,14,17,1,'可以由屋里人决定拉哪一边的门索']],
 [witness('hall-choose','跟野檀、甫岸试完以后，在他们自己的家里决定用哪一扇',13,11,[s('野檀','两条路都走过了。我留在原屋。你若要上方，帮卧缨卸月幕；若用下方，把夜里收网那一班真的留给我们。'),s('甫岸','你推哪扇，我就跟哪扇自己出来。',[
  {text:'卸下影戏月幕，把上院交给过冬的两户',set:'ridge-chosen'},{text:'留上院演夜戏，夜里收起平岸网让兽回头',set:'sill-chosen'}])],'house-decided',['ramp-passed','sill-passed'],{after:[s('野檀','门还是要人亲自开，没推过去就别说已安顿。')]}),
  person('hall-broom','立在门边看着一把紫扫帚的白逐',22,13,[s('白逐','来一班人踩一地泥，我有一把见到泥就掉毛的扫帚。有人想跟我换只勤快点的么？')])],
 [exit(3,11,'screen-slope',[29,12],'放慢景车回上坡'),exit(21,16,'curtain-tow',[30,11],'跟平舟回晾网口'),
  exit(29,11,'moon-dorm',[4,11],'拆老月布，实际打开改成住房的上院',['ridge-chosen']),exit(31,14,'net-dorm',[4,11],'和新住户转开低门、亲自绕兽过夜',['sill-chosen'])]);
export const upper=region('moon-dorm','冬岸 · 拆了月幕以后会天亮的新房',5,'north-interior',31,20,'wood',
 [['wall',0,0,31,4,'半扇旧幕已卸的梁'],['building',3,4,7,5,'没有床幔的第一间家'],['crate',15,4,5,4,'用脚能开的轻滑门'],['building',23,3,7,6,'转给邻居住的第二间'],['wall',0,15,10,5,'仍可俯见成兽通行的屋外高角']],
 [['path',3,10,25,2,'甫岸自己可以走回来的外弯'],['lamp',17,12,1,1,'只有白天才可用的新戏台']],
 [fixture('moon-unhook','沿先前景车的弧线把真月幕摘下来、存进矮柜',11,11,[s('卧缨','我给这块月亮缝过五回。今天我自己把头一只钩摘下来。白日演出少人，房间里总算会天亮。')],'moon-loose',['ridge-chosen']),
  witness('moon-open','让甫岸和两户住客从外把角自己把行李车送过门',21,11,[s('甫岸','放手。我把门打开了，能进去，也能回来。野檀还在楼下等我借她的斧子。')],'concourse-agreed',['moon-loose'],{action:{type:'flag',id:'concourse-agreed',set:'ridge-rooms'}})],
 [exit(3,11,'split-houselight',[28,11],'离开住客自己的上院')]);
export const lower=region('net-dorm','冬岸 · 留着兽口的平岸旧院',5,'winter-coast',31,21,'wood',
 [['water',0,0,31,4,'空出一整段的幼兽归水口'],['building',2,3,8,6,'挂起而非铺平的旧晾网'],['boat',14,3,8,5,'弯钩自己转的渡头'],['building',23,4,8,5,'能从艇和巷子两头进入的老屋'],['crate',0,15,9,6,'整夜须守着的收网格']],
 [['pier',3,10,25,2,'给两户居民和小兽错时间的平门'],['rope',9,13,13,1,'能改时候却不能一夜塞死的网幕']],
 [fixture('netdorm-night','把居民的网成束收入室内空出脚下的外缘',11,11,[s('野檀','这下我得夜里来一次。下决心的是我，凭什么让小垛替我守第一夜。')],'flat-tied',['sill-chosen']),
  witness('netdorm-open','让甫岸开门，小垛把车穿过仍留给幼兽的回弯',21,11,[s('小垛','它踩我的脚印，它没踩我！我是不是也能借它的路？'),s('甫岸','能。趁现在，后头那家可要出门了。')],'concourse-agreed',['flat-tied'],{action:{type:'flag',id:'concourse-agreed',set:'sill-rooms'}})],
 [exit(3,11,'split-houselight',[30,14],'在兽路还敞着时回前厅')]);
