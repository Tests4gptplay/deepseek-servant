import {exit,object,person,say} from './parts.mjs';
import {region} from './voyage-parts.mjs';
import {tidePost} from './district.mjs';

const marks={
 sheet:['open'],hull:['material'],basket:['material'],runner:['voice'],nurse:['voice'],
 desk:['settled','rumor','quiet','posted','corrected'],
 cast:['sailed','load-public-grain','load-public-bed','load-quiet-grain','load-quiet-bed']
};
export function station(key,label,x,y,npc=false,requires=[]){
 const set=(marks[key]||[]).map(id=>'quaybill-'+id);
 return (npc?person:object)('quaybill-'+key,label,x,y,[],{requires,action:{type:'quaybill',key,id:set[0],set}});
}
const sign=(id,label,x,y,who,line)=>object('quaybill-'+id,label,x,y,[say(who,line)]);
export const gallery=region('quaybill-wet-sheet','盐市 · 五号栈的湿纸廊',3,'salt-interior',27,18,'stone',
 [['building',0,0,8,5,'晒浆纸房'],['building',13,0,10,5,'写副单的小账厢'],['crate',20,12,7,5,'装旧湿账的竹函'],['building',0,13,6,5,'淋退了色的票房隔壁']],
 [['path',1,8,24,2,'一条头朝南一条头朝北的板车痕'],['qb-paper',8,6,5,3,'保住原折痕的背光夹'],['qb-slip',16,7,3,2,'公议留夹与带回的私夹']],
 [station('sheet','两层粘在一起的《栖鸥号六袋白麦》',9,9),station('desk','临水听账桌，可以试写、撤下或正式送交',17,9),
 station('seller','守着唯一饭篓的粮商晏甫',7,10,true),
 sign('guide','贴在湿墙上的临时取证路图',13,10,'晒纸人','沿西门去舟腹，把拉粮的两个磨口拿来对。东门去浴房，看回水眼是不是街上的绳也能沾。谁站在岸上、谁站在船上，要分开问。')],
 [exit(2,9,'salt-lane',[14,8],'回盐市晾尺行'),exit(24,8,'quaybill-sill',[3,8],'去五号泊台和舟腹'),exit(16,15,'quaybill-steam',[3,8],'沿旧回水渠进浴房')]);

export const sill=region('quaybill-sill','五号泊 · 退水后仍挂在桩上的船名',3,'salt-market',31,19,'wood',
 [['water',0,0,18,4,'潮痕覆在号桩上'],['building',20,0,8,5,'舟脚换绒鞋的旧屋'],['water',21,14,10,5,'铁链下的回流'],['crate',0,13,7,6,'退下的夹板和桩条']],
 [['pier',1,7,28,3,'舟舷只到第四个绳眼'],['qb-hull',5,4,9,4,'四只磨亮的舷眼和两个不动的岸钉'],['qb-bathline',14,9,9,3,'潮线跨过的山墙绳']],
 [station('hull','把可挪动的木规贴住舟舷弯痕',9,9),station('runner','在船脚上擦手的庹英',21,9,true),tidePost('quaybill-sill-tide',15,8),
 sign('plate-hint','补过船头的倒榫尖',6,8,'伊沃','弯刮痕全在活动舷的内面。先顺榫的尖向码头，再把压尺挪到退潮露出的那条舷线。上面的横划一直到岸墙，别只数到六。')],
 [exit(2,8,'quaybill-wet-sheet',[23,8],'回湿纸廊'),exit(28,10,'quaybill-steam',[21,9],'绕到浴房偏墙')]);

export const steam=region('quaybill-steam','旧鲛浴房 · 蒸麦锅与岸边回水渠',3,'salt-interior',27,19,'stone',
 [['building',0,0,8,5,'夜里借给替班人的更衣室'],['wall',13,0,7,4,'带雨篦的回水墙'],['building',20,13,7,6,'捂蒸麦饭的窄厨房'],['water',0,13,7,6,'锅底泄出去的一道盐水']],
 [['path',2,8,22,2,'碱垢从炉底一直挨到门外'],['qb-oven',8,5,6,3,'锅口热，门孔常冷的旧灶'],['qb-seam',16,8,5,2,'两只袋底的蒸痕']],
 [station('basket','把六根有号的袋线贴到热汽与冷水的界面',11,9),station('nurse','借灶给夜班人做饭的岑藕',17,10,true),
 sign('steam-hint','两只沾麦糠的蒸屉',7,8,'灶下的小字','问袋底碰过什么。热汽把内线变黄，外面刮盐水只白掉一层。让凉的一面朝渠；摸锅沿余温，千万别拿袋口一个蓝圈认亲。')],
 [exit(2,8,'quaybill-wet-sheet',[16,14],'回湿纸廊'),exit(24,9,'quaybill-sill',[27,10],'绕回五号泊')]);
