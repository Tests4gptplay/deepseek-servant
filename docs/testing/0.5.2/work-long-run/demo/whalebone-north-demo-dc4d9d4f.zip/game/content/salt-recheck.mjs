import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {setting,shiftPost,pages} from './registry-parts.mjs';
import {say as s,object,person,exit} from './parts.mjs';

export const die=region('ticket-works','盐市 · 回纹票作',3,'salt-interior',27,18,'stone',
 [['building',1,1,6,5,'低温退蜡角'],['crate',10,1,5,5,'三层压印皮垫'],['building',20,1,6,5,'保管原模的盲窗'],['crate',17,12,9,6,'撤回后才打开的旧夹板']],
 [['path',2,8,22,2,'向两班工人都开着的验样线'],['lamp',13,7,1,1,'用斜光看的凹缺']],
 [witness('maker-rules','压蜡工·狄芬',8,8,[s('狄芬','看得见这个裂角的人，都能仿个裂角。真旧印有第二层：印台歪了，背纸左下也受压。'),s('瑟琳','我母亲做封票时，按印会朝自己身子偏。你要说她造假，先证明这不是她的手劲。'),s('狄芬','就是这个意思。我们拿两张废蜡试，一张热、一张冷。真票暂且放回她手上。'),s('玛拉','我只带背纸走。它能说明压过一次还是两次，不能代你们认人。')],'pressure-rules',['dry-standard']),
 setting('lay-warm','托热毛毡放第一根背纸',13,8,[s('狄芬','热蜡连模裂角都摊圆，背面却是平的。留着反样，否则只交你想看见的结果。'),s('瑟琳','我的指头能在裂角旁压出第二条阴影。阴影不能自己证明谁做过。')],['pressure-rules'],{'wax-warm':true,'wax-cold':false,'wax-handed':false}),
 setting('lay-cold','在另一张干垫上重新冷压',19,8,[s('瑟琳','干垫的左下角穿出纸背，松手弹回一点。'),s('狄芬','先去临仓取对光木板。票七和票八的背角若不在同一处，就不能说是同批重开。')],['pressure-rules'],{'wax-warm':false,'wax-cold':true,'wax-handed':false}),
 fixture('release-wax','从夹板撤下试样，让软印和硬印都能归还',16,9,[s('狄芬','两张废样都拿得回来。你不把纸留在我这里，我也不会替你在听证廊证成。')],'wax-withdrawn',['pressure-rules'],{action:{type:'flag',id:'wax-withdrawn',set:{'wax-warm':false,'wax-cold':false}}}),
 fixture('retired-lining','出示筝的见证，请她自己剥出旧班退下的背纸',11,9,[s('筝','新章取代了原章，我仍留着下面这层纸。你可以取压痕，不能说你看过已经化掉的原蜡。'),s('狄芬','今天拿来的是旧背样，和仓守保住的原印来自两种人。收样的人把这句写进去。')],'backing-known',['witness-first','testimony-lodged']),
 person('mute-docket','给两张背纸刻边的仲寻',10,10,[s('仲寻','我不识印文。切口朝里是收过的，朝外是还未收。字给一个人看，刀口给一屋子人摸。'),spoken('仲寻','那块分粮版是真的有人用过。两个窄疤挨在一起，我不用问旁人也能摸出复印。','board-proved')])],
 [exit(2,8,'salt-lane',[18,10],'回一街市口'),exit(24,9,'transit-shed',[3,8],'拿背纸去临仓'),exit(15,12,'blind-window',[3,7],'探问开给夜班的无字凭窗',['ticket-mother-heard'])]);
export const shed=region('transit-shed','盐市 · 两班共用的过仓棚',3,'salt-market',30,17,'wood',
 [['water',0,0,30,3,'码头窄渠'],['crate',3,4,7,4,'七潮下船木位'],['crate',15,4,6,4,'八潮再批木位'],['building',20,12,10,5,'不会再下第二次货的旧匣']],
 [['pier',2,9,24,2,'一条车轨两个落印桌'],['rope',10,7,5,1,'带分度的过仓湿绳']],
 [witness('weigh-token','旧铜码的保管人·枣惠',8,9,[s('枣惠','铜码不是一袋粮。第七潮我把码交给出仓人，第八潮他拿回码说“已移库”，不是又卸了十二袋。'),s('玛拉','为何在两班簿里各见一次？'),s('枣惠','账上两次是对的，货上两次才是错的。铜码右肩的锉印缺了第三牙，你得拿原班的蓝边秤复看。')],'notched-token',['dry-standard']),
 shiftPost('call-day-shift',11,9,false),shiftPost('call-night-shift',24,9,true),
 fixture('seventh-hook','在白绳班把三缺齿码挂回七潮秤',12,7,[s('枣惠','秤尾接触第十二格。你看这道红漆，被真车轴蹭低了一寸；后面三个格子还满着漆。'),s('灰工','我是那天真正卸过的人。你记我的班，别双算我的肩。')],'seventh-hook',['notched-token','salt-day']),
 setting('new-goods-slot','把八潮的铜码放入新卸货格',23,8,[s('看门童','门里没有轴声，这一格却要算一车？请先看退车绳，七潮那批刚退回来。你可以拔出来重放。')],['seventh-hook','salt-night'],{'coded-transfer':false,'coded-new':true}),
 setting('transfer-slot','把同一码归在转仓格',15,9,[s('灰工','我在早班签卸货，另一个人在晚班签换位。你把同一人同一枚码留下，两班便都能承认自己的活。')],['seventh-hook','salt-night'],{'coded-transfer':true,'coded-new':false}),
 fixture('account-transfer','在车轨尽头比较两台的三齿锉口',18,10,[s('玛拉','两台的缺口相同，铁屑方向相反：不是第二辆新车，是旧货倒出。'),s('枣惠','把这件事写成“销账时又算进三袋”，不写成“卸粮人偷米”。我在这句下面签。')],'counter-duplicate',['coded-transfer'],{action:{type:'flag',id:'counter-duplicate',set:'duplicate-proved'}}),
 fixture('wax-side-light','把可撤回的背纸贴到临仓斜光板',7,11,[s('狄芬','票七和票八在同一歪角第二次压过。热样只有表字，冷样的受力点和原票夹层相合。'),s('仓守','我承认同一批十二袋被开出十五个仓位；谁有意，谁只是赶单，这张纸还不能分。')],'wax-duplicate',['wax-cold','bins-seen','backing-known'],{lockedText:'用冷垫重取背样。公账先开时仓守在蓝章旁保住原蜡；护证后则要请筝拿出退班旧背纸。',action:{type:'flag',id:'wax-duplicate',set:'duplicate-proved'}})],
 [exit(2,8,'ticket-works',[23,9],'把错用的蜡样送回票作重取'),exit(27,9,'seal-vault',[8,9],'送原样到公仓'),exit(13,12,'brine-weigh',[9,9],'沿车轨回公秤')]);