import {say as s,feature as f,exit,person,object,flag} from './parts.mjs';
export const yard={
 id:'trim-yard',name:'白崖港 · 肋木场与压舱坑',act:1,width:30,height:20,ground:'wood',biome:'harbor',
 solids:[[1,1,5,4],[9,1,7,4],[21,0,8,4],[3,12,4,5],[10,13,7,4],[23,12,7,8]],
 features:[f('building',1,1,5,4,'木匠耳房'),f('building',9,1,7,4,'弯肋蒸房'),f('building',21,0,8,4,'索工组棚'),f('crate',3,12,4,5,'三列压舱块'),f('boat',10,13,7,4,'修船滑床'),f('water',23,12,7,8,'湿船槽'),f('rope',17,9,5,1,'双向滑索'),f('lamp',21,6,1,1,'外浮标回声盘')],
 entities:[
  person('foreman-count','敲饭铜板的工头·雀',7,8,[s('雀','一班六个肩膀，三趟能扛十二袋。今天有三班，另一个班的人刚把住院的抬上岸。'),s('玛拉','那十二袋空出来，是留给他们回去歇吗？'),s('雀','你拿这张工时木票去问布兰。他管潮，我管谁的肩上裂了口。')],{action:flag('work-slip'),after:[s('雀','一班一潮十二袋。夜班要开一锅饭，就得在头一船留下空位。')]}),
  object('outer-buoy-score','肋木上夹着的外浮标刻度条',20,7,[s('铅笔小记','外浮标敲在第二拍、第六拍。下一次是第十拍。蓝线才是内口过船刻度；去灯廊找它的回声。'),s('玛拉','两根木尺划的不是同一个地方。')],{action:flag('outer-ticks')}),
  object('line-cheek','压舱坑边的绳耳',4,11,[s('伊沃','下绳眼磨的是外侧，上绳眼磨的是内侧。两股绳是一只筐的去路和回路，不能拴回同一头。'),s('玛拉','那你让筐先下去，人留在牢的这头。')],{action:flag('opposed-rope')}),
  person('caulker','捻麻的修船匠·鲛背',11,7,[s('鲛背','别把麻塞死。船一吃水就胀，得给它留一条喘气的缝。'),{who:'鲛背',if:'keel-name',text:'三排铜钉？最里一排是空铆，压着写过字的夹层。有人拿这条舢板当信封用。'},{who:'鲛背',if:'vigil-thread',text:'篮边这段蓝纱是你搭的？等风换边我们好认哪一头是岸。'}]),
  object('fouled-dock','裹住浮门的灰甲蟹',19,14,[s('雀','它带着麻网卷在浮门边。照护的人走高廊，愿留在这的便跟我把索分开。')],{action:{type:'battle',id:'hemp-crab',value:'hemp-crab'},after:[s('雀','浮门让开了。压舱坑现在能直通粮趸。')]})
 ],exits:[exit(1,8,'wake-court',[26,10],'回摆灯院'),exit(27,7,'signal-gallery',[2,7],'走干燥的高廊避开浮门'),exit(21,13,'ration-berth',[3,14],'从清出的浮门抄近路',['hemp-crab']),exit(18,5,'upper-spar',[4,11],'循长芯灯走拉索近路',['night-lamp','ivo-line','berth-fixed'])]
};