import {district} from './district.mjs';
import {object,person,say,flag} from './parts.mjs';

export function region(id,name,act,biome,width,height,ground,blocks,land,entities,exits){
  return {...district(id,name,act,width,height,ground,blocks,land,entities,exits),biome};
}
export function fixture(id,name,x,y,dialogue,result,requires=[],extra={}){
  return object(id,name,x,y,dialogue,{requires,action:flag(result),...extra});
}
export function witness(id,name,x,y,dialogue,result,requires=[],extra={}){
  return person(id,name,x,y,dialogue,{requires,action:flag(result),...extra});
}
export function spoken(who,text,ifFlag){return {...say(who,text),if:ifFlag};}
