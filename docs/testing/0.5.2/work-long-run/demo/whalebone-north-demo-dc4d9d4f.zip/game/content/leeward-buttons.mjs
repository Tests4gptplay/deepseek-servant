import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {tidePost} from './district.mjs';
import {setting} from './registry-parts.mjs';

export const town=region('leeward-buttons','北航线 · 岛风夹缝里的五盏人家',4,'north-sound',43,26,'wood',
 [['water',0,0,43,4,'东浪还在外头、里浪已回的双股水'],['building',2,3,7,5,'把门朝背风开的豆腐房'],['building',12,3,6,5,'引船夫妇二楼的睡屋'],['building',22,2,7,6,'半铺兽医半铺草绳'],['building',33,3,8,5,'三班人用的外海炊锅'],['boat',1,16,8,6,'打了两种载线的测水艇'],['building',13,18,6,6,'几代漂标修手的铺子'],['crate',24,17,7,6,'等北运的保温汤砖'],['wall',35,16,8,8,'常退水的风缝']],
 [['path',3,10,36,3,'锅脚、石床和两道船台相接的弯街'],['pier',8,13,13,2,'由住户下到不同岸段的板桥'],['rope',22,14,11,1,'顺风与逆风的人抓绳的高度不同']],
 [witness('chart-wrong','米拉把自己上次署过名的小印图压在餐桌角',10,10,[s('米拉','我在着铅湾写了“北风旗向外，就走浅缺口”。我照着一次出海的旗记的，没记那天退潮。昨天双罐艇照它走，回到了出发的豆腐房。下面这两针歪字是我的，不是老图家的。'),s('舵手茶斛','我又没有失踪。你若只给我一张道歉的新纸，我还是要吃一天凉豆饭，去看看艇是怎么回来的。'),s('玛拉','把错图也带着，两处风和水分开走，看它哪一笔不该连。')],'chart-disputed',['pin-rub','party:mira']),
  person('isle-tofu','在刀背上试豆腐冷暖的方雁',17,12,[s('方雁','风大时我把汤碗套在两个炉之间。北面那一炉不冒烟，是漏气，不是天气好。'),spoken('方雁','茶斛的艇怎么又绕回来我现在知道了。米拉先拿自己锅上的墨擦，不用我替她把错迹涂掉。','fan-corrected')]),
  person('isle-crib','替小狗把四只脚各绑不同颜色的仓婆',27,11,[s('仓婆','小狗踏回来我看它跳哪只。红脚没湿，白脚湿了，回来的是趟浅水，不必急着给四只脚全擦。'),spoken('仓婆','蜡牌的两色也可分，可别学我全系在一条狗上。','float-paired')]),
  setting('load-crock','上满两罐暖砖，把船压到深吃水刻',33,11,[s('茶斛','算上这两罐，低门白线盖到手背。货留齐就必须走外绕；要退回来，这里仍有岸吊。')],['chart-disputed','!fan-sailed'],{'fan-heavy':true,'fan-light':false}),
  setting('unship-crock','用门吊卸下一罐砖，读露出来的浅吃水刻',34,13,[s('茶斛','近道吃浅，我把第二罐存岸上。不是粮自己消失，得有人以后回来接。')],['chart-disputed','!fan-sailed'],{'fan-heavy':false,'fan-light':true})],
 [exit(3,11,'wreck-slope',[11,10],'沿旧伤船坡回原北航'),exit(6,13,'sock-stair',[4,10],'走西岸背风旗梯',['chart-disputed']),exit(36,11,'egg-meridian',[4,10],'出东口试漂标的回程',['chart-disputed']),exit(22,15,'fan-throat',[4,10],'送载线试艇去风水分岔的夹喉',['float-paired','sock-heard'])]);

export const sock=region('sock-stair','北航线 · 背风袜阶与翻肚的云',4,'north-coast',29,20,'stone',
 [['wall',1,1,7,6,'将海风截住半层的黑崖'],['building',12,2,5,5,'补风袜的木棚'],['water',21,2,8,6,'低潮绕崖的卷流'],['crate',1,15,8,5,'曳缆的无底箱'],['wall',20,15,9,5,'长一线白贝的踏脚']],
 [['path',3,9,23,2,'坡降三阶但能上来的石门'],['rope',10,12,11,1,'只反映空中风的两幅旧袜']],
 [fixture('sock-air','把风袜的绿尾从遮风的岩后移到外崖',9,9,[s('米拉','尾巴一直指海。我的笔当时没有画错这幅旗，错在又从它引了一根水箭。')],'sock-air',['chart-disputed']),
  fixture('sock-heel','落潮在阶底以软蜡印艇尾被海藻刮过的方向',19,10,[s('茶斛','印子朝岛心。上头的旗指海，脚底苔叶还往屋里倒。空中和水里至少有一段相反。')],'sock-heard',['sock-air','tide:low']),
  tidePost('sock-clock',12,12),person('sock-mender','给小孩做迎风斗篷的莓梢',15,11,[s('莓梢','风袜是我穿旧的裤腿。早班看的是左边膝盖，有大补丁。回水在海里，有人问我膝盖为什么画错地图，真倒霉。')])],
 [exit(3,10,'leeward-buttons',[7,13],'回五灯街米豆炉'),exit(25,10,'edge-bleach',[4,10],'从白贝踏脚查看走错的回湾',['sock-heard'])]);

export const meridian=region('egg-meridian','北航线 · 一枚来回翻面的蛋浮',4,'north-sound',32,21,'wood',
 [['water',0,0,32,4,'越过湾外时向北走的泡线'],['boat',2,3,8,5,'卵形三色漂架'],['wall',15,2,5,6,'外浪时间记在此处的灰岩'],['building',24,3,7,5,'给补漂人避雨的小平台'],['water',0,15,11,6,'向回弯挤去的水路'],['crate',23,15,9,6,'能把浮壳竖起的软兜']],
 [['pier',2,9,27,2,'与岸灯成直角的回收栈'],['rope',10,12,13,1,'两端毛眼不同的返标绳']],
 [witness('egg-sender','补漂壳却讨厌鸡蛋的乌桅',8,10,[s('乌桅','红耳朝上是出去，灰耳磨白是回来。好些人看见同一颗蛋两次，便把两只艇加在一块儿。我不问几点，我问你拿回来哪面沾着哪种草。')],'egg-taught'),
  fixture('egg-release','涨潮从东栈松开带红耳的船壳',15,9,[s('米拉','肥泡顺着风出海，但蛋壳底那条细绳朝屋的方向拉。两股在这儿分了层。')],'egg-out',['egg-taught','tide:high']),
  fixture('egg-catch','低潮从另一侧捞回翻灰面的带子',23,11,[s('乌桅','灰面头上挂了西崖的白贝须。它走过内弯，没从北岸凭空变出另一条同绳。留两面都不擦，去夹喉再对一次。')],'float-paired',['egg-out','tide:low']),
  tidePost('egg-clock',11,12)],
 [exit(3,10,'leeward-buttons',[35,11],'顺收索回五灯锅'),exit(27,10,'edge-bleach',[24,10],'跟漂在低湾里的掉漆侧标走',['egg-out'])]);
