import {north,windGear} from './the-sun-on-the-other-face.mjs';
import {winter,harbor} from './the-sleeve-in-the-snow.mjs';
import {windOpponents} from './cloth-which-pulls-back.mjs';
import {say as s,person,exit} from './parts.mjs';
import {spoken} from './voyage-parts.mjs';

const benches=[
 [north,'north',5,9,'红脊油炉旁的暖石','霁葵','我借你们刷松脂的温水。先松开紧着的手指，买不起药也能回来。'],
 [winter,'winter',5,9,'晒工换班用的半圆干垫','袁叠','用我那块干垫歇。吹白的手恢复知觉再上，工头急也只能等。'],
 [harbor,'harbor',5,11,'角落已经撑牢的斜柱','符荻','这一小块稳着。队里谁站不起来，先扶他坐好，角裂过还是裂过，别怕回来让人看见。']
];
for(const [m,id,x,y,title,speaker,line] of benches)m.entities.push(person('windloom-'+id+'-rest',title,x,y,[s(speaker,line)],{action:{type:'rest'}}));
export const windMaps=[north,winter,harbor];
export {windGear,windOpponents};
const q=(id,name,stages)=>({id,name,kind:'side',startFlag:stages[0],endFlag:stages.at(-1),stages});
const lines=[q('who-can-let-go','谁有空出来的手',['windloom-north-open','windloom-north-done']),
 q('white-cloth-long-shadow','白布上的湿影',['windloom-winter-open','windloom-winter-done']),
 q('the-cloth-had-a-name','那一角原来有名字',['windloom-harbor-open','windloom-harbor-done','windloom-homeward'])];
export const windQuests=Object.fromEntries(lines.map(v=>[v.id,v]));
const clue=person('windloom-beacon-neighbor','正在航标下面收细线的梳姐',15,8,[
 s('梳姐','你看那片白布，刚被风吹反的时候正面还晒着太阳，地上却先黑了。红脊坪的霁葵教小徒做头一匹带名字的帆，最近一只海鹫老往布背里钻。'),
 spoken('梳姐','符荻那匹红还整着。她现在敢先抬起手再说“我也会”。','windloom-north-kept'),
 spoken('梳姐','她把毛边留了下来，没换新布糊弄谁。红脊上遇过什么，她自己愿意讲。','windloom-north-scar')]);
const finale=person('windloom-bare-fingers','船尾挤在一件半干学徒围裙里的师徒',8,10,[
 spoken('符荻','师傅把结实的那面背给风，我能看见她的手。港里还挂着我完整的一面，下回我去把它收下来做两片小的。','windloom-harbor-kept'),
 spoken('符荻','你摸，最后一圈针是我第一次一个人缝的。我把它剪了。现在带走的是这圈针，名字归我，不跟着棚子走。','windloom-harbor-scar'),
 s('霁葵','北边那匹红我总想替你解释结没结实。等靠岸你自己说。我在旁边替你穿第二根针。'),
 s('玛拉','一块布能留下两个人不同的那一刻。回到墓坡，我也会把父亲做过的两件事各讲完整。')
],{requires:['windloom-harbor-done'],action:{type:'flag',id:'windloom-homeward'},after:[s('符荻','我们二人的围裙借着轮流穿。穿长一点的先做师傅？不行，针还得各认各的。')]});
export function withWind(map){
 if(map.id==='red-beacon')return {...map,entities:[...map.entities,clue],exits:[...map.exits,exit(6,9,north.id,[3,10],'跟红布背影进北航晒帆坪',['party:mira'])]};
 if(map.id==='lee-mouth')return {...map,exits:[...map.exits,exit(18,9,winter.id,[3,9],'沿白布湿影进晒工的霜田',['party:mira'])]};
 if(map.id==='flood-stair')return {...map,exits:[...map.exits,exit(21,9,harbor.id,[3,12],'抬头看倒兜的四面布，绕去晒帆廊',['clutch-still'])]};
 if(map.id==='safe-keel')return {...map,entities:[...map.entities,finale]};
 return map;
}
