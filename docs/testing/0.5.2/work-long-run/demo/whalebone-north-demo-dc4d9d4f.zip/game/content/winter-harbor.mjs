import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit,object,flag} from './parts.mjs';
import {tidePost} from './district.mjs';
export const village=region('winter-court','冬岸 · 晒网与四炉院',5,'winter-village',32,22,'stone',
 [['building',1,1,5,5,'一炉公屋'],['building',9,1,5,5,'晒网校舍'],['building',19,1,6,5,'病房'],['building',27,3,5,5,'鲱鱼铺'],['building',2,14,6,6,'石砌炊间'],['building',12,16,7,6,'锅炉房'],['building',24,15,7,5,'客船寄宿间']],
 [['path',0,9,32,3,'四炉轮饭的主街'],['rope',7,6,13,1,'干网内街'],['lamp',8,12,1,1,'点名灯']],
 [witness('winter-cook','分炉饭的勾婶',9,12,[s('勾婶','空铺能借，暖炉不能借两次。有三炉在烧，初冬两家同轮一炉。第四炉是熄的，别在你们图上涂亮。'),s('瑟琳','两家先分到锅和药，我再去数能放担架的地方。')],'hearth-count'),
 person('dry-net-kid','用网眼算数的小孩',15,8,[s('小孩','一张网边有六人位。我的弟弟只占半张毯，可喝水得用整只杯。写张单子不是把人塞进网眼。'),spoken('小孩','那边盖好两口水罐了。我去把前院的碗重新洗一遍。','water-casks')]),
 object('long-bench','靠炉长凳',20,12,[s('勾婶','能歇眼，得给铅垂留地方晾。')],{action:{type:'rest'}}),
 person('selene-ledger','瑟琳争取的第二班饭',22,10,[spoken('瑟琳','家里那张饭筹仍押在药铺。先给不会划船的人上岸，我用接下来的量潮工钱赎。','witness-first'),spoken('瑟琳','母亲少了封票的工。我把北点的粮载分开签，换她重新排队也能按份领。','ledger-first'),s('勾婶','有空位就收人；你把来路写实，我就敢开锅。')],{requires:['hearth-count','fresh-proved'],action:flag('family-share')})],
 [exit(2,10,'lee-mouth',[12,15],'回碎浪门'),exit(2,6,'lee-ridge',[19,8],'沿网街上背风脊'),exit(20,8,'fresh-gallery',[21,10],'向东取水'),exit(29,10,'moor-pocket',[3,8],'去双刻泊船桩'),exit(9,18,'winter-ward',[3,7],'进公屋及病床')]);
export const moor=region('moor-pocket','冬岸 · 两潮泊桩',5,'winter-coast',24,18,'wood',
 [['water',0,0,24,4,'上湾浮冰'],['pier',5,5,4,4,'搁浅的外桩'],['water',14,9,10,5,'内港水域'],['building',2,13,5,5,'报潮屋']],
 [['rope',9,6,12,1,'外沿六结门线'],['lamp',11,11,1,1,'内湾第五标'],['pier',7,9,6,3,'两岔小堤']],
 [fixture('high-berth','涨水检查外桩的满潮线',8,10,[s('米拉','满潮有八结，背后却是平沙。只记今天这一步，会批准一条退潮便锁死的路。')],'moor-high',['tide:high']),
 fixture('low-berth','退水时用探杖步到内桩',13,8,[s('瑟琳','这边低潮仍有七结，外桩只余三结。吃水六结的满载粮船要过内湾。'),s('伊沃','我给内桩挂一条可从外边取下的进港索。')],'moor-low',['tide:low']),
 fixture('moor-chain','把双刻的绳圈移到内桩',11,12,[s('米拉','图上写内湾，满潮八，退潮七；外桩画成小船专用。下一班照我刚走的回线再量。')],'moor-proved',['moor-high','moor-low','north-chart']),
 tidePost('moor-clock',7,11)],
 [exit(2,8,'winter-court',[28,10],'回晒网院'),exit(21,15,'cold-pump',[3,8],'沿隔冰栈去废泵房',['moor-proved'])]);
export const ward=region('winter-ward','冬岸 · 横铺公屋',5,'winter-interior',21,15,'wood',
 [['building',1,1,5,4,'公共洗手间'],['crate',10,1,7,4,'四张担架位'],['crate',13,10,7,4,'折起的守夜床']],
 [['lamp',7,7,1,1,'床数木格'],['path',2,6,17,3,'容担架回转的走廊']],
 [fixture('bed-gauge','把旧担架实际推出门再转弯',9,7,[s('玛拉','两张铺太靠门，一放平就顶住转角。能收病人的是四张，不是纸上的六张。'),s('勾婶','两家基本床位我担得起。多要靠人洗滤罐、换灯班，不能光往墙上画铺。')],'bed-count',['hearth-count']),
 fixture('ward-extra','给两个空床位系上水罐吊带',12,8,[s('勾婶','水送得进，夜里响铃有人起。西窗可以送来两架病床，我把屋最暖的位置挪给她们。')],'winter-extra',['bed-count','water-casks','winter-bell']),
 fixture('winter-proof','冬港复核后给布兰发回程签',16,7,[s('玛拉','背风、淡水、进港、过冬床位，四格都写出限制。不能证明所有人都能过冬，能证明原地重下锚不是仅剩的一条路。'),s('瑟琳','附我的领粮签，调给港里的船。请布兰把今天的实测看完再摸锚柄。')],'winter-proof',['lee-proved','fresh-proved','moor-proved','bed-count','family-share'])],
 [exit(2,7,'winter-court',[9,17],'回四炉院'),exit(18,8,'anchor-yard',[2,10],'带四项冬港实测搭返航船',['winter-proof'])]);
