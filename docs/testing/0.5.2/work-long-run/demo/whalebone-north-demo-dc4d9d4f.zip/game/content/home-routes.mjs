import {fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,exit} from './parts.mjs';

const changes={
 'north-pier':{exits:[exit(12,8,'lead-sound',[2,10],'把空白海图带出盐市',['north-ready'])]},
 'wharf-scale':{
   entities:[witness('rescue-porters','在旧秤灯等船的两户人',18,12,[s('秤手','这次车不过磅，人不当斤两。我把青环系在老药师的腕子，白环给刚失去船的人。'),spoken('秤手','牵索班先前进食的人都在。我交给他们两条绳，担起回头引路的工作。','crew-first'),spoken('秤手','病船那批粮留出两副担架。先给没法自己过渡的人。','grain-first')],'base-group',['tilt-sighted'])],
   exits:[exit(18,10,'flood-stair',[7,7],'看被水切开的原车道',['harbor-tilted']),exit(6,12,'wake-court',[5,10],'领两户穿旧殓棚侧巷',['base-group']),exit(22,14,'lower-tide',[3,4],'墓坡安葬后接回低潮访客路',['grave-signed'])]
 },
 'wake-court':{
   entities:[witness('court-roll','原摆灯院的点名人·柏姐',12,9,[s('柏姐','我数青、白环，不再数空灯罩。抬头，等两户都到院门，我才让你们过。'),spoken('柏姐','上一班留下的饭牌换过长芯。今晚我家的针线灯还照得到后院。','night-lamp')],'court-count',['base-group']),witness('thread-hand','把打结针匣带上的芬',19,9,[s('芬','那孩子怕看水。她今天不归你拉，你交我这盒线，我在灯影里领她自己迈过去。')],'thread-child',['night-lamp','court-count'])],
   exits:[exit(5,11,'wharf-scale',[7,12],'送完人可回秤桥复检',['base-group']),exit(6,9,'flood-stair',[23,11],'由摆灯院高门下浮桥',['court-count'])]
 },
 'dry-court':{
   entities:[witness('sling-wards','把病床卡入西窗滑梁的井嫂',14,11,[s('井嫂','前一回，缺横闩是把床垫稳。这一回床不能留。西窗的梯正好是两只滑环的距离。'),s('伊沃','西窗有人上，冬岸有人接。谁都不用再朝一面黑玻璃求救。')],'stretchers-on',['west-stairs','winter-extra','court-count','north-linesman'])],
   exits:[exit(11,14,'flood-stair',[5,13],'从西窗新梯回倾斜收粮坡',['west-stairs','court-count']),exit(16,11,'lee-cutter',[15,7],'将床送至偏舷舟',['stretchers-on'])]
 },
 'salt-lane':{
   entities:[witness('press-workers','拎着盐票木匣的铅字工',19,10,[s('铅字工','你把旧账挂过街口，我们才有仓守签的油票。带上三副铅字和两支桨：冬岸修索棚得靠人过冬。')],'workers-aboard',['ledger-first','north-lampstock','court-count'])],
   exits:[exit(21,10,'flood-stair',[21,8],'循公仓油灯回倾港浮板',['north-lampstock','court-count'])]
 },
 'winter-ward':{
   entities:[witness('bed-receiver','接手西窗两架病床的勾婶',8,9,[s('勾婶','两张床的环我自己摘。水罐、担架转角、晒衣院人的名字都对上了。'),s('玛拉','这一步有人接到，表上才写“到岸”。')],'beds-arrived',['beds-ferried','winter-extra'])],
   exits:[exit(11,10,'lee-cutter',[11,11],'送空担架回双舷小艇',['beds-ferried'])]
 }
};
const floodVoices={
 'pall-bearer':['抬棺人','殓棚转到高门后。我第一次抬活人家里那只摇篮，轻得我不敢用送丧的步子。'],
 'weigh-clerk':['秤手','靠车道那两家已经点过。称多少重量是我平时的事，今天看他们能不能自己站稳。'],
 'lamp-neighbor':['柏姐','我还在这间屋，白纸灯只剩一张。这一次拿它找窗，不拿它给人送行。'],
 'seamstress':['芬','腰带这样一扣，空着手也能牵两个人。缝围裙的针留下了。']
};
export function withHomeRoutes(map){
  const extra=changes[map.id];if(!extra)return map;
  const exits=map.exits.map(e=>map.id==='wharf-scale'&&e.to==='lower-tide'
    ?{...e,requires:[...e.requires,'!harbor-tilted'],lockedText:'老木梯已经没入水中。沿殓棚后的高门，把人带进摆灯院。'}:e);
  const entities=map.entities.map(e=>{
    const voice=floodVoices[e.id];if(!voice)return e;
    const lines=old=>[spoken(...voice,'harbor-tilted'),...old.map(l=>({...l,if:['!harbor-tilted',...[].concat(l.if||[])]}))];
    return {...e,dialogue:lines(e.dialogue),...(e.after?{after:lines(e.after)}:{})};
  });
  return {...map,entities:[...entities,...(extra.entities||[])],exits:[...exits,...(extra.exits||[])]};
}
