import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit,flag} from './parts.mjs';
import {setting} from './registry-parts.mjs';
export const inn=region('tilting-inn','锚夜 · 拆门的旧泊客栈',6,'flood-harbor',29,19,'wood',
 [['building',1,1,6,6,'仍住着二户的内间'],['wall',13,1,6,6,'旧当房的斜墙'],['boat',22,3,7,5,'地板下半出水的小艇'],['crate',3,13,6,6,'暂寄的私人物件'],['water',16,14,13,5,'原来的后院']],
 [['path',2,9,24,2,'带铰圈的门板路'],['rope',8,11,10,1,'留四人并肩的索线']],
 [witness('bran-at-inn','正在卸最旧一扇客房门的布兰',8,9,[spoken('布兰','这屋的租押已经给了古杳，床底银匣不是我的。门板我能拆，别把她的押金装进伤船赔款。','berth-bond'),spoken('布兰','鱼桶已经跟船去了，两班钱仍欠着。我顺手搬走屋里新买的桌子，给井梁抵一份。你把老板的家谱留墙上。','fish-bond'),s('玛拉','你把客人的门拆了，把睡在门里的人放在哪里？'),s('客婆','他打算把我抬过去。我自己开门，你们抬床，手都留给该做的那点活。')],'inn-offered',['bran-at-drum']),
 fixture('mara-footrail','在斜地板先托空床，再请客婆自己起身',15,9,[s('玛拉','先把空床从坡上移走，平地就能容你自己站稳。我抬棺的规矩是让四角齐，抬活人时得先问哪里疼。'),s('客婆','右脚没力，左脚还听话。你说“走”时我不一定能走，我拿杯把敲一下才算。')],'inn-clear',['inn-offered']),
 person('landlord-son','拿房号钉找东西的毓子',12,11,[s('毓子','十七码房欠我们一条毛巾。他出来了没？毛巾不要了，我只是靠这个记得还有谁。'),spoken('毓子','自个儿敲杯子的，是八号房。钉子我收起来，免得别人凭张牌叫错人。','inn-clear')])],
 [exit(2,9,'anchor-yard',[8,10],'回转运锚场'),exit(25,10,'copper-gutter',[3,8],'沿刚空出的地板进账册排沟',['inn-clear'])]);
export const gutter=region('copper-gutter','锚夜 · 会翻身的铜沟',6,'flood-harbor',27,18,'stone',
 [['water',0,0,27,4,'原车道来的涨水'],['wall',3,4,5,3,'门板头的平铰'],['crate',14,4,7,3,'两种长度的缓坡肋'],['water',17,13,10,5,'层层下陷的鱼汤巷']],
 [['pier',2,8,22,3,'两端能分开调平的空沟板'],['rope',9,11,12,1,'给老人自己搭着的扶绳']],
 [witness('gutter-reader','旧排水工·鹿姑',9,8,[s('鹿姑','你在墙上找直线会找死。这一段地板是整块翻过去的。先把一次谁都不许上的空板放出来，看热汤往哪边流。'),s('米拉','图上我画过一条“扶栏”。原来那东西到了半夜会变成荷叶朝下。'),s('鹿姑','你要带人越沟，告诉我走斜板还是绕干楼。前者短、等时长；后者长，小孩能自己走。')],'gutter-read',['inn-clear']),
 setting('deck-wrong','两头一起封紧试板',14,8,[s('鹿姑','沟没松，汤就向两边溢。别把人推上去。把一头留给浮木自己找平。')],['gutter-read'],{'gutter-locked':true,'gutter-loose':false}),
 setting('deck-float','把内端交给浮木，外端留在旧铰',19,9,[s('伊沃','前端随水走，外端仍能从干处靠过去。我把会摆的那头凿个圆记号，下一班不用摸索。')],['gutter-read'],{'gutter-locked':false,'gutter-loose':true}),
 fixture('mara-tray','拿空碗试一次浮板横走',12,10,[s('玛拉','碗底碰了一下，水没洒。没有人能替里间的老太太决定是不是愿走这里。先去请她。')],'float-tested',['gutter-loose']),
 person('path-elected','里间住户实际选过沟还是走干楼',16,11,[s('客婆','黑水下面的板我知道能承，颤一顿脚会疼。在干楼我绕两个转角要多一阵，你能派一个人顶替我喂灯？'),s('鹿姑','看哪个班还有人接。浮板先由桨工稳住，干楼先由木匠把旧窗拆宽。你去哪边开工？',[
 {text:'给短浮板派桨工稳住，等看水的人点头',set:'evac-float'},{text:'给干楼开窗，绕两个转角给住家步行',set:'evac-loft'}])],{requires:['float-tested'],action:flag('evac-elected'),after:[s('客婆','路是备好的，人还没过。见着我的黄杯才许写我到了。')]})],
 [exit(2,8,'tilting-inn',[24,10],'回拆门客栈'),exit(24,8,'yellow-cup',[3,8],'短浮板送去接人平台',['evac-float']),exit(14,13,'shutter-walk',[3,8],'绕干楼两转角走廊',['evac-loft'])]);
export const shutters=region('shutter-walk','锚夜 · 雾里干楼横窗',6,'whale-interior',24,17,'wood',
 [['wall',0,0,24,3,'被震裂的周梁'],['wall',3,4,5,3,'第一个折角'],['building',13,2,7,5,'窗后的洗碗屋'],['crate',17,12,7,5,'第二折角的便柜']],
 [['path',2,8,19,2,'供两人扶墙并行的干廊'],['lamp',14,10,1,1,'木匠留下的低灯']],
 [witness('shutter-carpenter','从里面打开窗的索木匠',10,8,[s('索木匠','我不爱别人从外面来踢门。要换窄窗，里外各站一个，我把自己的饭桌先挪开。'),s('伊沃','我在外边听见你拔榫，再接。那边的老人不用合着我步子走，墙下有停处。')],'shutter-open',['evac-loft']),
 fixture('stairs-cup','接住拐角送过来的空黄杯',15,9,[s('客婆','叮。第一弯我能过。二弯要停，请你们别在后面喊我名字催。'),s('玛拉','前头的人都听到了。窗已开，拿着杯等你。')],'cup-travel',['shutter-open'])],
 [exit(2,8,'copper-gutter',[13,13],'回铜沟通风口'),exit(20,9,'yellow-cup',[14,10],'循干廊到接人台',['cup-travel'])]);
export const landing=region('yellow-cup','锚夜 · 有黄杯才算抵达的接人台',6,'flood-harbor',25,17,'wood',
 [['water',0,0,25,3,'早转鲸背的湾口'],['crate',3,4,4,3,'挂半湿绳的箱'],['building',15,3,7,4,'有三扇不同高矮的落足门'],['water',16,13,9,4,'小筏的转舷处']],
 [['pier',2,8,20,3,'一长一短两路的终点'],['lamp',12,7,1,1,'换手者的短红灯']],
 [witness('steady-cup','等过沟的人把黄杯自己举起来',9,8,[s('桨工','浮板刚才碰了一下。她没敲杯，我就把它又稳回去，多磨了半班。现在听到了。'),s('客婆','叮。我有腿，也会自己说到。你们谁要借毛巾，先让我擦脸。')],'cup-travel',['evac-float','float-tested']),
 witness('cup-received','从客婆本人手中取空杯上岸',17,9,[spoken('毓子','从干楼走来的，鞋跟还沾着我家饭桌底下的油花。妈妈你留着鞋别洗，我明天去找那张桌。','evac-loft'),spoken('毓子','浮木把杯沿磨出一道白线。杯没丢，人没淋透。桨工欠的一顿饭我记住。','evac-float'),s('客婆','我把杯放在床脚，别挂成给活人的丧铃。今晚渴了还要喝。')],'inn-arrived',['cup-travel'])],
 [exit(2,8,'copper-gutter',[23,8],'循已稳的短浮板回沟',['evac-float']),exit(15,10,'shutter-walk',[19,9],'从干廊回转角',['evac-loft']),exit(22,9,'anchor-yard',[15,13],'从接人台回去接锚柄')]);
