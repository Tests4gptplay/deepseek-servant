import {exit,object,person,say as s} from './parts.mjs';
import {region,spoken} from './voyage-parts.mjs';
import {gallery,sill,steam,station} from './six-sacks-under-one-boat-name.mjs';

const plank=region('quaybill-last-lighter','锚断之夜 · 装暖铺还是装白麦的末驳',6,'salt-market',30,18,'wood',
 [['water',0,0,18,4,'绑在转缆上的末驳'],['building',22,0,8,6,'粥棚出的白气'],['crate',16,13,6,4,'已上绳的黄粮'],['water',0,13,8,5,'斜坡漂下的门槛']],
 [['pier',1,8,27,3,'能推回去重选的一辆平车'],['qb-hull',3,4,10,4,'末驳唯一平稳的前舱'],['qb-oven',18,5,5,3,'借来的暖铺和锅']],
 [station('freight','看末驳仅余的舱口和可用的票',8,9),station('bed','沿左辙实际推一张能盛两人的暖铺',15,10),station('flour','沿右辙推粮，摸清领出的袋数',22,9),station('cast','查看实载再把驳子交给引航人',24,11)],
 [exit(2,8,'flood-stair',[8,8],'原路回撤离石阶')]);

export const quaybillMaps=[gallery,sill,steam,plank];
export const quaybillQuest={id:'six-under-a-name',name:'六袋怎么全上了一条船',kind:'side',startFlag:'quaybill-open',endFlag:'quaybill-settled',stages:['quaybill-open','quaybill-material','quaybill-voice','quaybill-settled']};
const caller=person('quaybill-liner','白崖港给粮篓缝布衬的晞娘',7,10,[
 spoken('晞娘','你没把名字拿去贴。我这小铺还可以给病过的人赊热饭，要先替两担粮垫钱，灶里只好煮一锅。','quaybill-quiet'),
 spoken('晞娘','你贴了转用的全单，栖鸥号的账能结，我的两担货也赎回来了。替班人怕再被当众点过数，送饭要绕到后门。','quaybill-posted'),
 spoken('晞娘','街上说有人拆了两袋。我想知道是谁把“没跟船走”说成“装进自己碗里”。','quaybill-rumor'),
 s('晞娘','我在衬里绕半圈蓝线。麦拿去给不想被点名的人吃，也不要让晏家给同一锅饭掏两次钱。等你们要回盐市，顺便看一眼。')]);
const rumor=station('street','盐市夹着糊浆粮单的短绳',17,8);
const terminal=person('quaybill-boat-returns','在撤离驳上还晾着票的庹英与岑藕',9,10,[
 spoken('庹英','两袋都过来了。粥棚能开早晚两锅。两名腿软的替班人让人扶着走了远坡，我空出手来便去找他们。','quaybill-load-public-grain'),
 spoken('晏甫','有签字的两袋只取走一袋垫铺，另一袋进粥棚。两个替班人睡了暖的。我愿意在少一袋旁再签我的名。','quaybill-load-public-bed'),
 spoken('岑藕','我们把空位给两个人，没当众叫他们自报姓名。灶还能烧一锅，却要等别船捎麦。我欠那个开灶人的一次换班。','quaybill-load-quiet-bed'),
 spoken('庹英','晏家赊出来一袋，没人拿两袋的票再来讨一遍。我抬了那一袋；没床的两人会记得谁替他们扶了栏杆。','quaybill-load-quiet-grain'),
 spoken('晏甫','名字曾当街挂过，我女儿后来每逢开铺还得多解一次绳。即使原件收正了，这个麻烦也留在她手里。','quaybill-rumor'),
 s('玛拉','一张单能证明什么、不能证明什么，最后都得留给站在船上的人亲口说。')],{requires:['quaybill-sailed']});
export function withQuaybill(m){
 const additions={
  'wharf-scale':{entities:[caller]},
  'salt-lane':{entities:[rumor],exits:[exit(13,8,'quaybill-wet-sheet',[3,9],'进五号栈的湿纸廊')]},
  'flood-stair':{exits:[exit(7,8,'quaybill-last-lighter',[3,8],'沿已核过的粮票去末驳',['quaybill-settled','clutch-still'])]},
  'safe-keel':{entities:[terminal]}
 }[m.id];
 if(!additions)return m;
 return {...m,entities:[...m.entities,...(additions.entities||[])],exits:[...m.exits,...(additions.exits||[])]};
}
