import {object,say as s} from './parts.mjs';

const ruled=(who,text,flag)=>({...s(who,text),if:'quaybill-'+flag,quaybillCentral:true});
const official=[
 ruled('理算员','原粮账仍是短三枚干衡印。五号泊那两袋实在，只是转用。两件事分别落在一页，你们才不会把已供替班的饭再从灶里追回。晏甫肯署名，蓝绳柜里有商行寄存的盐橘药剂，凭他这行字可以当场领。','posted'),
 ruled('理算员','原来少的三枚干衡印照旧。岸上那锅麦另记两袋转用，数字看得见，领饭人的脸留在帘后。右边的热匣给当班的人留了一份回暖盐膏；用盲号便能领。','quiet')
];
const listeners=[
 ruled('粥棚代领人','两袋的钱有人署了，摆锅的钱可以当场结。有个脚夫下午来唱匿名替班的号时漏掉了自己的，我会替他守着。','posted'),
 ruled('粥棚代领人','我知道空米袋去哪儿了。那两个人能从后门进来吃热饭，锅底的柴要多赊一班；我自己记，不能从她家的饭筹上再划一道。','quiet')
];
const pickup=(id,label,x,flag,item,person,line,after)=>object('quaybill-docket-'+id,label,x,10,[s(person,line)],{
 requires:['shortfall-proved','quaybill-'+flag],lockedText:'先在原三格印台厘清干重，再核看五号泊那张实际签过的分录。这笔凭签一张只能领一种。',
 action:{type:'item',id:item,value:1,set:'quaybill-official-'+flag},after:[s(person,after)]
});
export function mainHearing(m){
 if(m.id!=='petition-hall')return m;
 const entities=m.entities.map(e=>e.id==='petition-counter'?{...e,after:[...e.after,...official]}:e.id==='ration-deputy'?{...e,dialogue:[...listeners,...e.dialogue]}:e);
 entities.push(pickup('blue','蓝绳柜里晏家押作医资的盐橘药剂',9,'posted','tonic','晏甫','不是粥，是我家给搬粮人留的人情。你把姓名写得跟凭据一样窄，我肯把这瓶换给你带上船。','这张已领。粮还在码头，你带走的一瓶药不能再写进麦袋里。'),
  pickup('warm','帘脚盲号对应的当班回暖盐膏',14,'quiet','brine-dose','岑藕','这份盐膏本来给接粮替班的人。你没要他们在布帘上写名字，我就把匣子打开。','匣底还留着勺印，就这一份。下回用空的匣子盛回暖房的湿布。'));
 return {...m,entities};
}
