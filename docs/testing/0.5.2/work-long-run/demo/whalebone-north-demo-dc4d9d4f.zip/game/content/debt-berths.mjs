import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit} from './parts.mjs';
import {mechanism,tidePost} from './district.mjs';

export const landing=region('hems-berth','冬岸 · 收布人与暖砖艇各走一半的斜泊台',5,'winter-coast',36,22,'stone',
 [['water',0,0,36,4,'冬雾压着两色载线'],['building',2,3,8,5,'给还没干透的床单的火房'],['crane',15,3,7,5,'可吊两罐或一副帆夹的泊台'],['boat',26,4,9,5,'从外档迟来的夜班船'],['water',0,16,13,6,'轻艇过来的低喉'],['crate',24,16,12,6,'换班人靠近灯罩的油架']],
 [['pier',3,10,29,2,'从上面暖间走到实际靠泊人的窄面'],['rope',7,14,19,1,'同一根梁新分了运砖和悬布的两个孔']],
 [fixture('berth-gauze','把盐市晒阁的短布挂在挡浪缝里，留人上下的窗',8,10,[s('聂溲','两床换出的布弓能拆成两半。我把左半拿来给冬岸挡喷雾，右边仍给原楼睡。你留出的门我走得过。')],'hem-winter',['hem-loft-working','hem-mats-set'],{action:{type:'flag',id:'hem-winter',set:'hem-warm-stair'}}),
  fixture('berth-warmclip','从洗布驳卸下一双预热布夹，把冻紧的靠索换到热手里',15,10,[s('槿石','我们给凉舷换过班，这点手温省了我一轮硬扯。卸布的船现在真能把冬岸夜工拉近。')],'hem-winter',['hem-scow-working','hem-mats-set'],{action:{type:'flag',id:'hem-winter',set:'hem-warm-jaw'}}),
  witness('berth-one','呃禾带回第二只暖罐，叫去接它的人也自己下船',22,11,[s('呃禾','我们用掉一趟完整的低水才把漏下的罐接全。给先到的病人添好火，帮忙划第二趟的郁斑肩上磨了皮，他也得留张铺。')],'fan-winter',['fan-inside','fan-certified','tide:low'],{action:{type:'flag',id:'fan-winter',set:'fan-crock-caught'}}),
  witness('berth-oil','在高水靠外档，让借出一班灯油的人登上暖船',29,11,[spoken('禾乌','橙帆没动，今天能多挡一夜风。灯油的主人禾染先进去烤手，暖罐都已卸过。','wing-kept-sail'),spoken('禾乌','篷布借给了浮巢，侧窗少一面挡风。两罐是全的，禾染却要到火房借衣，不能画成早已睡暖。','wing-offered')],'fan-winter',['fan-outside','fan-certified','tide:high'],{action:{type:'flag',id:'fan-winter',set:'fan-lighter-home'}}),
  person('berth-jingle','把小钉摇得比铜钟还勤的长照',19,13,[s('长照','今晚看看谁偷偷把锅沿当鞋架。我的铺已经少一只靴了，拿出来不追究。'),spoken('长照','有人终于把盐市那篓活物和铺单分开。没人想半夜踩一条鳗。','eel-safe')]),tidePost('hemberth-clock',11,13)],
 [exit(3,11,'moor-pocket',[8,12],'回冬岸两刻泊桩')]);

export const dusk=region('shuttle-dusk','锚断之夜 · 会压掉一个人肩位的旧布巷',6,'whale-city',34,21,'wood',
 [['water',0,0,34,4,'涌进原先鞋底高处的斜潮'],['building',2,3,8,5,'已向外翻半扇的旧住户窗'],['crane',15,3,5,5,'错位的布弓桩'],['boat',24,3,9,5,'从里侧才能接近的湿布驳'],['wall',0,16,11,5,'早市石台已倾得不能靠人排队'],['water',23,15,11,6,'探到第三间屋下的水缝']],
 [['path',3,9,27,2,'一边留里屋人，一边给外船的转角'],['rope',10,13,15,1,'曾在冬岸收住的一道活索']],
 [witness('dusk-window','聂溲把保留下的另一半布弓吊在倒窗，请龙钟夜工自己抓住',8,10,[s('聂溲','本来要占两张床的地方，现在够两个人肩并肩把老松麝送上来。上头喷过冷水，我知道手应该伸在哪一边。')],'hem-evac',['hem-warm-stair','!grave-signed'],{lockedText:'当夜要先从冬岸带来合用的布弓。退水以后，窗底的压痕留给住户辨认。',action:{type:'flag',id:'hem-evac',set:'hem-nightcot-home'}}),
  witness('dusk-hook','槿石换掉冷夹，让受伤的拧布工从艇缝里平着退出来',15,10,[s('槿石','不走屋上，低缝够一个肩。冬岸靠泊时我们换过手，阿茸能自己收一下这只暖夹，出艇后还拿得起她的鞋。')],'hem-evac',['hem-warm-jaw','!grave-signed'],{lockedText:'当夜要有人从冬岸暖过布夹。退水以后，舟工在岸上修夹，不再从旧缝撤人。',action:{type:'flag',id:'hem-evac',set:'hem-deckhand-home'}}),
  fixture('dusk-crock','把第二趟才收到的空罐架作为郁斑登岸的横肩',20,12,[s('郁斑','去的时候我划补运那一趟，回来轮我让别人扛一下。双罐没算成双人，我有自己的落脚位。')],'fan-evac',['fan-crock-caught','!grave-signed'],{lockedText:'补运人得赶上锚夜那一渡。退水以后，空罐横梁交还给装卸班。',action:{type:'flag',id:'fan-evac',set:'fan-second-rower'}}),
  fixture('dusk-hood','禾染把自己借过油的灯放低，带外街迟来的人从布巷退过',27,11,[s('禾染','我借过油，今天就知道那盏撑不了一整夜。把灯降到门槛，人能一只只脚看着过。最后我自己也走。')],'fan-evac',['fan-lighter-home','!grave-signed'],{lockedText:'借油人得在锚夜前靠岸。退水以后，旧肩门留着灯钩，过了那一夜就不再从这里撤人。',action:{type:'flag',id:'fan-evac',set:'fan-oil-return'}}),
  person('dusk-aunt','在窗台试水壶提手的同巷奶嫂',12,12,[
    spoken('奶嫂','帮到谁我都认，别站住给我念他们的称号。我上边的媳妇要水，凉了得再烧。','!grave-signed'),
    spoken('奶嫂','那晚媳妇要水，今天她提着空桶来要自己的旧窗板。别替她说谢，帮我把桶放低一点，她手腕还疼。','grave-signed'),
    spoken('奶嫂','晒阁那副布弓确实担过两个人。上面的凹痕成了一双，摸一下就分得开。','hem-nightcot-home'),
    spoken('奶嫂','阿茸出艇时自己提着鞋。槿石说她那只暖夹要带回去修，再冰一回还用得上。','hem-deckhand-home'),
    spoken('奶嫂','郁斑的肩膀磨出一条红道。横梁留给他自己卸，谁都别把他写成第三件货。','fan-second-rower'),
    spoken('奶嫂','借油那班把灯放得很低。门槛留着禾染靴底的一道黑泥，我扫地给她绕开了。','fan-oil-return')])],
 [exit(3,10,'flood-stair',[13,12],'沿框架回撤离坡')]);

export const endSalt=[
 witness('loft-backwork','回原来留过风路的房，帮松麝把理发镜正回来',19,12,[s('松麝','床没找全，镜子能照到耳朵了。手不稳也可以给人修耳后毛，下次问我是不是继续做工，让我自己回。'),s('聂溲','你们走后我给那两张临时床装了能拆的合页。它们还属于住在这里的人。')],'hem-home',['grave-signed','hem-nightcot-home']),
 witness('scour-backwork','把阿茸那只夹留在工艇上新开的暖窗里',21,12,[s('阿茸','请把暖夹放在一伸手的格里。我把早班还给沙荷，自己开始给夜班修铁爪。没人因为被救就欠另一个人一辈子劳力。')],'hem-home',['grave-signed','hem-deckhand-home'])
];
export const backTown=[
 witness('town-rubbing','和郁斑把两趟运罐的人名分别拓在装卸梁内侧',24,12,[s('郁斑','收钱的账写两罐，受伤的表写我名字，绝不要把“第二罐”当我姓。我的肩好些，今天我亲手抹这面泥。')],'fan-home',['grave-signed','fan-second-rower']),
 witness('town-oilshade','和禾染换回一扇真正能护夜工的灯罩，再让她自己睡',31,12,[s('禾染','我以前把借油算成情面帐，今天用掉的那一班是我在北岸走过的。把好灯留夜班，我带走这只是修理工又肯接活了。')],'fan-home',['grave-signed','fan-oil-return']),
 person('town-map-hang','重新回到豆腐灶旁的旧印图',19,10,[s('灶边的小纸','风箭下面如今有两条不同粗细的水纹，旁边那道擦痕一直保留。'),spoken('米拉','我把留岸那只暖罐写在图缘，免得下个走近路的说粮凭空少一份。','fan-inside'),spoken('米拉','外档的灯仍有人守。通行若要别人熬一班，也得把代价留在图上。','fan-outside')]),
 witness('town-mend-sail','把从空巢收回的帆缝进禾染夜工船的挡风侧窗',27,14,[s('禾染','不用洗成新布。我认得这道给鸟爪蹭薄的红边，缝在窗里边，来年我能查它有没有裂。'),s('米拉','图上那一趟借布，现在可以记下归还的日子了。')],'wing-cloth-restored',['grave-signed','fan-home','wing-cloth-regained'])
];
