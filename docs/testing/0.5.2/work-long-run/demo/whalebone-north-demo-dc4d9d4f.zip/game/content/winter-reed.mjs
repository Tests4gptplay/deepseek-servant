import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,exit,flag} from './parts.mjs';
import {setting} from './registry-parts.mjs';
import {tidePost} from './district.mjs';
export const loft=region('loft-reed','冬岸 · 画歪三层的挂网街',5,'winter-village',30,19,'stone',
 [['building',1,1,5,6,'临冬搬低的鱼架'],['building',10,1,6,5,'俯看高栏的两层绘网屋'],['building',21,2,8,5,'封着积冰的敲钟楼'],['crate',2,13,6,6,'绳工的遮雪棚'],['water',17,13,13,6,'正在上涨的排鱼暗渠']],
 [['path',2,8,24,3,'沿墙标高的挂网街'],['rope',10,10,9,1,'低窗内侧渔线'],['lamp',15,7,1,1,'旧测纸唯一的灯']],
 [witness('wrong-step','脸贴齐窗台的修窗人·晞渠',8,8,[s('晞渠','你是图署出来的吗？这巷里三张“高处”符号是去年你给的。我孩子靠那图抬水，把小车送到水落最低的街。'),s('米拉','我当时站的是网架二楼。我写了三层高，没有写我是从谁的窗向下量。拿原图给我。'),s('晞渠','不忙给你。先去走孩子推过的路，问他哪一块砖先湿；他有名字，叫小岩。')],'wrong-step',['moor-proved']),
 witness('wet-cart','给车轮另编绳边的学徒小岩',20,9,[s('小岩','靠墙第五块先湿。不是车跑得慢，是那个转弯处比地坪低了两块砖。纸上的“上窗”却画在那块砖正上头。'),s('米拉','我要把示意升降的线先取下来。你先别告诉我哪边是对的，我按船尺往返着验。')],'cart-scratch',['wrong-step']),
 person('slant-gran','给晒鱼架踢冰的阮婆',11,11,[s('阮婆','这六扇网都朝街，不是住六家。我常看见外地人点窗数人。你要藏药床还是找空路，问门旁的孩子。'),spoken('阮婆','暖床挪到屋里，鱼架就留给出工人。小岩这几夜还拿它练推独轮车，我叫他慢着走。','chart-shelter'),spoken('阮婆','有人每天替低窗换一条架高的响索。今天轮到我；明天我若生病，钟牌上有替手的姓。','chart-hoist')])],
 [exit(2,8,'grain-tender',[25,9],'下斜坡回粮驳'),exit(26,9,'fifth-brick',[3,8],'沿小岩的车印找第五块砖'),exit(14,14,'winter-court',[17,12],'绕网仓回炉街')]);
export const brick=region('fifth-brick','冬岸 · 上窗下面的第五块砖',5,'winter-village',24,17,'stone',
 [['water',0,0,24,3,'引渠浅湾'],['wall',3,4,4,3,'网上窗的投影墙'],['building',13,3,7,4,'放铁垂的地门'],['crate',16,12,8,5,'能升起的小车台']],
 [['rope',3,8,16,1,'齐窗拉平的勘线'],['lamp',12,9,1,1,'第五块湿砖'],['pier',6,11,10,1,'跑车时会碰到的槽']],
 [setting('top-baseline','沿二楼窗横档画第一条临时线',7,8,[s('米拉','窗框三尺高，车轮走的是窗外低处。我先画上窗，另一处一旦比不齐就撤回。')],['cart-scratch'],{'street-datum':false,'window-datum':true}),
 setting('street-baseline','把铅线移到地门砖下重校',16,9,[s('小岩','从这里到我鞋头那块砖刚好平。给窗留个高低差，不用再把屋顶叫路。')],['cart-scratch'],{'street-datum':true,'window-datum':false}),
 tidePost('brick-tide',10,10),fixture('brick-wet','在回潮踩车辙测第一个水口',18,8,[s('米拉','低砖没过一个轮圈的时候，上窗还是干。若我站回二楼，能看四条路，走下来才知道只有两条能拖车。')],'brick-wet',['street-datum','tide:high']),
 fixture('brick-dry','退水后用小岩的空车重走门槛',9,11,[s('小岩','急落的地方不是那块高砖，是湿到只剩一线苔的缝。你画车路线，我画人能经过的石阶，别用一个标。')],'brick-dry',['street-datum','tide:low']),
 person('chart-liability','米拉在自己错标的原址签名承担改图',13,8,[s('米拉','我认，我把房上的高度当成街上的了。不是写错数，是从没跟着一辆车走到门口。'),s('晞渠','把你接下来的一段工给这条路。我们可以搬一间内床给孩子住，也可搭索把低窗升作夜间集合标。'),s('小岩','我能留窗发出声音，不愿被人关在屋里。可我奶奶愿睡在暖屋，别替她也选。',[
 {text:'把一间内床换给会怕水声的住户',set:'chart-shelter'},{text:'米拉出工装响索，留下低窗人自己的开关',set:'chart-hoist'}])],{requires:['brick-wet','brick-dry'],action:flag('chart-corrected'),after:[s('米拉','我的冬图在这处留了高、低两个小名。今晚实际由谁住或谁守铃，得等倾港的人亲自来。')]})],
 [exit(2,8,'loft-reed',[25,9],'把实测带回挂网街')]);
export const linen=region('linen-slope','冬岸 · 新雪下的洗布坊',5,'winter-village',25,17,'stone',
 [['building',1,1,6,5,'照料病人的冬洗屋'],['crate',12,1,7,5,'有该还回去的旧褥'],['water',16,12,9,5,'沿下坡的洗布水道']],
 [['path',2,8,21,2,'晒带沿墙回暖'],['rope',7,10,11,1,'三户各一块旧布']],
 [witness('first-hem','想自己走到船沿的铺主·寒麦',8,8,[s('寒麦','葬人的白布怎么洗？你别笑。来避冬的人穿我的旧外衣出去，远远看去像被抬走。我想换个颜色。'),s('玛拉','我送葬时折白面，让亲属能摸到边。你们要走，里子翻出来还要能从自己肩上拉开。你想在布上留什么？'),s('寒麦','一个袖口能向外翻的补丁。我哥哥怕闻皂叶，让他也摸摸。')],'hem-request',['bed-count']),
 fixture('brother-linen','去灶背试一块不会认错的袖里',15,8,[s('寒麦的兄长','我眼睛不好，毛面朝我就太扎。你要用来扶我，我宁肯不穿。把软里朝上留一道横缝，我自己能松。'),s('玛拉','我以前替亡者把两袖扣齐。这次你一只手要拿帽子，另一只手要有空。')],'hem-tested',['hem-request']),
 person('whose-cloak','交回能自己翻开的实衣',11,10,[s('寒麦','哥哥穿自己那件。余下有两幅，布不够把两件都做齐：可以围到候船孩子身上，也可给夜里接人的摆渡人遮雪。'),s('玛拉','我不替谁定要不要套，你们挑真会伸手接的人。',[
 {text:'让等船的绣班孩子先穿',set:'cloth-for-child'},{text:'留给交替守舷的摆渡人',set:'cloth-for-oars'}])],{requires:['hem-tested'],action:flag('cloak-promised'),after:[s('寒麦','衣服没有穿到人身上，便只能说做好。水涨以后，别把布卷随人名一并点掉。')]})],
 [exit(2,8,'winter-ward',[7,9],'回横铺前堂'),exit(22,8,'kin-larder',[18,10],'送新衣去热席巷')]);
