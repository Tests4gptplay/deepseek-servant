import {region,fixture,witness,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit,flag} from './parts.mjs';
export const testimony=region('testimony-room','鲸城 · 门帘内外的船难书室',2,'whale-interior',21,16,'wood',
 [['building',1,1,6,5,'米灯在屋里的近窗'],['crate',10,2,6,4,'没交给港署的相片木版'],['building',15,11,6,5,'封门的小纸阁']],
 [['rope',7,6,10,1,'由屋里的人自己收放门帘'],['lamp',9,9,1,1,'不对准面孔的矮灯']],
 [witness('witness-boundary','曾被近艇接走的迟荻',7,8,[s('迟荻','你父亲在船上把我抱起来，我记得他袖口湿到肘。我不愿意别人把我当成能替半城原谅他的那个人。'),s('玛拉','我来听你的话，不来收一张赦书。你想见到伊沃，还是只把空灯架拿给他？'),s('迟荻','先把他那本总簿里的“全体归队”遮住。我想看看，没有那四个字，他会不会还往下念。')],'speaker-boundary',['beds-list']),
 person('witness-chair','迟荻自己拉动的门帘',13,8,[s('迟荻','我没说十一颗钮扣就是十一个人。近艇与远艇要分开。我肯留下远门的三响，也要选择写在哪里。'),s('伊沃','我把改好的册放在外面。你从里边说。'),s('迟荻','给眼下要用的人，还是留份没有名字的教具，都行。别问我要第三种。',[{text:'封入木套交给现在的值灯人',set:'speaker-sealed'},{text:'不署姓名，教后来者从外边开灯',set:'speaker-lesson'}])],{requires:['folio-corrected'],action:flag('speaker-choice'),after:[spoken('迟荻','只交值灯人的手。带回去的回条可以写你，不许写我的住址。','speaker-sealed'),spoken('迟荻','你先去教。有人真会从另一边重新开灯，再回来敲我的帘。','speaker-lesson')]}),
 person('folio-child','在书柜上夹木版的梓曲',10,10,[s('梓曲','你把木版摆正，我就看不见我妈画的那只歪脚艇了。她觉得谁都该先画一只歪的，那样才有人愿意在旁边改。')])],
 [exit(2,7,'eight-landing',[15,14],'掀帘回八户街'),exit(18,8,'shutter-school',[3,7],'循木版外廊去灯课',['speaker-boundary'])]);
export const school=region('shutter-school','鲸城 · 值灯人的反开课房',2,'whale-interior',23,15,'stone',
 [['wall',1,1,6,4,'旧钟箱'],['crate',10,1,6,5,'装过灯册的船匣'],['wall',17,9,6,6,'从另一边看得见的光墙']],
 [['lamp',7,6,1,1,'近窗白玻璃'],['lamp',15,6,1,1,'远窗蓝灯'],['rope',8,9,6,1,'反向活环']],
 [fixture('separate-lines','将两条艇的记号移回不同槽',10,7,[s('伊沃','近艇九个扣，远艇三声铃。两个归还口我自己蒙成一格，才写得出全体归队。'),s('玛拉','你写的是登记人的错，不是迟荻需要替你担保的数字。')],'folio-corrected',['speaker-boundary','near-witness','far-roll']),
 witness('lesson-switch','让一名没当过港卫的人从外边开灯',15,8,[s('学徒','我握的这头能把蓝灯拉回来。你站着别动，得让我从另一面试。'),s('伊沃','好。我不指你朝哪边。')],'speaker-taught',['speaker-lesson'],{action:{type:'flag',id:'speaker-taught',set:'speaker-action'}}),
 witness('sealed-box','把无址木套交到现任值灯人手上',7,9,[s('值灯人','收件人是我，不上全港传阅。哪天我换班，先去问迟荻还愿不愿再交一次。')],'speaker-delivered',['speaker-sealed'],{action:{type:'flag',id:'speaker-delivered',set:'speaker-action'}})],
 [exit(2,7,'testimony-room',[17,8],'回书室'),exit(19,7,'west-lamp',[7,10],'从灯课走老塔外廊',['gate-safe'])]);
export const heron=region('net-heron','鲸城 · 舷网白鹭通风台',2,'whale-roof',22,16,'wood',
 [['water',0,0,22,3,'潮云下的舷沿'],['crate',3,4,5,4,'修翼布的网箱'],['wall',13,2,6,6,'挂着幼鸟钩环的通风框'],['water',14,12,8,4,'无人脚踩的外海']],
 [['rope',7,8,11,1,'白鹭占住的排风绳'],['pier',3,9,13,2,'能绕巢的矮风台']],
 [person('heron-girl','守网鸟的木鸢',7,9,[s('木鸢','白鹭捡到小鱼就把网绳当窝口，扯绳它会用翅把人推回井。你可驯它看空筐，也可护阵把断绳松开。都别往巢里伸手。')]),
 fixture('bait-pan','把鱼尾挂在远离巢的旧筐',10,9,[s('木鸢','潮退以后浅水虾露出来。把旧筐移过两根桩，它看见自己的影子会跟着走。')],'heron-bait',['tide:low']),
 fixture('heron-move','走到外台翻转旧筐的内衬',18,9,[s('伊沃','站到它看得见的方向，别堵巢。它去啄筐，断网自己松下来了。')],'net-open',['heron-bait']),
 object('heron-standoff','挡路的护巢白翅',12,8,[s('木鸢','网外保持一臂；它抬右翼，下一击从右上扇向左下。'),s('玛拉','我护人前臂，不碰巢。伊沃，听见木扣脱落就放开。')],{requires:['!net-open'],lockedText:'巢还在通风台。网绳已经从它脚边移开。',action:{type:'battle',id:'sail-heron',set:'net-open'}}),
 object('counter-sleeve','木鸢编的短距牵索护手',9,11,[s('木鸢','夹在绳和掌之间，给拆硬壳的人留一段力道。护手是我给的，不是从鸟身上剥的。')],{requires:['net-open'],action:{type:'item',id:'line-brake',value:1,set:'net-gift'}})],
 [exit(2,7,'loom-run',[13,14],'回织架夹层'),exit(18,10,'dry-court',[22,12],'从腾空的风台沿网直接下晒衣院',['net-open'])]);
export const bird={id:'sail-heron',name:'守通风网的白翅',enemy:'港鹭',hp:39,attack:4,level:3,
 phases:[{fromHp:39,tell:'单脚挑绳，右翼伏低，防划过去的绳盘。',moves:[{name:'踏绳骤推',kind:'ram',counter:'guard',power:1.3},{name:'半翼推潮',kind:'rush',counter:'dodge',power:1.2}]},
 {fromHp:19,tell:'双翼半盖巢，长喙探网外的结。',moves:[{name:'翅背封网',kind:'shell',counter:'skill',power:1.0},{name:'吹绳绕圈',kind:'whirl',counter:'dodge',power:1.3}]}],
 rewards:{xp:14,label:'断绳落回风台，成鸟和幼鸟留在自己的巢里。'}};