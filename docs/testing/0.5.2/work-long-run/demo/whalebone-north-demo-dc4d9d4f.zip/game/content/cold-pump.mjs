import {region,fixture,spoken} from './voyage-parts.mjs';
import {say as s,person,object,exit} from './parts.mjs';
export const pump=region('cold-pump','冬岸 · 弃用的活塞间',5,'winter-interior',19,15,'stone',
 [['wall',0,0,19,3,'泵壳保温层'],['water',3,5,5,3,'鳃虫吸附池'],['crate',12,8,5,5,'冰死的落水锤']],
 [['rope',8,6,6,1,'轻锤横臂'],['lamp',10,9,1,1,'守房人灯']],
 [person('pump-mender','退休的砸冰妇·独笛',5,9,[s('独笛','这里两种办法。敲它的背甲，潮虫就松开管子。你要舍不得碰它，开我的药柜，用暖盐布把它引上游。后面都是同一扇门。')]),
 object('pump-salve','暖盐布与铅口夹',9,7,[s('瑟琳','这块布留一点我母亲做粥的橘皮味。汤匙那么重，足够引小东西跟着跑。')],{action:{type:'item',id:'tonic',value:1,set:'warm-cloth'}}),
 fixture('lure-ice','把暖盐布挂到背水岩缝',11,6,[s('独笛','等它自己爬过去，长锤不压背甲就算脱身。现在手柄活了。')],'pump-free',['warm-cloth','party:selene']),
 object('cold-whelk','守在泵舌上的浪纹螺',9,10,[s('米拉','它会把风口当硬壳的一面。站到木架的纵线，等它自行翻面。')],{requires:['!pump-free'],lockedText:'泵舌上只剩湿痕，浪纹螺已移回水槽。',action:{type:'battle',id:'frost-whelk',set:'pump-free'}}),
 fixture('hospital-clamp','扳下解冻的活塞',16,7,[s('独笛','第一桶留给炉前的人。多开的泵房过一冬能少走一百次冻路，比在档案上多两床实在。')],'spare-pump',['pump-free'])],
 [exit(2,7,'moor-pocket',[20,15],'沿隔冰栈返内港')]);

export const shoalFoe={id:'frost-whelk',name:'泵风口的浪纹螺',enemy:'浪纹螺',hp:55,attack:5,level:5,
 phases:[
 {fromHp:55,tell:'白线贴壳，腹足紧贴整根缆。',moves:[{name:'沿线旋进',kind:'whirl',counter:'dodge',power:1.2},{name:'吸盘护腹',kind:'shell',counter:'skill',power:1.1}]},
 {fromHp:22,tell:'腹足离地，冒出白色气泡。',moves:[{name:'冰槌翻顶',kind:'ram',counter:'guard',power:1.6},{name:'侧壳滑行',kind:'rush',counter:'dodge',power:1.4}]}],
 rewards:{xp:22,items:{tonic:1},label:'从泵沿收回一瓶冷存的盐橘药剂。'}};
export const anchorFoe={id:'anchor-clutch',name:'三段啮合的锚机',enemy:'倒冲棘轮',hp:164,attack:6,level:7,objective:'拆除止动钩、释力、待手动解锚',
 phases:[
 {fromHp:164,tell:'白齿过我膝盖。压住机脚才不被头一段震倒。',moves:[{name:'压舷重锤',kind:'ram',counter:'guard',power:1.5},{name:'横过滑道',kind:'rush',counter:'dodge',power:1.3}]},
 {fromHp:118,tell:'磨黑的齿面遇到副钩。打在外壳上会把动力送回底座。',moves:[{name:'副钩闭合',kind:'shell',counter:'skill',power:1.15},{name:'转臂扫行',kind:'whirl',counter:'dodge',power:1.4}]},
 {fromHp:65,tell:'第三声空响后绳盘反转，黑线先经过西侧，再回中轴。',moves:[{name:'卷索逆扫',kind:'whirl',counter:'dodge',power:1.6},{name:'滑接最后一齿',kind:'ram',counter:'guard',power:1.6}]}],
 rewards:{xp:35,label:'钩爪失去咬合，锚柄仍须有人亲手松开。'}};
