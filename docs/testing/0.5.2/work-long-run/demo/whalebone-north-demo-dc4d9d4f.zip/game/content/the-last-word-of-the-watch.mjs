import {say as s,person,exit} from './parts.mjs';
import {fixture,witness,spoken} from './voyage-parts.mjs';
import {mechanism} from './district.mjs';
import {coatFirst} from './the-coat-over-the-lid.mjs';

const dayTwo=['shift-called','!early-castoff'],launch=['early-castoff','!roof-shelter'];
const second={
 'rope-market':[
  witness('saltcoat-wrong-word','端起老更客摊边的半只粥碗，听清父亲从前改过哪一句早饭调',9,13,[s('老更客','你爸的调就会半截。别人唱“慢些，粥还热”，他最爱来一句“慢些，粥还慢”。小孩子笑了他才肯吃自己的。'),s('玛拉','小时候我以为他真不会唱。下回遇到原来唱这曲的人，我得问问是谁先笑的。')],'saltcoat-old-word',['saltcoat-airgap','!coffin-aboard'])],
 'wick-house':[
  fixture('saltcoat-hot-cup','拿早上那枚钱买一盏有盖的热水，一个人坐到头位等车',5,8,[s('灯房嫂子','热水钱只收买得起的人。靠门最背风的凳给你留到这杯喝完。'),s('玛拉','舌尖被烫了一下。我还会嫌水太热，真奇怪。')],'saltcoat-warm-seat',['vigil-finished','!saltcoat-fruit-paid','!early-castoff']),
  witness('saltcoat-plain-cup','未留热水钱，在公用长凳和守火的人分半盏温水',10,9,[s('灯房嫂子','那枚钱给了果摊，头位这回已经有人。坐长凳吧。我们只剩温水，可还有人坐在这里。'),s('玛拉','我平时替别人看火，倒不知道坐近了是什么味儿。'),s('守火工','芜菁皮。别嫌，烤熟了甜。')],'saltcoat-shared-water',['vigil-finished','saltcoat-fruit-paid','!early-castoff'])],
 'wake-court':[
  witness('saltcoat-ask-first','在廊檐边等一位送婴儿回家的母亲自己决定要不要学徒搭手',15,10,[s('阿汲','车外那角搭着水，我能把干地腾给你吗？我不动你家孩子。'),s('年轻母亲','手别伸过蓬。我想自己抱。你替我扶着那扇要关的门。'),s('阿汲','好。我在门这边。'),s('玛拉','他两只手都搭在门板上，一直到那家人把车转过去。')],'saltcoat-help-asked',['coffin-aboard','saltcoat-taught','!early-castoff'])],
 'shift-square':[
  witness('saltcoat-noon-pass','向换鞋房老板领一张能从粮趸直上高桁的亲属站票',7,7,[s('换鞋房老板','送棺本人有半块短桥牌。旁边那条上走梁的梯道照开。等划好泊位，拉索人开道后，粮趸便能从短桥上高桁。谁还持牌，谁站在靠窗那一边。'),s('玛拉','我若把它让给别人？'),s('换鞋房老板','你从灯廊走公共梯。今天这块不补，也不收第二次钱。')],'saltcoat-noon-ticket',dayTwo),
  witness('saltcoat-hear-singer','站到歌工惟芦够得着的矮阶，不打断她唱完点班那一轮',14,7,[s('惟芦','近班鞋底一齐落地，过一口气才点远班。一首班歌给的只有一份钱。你爹把那调拿来哄小孩，拿去十七年，连个尾音也没来还。'),s('玛拉','他也哄我，唱得难听。我可以请你来，但不能说他临走时等你。'),s('惟芦','我不唱挽歌，也不要让整港听我的名字。想下班去侧窗，我得有人真顶我的活；若还在岗，我只愿从桁外给他比一下手。也可以算了。'),s('矮阶','西边招工房听得见人脚；东边雨帽廊有人朝着货窗过日子。两处都还开着。')],'saltcoat-met-singer',dayTwo),
  witness('saltcoat-singer-choice','把自己的站票放在矮阶上，和惟芦商量这一班怎样过',12,8,[s('惟芦','替班的要有人接上两头，钱仍是我该领的。留我在原位，就把你那张短桥牌让给我要借的看窗人，自己绕灯廊。你若只来请我在众人前唱，我的回答是不要。'),s('玛拉','今天这段路怎样走？',[{text:'我去招工房代唱这一班，给你一趟带薪的独处，不问你说什么',set:'saltcoat-cover-choice'},{text:'保留你的班，请你自己选告别手势，再把我的短桥站位让给看窗人',set:'saltcoat-window-choice'},{text:'替街坊请求一支公开挽歌，听她亲口答应或拒绝',set:'saltcoat-invited-crowd'}]),s('惟芦','说出口还不顶事。等你真的到了该站的地方，我才动。'),spoken('惟芦','你们可以照常出航。那支歌留在我这里，我要继续唱给活人听。','saltcoat-invited-crowd')],'saltcoat-paid-answer',[...dayTwo,'saltcoat-noon-ticket','saltcoat-met-singer'],{after:[s('惟芦','刚才的话算数，别再换一种问法，问到我点头为止。')]}),
  witness('saltcoat-family-promoter','把歌工拒绝的原话带回街角凑热闹的搭台人，不替她找借口',26,8,[s('搭台人','没时间呢，还是嗓子不好？我们可以等。'),s('玛拉','都不是。她说不唱给人看。那面台留给明天开市。'),s('搭台人','……行。我妹妹下午来修蓝靴子，用得着一张没铺白布的宽台。')],'saltcoat-declined',['saltcoat-invited-crowd',...dayTwo],{action:{type:'flag',id:'saltcoat-declined',set:'saltcoat-second-ended'}}),
  witness('saltcoat-hear-refrain','趁两班之间的小空隙，把养父唱错的那一句轻声还给惟芦',15,10,[s('玛拉','“慢些，粥还慢。”我小时候拍桌子笑他。你听过吗？'),s('惟芦','粥当然不会慢。他怕自己吃得急，教小孩子笑住他。我也学会这句，夜班吃饭拿来救我自己。'),s('玛拉','那我只带这句走。你想对他说的，全留你自己。')],'saltcoat-shared-refrain',[...dayTwo,'saltcoat-old-word','saltcoat-met-singer'])],
 'haul-office':[
  fixture('saltcoat-near-shoes','在近班的鞋凳旁听一整句，认清墙声和真回唱的不同',7,7,[s('鞋工瓶姑','你看，鞋尖歪着是我在换袜，嘴上“到”是答别人。我鞋底一旦平平贴上白木，孩子们才搭最后一个字。对面空墙不穿鞋，回得比他们早。'),s('玛拉','先看见人，再接她的末字。站我爸床前时，我也老把自己的回声听成他答应。')],'saltcoat-heard-shoes',[...dayTwo,'saltcoat-cover-choice']),
  mechanism('saltcoat-lead-shift','站在两列鞋凳中间亲自唱下一折，等还在换鞋的人作出回应',17,9,[s('近班','起——鞋跟还在门槛外。墙先回了一个起字，远班女孩低头系白线。')],[...dayTwo,'saltcoat-heard-shoes'],'saltcoat-shift-in','近班已过槛，远班鞋底还悬着，墙上先还了一个音。什么时候接下一句？',['循墙回音立刻点远班，赶出独处的时间','把近班的人再点一遍，用大声盖住回音','等远列穿白线鞋的孩子站实，听见她的回唱再接尾字'],2,'空墙先回，远班还没站好。看鞋底贴到白木，再听人声，不能让未归的人失去工钱。',[s('远班女孩','我到了。我自己站好了。换回去吧，别把我名字点到隔壁锅摊去。')])],
 'wet-arcade':[
  witness('saltcoat-meet-sill','在借凳馆找到给货窗开百叶的桐萝，听她先说清当班要看到哪一扇',12,8,[s('桐萝','我抚养惟芦长大，她不肯叫我妈。我们过同一扇窗时，她会把拇指朝自己，表示今天是她自己做的主。你看见窗外有旧蓝布，是我在这儿，不是要她唱给你听。'),s('玛拉','我得知道挡窗的是哪层。'),s('桐萝','看！筐不动的时候，窗里还是暗；一片一片跟风动的是你的棺车遮帘。你能决定的是哪一件？')],'saltcoat-window-kin',[...dayTwo,'saltcoat-window-choice']),
  mechanism('saltcoat-sight-test','从借凳馆矮窗口移动自己车上的一片遮帘，让惟芦看见真实的人影',24,9,[s('窗里','穿雨布的人仍在忙，没人准你上去叫他停工。')],[...dayTwo,'saltcoat-window-kin'],'saltcoat-view-ready','抬头看：筐影不动，风一来，窗上的暗边一收一放。你可以改动什么？',['请人把整个粮趸的筐都撤走','只折起自己车的迎风小帘，等里面的人自行伸手','把帘都掀起，站到棺前替两个人挥手'],1,'会随风动的属于你。留另一片挡住棺盖，不替窗里的人作手势。',[s('桐萝','够了。我能从这条缝里看见她鞋上一块白。把你的牌到粮趸交给我，我到桁边给她留窗。')])],
 'ration-berth':[
  witness('saltcoat-pay-the-shift','守到粮趸下班的最后一双鞋，在本人面前把当班钱算回惟芦手里',12,8,[s('记薪人','玛拉架起了远班，近班是惟芦领的。谁拿？'),s('玛拉','整枚给她。我答应换的是时间，没有拿她的班买我自己的饭。'),s('惟芦','钱到我手。侧窗还留着，我去跟那个永远唱不对的人说件不能告诉你们的事。起航时我会来把门拢上。')],'saltcoat-paid-leave',['saltcoat-shift-in','berth-fixed','!early-castoff']),
  witness('saltcoat-give-the-pass','在粮趸短桥前把唯一半牌交给桐萝，亲眼见她从自己的近路上去',19,8,[s('桐萝','我占着这个窗位，你和你的棺车就不从这条短桥并着走了。'),s('玛拉','我走灯廊，回来追得上。你在里面直看她，别向我转述。'),s('看桥工','她过去了，牌收在她那边。要上高桁走讯号灯廊公梯；第三天那里还能从下层看到她亲手伸的拇指。')],'saltcoat-seat-given',['saltcoat-view-ready','berth-fixed','!early-castoff']),
  person('saltcoat-pass-guide','短桥口正在暖脚的盲绳婆',6,11,[s('绳婆','脚边一条是短桥，有亲属站牌才开，没牌也走得通。朝内讯刻度亭走灯廊，再沿桁的一侧上。桥工只在卡过泊位、伊沃开了绳道才放行。'),spoken('绳婆','我听到桐萝把牌对折夹在袜里。她今天能看见谁，今后也不用到茶馆向你买一句话。','saltcoat-seat-given')])],
 'upper-spar':[
  witness('saltcoat-shut-sidewindow','起航笛响后到桁底的侧窗外，把最后一扇门留给领薪回来的惟芦亲自合上',7,7,[s('惟芦','我的钱在腰里，我自己的话也留在我自己嘴里了。你在门外，我从里面来关。'),s('玛拉','好。我就看看门缝一点点细下去。'),s('侧窗','黑线变成一线晨光，到最后是木板。玛拉没去补上那段没听见的话。')],'saltcoat-private-goodbye',['saltcoat-paid-leave',...launch],{action:{type:'flag',id:'saltcoat-private-goodbye',set:['saltcoat-sailed','saltcoat-second-ended']}}),
  witness('saltcoat-handsignal','起航时退到走梁背光的一侧，给远处手的主人留出最后一个字',19,8,[s('玛拉','我绕了公梯，从这边只看得见那半个窗。'),s('桐萝','她没有叫我妈，也没有唱歌。看，拇指朝她自己，手背向海。她做的是她答应要做的，不是做给我们猜谁该哭。'),s('惟芦','……'),s('玛拉','她已经松开了。那是她能给他的。')],'saltcoat-window-goodbye',['saltcoat-seat-given',...launch],{action:{type:'flag',id:'saltcoat-window-goodbye',set:['saltcoat-sailed','saltcoat-second-ended']}}),
  person('saltcoat-castoff-porter','把空乌木窗扣系回腰间的看桥人',8,10,[s('看桥人','起航笛响了，不等赶潮。没赶上的家人也有地方站。去北屋脊的横板和去南檐的病船都从这根桁下分开。'),spoken('看桥人','歌工留在岸上做她自己的班，今天台上没有一场她不肯唱的送别。','saltcoat-declined')])],
 'burial-cape':[
  fixture('saltcoat-last-hem','刻完墓碑，把收在棺车底座的那一小段自己的青披展开晾干',12,8,[s('玛拉','这儿比开市那天干。你把名字缝在下领，就缝在你自己身上。我自作主张翻过一次，后来只还你一层我自己用过的布。到这里，连那一折也能放平了。')],'saltcoat-private-echo',['grave-signed','saltcoat-dressed']),
  witness('saltcoat-last-door','在墓边让阿汲自己说他当日学到的工作，不把那位家属的名字带上碑',17,9,[s('阿汲','我没碰过我师傅养父的棺衣。我学会给车外做干沿。后来有位母亲只让我扶门，我扶了很久。'),s('玛拉','我还记得那门合上的响声。他不用写在我父亲碑上，给他自己的下一扇门就好。')],'saltcoat-public-echo',['grave-signed','saltcoat-help-asked']),
  fixture('saltcoat-last-window','到坡脚车窗旁决定把那几息没人听到的静默继续留给原来的两人',13,11,[s('玛拉','惟芦自己关了侧窗。我知道她花了多大功夫争到那一下。旁人总问她到底说了什么，我连“对不起”三个字也不替她编。')],'saltcoat-wage-echo',['grave-signed','saltcoat-private-goodbye']),
  fixture('saltcoat-last-hand','站到迎海一侧，在自己的手背上重看那天格外清楚的晨光',20,11,[s('玛拉','桐萝看见的是养大的人，我看见的是我父亲的朋友。一扇窗里两个人，都不用替对方改名字。'),s('米拉','那我海图上还是只写“借凳馆东窗”。谁曾站在那里，我们路过时记得就够。')],'saltcoat-hand-echo',['grave-signed','saltcoat-window-goodbye']),
  fixture('saltcoat-last-breakfast','等同伴端碗后，在碑侧背风地唱一次没写进任何账簿的错早饭调',11,12,[s('玛拉','慢些，粥还慢。'),s('瑟琳','慢的到底是粥还是你？'),s('玛拉','是我爸。他吃得太快，教我笑住他。等这碗凉一点，我讲给你听他还有哪几个字唱得不好。'),s('坡下','同伴们端着自己的碗等了片刻。远处的人各有早饭。')],'saltcoat-breakfast-echo',['grave-signed','saltcoat-shared-refrain','saltcoat-sailed']),
  person('saltcoat-fresh-flowers','在坡边替自家老人换一束花的鞋工瓶姑',6,11,[s('瓶姑','我是给我舅父换花的。他睡在下面那级，不是每个人都来找你。我带了热水，要不要分一口？'),spoken('瓶姑','惟芦后来还在港口唱工歌，没给那次台子唱挽歌。那是她自己的原话。','saltcoat-declined')])]
};
const marks={
 'wharf-scale':[['rope',13,8,3,1,'晾在棺车边上的旧青披，低角贴近车板']],
 'rope-market':[['stall',16,10,3,1,'只肯匀出一转的油果摊'],['rope',12,10,2,1,'果盘边只许用在空架的晾布']],
 'shift-square':[['plank',20,8,2,1,'站得下一个人的歌工矮木台'],['sign',22,8,1,1,'远班和近班错齿的鞋牌']],
 'haul-office':[['plank',15,10,3,1,'远班鞋底要真正贴上的白木凳面'],['crate',17,10,1,1,'远班鞋柜的小木箱']],
 'wet-arcade':[['awning',20,9,3,1,'随风收放的棺车小帘和借凳馆窄窗口']],
 'upper-spar':[['rope',16,8,2,1,'窗边晾着的蓝布，记着桐萝在里面'],['lamp',17,8,1,1,'两片百叶之间的小灯']],
 'burial-cape':[['rock',12,12,1,1,'碑侧能将旧布摊开的背风石']]
};
const short=['saltcoat-noon-ticket','berth-fixed','ivo-line','!saltcoat-seat-given','!roof-shelter'];
export const shortUp='凭一块亲属站牌，从粮趸短桥直接登高桁';
export const shortDown='凭原半牌过短桥回粮趸';
const paths={
 'ration-berth':[exit(25,12,'upper-spar',[18,12],shortUp,short)],
 'upper-spar':[exit(25,12,'ration-berth',[18,12],shortDown,short)]
};
export function withSaltcoat(map){
 if(!coatFirst[map.id]&&!second[map.id]&&!paths[map.id])return map;
 const hints={
  'wharf-scale':'开市先和送棺人说话，再到车背风面看棺肩和车底。公用干披和通往修索市的主路一直有人照管。',
  'rope-market':'在秤桥查明湿的是哪一折，再来借一转果架，先试布，后择内帘或空架。送棺上船前仍来得及。',
  'coffin-hoist':'吊台照常开。若要亲手护披，须在开市时查清外披、在果摊做完自己选的一转架，再回到吊台。',
  'wick-house':'守灯到天亮后，可在灯房过第一口水。买得起热水坐靠门位，护了果盘就同守火工坐长凳。',
  'wake-court':'只有真的在空架教过阿汲，第二天才会见他开口问家属。邻舍不必等他来才出门。',
  'shift-square':'先完成守灯，听广场报换班，听惟芦唱完一轮，拿明白短桥站牌的去处；第三日起航就不重排昨日的班。',
  'haul-office':'换班时约好替惟芦唱，再从近班的鞋凳听回声，退到两列中间等真人站好。她得在起航前真领到工钱。',
  'wet-arcade':'换班时约好保留惟芦的岗，在借凳馆问桐萝，再看借凳馆的窗。谈妥泊位后在粮趸交站票。',
  'ration-berth':'泊位划定后、鸣笛之前，到粮趸结清当班钱或交唯一半张站票。灯廊的公梯照开。',
  'upper-spar':'先在粮趸办完那个人的一件事，到高桁听伊沃喊起航，再从桁底侧窗或背光一侧看她自己的告别。',
  'burial-cape':'先完成安葬。墓边只收在开市、换班与起航时亲手做过的事。'
 };
 const names={
  'saltcoat-notice':'背风处的棺车','saltcoat-high-edge':'棺肩的迎风面','saltcoat-low-edge':'车底外披的折口','saltcoat-cart-helper':'学徒阿汲',
  'saltcoat-lease':'果摊主人芹绶','saltcoat-turn-hem':'空架上的两道折边','saltcoat-own-turn':'果架旁的内帘','saltcoat-private-fee':'付掉果盘工钱','saltcoat-empty-frame':'请阿汲在空架上试水','saltcoat-wrong-word':'果摊边的半只早饭碗','saltcoat-candle-seller':'掰软果核的老更客',
  'saltcoat-private-dress':'内帘里的家用青披','saltcoat-public-dress':'塔婶和公用干披','saltcoat-direct-porter':'守吊台的塔婶',
  'saltcoat-hot-cup':'花钱买靠门的热水','saltcoat-plain-cup':'长凳边的半盏温水','saltcoat-ask-first':'阿汲与檐下的婴儿车',
  'saltcoat-noon-pass':'换鞋房的半张站票','saltcoat-hear-singer':'惟芦的换班歌','saltcoat-singer-choice':'惟芦手边的两面班牌','saltcoat-family-promoter':'街角搭台人','saltcoat-hear-refrain':'歌工阶边的粥碗',
  'saltcoat-near-shoes':'近班换鞋的白木凳','saltcoat-lead-shift':'两列鞋凳之间的领唱位','saltcoat-meet-sill':'借凳馆的桐萝','saltcoat-sight-test':'风里摆动的棺车小帘',
  'saltcoat-pay-the-shift':'最后一双鞋的班钱','saltcoat-give-the-pass':'把半张站票交给桐萝','saltcoat-pass-guide':'暖脚的绳婆',
  'saltcoat-shut-sidewindow':'等惟芦从里面合窗','saltcoat-handsignal':'背光处的一双手','saltcoat-castoff-porter':'高桁看桥人',
  'saltcoat-last-hem':'碑旁摊开的旧青披','saltcoat-last-door':'墓道旁的扶车门','saltcoat-last-window':'坡脚无人转述的窗','saltcoat-last-hand':'迎海的手背','saltcoat-last-breakfast':'同伴的早饭碗','saltcoat-fresh-flowers':'来替舅父换花的瓶姑'
 };
 const objects=['saltcoat-wrong-word','saltcoat-own-turn','saltcoat-singer-choice','saltcoat-hear-refrain','saltcoat-shut-sidewindow','saltcoat-handsignal','saltcoat-last-door'];
 const additions=[...(coatFirst[map.id]||[]),...(second[map.id]||[])].map(e=>({...e,name:names[e.id]||e.name,...(objects.includes(e.id)?{kind:'object'}:{}),...(e.requires?.length?{lockedText:hints[map.id]}:{})}));
 return {...map,entities:[...map.entities,...additions],
  features:[...map.features,...(marks[map.id]||[]).map(([kind,x,y,w,h,label],i)=>({id:'saltcoat-'+map.id+'-mark-'+i,kind,x,y,w,h,label}))],
  exits:[...map.exits,...(paths[map.id]||[]).map(e=>({...e,lockedText:'短桥只认尚在自己手里的亲属半牌，泊位和高桁绳路也要先定好。半牌已给桐萝时，从公共灯廊走，粮趸和高桁都能到。'}))]};
}
const arcs=[
 ['a-turn-of-the-fruit-rack','一转空架，一层家人的旧青披','side',['saltcoat-noticed','saltcoat-wick-seen','saltcoat-one-turn','saltcoat-airgap','saltcoat-chosen','saltcoat-finished']],
 ['sing-for-the-next-pair-of-shoes','等鞋底站稳了才唱最后一个字','side',['saltcoat-met-singer','saltcoat-paid-answer','saltcoat-second-ended']],
 ['what-went-in-the-porridge','慢些，粥还慢','hidden',['saltcoat-old-word','saltcoat-shared-refrain','saltcoat-breakfast-echo']]
];
export const saltcoatQuests=Object.fromEntries(arcs.map(([id,name,kind,stages])=>[id,{id,name,kind,stages,startFlag:stages[0],endFlag:stages.at(-1)}]));
