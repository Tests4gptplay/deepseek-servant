import {face,rod,plate,box,line,oval,poly,beam,hanging,ring,lamp} from '../lamplit-whale/fixtures.mjs';
import {northern,isWatch} from './horizon.mjs';
import {gauge,lit,capstan,slate,timber,spool} from './shore-craft.mjs';
import {windSock,shell} from './island-works.mjs';
import {headwaterFeature,headwaterPlaces} from './headwaters.mjs';
import {windFeature,windPlaces} from './windward.mjs';
import {opticsFeature,opticsEntity} from './optics.mjs';
export {northern,northernHorizon,watchLight} from './horizon.mjs';
export function northernFeature(c,p,m,f,s,t){return headwaterFeature(c,p,m,f,s,t)||windFeature(c,p,m,f,s,t)||opticsFeature(c,p,m,f,s,t);}
const wakes={
 'rib-survey':[[3,1,18,1]],'deep-sluice':[[1,.8,24,1],[8.7,6.1,4,-1],[19.5,12,7,1]],
 'red-beacon':[[12,.7,10,1],[.4,14.1,6,-1]],'wreck-slope':[[2,.5,23,1],[20.4,14.7,5,-1]],
 'leeward-buttons':[[3,1,34,1],[4,2.8,31,-1]],'sock-stair':[[21.6,3.8,5,-1]],
 'egg-meridian':[[1,.7,28,1],[.3,16.4,8,-1]],'edge-bleach':[[2,.9,28,-1],[.7,16.8,9,-1]],
 'fan-throat':[[2,.7,34,1],[3,2.9,31,-1],[1,18.4,10,-1]]};
function drift(c,p,x,y,len,dir,high,t){
 for(let i=0;i<Math.floor(len*1.6);i++){
  const f=(i*.62+((t*.09)%1.2))%len,v=y+Math.sin(f*.54)*.22+(i%3)*.23+(high?.11:0),u=x+f;
  rod(c,p,[u,v,1],[u+.31*dir,v-.035,1],'#d8e2cd9c',1.0);
  if(i%5===1){const a=p(u,v,2);oval(c,...a,3.8,1.45,'#bfc8a2');rod(c,p,[u,v,2],[u-.24*dir,v+.03,1],'#7b9581',1.2);}
 }
}
export function northernFloor(c,p,m,s,t){
 const high=s.tide==='high';for(const [x,y,l,dir] of wakes[m.id]||[])drift(c,p,x,y,l,dir,high,t);
 if(m.id==='silent-gimbal'){
  face(c,p,[[.4,2,0],[24,2,0],[24,12.8,0],[4,12.3,0]],'#34484a39');
  for(let j=0;j<3;j++){const from=4.4+j*6.7;face(c,p,[[from,2.7,0],[from+.44,2.7,0],[from+2.1,10.6,0],[from+.62,10.6,0]],j%2?'#f5d5952b':'#9dd2cf35');}
 }
 if(m.id==='sock-stair'){for(let i=0;i<7;i++){const x=16+i*.64;rod(c,p,[x,10.65,1],[x+.58,10.4,1],high?'#728a818c':'#7d8466',1.5);}}
}
export function northernEntity(c,p,m,e,s,t){
 if(opticsEntity(c,p,m,e,s,t))return true;const x=e.x+.52,y=e.y+.46,hi=s.tide==='high';
 if(e.id.endsWith('-watch-evening')||e.id.endsWith('-watch-morning')){
  const night=e.id.endsWith('evening');box(c,p,x+.12,y-.40,.44,.44,0,19,timber);lamp(c,p,x+.42,y-.2,28,t,night?isWatch(m,s):!isWatch(m,s),1.05);return true;}
 if(e.id==='sock-air'){windSock(c,p,x+.10,y-.49,33,t,true);return true;}
 if(e.id==='sock-heel'){for(let j=0;j<7;j++){const q=p(x+.26+j*.09,y-.35+(j%3)*.08,3);line(c,q[0],q[1],q[0]-(hi?4:10),q[1]-2,'#667e65',1.4);}return true;}
 if(e.id==='egg-release'||e.id==='egg-catch'||e.id==='float-pin-dark'){shell(c,p,x+.47,y-.27,hi?9:3,e.id==='egg-release'?'#bf7f66':'#b9b8a1',e.id!=='egg-catch'||!!s.flags['float-paired']);return true;}
 if(e.id==='bleach-turn'){spool(c,p,x+.45,y-.33,2,'#c3b69a');return true;}
 return false;
}
export function northernPlaces(c,p,m,s,t,ordered){
 const add=(x,y,fn)=>ordered.push([x+y+.33,fn]);headwaterPlaces(c,p,m,s,t,add);windPlaces(c,p,m,s,t,add);
}
