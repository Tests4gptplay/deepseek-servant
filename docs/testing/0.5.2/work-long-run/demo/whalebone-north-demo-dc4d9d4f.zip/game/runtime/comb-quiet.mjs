import {stats} from './party.mjs';
export function quietComb({world,s,flags,ex,show,note,part,fight,readings}){
  if(part==='crown'){
    if(flags['comb-safe'])return show('里桩水面透出了天光','仅有的两张小帆绕着回水口转圈。米拉把这段静水标成可用的避浪处。');
    if(flags['comb-driven'])return show('换向的帆冠',flags['comb-brood-safe']?'整冠已向外湾，桩内的幼珠仍连着两小串。':'外湾的暗弧在慢慢远去，近岸没有幼珠。');
    return show('背流面为何堵住了', '数十顶帘梳挤在里桩，琥珀腹珠时隐时现。桩边有上岸绳，未下水的人都可以从高处绕开。',[
      ['沿原岸绕开整冠',()=>note('comb-bypassed','退回桩岸','四个人让过这一阵潮，帘冠还在原处。照常沿海路旅行即可。')],
      ['观察静水窄缝',()=>show('里桩往南两步','完整倒影指向静水窄缝。先在窄缝听声，再到旧回水口松索。')],
      ['四人同入背流',()=>fight('comb-crown')] ]);
  }
  if(part==='quiet'){
    if(flags['comb-driven'])return show('鲸皮绳上的重力','里桩空了。重装垫肩留着刚才的受力痕，可以交给原装备页上的同伴。');
    if(flags['comb-safe'])return show('无风的窄缝','里桩的幼珠已游出。两重倒影正把一条深水小路留下。');
    if(readings<2)return show('水面有两层声音','一层拍桩，一层贴着桩根绕。白崖潮脚的泡线和旧环、着铅湾的虾笼与帆影都能帮人分开它们。');
    return show('桩后哪一刻能松索？','水尖连白时桩身会抖，幼珠贴住下游的阴影；泡线断开时铁环才垂。',[
      ['等白线断开，朝背流放松',()=>note('comb-open','给幼串留了一个口','回水口传来三声空响。到那根旧里桩托高湿索，幼串才能完整穿过去。')],
      ['趁白线连起收紧',()=>note('comb-mistimed','湿索又绷了回去','细珠贴上桩背，绳端尚在手中。放松等下一次断浪，仍可以再来。')] ]);
  }
  if(part!=='return')return;
  if(flags['comb-safe']){
    if(flags['comb-anchorage'])return show('新标的避风处','背流里有一片不湿的平岩。行李卸下来，潮声也不再盖过人声。',[
      ['在背风平岩扎营',()=>{
        for(const id of ex.roster){const h=ex.heroes[id],max=stats(world,id,h.level);h.hp=max.hp;h.mp=max.mp;}
        note('comb-camped','天亮再出湾','热汤分完，四个人的体力和气力已恢复。里桩上的细珠仍顺流去。');
      }] ]);
    return show('静水下面还藏着什么','放幼珠的回涡内侧不再起浪。用影尺量一次，可以留下真正能避风的停泊标。',[
      ['以回汐影尺落下避风标',()=>note('comb-anchorage','图上多出一条短深线','这里的潮声不盖过说话。下次进湾，即使没有风帆也能认出停泊点。')] ]);
  }
  if(flags['comb-driven'])return show('回水口的后果',flags['comb-brood-safe']?'两串活珠挤在旧绳下，待下次静潮出湾。':'空绳打在里桩上。母冠已从外湾带走余下的幼串。');
  if(!flags['comb-open'])return show('桩根的绳埋在水下','绳没松，硬拔只会让帘冠翻过来。先沿完整倒影去静水窄缝等一次断浪。');
  show('最后一段湿索','回水口旁一线银珠等着。托高湿索，还是用桩把它们截住？',[
    ['托高湿索让幼串游过',()=>{ex.stock['comb-glass']=(ex.stock['comb-glass']||0)+1;note('comb-safe','整冠自行离了桩','先是幼珠，然后是阴影里的成体。瑟琳从松索取下一段透明旧浮尺：回汐影尺可以佩戴，也可以回到此处量出避风停泊标。');}],
    ['再等一阵',()=>show('还来得及','米拉先把桩上的湿结接住，四人随时可以回来。')] ]);
}
