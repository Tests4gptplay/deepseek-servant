import {poly,line,oval,rand} from './paint.mjs';
const stone=['#bdbaa2','#c5c1aa','#b3b6a1','#c9c3a9','#bcb89f'];
const timber=['#b48661','#ad7e58','#c5996c','#bd936c'];
export function material(map,x,y){
  let kind=String(map.ground||'stone');
  for(const f of map.features||[])if(x>=f.x&&y>=f.y&&x<f.x+(f.w||1)&&y<f.y+(f.h||1)){
    const k=f.kind+' '+(f.label||'');
    if(/water|sea|basin|pool|水面|海面/i.test(k)||f.kind==='boat'&&!/滑床|船台|维修台/.test(f.label||''))kind='water';
    else if(/board|plank|wood|pier|dock|jetty|bridge|walkway|stack|栈|木桥|甲板/i.test(k))kind='wood';
    else if(/lane|road|street|paving|step|path|路面|坡道/i.test(k))kind='stone';
    else if(/grass|garden|meadow|庭院|草地/i.test(k))kind='grass';
  }
  if(kind==='stone'&&map.act>=4&&!map.biome.includes('interior')&&map.id!=='winter-court'&&map.id!=='flood-stair')return map.act===5?'snow':'shale';
  return /water|sea|ocean|水域/i.test(kind)?'water':/wood|dock|pier|plank|board|栈|木板/i.test(kind)?'wood':/grass|moss|草/i.test(kind)?'grass':'stone';
}
export function tile(c,p,x,y,kind,tide,t,edge){
  const point=(dx,dy,z=0)=>p(x+dx,y+dy,z);
  const corners=[point(0,0),point(1,0),point(1,1),point(0,1)];
  const n=rand(x,y), tone=(arr,index)=>arr[Math.floor(index*arr.length)];
  if(edge&&kind!=='water'){
    for(const side of edge){const [a,b]=side===0?[corners[1],corners[2]]:[corners[2],corners[3]];
      const depth=tide==='high'?8:17;poly(c,[a,b,[b[0],b[1]+depth],[a[0],a[1]+depth]],side===0?'#566d67':'#758478');line(c,a[0],a[1]+depth-1,b[0],b[1]+depth-1,'#9fae96');}
  }
  if(kind==='water'){const wet=tide==='high'?'#589099':'#74a49d';poly(c,corners,wet,wet);if(n>.65){const [a,b]=point(.14+rand(x+1,y)*.53,.28+rand(x,y+4)*.44);line(c,a,b+Math.sin(t*.7+x)*.65,a+4+n*6,b,'#bfd0b8',.85);}return;}
  if(kind==='shale'||kind==='snow'){
    const snow=kind==='snow';
    const swell=.45+.20*Math.sin(x*.19+y*.22)+.14*Math.cos(y*.36-x*.11)+.08*Math.sin(x*.54-y*.42);
    const rgb=snow?[180+swell*19,194+swell*15,185+swell*16]:[146+swell*18,155+swell*13,142+swell*12];const land='rgb('+rgb.map(Math.round).join(',')+')';poly(c,corners,land,land);const [a,b]=point(.2,.58);
    if(n>.65)line(c,a,b,a+6+n*6,b-1.4,snow?'#d6dbcc':'#838e80',.9);
    if(n>.48){const [v,j]=point(.65,.32);line(c,v,j,v+3,j-1,snow?'#8eaaa7':'#707e77',1.4);}return;
  }
  const color=kind==='wood'?tone(timber,n):kind==='grass'?tone(['#8b9d78','#91a481','#99a884'],n):tone(stone,n);
  poly(c,corners,color,color);
  if(kind==='wood'){
    for(let k=0;k<4;k++){const y=k/4;line(c,...point(0,y),...point(1,y),'#785e4a',.9);line(c,...point(.1,y+.12),...point(.65,y+.12),'#d2a67d',.65);}
    for(const a of [.1,.93]){const pos=point(a,.20);oval(c,...pos,1,.7,'#715e4b');}
  }else if(kind==='stone'){
    line(c,...corners[1],...corners[2],'#a7aa94',.7);line(c,...point(0,.5),...point(1,.5),'#9ea48d',.75);
    line(c,...point(.32,0),...point(.32,.5),'#adb09a',.7);
    line(c,...point(.74,.5),...point(.74,1),'#a4aa92',.8);line(c,...point(.06,.54),...point(.49,.54),'#d4d1b8',.7);
  }else for(let k=0;k<3;k++){const [a,b]=point(rand(x+k,y+6),rand(y+k,2*x));line(c,a,b,a+1,b-3,'#778b68',.7);}
}
