import {poly,line,oval} from './heelturn-cabins.mjs';
import {mudClapper} from './keelpot-clapper.mjs';
const cord='#b7a473',post='#6a5743',light='#d1c39b',iron='#545d58';
function board(c,q,x,y,w,h,z,top){
 const a=q(x,y,z),b=q(x+w,y,z),v=q(x+w,y+h,z),d=q(x,y+h,z);
 poly(c,[a,b,v,d],top,post);poly(c,[d,v,q(x+w,y+h,z-4),q(x,y+h,z-4)],'#897458',post);
}
function fish(c,[x,y],size,turned=false){
 c.save();c.translate(x,y);c.scale(turned?-size:size,size);
 poly(c,[[-4,0],[-6,-3],[-6,2],[-3,1],[-1,3],[4,2],[6,0],[4,-2],[0,-2]],'#a7b5a6','#586c68');
 line(c,[[-3,0],[1,1],[4,0]],'#d8d2b4',1);oval(c,[3.7,-.4],.65,.55,'#343f43');c.restore();
}
function basket(c,[x,y],r){
 oval(c,[x,y+1],r,r*.4,'#7d7555');oval(c,[x,y-r*.5],r,r*.5,'#b6a16d');
 for(let i=-2;i<=2;i++)line(c,[[x+i*r*.3,y-r*.58],[x+i*r*.22,y+.4]],'#887f57',1);
}
export function shopWork(c,q,f,map){
 const w=f.w,h=f.h;
 for(let y=.6;y<h;y+=.65)line(c,[q(.2,y,1),q(w-.4,y,1)],'#b8a783',1);
 const fishShop=map.id==='keelpot-yard'&&f.x===0;
 const netShop=map.id==='keelpot-yard'&&!fishShop;
 const shade=fishShop?'#ad735c':netShop?'#759183':'#869193';
 for(let i=0;i<8;i++){
  const x1=.15+(w-.32)*i/8,x2=.15+(w-.32)*(i+1)/8;
  poly(c,[q(x1,.05,43),q(x2,.05,43),q(x2,h*.32,37),q(x1,h*.32,37)],i%2===0?shade:'#d1bc91',post);
  poly(c,[q(x1,h*.32,37),q(x2,h*.32,37),q(x2,h*.32,33),q((x1+x2)/2,h*.32,31),q(x1,h*.32,33)],i%2===0?shade:'#c9b58f');
 }
 for(const xx of [.22,w-.26]){line(c,[q(xx,h*.34,0),q(xx,h*.34,38)],post,3);line(c,[q(xx,h*.34,37),q(xx,.10,44)],light,2);}
 if(fishShop){
  for(const z of [20,29])line(c,[q(.55,.32,z),q(w-.65,.32,z)],cord,1.6);
  for(let k=0;k<7;k++){const u=.85+k*(w-1.6)/7;
   line(c,[q(u,.35,29),q(u,.4,21)],post,1);fish(c,q(u,.45,18),.7+k%3*.16,k%2===0);
  }
  board(c,q,1.15,h*.58,w*.53,.70,12,'#a98c67');
  for(let k=0;k<5;k++)fish(c,q(1.4+k*.60,h*.65,13),.90,k%2===0);
  for(let k=0;k<3;k++)basket(c,q(w*.76,h*(.46+.12*k),4),6+k);
 }else if(netShop){
  for(let k=0;k<3;k++){const [x,y]=q(w*.5+k*.32,h*.37,12);
   for(let d=0;d<3;d++)oval(c,[x,y-k-d],8-k,2.8, k===1?'#7a906c':'#b39c69');
  }
  board(c,q,.5,h*.55,w*.68,.66,10,'#aa9975');
  for(let j=0;j<6;j++){const u=.6+j*w*.09;line(c,[q(u,h*.57,13),q(u+.2,h*.83,1)],j%2?cord:'#768b75',1.7);}
 }else{
  board(c,q,.6,h*.46,w*.57,.64,10,'#a39474');
  for(let i=0;i<3;i++)basket(c,q(w*.35+i*.64,h*.62,6),6);
 }
}
export function visibleLoad(c,x,y,s){
 const k=s.progress?.keelpotFreight?.shoulder;if(!k||!s.map.startsWith('keelpot-'))return;
 const left=s.facing?.[0]<0?-1:1; c.save();c.translate(x,y);c.scale(left,1);
 line(c,[[-12,-18],[-3,-19],[13,-15]],'#e1c37f',2.5);
 line(c,[[10,-15],[8,-6],[13,-4],[15,-13]],'#4b5b51',1.4);
 if(k==='blue'||k==='rust'){
  oval(c,[11,-3],5.1,5.3,k==='blue'?'#a98e69':'#b38562');oval(c,[11,-7],4.1,1.8,k==='blue'?'#556e89':'#a7614c');
 }else{
  poly(c,[[4,-6],[11,-9],[20,-6],[14,-3]],'#989966',iron);for(let i=0;i<4;i++)oval(c,[8+i*2.4,-6+i%2],1.8,1.05,'#dad9b4');
 }
 c.restore();
}
export function dockDetail(c,x,y,t,e,s){
 if(e.id==='keelpot-stand'){
  if(s.flags['keelpot-cleared']){for(let i=0;i<3;i++)oval(c,[x-5+i*3,y-1-Math.sin(t*2+i)],1.4,1,'#b6ccc1');}
  else{c.save();c.translate(x,y);c.scale(.8,.8);mudClapper(c,0,0,t,'idle');c.restore();}return true;
 }
 if(e.id==='keelpot-brine-tub'){
  oval(c,[x,y],9,3.1,'#6f6854');oval(c,[x,y-4.5],8.9,3.8,'#b59b73');oval(c,[x,y-5],7.0,2.4,'#71918b');
  line(c,[[x-6,y-3],[x+6,y-3]],'#d8c18e',1.2);return true;
 }
 return false;
}
