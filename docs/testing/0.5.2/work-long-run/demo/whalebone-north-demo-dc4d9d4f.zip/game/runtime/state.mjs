import {hearthStep,visitBayDoor,residentPresent} from './lullaby-partners.mjs';
import {bayFootfall} from './driftbay-footfall.mjs';
import {afterStageStep,takeBothHome} from './second-shadow/where-the-ropeman-stands.mjs';
import {loadChart,notePassage} from './field-atlas/passages.mjs';
import {syncParty} from './party.mjs';
export const SAVE_KEY='whalebone.north.save.v1';
const record=o=>o!==null && typeof o==='object' && !Array.isArray(o);
export function walkable(map,x,y){
  return Number.isInteger(x)&&Number.isInteger(y)&&x>=0&&y>=0&&x<map.width&&y<map.height&&
    !(map.solids||[]).some(([a,b,w,h])=>x>=a&&y>=b&&x<a+w&&y<b+h);
}
export function fresh(world){
  if(world?.version!==1||!world.maps?.[world.start?.map]||!walkable(world.maps[world.start.map],world.start.x,world.start.y)) throw Error('内容入口或初始落点无效');
  const state={version:1,...world.start,flags:{},inventory:{},progress:{},tide:'low',facing:[0,1],victories:0};
  syncParty(world,state);return state;
}
export function decode(world,raw){
  const v=JSON.parse(raw);
  if(v?.version!==1)throw Error('此存档版本尚不兼容');
  if(!world.maps[v.map]||!walkable(world.maps[v.map],v.x,v.y))throw Error('存档落点不可用');
  for(const k of ['flags','inventory'])if(!record(v[k]))throw Error('存档缺少 '+k);
  if(v.tide!==undefined&&!['low','high'].includes(v.tide))throw Error('存档潮位不受支持');
  if(Object.values(v.inventory).some(n=>!Number.isSafeInteger(n)||n<0))throw Error('存档物件计数无效');
  if(v.victories!==undefined&&(!Number.isSafeInteger(v.victories)||v.victories<0))throw Error('存档战斗计数无效');
  const state={...fresh(world),...v,progress:record(v.progress)?v.progress:{},facing:(v.map==='keel-in-shadow'||v.map==='hulls-not-in-line')&&Array.isArray(v.facing)&&v.facing.length===2&&v.facing.every(Number.isInteger)&&Math.abs(v.facing[0])+Math.abs(v.facing[1])===1?[...v.facing]:[0,1]};
  if(Object.hasOwn(v,'fieldChart'))state.fieldChart=loadChart(world,state,v.fieldChart);
  if(!v.expedition){
    for(const id of Object.keys(world.encounters||{}))if(state.flags[id])state.flags['reward:'+id]=true;
  }
  syncParty(world,state);return state;
}
export function allows(s,requires){
  const tags=Array.isArray(requires)?requires:requires?[requires]:[];
  return tags.every(key=>typeof key==='string' && (key.startsWith('!')?!marked(s,key.slice(1)):marked(s,key)));
}
export function marked(s,key){return key===('tide:'+s.tide)||Boolean(s.flags[key]);}
export function setFlags(s,keys){
  if(typeof keys==='string')s.flags[keys]=true;
  else if(Array.isArray(keys))keys.forEach(key=>setFlags(s,key));
  else if(record(keys))for(const [key,value] of Object.entries(keys))s.flags[key]=value;
}
export function step(world,s,dx,dy){
  if(Math.abs(dx)+Math.abs(dy)!==1)return false;
  s.facing=[dx,dy];
  if(!walkable(world.maps[s.map],s.x+dx,s.y+dy))return false;
  s.x+=dx;s.y+=dy;bayFootfall(world.maps[s.map],s);hearthStep(world.maps[s.map],s);afterStageStep(s);return true;
}
export function targets(world,s){
  const map=world.maps[s.map];
  const rank=t=>{
    const dx=t.x-s.x,dy=t.y-s.y,d=Math.abs(dx)+Math.abs(dy);
    if(d>1)return 10;
    if(d===0)return 0;
    return dx===s.facing[0]&&dy===s.facing[1]?1:2;
  };
  const list=[...(map.entities||[]).filter(e=>residentPresent(s,e)).map(value=>({kind:'entity',value})),...(map.exits||[]).map(value=>({kind:'exit',value}))];
  return list.filter(t=>rank(t.value)<10).sort((a,b)=>rank(a.value)-rank(b.value));
}
export function enter(world,s,exit){
  const dest=world.maps[exit.to];
  if(!dest||!Array.isArray(exit.at)||!walkable(dest,...exit.at)||!allows(s,exit.requires))return false;
  notePassage(world,s,s.map,exit);
  takeBothHome(s);const from=s.map;[s.x,s.y]=exit.at;s.map=exit.to;visitBayDoor(s,from);return true;
}
export function takeAction(s,entity){
  const a=entity.action;
  if(!a)return;
  if(a.type==='tide'){
    s.tide=['high','low'].includes(a.value)?a.value:(s.tide==='high'?'low':'high');
    if(a.id)s.flags[a.id]=true;
  }else if(a.type==='flag'&&a.id)s.flags[a.id]=a.value??true;
  else if(a.type==='item'&&a.id){
    const once='collected:'+entity.id;
    if(!s.flags[once]){s.inventory[a.id]=(Number(s.inventory[a.id])||0)+(Number(a.value)||1);s.flags[once]=true;}
  }
  setFlags(s,a.set);
}
