import {face,rod,beam,box,plate,lamp,ring,poly,oval,oak,tar,brass} from './fixtures.mjs';
import {wheel} from '../voyage-shapes.mjs';
function sluice(c,p,x,y,open,t){
 const w=2.37,up=open?17:1;for(const xx of [x,x+w]){box(c,p,xx-.09,y-.12,.21,.38,0,28,tar);ring(c,p(xx,y+.18,25),3.4,'#c2ae79',.92);}
 beam(c,p,[x-.12,y,28],[x+w+.13,y,28],5);
 face(c,p,[[x+.12,y,up],[x+w-.11,y,up],[x+w-.11,y,up+16],[x+.12,y,up+16]],open?'#83948c':'#677d76','#425956');
 for(let i=0;i<5;i++)rod(c,p,[x+.2+i*.44,y+.03,up+1],[x+.2+i*.44,y+.03,up+15],'#a59c79',1.45);
 const z=up+4;rod(c,p,[x+.1,y+.08,z],[x+w-.1,y+.08,z+7],'#a6a389',2);
 if(open)for(let i=0;i<7;i++){const xx=x+.3+i*.28,yy=y+.14+(i%3)*.12;rod(c,p,[xx,yy,1],[xx-.06,yy+.72+.08*Math.sin(t+i),0],i%2?'#c6d5bd':'#95b6ab',1.9);}
}
export function lockThings(c,p,f,s,t){
 const safe=!!s.flags['gate-safe'];
 if(f.kind==='water'){const outer=f.x===5,x=f.x+.2,y=f.y+.2;
  plate(c,p,x,y,f.w-.4,f.h-.4,1,outer?'#587e7c':'#648580','#547069');for(const yy of [y,y+f.h-.42])beam(c,p,[x,yy,2],[x+f.w-.38,yy,2],3);
  for(let j=0;j<12;j++){const xx=x+.3+(j%3)*.87,yy=y+.67+j*.32;rod(c,p,[xx,yy,2],[xx+.43,yy,2],outer&&safe?'#bfd3baba':'#93aaa080',1.2);}
  sluice(c,p,x+.55,y+f.h-1.26,outer?safe:false,t);return true;}
 if(f.kind==='crane'){box(c,p,11.85,5.66,2.45,.75,0,10,tar);for(let i=0;i<5;i++){const x=12.02+i*.41,h=[19,25,34,29,20][i];box(c,p,x,5.88,.18,.22,8,h,brass);const q=p(x+.08,5.96,h+8);oval(c,...q,3.4,1.6,'#3c5153');}beam(c,p,[12.15,6.1,12],[15.15,9.37,safe?7:15],3.3);return true;}return false;
}
function shutters(c,p,x,y,on){
 const w=1.18;box(c,p,x,y,w+.13,.24,1,24,tar);
 face(c,p,[[x+.08,y+.26,4],[x+w,y+.26,4],[x+w,y+.26,22],[x+.08,y+.26,22]],on?'#f3d692':'#3f5556');
 for(let i=0;i<4;i++){const z=4+i*4.5;face(c,p,[[x,y+.29,z],[x+w,y+.29,z],[x+w,y+.23,z+(on?2:4.1)],[x,y+.23,z+(on?2:4.1)]],on?'#a69874':'#7b8b80','#536763');}
 beam(c,p,[x-.08,y+.25,24],[x+w+.12,y+.25,24],3.8);
}
export function blinds(c,p,s,t){
 const lit=!!s.flags['light-replay'],x=10.28,y=7.43;
 box(c,p,x-.22,y-.19,3.05,.77,0,4,oak);
 shutters(c,p,x,y,lit);shutters(c,p,x+1.63,y,false);lamp(c,p,x+1.33,y-.05,25,t,true,.77);
 for(const k of [0,1.14])rod(c,p,[x+1.72+k*.75,y+.32,5],[x+2.23+k*.32,y+.32,22],'#685e4e',2.4);
 if(lit){
  const a=p(x+.12,y+.35,14),b=p(x+1.07,y+.35,14);
  poly(c,[a,b,[b[0]-44,b[1]+36],[a[0]-65,a[1]+42]],'#e6d9a740');
  rod(c,p,[x+.12,y+.35,14],[x+1.07,y+.35,14],'#fff1bd',3.9);
  rod(c,p,[x+.17,y+.36,13.5],[x+.98,y+.36,13.5],'#fff8da',1.5);
  for(let j=0;j<3;j++)rod(c,p,[x+.1+j*.28,y+1.03,1],[x+.22+j*.32,y+1.53,1],'#dec88c',1.5);
 }
}
export function lockMark(c,p,e,s,t){
 if(e.id==='organ-crossbar'){const q=p(14.93,10.17,12);box(c,p,14.57,10.09,.56,.36,0,10,oak);wheel(c,...q,8,s.flags['gate-safe']?1.5:0,9);return true;}
 if(e.id==='blind-louvers'){const x=e.x+.18,y=e.y+.59;box(c,p,x,y,.66,.42,0,8,oak);rod(c,p,[x+.28,y+.23,8],[x+.50,y+.25,s.flags['light-replay']?11:20],'#c4ad75',2.8);return true;}return false;
}