import {line,oval,poly} from '../paint.mjs';
import {box,plate} from '../voyage-shapes.mjs';

const walnut=['#af8f65','#876b50','#655445'];
const brush=(c,p,a,b,color,w=1)=>line(c,...p(...a),...p(...b),color,w);
function casement(c,p,x,y,width,wet){
 const q=(u,z)=>p(x+u,y,z);
 poly(c,[q(0,1),q(width,1),q(width,45),q(0,45)],wet?'#92a299':'#b7aa94','#796e61');
 for(let k=0;k<width;k+=.38)brush(c,p,[x+k,y+.01,0],[x+k,y+.01,44],wet?'#82988c':'#aa9b82',.9);
 for(let i=.36;i<width-.83;i+=1.56){
   poly(c,[q(i,14),q(i+1.14,14),q(i+1.14,35),q(i,35)],wet?'#789a97':'#7b9d9d','#766f60');
   brush(c,p,[x+i+.56,y+.04,14],[x+i+.56,y+.04,36],'#dac8a5',1.8);
   brush(c,p,[x+i,y+.04,25],[x+i+1.13,y+.04,25],'#c9b99c',1.2);
   box(c,p,x+i-.09,y-.03,1.33,.27,13,2.4,walnut);
 }
 brush(c,p,[x-.05,y+.02,44],[x+width+.05,y+.02,44],'#796b59',3);
}
function thread(c,p,x,y,z,hue){
 const [a,b]=p(x,y,z);oval(c,a,b,4.6,2.1,'#786d58');
 c.fillStyle=hue;c.fillRect(a-3.6,b-5.1,7.2,5.1);oval(c,a,b-5.3,4.5,1.8,'#c4a97c');
 line(c,a-2.9,b-3.3,a+3,b-2.7,'#d7c6a0',.8);
}
function cuttingTable(c,p,x,y){
 for(const [u,v] of [[.12,.12],[2.5,.12],[.12,1.0],[2.5,1.0]])box(c,p,x+u,y+v,.11,.14,0,16,walnut);
 box(c,p,x,y,2.74,1.17,15,3.2,walnut);
 const a=(u,v)=>p(x+u,y+v,18.4);
 poly(c,[a(.12,.10),a(1.33,.07),a(1.55,.40),a(1.74,.65),a(1.22,.90),a(.36,.92)],'#ab786e','#8d685d');
 for(let k=0;k<5;k++)brush(c,p,[x+.39+k*.15,y+.35,18.8],[x+.47+k*.15,y+.37,18.8],'#e4cead',1);
 thread(c,p,x+2.15,y+.18,19,'#628b8f');thread(c,p,x+2.36,y+.36,19,'#a8665b');
 const [sx,sy]=a(1.83,.7);
 for(const v of [-2,2]){c.beginPath();c.ellipse(sx-2,sy+v,2.2,1.7,0,0,Math.PI*2);c.strokeStyle='#766954';c.lineWidth=1.4;c.stroke();}
 line(c,sx,sy-1,sx+8,sy+3,'#686f67',1.4);line(c,sx,sy+1,sx+7,sy-3,'#656c62',1.4);
}
function stand(c,p,x,y,garments){
 const A=p(x,y,36),B=p(x+4.4,y+.18,32);
 brush(c,p,[x,y,0],[x,y,38],'#7d6a54',2.6);brush(c,p,[x+4.4,y+.18,0],[x+4.4,y+.18,34],'#7d6a54',2.6);
 c.beginPath();c.moveTo(...A);c.quadraticCurveTo((A[0]+B[0])/2,(A[1]+B[1])/2+6,...B);c.strokeStyle='#8b806a';c.lineWidth=1.4;c.stroke();
 for(const [k,col] of garments.entries()){
  const f=(k+.55)/(garments.length+.4),cx=A[0]+(B[0]-A[0])*f,cy=A[1]+(B[1]-A[1])*f+4*Math.sin(Math.PI*f);
  poly(c,[[cx-5,cy],[cx+5,cy+.4],[cx+8,cy+9],[cx+5,cy+11],[cx+4,cy+22-k],[cx-5,cy+20-k],[cx-4,cy+11],[cx-8,cy+7]],col,'#786e60');
  line(c,cx-1,cy+3,cx-2,cy+17-k,'#c2b59b',.9);
 }
}
function runner(c,p,x,y,w,h,color){
 plate(c,p,x,y,w,h,.4,color);
 for(const v of [.14,h-.18])brush(c,p,[x+.06,y+v,.7],[x+w-.05,y+v,.7],'#c0ad83',1.8);
 for(let n=.08;n<w;n+=.24){brush(c,p,[x+n,y,.6],[x+n+.02,y-.12,.6],'#aa9a7f',.9);brush(c,p,[x+n,y+h,.6],[x+n+.02,y+h+.11,.6],'#aa9a7f',.9);}
}
export function clothingHouseObject(c,p,map,f){
 if(map.id!=='under-the-doorknock')return false;
 if(f.kind==='building'||f.kind==='wall'){casement(c,p,f.x,f.y+f.h-.14,f.w,f.kind==='wall');return true;}
 if(f.kind==='crate'||f.kind==='path'||f.kind==='sign')return true;
 return false;
}
export function clothingHouseFloor(c,p,map,state,list){
 if(map.id!=='under-the-doorknock')return;
 runner(c,p,6.6,11.7,5.35,1.14,'#758981');runner(c,p,18.3,12.2,4.82,1.35,'#987e72');
 runner(c,p,23.5,15.4,3.75,1.2,'#819796');
 list.push([13+8.6,()=>stand(c,p,12.4,8.4,['#879c91','#b78d79','#738a94'])]);
 list.push([28+10.05,()=>stand(c,p,25.4,9.8,['#ae625f','#b8aa80','#748b9b','#cab591'])]);
 list.push([27+16,()=>cuttingTable(c,p,24.6,16.8)]);
 list.push([12+9.5,()=>cuttingTable(c,p,12.0,9.4)]);
}
