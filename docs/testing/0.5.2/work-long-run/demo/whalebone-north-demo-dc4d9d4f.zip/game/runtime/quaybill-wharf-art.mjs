import {poly,line,oval} from './heelturn-cabins.mjs';

const ink='#394e51',edge='#675244',paper='#dfcc9d',amber='#b9874f',blue='#526e82';
function sheet(c,q,w,h,s){
 const x=w-.4,y=h-.25,peg='#6f5142';
 poly(c,[q(.15,.1,8),q(x,.1,8),q(x,y,8),q(.15,y,8)],'#957756',edge);
 for(const [u,v] of [[.25,.3],[x-.13,.3],[.25,y-.2],[x-.13,y-.2]])line(c,[q(u,v),q(u,v,30)],peg,3);
 for(let i=0;i<4;i++){
  const a=.35+i*(w-.6)/4,b=a+(w-.9)/4;
  poly(c,[q(a,.42,25),q(b,.42,25),q(b,y-.20,12+i%2*3),q(a,y-.13,13)],i===2?'#bfab83':paper,edge);
  line(c,[q(a+.06,.55,24),q(a+.07,y-.27,16)],i%2?blue:amber,1.2);
  for(let j=1;j<5;j++){const v=.4+j*(h-.9)/5;line(c,[q(a+.12,v,23-j*1.4),q(b-.13,v+.02,23-j*1.4)],ink,.8);}
 }
 if(s.flags['quaybill-rumor']){const [x,y]=q(w*.52,h*.55,23);oval(c,[x,y],3,2,'#9d4637');}
}
function hull(c,q,w,h,s){
 const z=10,settled=s.flags['quaybill-sailed'];
 const a=q(.3,h*.6,z),b=q(w*.18,.3,z),d=q(w*.88,.45,z),e=q(w-.15,h*.5,z),f=q(w*.78,h*.90,z),g=q(w*.2,h*.92,z);
 poly(c,[a,b,d,e,f,g],'#715749',edge);
 poly(c,[b,d,e,[e[0],e[1]+8],[d[0],d[1]+10],[b[0],b[1]+8]],'#8f7153',edge);
 poly(c,[a,b,d,e,f,g],'#b39871',edge);
 for(let i=0;i<4;i++){
  const u=w*(.22+.15*i);line(c,[q(u,h*.28,z+1),q(u+.08,h*.76,z+1)],'#8d755e',1.7);
  const v=q(u,h*.78,z+4);oval(c,v,3.2,2,'#ccb379',ink);line(c,[[v[0]+1,v[1]],q(u+.2,h*.86,z+2)],'#735544',1);
 }
 for(const u of [w*.3,w*.7]){const at=q(u,h*1.04);line(c,[at,q(u,h*1.04,19)],edge,4);line(c,[q(u-.11,h*1.05,11),q(u+.12,h*1.05,11)],blue,3);}
 const load=s.progress?.quaybill?.load;
 if(load&&!settled){for(let i=0;i<load.bags;i++)oval(c,q(w*(.42+i*.2),h*.52,18),7,5,amber,edge);if(load.people)poly(c,[q(w*.32,h*.35,20),q(w*.61,h*.35,20),q(w*.58,h*.73,20),q(w*.30,h*.7,20)],'#a6a9a0',blue);}
}
function stove(c,q,w,h,t){
 for(let n=0;n<2;n++){
  const u=.3+n*w*.43,v=.45;const top=q(u+w*.16,v+h*.41,20);
  poly(c,[q(u,v),q(u+.32*w,v),q(u+.32*w,v+h*.7),q(u,v+h*.7)],'#ad8967',edge);
  line(c,[q(u+.14*w,v+h*.7),q(u+.14*w,v+h*.7,15)],'#765a49',3);
  oval(c,top,11,6,'#b3a081',edge);oval(c,[top[0],top[1]-1],7,3,'#887d5d');
  for(let j=0;j<3;j++){const a=t*.9+j;line(c,[[top[0]-5+j*4,top[1]-4],[top[0]-3+j*4+Math.sin(a)*2,top[1]-10],[top[0]-6+j*4,top[1]-16-j]],'#eee2c8',1.2);}
 }
}
export function quaybillFeature(c,p,m,f,s,t){
 if(!m.id.startsWith('quaybill-')||!f.kind.startsWith('qb-'))return false;
 const q=(x,y,z=0)=>p(f.x+x,f.y+y,z),w=f.w,h=f.h;
 if(f.kind==='qb-paper'||f.kind==='qb-slip')sheet(c,q,w,h,s);
 else if(f.kind==='qb-hull')hull(c,q,w,h,s);
 else if(f.kind==='qb-oven')stove(c,q,w,h,t);
 else for(let i=0;i<6;i++){const u=.2+i*(w-.6)/6;line(c,[q(u,.3,2),q(u+.18,h*.52,4),q(u+.1,h-.15,2)],i<4?blue:amber,2);oval(c,q(u+.06,h*.44,4),1.7,1.2,paper);}
 return true;
}
