import {line,poly,oval} from './paint.mjs';
const apron=['#bd7256','#ddc5a2','#476b72','#cc9f55','#786675'];
function pan(c,x,y,t,full){
 oval(c,x+1,y+8,29,9,'#3a352c4d');
 for(const dx of [-17,15])line(c,x+dx,y+1,x+dx-2,y+9,'#59413a',4);
 poly(c,[[x-24,y-11],[x+23,y-11],[x+20,y+4],[x-21,y+4]],'#854c39','#4a3832');
 oval(c,x-1,y+1,10,5,'#352b2a');
 for(let i=0;i<3;i++){const a=x-6+i*4,k=3*Math.sin(t*4+i);poly(c,[[a-3,y+2],[a+1,y-6-k],[a+4,y+2]],i===1?'#ffd185':'#d87545');}
 line(c,x+18,y-13,x+35,y-19,'#3e3b32',3);oval(c,x,y-14,26,8,'#383c37');oval(c,x-1,y-15,23,5,'#75623e');
 for(let i=0;i<(full?4:2);i++){const a=x-13+(i%3)*10,b=y-15+Math.floor(i/3)*3;oval(c,a,b,6.7,2.6,i===0?'#985d39':'#d6a35e');line(c,a-3,b,a+1,b+1,'#87563d');}
 for(let i=0;i<3;i++){const a=x-11+i*10,k=Math.sin(t*1.6+i)*4;c.strokeStyle='#f1e6c18c';c.lineWidth=1.1;c.beginPath();c.moveTo(a,y-20);c.bezierCurveTo(a+4+k,y-28,a-9+k,y-31,a+k,y-42-i*3);c.stroke();}
}
export function hearthFeature(c,p,m,f,s,t){
 if(!f.kind?.startsWith('lull-'))return false;
 const [a,b]=p(f.x+.5,f.y+.5),[u,v]=p(f.x+f.w-.32,f.y+.6);
 if(f.kind==='lull-fryer'){pan(c,a,b,t,!s.flags['lullaby-accompany']);for(let i=0;i<4;i++)oval(c,a+32,b-17-i*2,8,2.5,i%2?'#d4b586':'#a28770');}
 if(f.kind==='lull-cloths'){line(c,a,b,a,b-44,'#765b47',3);line(c,u,v,u,v-44,'#765b47',3);line(c,a,b-43,u,v-43,'#594b39',1.6);
  for(let i=0;i<5;i++){const k=(i+.2)/5,x=a+(u-a)*k,y=b+(v-b)*k-42,w=Math.max(12,(u-a)/6.5),h=15+i%3*4,d=t?2.8*Math.sin(t*1.7+i):0;
   poly(c,[[x,y],[x+w,y+2],[x+w+d,y+h-3],[x+w*.65+d,y+h],[x+d,y+h-3]],apron[i],'#574e43');
   line(c,x+w*.3,y+3,x+w*.26+d,y+h-4,'#ebd6a474');}}
 if(f.kind==='lull-banister'){for(let i=0;i<f.w;i++){const [x,y]=p(f.x+i+.28,f.y+.62),[u,v]=p(f.x+i+1.15,f.y+.62);line(c,x,y+1,x,y-19,'#66533e',3.5);line(c,x,y-17,u,v-17,'#63553e',3);line(c,x,y-12,u,v-12,'#c5a67b',1.5);}}
 return true;
}
