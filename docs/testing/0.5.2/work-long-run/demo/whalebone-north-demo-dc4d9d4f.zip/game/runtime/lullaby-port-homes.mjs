import {line,poly,oval} from './paint.mjs';
const tileColours=[['#865e4d','#9b7360'],['#5d757b','#75898a'],['#847365','#a19074'],['#6c706b','#838981']];
const face=(c,arr,fill,edge)=>poly(c,arr,fill,edge);
export function kitchenHomes(c,p,m,f,t){
 if(!m.id.startsWith('lullaby-')||f.kind!=='building')return false;
 const x=f.x,y=f.y,w=f.w,h=f.h,kind=(x*7+y+m.id.length)%4,[dark,mid]=tileColours[kind],high=28+kind*5;
 const a=(u,v,z)=>p(x+u,y+v,z),stroke=(u,v,z,j,k,l,col,width=1)=>{const [a1,b1]=a(u,v,z),[a2,b2]=a(j,k,l);line(c,a1,b1,a2,b2,col,width);};
 const front=(u,z,uw,zh,fill)=>face(c,[a(u,h,z),a(u+uw,h,z),a(u+uw,h,z+zh),a(u,h,z+zh)],fill);
 face(c,[a(0,h,0),a(w,h,0),a(w,h,high),a(0,h,high)],kind%2?'#caa982':'#c7ae8b','#625b4c');
 face(c,[a(w,0,0),a(w,h,0),a(w,h,high),a(w,0,high)],'#8e806a','#635e50');
 for(let z=4;z<high;z+=5)stroke(0,h,z,w,h,z,'#9a897193');
 for(let z=5;z<high;z+=6)stroke(w,0,z,w,h,z,'#796d5d8a');
 for(let u=.35;u<w;u+=1.15){stroke(u,h,0,u,h,high,'#77614e',2);if(u+.67>=w)continue;
  const isDoor=u<1.4;front(u+.12,isDoor?0:13,.70,isDoor?24:12,'#4d5148');front(u+.19,isDoor?1:14,.53,isDoor?20:9,isDoor?'#926e50':kind%2?'#edc482':'#a9c0b1');
  if(isDoor){for(let z=3;z<19;z+=4)stroke(u+.23,h,z,u+.66,h,z,'#685a48');stroke(u+.57,h,9,u+.62,h,9,'#e5be74',2);}
  else{stroke(u+.45,h,14,u+.45,h,23,'#715c49',1.8);stroke(u+.16,h,18,u+.71,h,18,'#745e49');stroke(u+.04,h,11,u+.87,h,11,'#796148',3);}}
 for(let v=.6;v<h-1;v+=1.5){const f1=[a(w,v,12),a(w,v+.65,12),a(w,v+.65,21),a(w,v,21)];face(c,f1,'#625c4d');stroke(w,v,16,w,v+.65,16,'#b6a27c');}
 const ridge=high+19+h*1.35,half=h/2;
 face(c,[a(-.24,-.22,high),a(w+.24,-.22,high),a(w+.25,half,ridge),a(-.25,half,ridge)],dark,'#5e594d');
 face(c,[a(-.25,half,ridge),a(w+.25,half,ridge),a(w+.3,h+.25,high),a(-.3,h+.25,high)],mid,'#5e594d');
 for(let k=1;k<6;k++){const v=half+(h+.25-half)*k/6,z=ridge+(high-ridge)*k/6;stroke(-.18,v,z,w+.2,v,z,'#b0a39277');}
 for(let i=0;i<w*2;i++){const u=i*.52;for(let k=0;k<4;k++){const start=(k+.2)/4,end=(k+.92)/4,v=half+(h-half)*start,z=ridge+(high-ridge)*start;stroke(u+(k%2)*.21,v,z,u+(k%2)*.21,half+(h-half)*end,ridge+(high-ridge)*end,'#716e645a');}}
 stroke(-.2,half,ridge,w+.33,half,ridge,'#c0ad8b',2.4);
 const [a0,b0]=a(w*.73,half-.1,ridge-1);c.fillStyle='#6d6558';c.fillRect(a0-3,b0-15,6,15);c.fillStyle='#b19475';c.fillRect(a0-5,b0-15,10,3);
 if(kind!==2)for(let i=0;i<3;i++){const k=t?Math.sin(t*.8+i)*2:0;oval(c,a0+i*4+k,b0-21-i*5,3+i*1.7,1.8+i*.7,'#ede6c839');}
 return true;
}
