import {poly,line,oval,arc} from '../paint.mjs';
import {bed,box,plate,tub} from '../voyage-shapes.mjs';
import {chair,table} from '../interior-furniture.mjs';
import {interiors} from './room-surfaces.mjs';

function wall(c,p,x,y,width,colors,window=true){
  const top=46;
  poly(c,[p(x,y),p(x+width,y),p(x+width,y,top),p(x,y,top)],colors.wall,colors.frame);
  for(let z=5;z<top;z+=8)line(c,...p(x,y,z),...p(x+width,y,z),colors.seam,.85);
  for(let d=.08;d<width;d+=1.45){
    line(c,...p(x+d,y,1),...p(x+d,y,top),colors.frame,3);
    line(c,...p(x+d+.03,y,1),...p(x+d+.03,y,top),colors.high,.8);
  }
  line(c,...p(x,y,top+1),...p(x+width,y,top+1),colors.frame,3.8);
  if(!window)return;
  for(let at=.8;at<width-1.3;at+=3.7){
    const a=x+at,w=1.2,h=23,z=13;
    poly(c,[p(a,y+.02,z),p(a+w,y+.02,z),p(a+w,y+.02,z+h),p(a,y+.02,z+h)],colors.window,colors.frame);
    const well=p(a+.36,y+.05,z+9);oval(c,...well,3.7,1.3,colors.high+'aa');
    line(c,...p(a+w*.53,y+.04,z),...p(a+w*.53,y+.04,z+h),colors.frame,2);
    line(c,...p(a-.08,y+.06,z),...p(a+w+.08,y+.06,z),colors.high,3.2);
    line(c,...p(a,y+.04,z+12),...p(a+w,y+.04,z+12),colors.frame,1);
  }
}
const walls={
  'mat-bed':{wall:'#a7987a',seam:'#8d8168',frame:'#706453',high:'#d9c99d',window:'#8ba6a0'},
  'felt-hour':{wall:'#9f927b',seam:'#897d6c',frame:'#6f6454',high:'#c8bc9b',window:'#9cae9d'},
  'sponge-sill':{wall:'#9a9986',seam:'#838576',frame:'#626e60',high:'#c6c7a8',window:'#83a09b'},
  'kettle-nook':{wall:'#b89875',seam:'#9e8066',frame:'#7c614c',high:'#dec398',window:'#a4ac92'},
  'oar-bunk':{wall:'#838b7d',seam:'#737e71',frame:'#5d6a60',high:'#bcb998',window:'#7e9e9d'}
};
function linen(c,p,x,y,dye,count=3){
  for(let i=0;i<count;i++){
    box(c,p,x+i*.07,y-i*.035,1.25,.72,4+i*2.5,2.5,[i%2?'#d2bc97':dye,'#9a8e79','#7a776b']);
    line(c,...p(x+.22+i*.07,y+.02,7+i*2.5),...p(x+.22+i*.07,y+.67,7+i*2.5),'#b19475',1);
  }
}
function basket(c,p,x,y){
  const [a,b]=p(x,y,5);oval(c,a,b+2,11,3.5,'#695946');oval(c,a,b-1,11,3.8,'#b99a69');
  arc(c,a,b-1,7.5,Math.PI,Math.PI*2,'#927756',1.7);
  for(let i=0;i<6;i++)line(c,a-8+i*3,b-2,a-6+i*2.3,b+2,'#ddc194',.9);
}
function cupboard(c,p,x,y,w,h,color){
  box(c,p,x,y,w,h,0,13,[color,'#8c7860','#695b4c']);
  for(let i=.35;i<w;i+=.75){
    line(c,...p(x+i,y+h,2),...p(x+i,y+h,12),'#78664f',1);const knob=p(x+i+.12,y+h+.01,8);oval(c,...knob,1.4,1,'#cfb48b');
  }
}
function oven(c,p,x,y){
  box(c,p,x,y,1.55,1,0,18,['#ad967e','#856e61','#695b52']);
  box(c,p,x+.17,y+.12,.38,.35,18,24,['#95826d','#806d5d','#60584e']);
  const [a,b]=p(x+1.0,y+.92,10);oval(c,a,b,8.4,5.1,'#4a423a');
  poly(c,[[a-4,b+2],[a-2,b-4],[a,b-1],[a+2,b-4],[a+3,b+2]],'#d89353');
  oval(c,...p(x+1.0,y+.44,19),8.5,3.1,'#4f5b55');
}
export function houseRoomFeature(c,p,map,f,state){
  const material=interiors[map.id];if(!material||f.id)return false;
  const {x,y,w=1,h=1,kind}=f;
  if(kind==='path')return true;
  if(kind==='rope'&&map.id==='oar-bunk'){
    line(c,...p(x+.2,y+.3,3),...p(x+w-.2,y+.3,3),'#b19f77',1.6);return true;
  }
  if(!['building','wall','crate'].includes(kind)||w<3||h<2)return false;
  const back=y<10,colors=walls[map.id];
  if(back&&(kind==='building'||kind==='wall')){
    const front=y+h-.17;wall(c,p,x+.18,front,w-.36,colors,kind==='building');
    if(map.id==='mat-bed'&&x>15){
      for(let i=0;i<4;i++){const a=x+.7+i*.56;poly(c,[p(a,front+.04,43),p(a+.57,front+.04,43),p(a+.38,front+.13,10),p(a+.11,front+.14,9)],i%2?'#557773':'#768a7c');}
    }else if(map.id==='oar-bunk'){
      for(let i=.45;i<w-.2;i+=2.55){const foot=p(x+i,front+.05,5),knee=p(x+i-.23,front+.12,35),head=p(x+i-.67,front-.14,53);
        c.beginPath();c.moveTo(...foot);c.quadraticCurveTo(...knee,...head);c.strokeStyle='#6f684f';c.lineWidth=4;c.stroke();c.lineWidth=1;}
      if(x>8)linen(c,p,x+w*.49,front-.38,'#779693',2);
    }else if(map.id==='kettle-nook'&&x<8)oven(c,p,x+w*.66,front+.08);
    else if(map.id==='sponge-sill'){const a=x+w*.5;box(c,p,a,front+.04,1.14,.12,0,32,['#807869','#8d8069','#6b6859']);const k=p(a+.81,front+.21,16);arc(c,...k,2.9,0,Math.PI*1.8,'#c2ad81',1.3);}
    return true;
  }
  if(map.id==='mat-bed'&&x>10&&y>10){
    plate(c,p,x+.3,y+.2,4.3,2.1,1,'#746257');
    bed(c,p,x+.8,y+.53,false,false);linen(c,p,x+3.0,y+.86,'#789189');chair(c,...p(x+.65,y+1.63),true);return true;
  }
  if(map.id==='kettle-nook'&&back){table(c,...p(x+w*.45,y+h-.42));basket(c,p,x+w*.74,y+h-.42);return true;}
  const backLine=back?y+h-.9:y+.65;
  const span=Math.min(4.2,w-.65);
  cupboard(c,p,x+.32,backLine,span,.7,back?material.light:material.board);
  if(map.id==='felt-hour'){linen(c,p,x+.72,backLine+.2,'#a89c86',4);linen(c,p,x+2.65,backLine+.18,'#7b8d82',2);}
  else if(map.id==='oar-bunk'){basket(c,p,x+.9,backLine+.17);const bell=p(x+2,backLine+.25,17);oval(c,...bell,4,3,'#ab9463');}
  else if(map.id==='kettle-nook'){tub(c,...p(x+1,backLine+.22,15),8,'#888b6b');basket(c,p,x+2.4,backLine+.2);}
  else{basket(c,p,x+1,backLine+.2);linen(c,p,x+2.2,backLine+.14,map.id==='mat-bed'?'#859d90':'#a89172',2);}
  return true;
}
