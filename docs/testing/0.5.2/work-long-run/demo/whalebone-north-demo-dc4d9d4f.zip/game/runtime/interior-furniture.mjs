import {line,poly,oval,arc} from './paint.mjs';
const box=(c,x,y,w,d,h,top,left,right)=>{
 const points=[[x,y-h],[x+w,y+d*.48-h],[x+w-d,y+d*.89-h],[x-d,y+d*.42-h]];
 poly(c,[points[2],points[3],[x-d,y+d*.42],[x+w-d,y+d*.89]],left,'#594d40');
 poly(c,[points[1],points[2],[x+w-d,y+d*.89],[x+w,y+d*.48]],right,'#594d40');
 poly(c,points,top,'#70614e');
};
export function chair(c,x,y,dark=false){
 const wood=dark?'#695240':'#8c674b';
 for(const [a,b] of [[-5,0],[4,4],[8,0],[-1,-4]])line(c,x+a,y+b,x+a,y+b-11,wood,2);
 poly(c,[[x-7,y-12],[x,y-15],[x+9,y-11],[x+1,y-7]],'#b28a60','#6f5b48');
 line(c,x-6,y-12,x-6,y-24,wood,2);line(c,x+1,y-8,x+1,y-20,wood,2);line(c,x-7,y-23,x+2,y-19,wood,3);
}
export function glow(c,x,y,r,col){
 const g=c.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,col);g.addColorStop(1,'#d6a05a00');c.fillStyle=g;c.fillRect(x-r,y-r,r*2,r*2);
}
export function table(c,x,y){
 chair(c,x-23,y+2,true);chair(c,x+21,y-9,true);
 for(const [a,b] of [[-22,0],[17,5],[-10,8],[26,-1]])line(c,x+a,y+b,x+a,y+b-20,'#71563f',3);
 box(c,x-14,y-18,37,21,3,'#ad865f','#8f674d','#755b48');
 poly(c,[[x-21,y-16],[x-6,y-23],[x+18,y-12],[x+5,y-6],[x+5,y+1],[x-10,y-6],[x-10,y-11]],'#e0d5b6','#b8aa91');
 line(c,x-11,y-10,x+4,y-4,'#6c8b8a',1.5);oval(c,x+11,y-13,4.3,1.9,'#786f58');
 chair(c,x+11,y+17);
}
function fire(c,x,y,t){
 glow(c,x-3,y-15,48,'#eaaa5860');
 box(c,x-10,y+2,29,22,29,'#af9b7b','#997b61','#816f5a');
 box(c,x+1,y-19,13,11,30,'#a38b6d','#927357','#7b6954');
 poly(c,[[x-19,y-2],[x-17,y-16],[x-11,y-20],[x-2,y-16],[x-3,y+3]],'#453d35','#685443');
 for(let i=0;i<3;i++){const dy=Math.sin(t*3.3+i)*2;poly(c,[[x-17+i*4,y-2],[x-14+i*4,y-11-i+dy],[x-12+i*4,y-4],[x-10+i*4,y-i]],i===1?'#f5c783':'#cd8050');}
 oval(c,x-6,y-26,8.6,3.3,'#534f43');line(c,x-6,y-26,x+1,y-33,'#5d5849',1.4);
}
function bowl(c,x,y,s,t){
 box(c,x-8,y,18,14,7,'#94765c','#79604a','#695741');
 oval(c,x-2,y-8,10,4,'#ede5d0');arc(c,x-2,y-9,8.5,0,Math.PI,'#b7b19b',1.8);
 oval(c,x-2,y-8,7.1,1.8,s.flags['vigil-salt']?'#eee6cf':'#8d9a93');
 if(s.flags['vigil-thread']){c.strokeStyle='#487987';c.lineWidth=1.8;c.beginPath();c.moveTo(x-7,y-8);c.bezierCurveTo(x-3,y-16,x+4,y+5,x+13,y-1);c.stroke();}
 if(s.flags['vigil-finished']){glow(c,x+9,y-17,22,'#ecc17a61');oval(c,x+9,y-9,3,6,'#e1c494');oval(c,x+9,y-17,1.5,3+Math.sin(t*3)*.6,'#f5d888');}
}
export function interiorProp(c,p,f,mode,s,t){
 const k=f.kind,label=f.label||f.name||'',w=f.w||1,h=f.h||1;
 const [x,y]=p(f.x+w*.5,f.y+h*.5);
 if(k==='wall'||mode==='vigil'&&k==='rope')return true;
 if(f.id==='vigil-bowl'){bowl(c,x+14,y-8,s,t);return true;}
 if(f.id==='paper-boat'){poly(c,[[x-7,y],[x-1,y-4],[x+7,y-2],[x+1,y+2]],'#e3d7ad','#9f9275');line(c,x-1,y-4,x+1,y+2,'#6c9190');return true;}
 if(k==='hearth'||/暖灶/.test(label)){fire(c,x,y,t);return true;}
 if(/长桌|缝纫台|晾样木柜/.test(label)){table(c,x,y);return true;}
 if(k==='lamp'){box(c,x-3,y,8,6,6,'#9e825f','#77654f','#655b46');oval(c,x,y-7,5,2.3,'#a99168');glow(c,x,y-10,mode==='vigil'&&s.flags['vigil-finished']?48:23,'#eec47968');oval(c,x,y-11,1.8,3.3,'#f4d791');return true;}
 return false;
}
