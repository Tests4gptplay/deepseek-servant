import {allows} from '../state.mjs';
import {line,oval,poly} from '../paint.mjs';
import {fruitRack,coffinCoat} from './market.mjs';
import {shutter,person,plank,pass,cup} from './watch.mjs';
import {station} from './stations.mjs';
const animated=new Set(['turn-hem','empty-frame','private-dress','public-dress','sight-test','give-the-pass','shut-sidewindow','handsignal','singer-choice','family-promoter','last-breakfast']);
export const saltcoatCue=id=>id?.startsWith('saltcoat-')&&animated.has(id.slice(9));
const prefix='saltcoat-';
function local(c,x,y,draw,scale=1){c.save();c.translate(x,y);c.scale(scale,scale);draw();c.restore();}
function props(c,id,s){const q=k=>!!s.flags[prefix+k];
 if(id==='rope-market-mark-0'){fruitRack(c,{paid:q('fruit-paid'),teaching:q('learnt'),settled:q('airgap')});return;}
 if(id==='rope-market-mark-1'){line(c,-19,0,-19,-18,'#715947',2);line(c,17,3,17,-15,'#715947',2);line(c,-19,-16,17,-13,'#b39465',1.4);if(q('public'))poly(c,[[-11,-15],[4,-14],[4,-8],[-10,-7]],'#7d9590','#526761');return;}
 if(id==='wharf-scale-mark-0'){if(!s.flags['coffin-aboard'])coffinCoat(c,{opened:q('airgap')});return;}
 if(id==='shift-square-mark-0'||id==='haul-office-mark-0'){plank(c,0,0,55);return;}
 if(id==='shift-square-mark-1'){plank(c,0,0,27);pass(c,4,-9);return;}
 if(id==='haul-office-mark-1'){plank(c,0,0,22);line(c,-8,-7,7,-9,'#d7c19b',3);return;}
 if(id==='wet-arcade-mark-0'){shutter(c,{open:q('view-ready')?.84:.17,curtain:true});return;}
 if(id==='upper-spar-mark-0'){shutter(c,{open:q('private-goodbye')?0:q('seat-given')?.87:.28,lit:true});return;}
 if(id==='upper-spar-mark-1'){line(c,0,0,0,-17,'#5d5448',2);poly(c,[[-4,-18],[0,-22],[4,-18],[2,-14],[-2,-14]],'#ddc38a','#6b5e45');return;}
 if(id==='burial-cape-mark-0'){poly(c,[[-19,-4],[-9,-10],[8,-9],[18,-3],[7,1],[-10,0]],'#8b9787','#747e70');if(q('private-echo'))poly(c,[[-10,-8],[1,-9],[8,-5],[11,-3],[-2,-3],[-11,-5]],'#79918c','#576b67');}
}
export function saltcoatFeature(c,p,map,f,s){if(!f.id?.startsWith(prefix))return false;const [x,y]=p(f.x+(f.w||1)/2,f.y+.45);local(c,x,y,()=>props(c,f.id.slice(9),s));return true;}
export function saltcoatEntity(c,p,map,e,s,focus,motion,t,reduce){
 if(!e.id?.startsWith(prefix))return false;const id=e.id.slice(9),[x,y]=p(e.x+.5,e.y+.5);
 const current=motion?.id===e.id&&!reduce,phase=current?Math.min(1,Math.max(0,(t-motion.at)/1.15)):1;
 const pastGrave=map.id==='burial-cape',offDuty=['handsignal','give-the-pass','pay-the-shift','empty-frame','private-fee','private-dress','public-dress'];
 if((pastGrave||offDuty.includes(id))&&!allows(s,e.requires)&&!s.flags[e.action?.id])return true;
 const actor=['lease','cart-helper','candle-seller','direct-porter','hear-singer','meet-sill','pass-guide','castoff-porter','fresh-flowers'].includes(id);
 const side=id==='pay-the-shift'?-20:id==='give-the-pass'?23:actor?11:18;
 local(c,x+side,y-(actor?2:4),()=>station(c,id,s,{phase,held:focus?.id===e.id}),actor?1.04:1);
 return true;
}
export function saltcoatGallery(c,p,map,s,ordered){
 if(map.id!=='signal-gallery'||!s.flags['saltcoat-noon-ticket']||s.flags['roof-shelter'])return;
 for(const [x,y,east] of [[15,13,false],[27,8,true]]){
   ordered.push([x+y+.8,()=>{const [a,b]=p(x+.55,y+.4);local(c,a,b,()=>{shutter(c,{open:east&&s.flags['saltcoat-seat-given']?.85:.19,lit:east});
    if(east&&s.flags['saltcoat-window-goodbye'])local(c,22,0,()=>person(c,'watcher','hold',1,-1),.75);
    if(!east){line(c,-22,-4,-20,-20,'#655d4e',2);line(c,-20,-20,-13,-23,'#c7af79',1);}});}]);
 }
}
export function saltcoatDetail(c,w,h,map,s,focus,motion,t,reduce){
 const obj=focus?.id?.startsWith(prefix)?focus:(!reduce&&motion?.id?.startsWith(prefix)&&t-motion.at<1.5?motion:null);
 if(!obj)return;const e=map.entities.find(k=>k.id===obj.id);if(!e||!allows(s,e.requires)&&!s.flags[e.action?.id])return;
 const id=e.id.slice(9),small=w<620;
 const scale=small?1.78:2.5,ww=small?176:240,hh=small?92:125,xx=w-ww-(small?12:28),yy=small?77:25;
 const phase=!reduce&&motion?.id===obj.id?Math.max(0,Math.min(1,(t-motion.at)/1.15)):1;
 c.save();c.beginPath();c.roundRect(xx,yy,ww,hh,4);c.clip();const g=c.createLinearGradient(xx,yy,xx+ww,yy+hh);
 g.addColorStop(0,'#e7dcc1');g.addColorStop(.56,'#c4c4a4');g.addColorStop(1,'#8d9b86');c.fillStyle=g;c.fillRect(xx,yy,ww,hh);
 poly(c,[[xx,yy+hh*.78],[xx+ww*.69,yy+hh*.56],[xx+ww,yy+hh*.64],[xx+ww,yy+hh],[xx,yy+hh]],'#9c8a70');
 for(let i=0;i<8;i++)line(c,xx+ww*.13*i,yy+hh,xx+ww*.42+ww*.13*i,yy+hh*.63,'#c4af8c',.85);
 local(c,xx+ww*.49,yy+hh*.85,()=>station(c,id,s,{phase,held:!!focus,detail:true}),scale);
 c.restore();c.save();c.strokeStyle='#796e59';c.lineWidth=1.2;c.strokeRect(xx+.5,yy+.5,ww-1,hh-1);c.restore();
}
