// A new chapter may add a second stop to a familiar journey. Explain the stop that still exists in this player's save.
export function priorWitnessClue(player,entity){
 const f=player.flags,requires=entity.requires||[];
 switch(entity.id){
  case 'bran-return':
   if(!requires.includes('common-lowered'))return;
   if(!f['winter-proof'])return '到冬岸核实背风、淡水、靠泊和住处，再把你亲眼能认的情形带给布兰。';
   if(f['common-lowered']&&!f['bran-home-visited'])return '鹅影坪已经看过他当众下锚。布兰还欠送错早饭的邻家一句话：回三扇早餐门，看清两枚圆钉和那枚失了帽的钉。';
   return;
  case 'bran-unpin':
   if(!requires.includes('common-release-word'))return;
   if(!f['clutch-still'])return '棘轮还在转。先在锚机房掂稳鞋铁、套绳、泄压口与标线，让四个人亲手把机械停住。';
   if(!f['both-bells'])return '棘轮停了，水还在走。由套闸去验窗叶，让屋内和低艇的两班把两响回铃实际送到楼上。';
   return;
  case 'cut-ramp':
   if(!requires.includes('common-neighbours-out'))return;
   if(!f['harbor-tilted'])return '旧锚还拖着街面。回棘轮楼等布兰解柄，再由玛拉打开北航道。';
   if(f['common-neighbours-out']&&!f['slant-placed'])return '刚才的粮队邻人已经到坡了。白漆门后还有一条斜街在倒灌，从背管把水放走，去辨认真正住那扇窗的人。';
   return;
  case 'winter-proof':
   if(!requires.includes('return-crossed'))return;
   if(!f['lee-proved'])return '去风口比较同一块布的迎风面和背风面，再把两次读数送回冬岸。';
   if(!f['fresh-proved'])return '水面看着都清。沿取水廊分别尝过下游带盐的芯和向上游回流的那股清水。';
   if(!f['moor-proved'])return '两只泊眼不能只验一种潮位。去回水泊分别试过高水、低水，再让系链的人亲手拉紧。';
   if(!f['bed-count'])return '从藏风院进病房把床位一张张实量。走道只够担架拐弯的地方不能当作第五张床。';
   if(!f['family-share'])return '去四炉院找瑟琳。还缺她家实际肯分的那一份粮，不能把架上的锅都算成别人的过冬饭。';
   if(!f['hearth-trial'])return '去冬岸的围锅处找陶鹊，让她当面试自己愿意过的日子。灶边到底怎么留人，须等她试完再回来。';
   if(!f['stores-backed'])return '去冻粮驳找古杳。那些货要靠哪一班送来、谁肯押自己的船，得让驳主当面承担再回来。';
   if(!f['night-landed'])return '过冬还缺暗处能靠岸的一班。从泊眼下到夜水和压重滑道，听岸上把最后那道夜闩交给哪种信号，等艇实际抵岸再回来。';
   if(!f['concourse-agreed'])return '去四炉院东面的皮窗街，陪野檀和甫岸走过高院和低岸。房能住，还需要真愿意开门的人。';
   return;
  default:return;
 }
}
