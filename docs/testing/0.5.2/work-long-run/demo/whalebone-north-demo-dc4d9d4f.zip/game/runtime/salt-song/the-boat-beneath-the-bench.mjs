import {poly,line,oval} from '../paint.mjs';
function seat(c,p,x,y,w,d,height,color){
 for(const i of [.12,w-.12])for(const j of [.10,d-.10])line(c,...p(x+i,y+j,1),...p(x+i,y+j,height),'#50392b',2.8);
 poly(c,[p(x,y,height),p(x+w,y,height),p(x+w,y+d,height),p(x,y+d,height)],color,'#67462f');
 for(let j=.20;j<d;j+=.31)line(c,...p(x,y+j,height+1),...p(x+w,y+j,height+1),'#d6b884',.7);
}
export function songRoomFurniture(c,p,map,s,t,ordered){
 if(map.id!=='salt-song-room')return;
 const at=(x,y,f)=>ordered.push([x+y+.1,f]);
 for(let i=0;i<8;i++){
  const x=9+i*1.13,y=7.2;const points=[p(x,y),p(x+.98,y),p(x+.98,y+.8),p(x,y+.8)];
  poly(c,points,i%3===0?'#a37d4b':'#775d47','#523c30');
  const [a,b]=p(x+.5,y+.4,1);oval(c,a,b,1.8,1.1,'#dbba7d');
 }
 for(const [x,y] of [[9.3,10.8],[13.8,10.8],[18.2,10.8]])at(x,y,()=>seat(c,p,x,y,2.5,.8,10,'#aa8255'));
 at(12,8,()=>{
  seat(c,p,10.5,7.7,4.7,1.1,19,'#8e6a45');
  for(let i=0;i<8;i++){const x=10.7+i*.52;poly(c,[p(x,7.8,20),p(x+.43,7.8,20),p(x+.43,8.5,20),p(x,8.5,20)],i===0||i===3||i===6?'#d6b17b':'#9ab3a0','#6d624d');}
 });
 at(16.4,5.6,()=>{const [a,b]=p(16.4,5.6,16);for(let j=-1;j<=1;j++){const x=a+j*8;oval(c,x,b+5,5.6,6,'#857358');oval(c,x,b,4.9,2,'#bea37c');oval(c,x,b-.2,3.2,1.2,'#433b31');}});
 at(24,6.4,()=>{for(let i=0;i<8;i++){const x=22.5+i*.35,y=5;line(c,...p(x,y,5),...p(x,y,37+7*Math.sin(i*.52)),'#986e49',3);line(c,...p(x,y,27),...p(x,y+.65,26),'#cfb686',1.4);}});
}
