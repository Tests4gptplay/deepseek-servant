import {line,poly,oval,arc} from './paint.mjs';
import {glow} from './interior-furniture.mjs';
function timedLamp(c,x,y,height,kind,lit,t){
 const shade=kind==='outer'?'#b06b51':'#d2b478';
 line(c,x,y,x,y-height,'#685a43',3.6);line(c,x-6,y,x,y-height+18,'#89765a',1.8);
 poly(c,[[x-6,y-height+2],[x+6,y-height+2],[x+5,y-height-7],[x-5,y-height-7]],lit?'#f1cc86':'#9b987d','#6b6956');
 poly(c,[[x-8,y-height-7],[x,y-height-14],[x+8,y-height-7]],shade,'#706952');
 if(lit){glow(c,x,y-height-2,22+Math.sin(t*2)*2,'#f3c57365');}
 if(kind==='outer'){line(c,x,y-height-13,x,y-height-23,'#6a6250',1.5);poly(c,[[x,y-height-22],[x+8,y-height-19],[x,y-height-15]],shade);}
}
function ribBed(c,p,f){
 const w=f.w||6,h=f.h||4,pt=(x,y,z=0)=>p(f.x+x,f.y+y,z);
 for(const y of [h*.18,h*.78])line(c,...pt(-.3,y),...pt(w+.3,y,-5),'#665b47',6);
 for(let i=.45;i<w;i+=.85){
  const aa=pt(i,h*.12,14),center=pt(i,h*.51,-4),bb=pt(i,h*.89,17);c.beginPath();c.moveTo(...aa);c.quadraticCurveTo(center[0],center[1]+12,...bb);c.strokeStyle='#83684e';c.lineWidth=4.3;c.stroke();
  line(c,...pt(i-.22,h*.16),...pt(i+.22,h*.16),'#ac9573',2);
 }
 line(c,...pt(-.18,h*.54),...pt(w+.28,h*.54),'#a58b63',2.7);
}
function tideScale(c,p,f,s,t){
 const [x,y]=p(f.x+(f.w||1)*.5,f.y+(f.h||1)*.5),wet=s.tide==='high';line(c,x,y,x,y-37,'#575d50',3);
 for(let i=0;i<7;i++)line(c,x-1,y-3-i*4,x+(i%2?3:6),y-3-i*4,'#c2ad81',1);
 oval(c,x+8,y-(wet?24:8)+Math.sin(t)*1.2,5,2,'#628e90');line(c,x,y-(wet?24:8),x+9,y-(wet?24:8),'#7d9891',1.6);
}
export function works(c,p,f,mode,s,t){
 const title=f.label||f.name||'',k=f.kind,w=f.w||1,h=f.h||1,[x,y]=p(f.x+w*.5,f.y+h*.5);
 if(mode==='yard'){
  if(/滑床/.test(title)){ribBed(c,p,f);return true;}
  if(/压舱块|压索块/.test(title)){
   for(let row=0;row<3;row++)for(let j=0;j<3;j++){let a=x-25+j*16+row*3,b=y-7+row*7;poly(c,[[a-7,b-3],[a,b-7],[a+9,b-3],[a+3,b+2],[a-7,b]],row%2?'#8a8975':'#9c977e','#6c7164');}return true;
  }
  if(/浮标|潮尺/.test(title)){tideScale(c,p,f,s,t);return true;}
 }
 if(mode==='signal'){
  if(k==='lamp'){const outer=/外|西/.test(title);timedLamp(c,x,y,outer?58:33,outer?'outer':'inner',s.flags['window-known']||outer!==('high'===s.tide),t);
   const z=outer?49:27;line(c,x-16,y-z+8,x+17,y-z-6,'#8d7555',2.7);line(c,x-14,y-z+8,x-12,y-z+20,'#82775c',1);
   poly(c,[[x-18,y-z+21],[x-17,y-z+16],[x-9,y-z+13],[x-7,y-z+17]],outer?'#a57159':'#b2a57b','#817a63');
   if(!outer){arc(c,x+10,y-z+3,5,0,Math.PI*2,'#ad986e',1.5);line(c,x+10,y-z+8,x+10,y-2,'#807761',1);}
   return true;}
  if(k==='pier'){const a=p(f.x+.1,f.y+.15),b=p(f.x+w,f.y+.15);line(c,...a,...b,'#776d53',3);
   for(let i=.25;i<w;i+=2.3){const [xx,yy]=p(f.x+i,f.y+.2);line(c,xx,yy+2,xx,yy-14,'#6d624c',2);line(c,xx,yy-13,...p(f.x+Math.min(w,i+2.3),f.y+.2,13),'#b49c75',1.2);}return true;}
 }
 if(mode==='court'&&(k==='lamp'||k==='rope'&&/晾/.test(title))){
  if(k==='lamp'){timedLamp(c,x,y,29,'inner',!s.flags['vigil-finished']||s.flags['night-lamp'],t);return true;}
  const length=Math.min(84,w*12);
  line(c,x-length,y+1,x-length,y-26,'#7d674f',3);line(c,x+length,y+2,x+length,y-18,'#826c4d',3);
  c.beginPath();c.moveTo(x-length,y-25);c.quadraticCurveTo(x,y-11,x+length,y-18);c.strokeStyle='#8e795a';c.stroke();
  for(const [j,tone] of [[-.81,'#9faeb0'],[-.46,'#be9a78'],[-.06,'#ded1a9'],[.28,'#a48991'],[.59,'#84999a']]){
   const u=x+j*length,v=y-18;poly(c,[[u,v],[u+12,v+1],[u+13,v+14],[u+8,v+17],[u-1,v+12]],tone,'#969580');}
  return true;
 }
 return false;
}
