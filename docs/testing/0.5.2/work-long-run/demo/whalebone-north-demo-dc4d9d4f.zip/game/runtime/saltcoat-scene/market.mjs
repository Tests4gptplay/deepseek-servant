// The rack is open on the player's side; short damp folds hang outside the cart.
function shape(c,points,ink,edge='#362d2a'){
  c.beginPath();c.moveTo(...points[0]);for(const point of points.slice(1))c.lineTo(...point);
  c.closePath();c.fillStyle=ink;c.fill();if(edge){c.strokeStyle=edge;c.lineWidth=1.15;c.stroke();}
}
function line(c,points,color,width=1.2){
  c.strokeStyle=color;c.lineWidth=width;c.lineCap='round';c.lineJoin='round';
  c.beginPath();c.moveTo(...points[0]);for(const point of points.slice(1))c.lineTo(...point);c.stroke();
}
function oval(c,x,y,rx,ry,fill){
  c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);c.fillStyle=fill;c.fill();
}
export function fruitRack(c,{paid=false,teaching=false,settled=false,turn=1}={}){
  oval(c,1,1,35,6,'#352e2952');
  for(const [x,y] of [[-27,-1],[-5,-6],[27,1],[1,6]]){
    shape(c,[[x-2,y-14],[x+2,y-13],[x+2,y],[x,y+1],[x-2,y]],'#79513e');
  }
  shape(c,[[-34,-17],[-9,-24],[32,-16],[7,-8]],'#b78053');
  for(let k=0;k<5;k++)line(c,[[-29+k*8,-17+k*1.5],[-8+k*8,-23+k*1.5]],'#614533',1.3);
  shape(c,[[-34,-17],[7,-8],[7,-4],[-34,-13]],'#694532');
  shape(c,[[7,-8],[32,-16],[32,-12],[7,-4]],'#86593c');
  for(const [cx,cy,n] of [[-17,-18,7],[4,-15,paid?0:5]]){
    oval(c,cx,cy,10,3.8,'#543e2d');oval(c,cx,cy-.8,9,2.6,'#c29356');
    for(let k=0;k<n;k++){const x=cx+[-6,-2,2,6,-4,0,4][k],y=cy+[-.3,.2,-.4,0,-2.9,-2.6,-2.8][k];
      oval(c,x,y-1.2,2.25,2.15,['#dc8b44','#a84c38','#d6a44c'][k%3]);oval(c,x-.55,y-2,0.65,.6,'#ffe4a0');}
    line(c,[[cx-9,cy],[cx-5,cy+2],[cx+4,cy+2.4],[cx+9,cy-.2]],'#b08253',1);
  }
  line(c,[[14,-17],[14,-29],[29,-25],[29,-13]],'#573c31',2.7);
  if(!teaching){shape(c,[[15,-28],[28,-25],[27,-15],[23,-14],[19,-17],[15,-17]],'#687f7c');
    const end=settled?Math.max(0,Math.min(1,turn)):0;
    shape(c,[[16,-18],[21,-16],[27,-16],[28+end*3,-14-end*5],[24+end*2,-12-end*4],[19,-14],[16,-15]],'#314d53');
    line(c,[[17,-16],[22,-14],[27+end*3,-15-end*4]],'#b4c3a9',1.2);
  }else{line(c,[[15,-25],[21,-23],[28,-22]],'#d9bc83',1.4);oval(c,27,-16,1,1.8,'#b0dce3');}
}
export function coffinCoat(c,{dry=false,publicCloth=false,opened=false,turn=1}={}){
  oval(c,0,1,29,6,'#32373450');
  for(const x of [-18,14]){oval(c,x,0,4,4.5,'#413b35');oval(c,x,0,1.3,1.5,'#b18b62');}
  shape(c,[[-27,-9],[-10,-16],[27,-9],[10,-3]],'#725342');
  shape(c,[[-27,-9],[10,-3],[10,0],[-27,-6]],'#4d3e34');
  shape(c,[[-24,-16],[-9,-22],[22,-15],[7,-9]],'#a17e55');
  shape(c,[[-24,-16],[7,-9],[7,-6],[-24,-12]],'#71573e');
  line(c,[[-19,-16],[8,-11],[16,-14]],'#dab982',1);
  const upper=publicCloth?'#c2b38c':'#7b9b99', lower=publicCloth?'#968e72':dry?'#667f79':'#425e65';
  shape(c,[[-16,-19],[-7,-22],[14,-17],[20,-15],[9,-13],[0,-14]],upper);
  shape(c,[[-16,-19],[0,-14],[9,-13],[8,-7],[2,-7],[-5,-10],[-11,-10],[-16,-13]],upper);
  const lift=opened?3.8*Math.max(0,Math.min(1,turn)):0;
  shape(c,[[-16,-14],[-10,-12],[-5,-12],[3,-9],[8,-9],[9+lift,-9-lift],[10+lift,-6-lift],[4,-5],[-4,-7],[-11,-8],[-16,-10]],lower);
  line(c,[[-15,-12],[-9,-10],[-4,-10],[4,-7],[9+lift,-8-lift]],publicCloth?'#dfcda4':'#c9ccc0',1.3);
  line(c,[[-8,-20],[-3,-17],[4,-16]],'#d5c9a2',1);
  if(!dry){line(c,[[-10,-9],[-8,-8]],'#92b6bb');oval(c,-10,-5,0.8,1.4,'#b2d0cc');}
}
