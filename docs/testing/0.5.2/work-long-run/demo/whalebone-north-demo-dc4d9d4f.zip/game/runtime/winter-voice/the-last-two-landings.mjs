import {cord,panel,oval,rope} from '../folded-house-art/materials.mjs';
function ringer(c,q,flags,t){
 for(const [u,v,z] of [[.14,.56,43],[.76,.51,48]]){cord(c,q,[[u,v,0],[u,v,z]],'#584e3c',7);cord(c,q,[[u-.008,v+.01,3],[u-.008,v+.01,z-1]],'#b29865',1.9);}
 const b=(u,v,z)=>q(u,v,z),motion=flags['whalefall-two-beats']?Math.sin(t*.0025)*1.4:0;
 rope(c,[q(.09,.56,39),q(.34,.59,34),q(.48,.6,32),q(.78,.50,43)]);
 panel(c,q,[[.32,.62,27],[.44,.62,29],[.51,.64,12],[.29,.64,11]],'#aa9977','#4a5047');oval(c,b(.40,.64,12+motion),10,2,'#544f3c');
 for(const z of [16,20,24])cord(c,q,[[.30,.65,z],[.45,.62,z+2]],'#d3c6aa',2);
 for(const v of [.66,.81]){panel(c,q,[[.04,v,2],[.95,v,4],[.95,v+.07,4],[.04,v+.07,2]],'#988464','#514d3c');}
 const y=flags['whalefall-cork-crossed']?.25:.82;
 panel(c,q,[[y-.09,.1,3],[y+.09,.1,4],[y+.15,.15,9],[y+.09,.2,15],[y-.08,.21,12],[y-.12,.15,6]],'#b2b199','#536c67');
 for(const u of [.42,.64]){cord(c,q,[[u,.72,4],[u+.10,.47,26]],'#a48b68',3.4);oval(c,b(u+.10,.47,26),4.1,2.4,'#7b6852');}
}
function fishRack(c,q,flags){
 for(const u of [.13,.79]){cord(c,q,[[u,.38,0],[u,.38,44]],'#67523b',5);cord(c,q,[[u-.015,.42,0],[u,.38,30]],'#ac9069',1.6);}
 cord(c,q,[[.08,.37,42],[.84,.37,45]],'#756651',4.4);
 for(let i=0;i<(flags['whalefall-house-fish']?3:5);i++){
  const u=.22+i*.11,v=.38,z=19+(i%2)*4;
  cord(c,q,[[u,v,43],[u,v,z+13]],'#bea575',1.4);
  panel(c,q,[[u,v,z+12],[u-.031,v,z+5],[u-.019,v,z-2],[u+.02,v,z-4],[u+.035,v,z+5]],i%2?'#9da7a0':'#969e85','#485f5e');
  const [x,y]=q(u-.008,v,z-1);oval(c,[x,y],1.4,1.2,'#2f4847');
 }
 const fill=flags['whalefall-lamps-crossed'];const pt=q(.78,.73,4);oval(c,pt,15,5.4,'#73654b');oval(c,[pt[0],pt[1]-3],15,4.2,'#ae966c');
 for(let i=0;i<5;i++)cord(c,q,[[.68+i*.04,.71,4],[.73+i*.035,.81,3]],'#806746',1.3);
 c.strokeStyle='#715a40';c.lineWidth=2;c.beginPath();c.ellipse(pt[0],pt[1]-4,9,10,0,Math.PI,Math.PI*2);c.stroke();
 if(!fill&&flags['whalefall-house-fish']){oval(c,[pt[0]-3,pt[1]-5],6,2.2,'#a5bdb7');oval(c,[pt[0]+3,pt[1]-3],6,2.2,'#d0d4bc');}
}
export function watchLanding(c,p,map,f,s,t){
 if(!['voice-damped-step','voice-smoke-rack'].includes(f.kind))return false;
 const q=(u,v,z=0)=>p(f.x+f.w*u,f.y+f.h*v,z);
 c.save();try{if(f.kind==='voice-damped-step')ringer(c,q,s.flags,t);else fishRack(c,q,s.flags);}finally{c.restore();}return true;
}
