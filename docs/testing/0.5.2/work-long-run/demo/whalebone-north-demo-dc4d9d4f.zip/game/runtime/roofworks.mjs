import {line,poly,arc,oval} from './paint.mjs';
export function tradeRoof(c,f,p,top,rise){
 const w=f.w||2,d=f.h||2,label=f.label||'';
 if(/殓|葬/.test(label)){
   const a=p(w*.12,d*.5,top+rise),b=p(w*.76,d*.5,top+rise);
   for(const [x,y] of [a,b]){
     line(c,x,y,x,y-10,'#796e56',2);oval(c,x,y-12,2.4,2,'#d9c39c');
   }
   c.beginPath();c.moveTo(a[0],a[1]-8);c.quadraticCurveTo((a[0]+b[0])/2,(a[1]+b[1])/2+1,b[0],b[1]-8);
   c.strokeStyle='#756e56';c.lineWidth=1.1;c.stroke();
   for(const frac of [.22,.42,.72]){const x=a[0]+(b[0]-a[0])*frac,y=a[1]+(b[1]-a[1])*frac-5;
    poly(c,[[x,y],[x+8,y+3],[x+7,y+15],[x+4,y+12],[x+1,y+14]],'#e9dec5','#b1aa8e');}
 }else if(/粮|仓/.test(label)){
   // Clerestory louvers dry the grain above the loading floor.
   const near=d*.63,far=d*.32,base=top+rise*.65,high=top+rise+12;
   const face=(u,v,z)=>p(u,v,z);
   poly(c,[face(w*.14,near,base),face(w*.78,near,base),face(w*.78,near,high),face(w*.14,near,high)],'#9b8865','#6c6953');
   poly(c,[face(w*.78,near,base),face(w*.78,far,base),face(w*.78,far,high),face(w*.78,near,high)],'#767f6e','#647263');
   for(let j=0;j<8;j++){const u=w*(.18+j*.073);line(c,...p(u,near,high-3),...p(u,near,base+2),'#525f56',2.5);}
   poly(c,[p(w*.10,near+.09,high),p(w*.81,near+.09,high),p(w*.81,far-.07,high+4),p(w*.1,far-.07,high+4)],'#667d73','#53675c');
   const [x,y]=p(w, d*.51,top+rise*.72);
   line(c,x,y,x+20,y-8,'#695c47',3);line(c,x+19,y-8,x+19,y+28,'#88765b',1);
   arc(c,x+19,y+28,2,0,Math.PI,'#78664c',1.4);
 }else if(/索|缆/.test(label)){
   const a=p(w*.15,d*.66,top+rise*.7),b=p(w*.74,d*.66,top+rise*.7);
   for(const [x,y] of [a,b]){line(c,x-4,y+2,x,y-13,'#675a48',2.5);line(c,x+4,y+2,x,y-13,'#88745b',2);}
   for(let k=0;k<3;k++){c.beginPath();c.moveTo(a[0],a[1]-12+k*2);c.quadraticCurveTo((a[0]+b[0])/2,(a[1]+b[1])/2+6+k*2,b[0],b[1]-12+k*2);c.strokeStyle=k===1?'#927957':'#b3a07a';c.lineWidth=1.2;c.stroke();}
 }else if(/秤/.test(label)){
   const [x,y]=p(w*.45,d*.5,top+rise);
   line(c,x,y,x,y-13,'#72634d',2.4);
   poly(c,[[x,y-18],[x+13,y-13],[x,y-10]],'#aa7453','#77654e');
 }
}
