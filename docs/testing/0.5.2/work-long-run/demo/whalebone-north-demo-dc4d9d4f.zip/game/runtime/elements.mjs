import {terms} from '../rules/vocations.mjs';
const sources={'frost-whelk':'cold','echo-ray':'tide','sail-heron':'wind','anchor-clutch':'impact','bell-crab':'impact','hemp-crab':'impact'};
const natural={'frost-whelk':{tide:.75,iron:1.25},'echo-ray':{tide:.70,light:1.22},'sail-heron':{wind:.82,light:1.18},'anchor-clutch':{iron:1.16,tide:1.2}};
export const incomingElement=(spec,intent)=>intent.element||sources[spec.id]||'impact';
export function spellHit(base,skill,spec,specialist){
 if(!specialist&&!spec.resistances)return {hit:base,note:''};
 const factor=Math.max(.45,Math.min(1.6,(spec.resistances||natural[spec.id]||{})[skill.element]??1));
 return {hit:Math.max(1,Math.round(base*factor)),note:factor===1?'':terms[skill.element]+(factor>1?'克制':'受抗')+' ×'+factor.toFixed(2)};
}
export function protect(member,element,raw,partyGuard){
 const factor=Math.min(.65,(member.resists?.[element]||0));const armor=Math.round(raw*factor);
 const brace=member.prep==='brace'?3:member.prep==='ward'&&['tide','cold','shock'].includes(element)?5:0;
 if(brace)member.prep=null;
 const bypass=Math.min(raw,brace+(partyGuard?2:0)+armor);
 return {loss:Math.max(0,raw-bypass),saved:bypass,element:terms[element]||element};
}
