import {posts,choosePost,dutyText} from './windloom-posts.mjs';
import {showField} from './battle-pairs/two-ends.mjs';
import { begin,move,settle,partyLine } from './battle.mjs';

export function encounter(ctx,spec,win,leave){
 const {ui,state,sound,world}=ctx;
 function start(){state.battle=begin(world,state.player,spec);ctx.sync();sound('battle');screen();}
 function withdraw(){const b=state.battle;if(b.phase==='active')settle(world,state.player,b,false);state.battle=null;leave();}
 function screen(){
  const b=state.battle;
  if(b.phase==='win'){
   const reward=typeof spec.reward==='string'?spec.reward:(spec.rewards?.label||'带回战利。');
   ui.show('battle-win','脱离交战',reward,[['收队',()=>{settle(world,state.player,b,true);state.battle=null;win();}]],b.log);return;
  }
  if(b.phase==='lose'){ui.show('battle-lose','退守安全点','这一轮可从入场状态重新安排装备和应对。',[['重试',start],['离开',withdraw]]);return;}
  const h=b.party[b.actor],input=kind=>()=>{const acted=move(b,kind,performance.now());if(acted)sound(kind==='dodge'?'tide':kind==='guard'?'touch':'battle');screen();};
  ui.show('battle',b.name+' · '+h.name,b.intent.tell+' · '+b.intent.name+'\n'+b.intent.hint+'　'+b.log+(b.windloom?'\n'+dutyText(b):''),[
    ['攻击',input('attack')],['协作技',input('skill')],['架势',input('guard')],['侧移',input('dodge')],['药剂 ×'+(b.stock.tonic||0),input('tonic')],...(b.stock['brine-dose']>0?[['盐膏 ×'+b.stock['brine-dose'],input('salve')]]:[]),...(b.windloom?[...Object.entries(posts).map(([id,name])=>['就位 · '+name,()=>{choosePost(b,id);screen();}]),['腾手护人',input('cover')]]:[]),['站位与搭手',()=>showField(ctx,b,input,screen)],['撤回护栏',withdraw]
  ],'第 '+b.round+' 轮　对手 '+b.hp+'/'+b.max+'　'+partyLine(b)+'　'+h.skill.name+' 耗气 '+(h.skill.cost??2));
 }
 start();
}
