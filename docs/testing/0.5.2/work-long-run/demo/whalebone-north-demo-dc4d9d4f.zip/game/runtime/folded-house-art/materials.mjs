import {poly,line,oval} from '../heelturn-cabins.mjs';
export {poly,line,oval};
export const wood={night:'#533f38',edge:'#48392e',light:'#ccad77',salt:'#d1d4b7',iron:'#4b5a59'};
export function pointOn(f,p){
 const x=f.x+.13,y=f.y+.14,w=f.w-.26,h=f.h-.28;
 return w>=h?(u,v,z=0)=>p(x+w*u,y+h*v,z):(u,v,z=0)=>p(x+w*v,y+h*u,z);
}
export function panel(c,q,uv,fill,edge){poly(c,uv.map(k=>q(...k)),fill,edge);}
export function cord(c,q,uv,color,width=1){line(c,uv.map(k=>q(...k)),color,width);}
export function lantern(c,pt,lit){
 const [x,y]=pt;
 if(lit){const glow=c.createRadialGradient(x,y,1,x,y,29);glow.addColorStop(0,'#ffc879af');glow.addColorStop(.4,'#efa85f4a');glow.addColorStop(1,'#ef9e5600');c.fillStyle=glow;c.fillRect(x-29,y-29,58,58);}
 line(c,[[x,y-21],[x,y-11]],'#453c34',1.4);
 poly(c,[[x-5,y-8],[x-3,y-12],[x+4,y-12],[x+6,y-7]],'#42615e','#373c34');
 poly(c,[[x-5,y-7],[x+5,y-7],[x+4,y+5],[x-3,y+5]],lit?'#f2c582':'#b6b4a0','#5b5849');
 line(c,[[x-3,y-6],[x-2,y+3]],'#fff2b7',1.2);line(c,[[x+3,y-6],[x+2,y+4]],'#8c7354');
 oval(c,[x+1,y+5],5,1.9,'#604b39');
}
export function hull(c,q,theme,w){
 panel(c,q,[[0,0],[1,0],[1,1],[0,1]],theme.floor,'#493f36');
 for(let i=0;i<8;i++){
  const v=.04+i*.12;cord(c,q,[[.025,v],[.29,v+.018],[.64,v-.012],[.96,v+.032]],i%2?'#c4ab773d':'#544e3d66',1.6);
 }
 const h=theme.height,low='#535446';
 for(let k=0;k<6;k++){
  const a=k*h/6,b=(k+1)*h/6;
  panel(c,q,[[.035,.70,a],[.965,.70,a+4],[.965,.70,b+4],[.035,.70,b]],theme.wood[k%3],'#594b3a');
  const u=.16+((k*7)%13)/21;cord(c,q,[[u,.70,a+.7],[u,.70,b-.4]],low,1.1);
  for(const v of [u-.022,u+.022])oval(c,q(v,.70,(a+b)/2),1.55,1.25,k%2?'#747b66':'#c9b084');
 }
 for(const u of [.05,.35,.65,.95]){
  panel(c,q,[[u-.018,.76],[u+.015,.76],[u+.044,.699,h+7],[u+.018,.695,h+7]],theme.rib,'#544635');
  cord(c,q,[[u+.008,.758,2],[u+.035,.702,h+5]],'#d1ad7e',1.45);
  for(const z of [9,h*.62])oval(c,q(u+.024,.735,z),2,1.5,'#525e59');
 }
 cord(c,q,[[.025,.70,h+4],[.48,.70,h+8],[.979,.70,h+8]],theme.cap,4);
 for(const u of [.10,.88])cord(c,q,[[u,.82,4],[u+(u<.5?.12:-.13),.704,h-3]],theme.rib,3);
 if(w>7)cord(c,q,[[.04,.94,1],[.25,.92,1],[.64,.87,1],[.96,.88,1]],'#c8bc8c66',2);
}
export function rope(c,points,ink='#806d4d'){
 line(c,points,'#594b39',3);line(c,points,ink,1.45);
}
