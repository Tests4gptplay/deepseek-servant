import {patch,timber,face,arch,chair,poly,line,oval} from './joinery.mjs';
const trim='#574936',pale='#b8a887',iron='#3e5853';
function threshold(c,p,f,s){
 const x=f.x+.45,y=f.y+.55,w=f.w-.9,d=f.h-.7,eave=64,ridge=91;
 const end=x+w,front=y+d,mid=y+d*.46;
 patch(c,p,[[x,front],[end,front],[end,front,eave],[x,front,eave]],'#bfae8c',trim);
 patch(c,p,[[end,y],[end,front],[end,front,eave],[end,mid,ridge],[end,y,eave]],'#897d66',trim);
 for(let k=0;k<6;k++){
  const ht=4+k*9;timber(c,p,[x,front,ht],[end,front,ht],'#817964',.75);
  for(let n=0;n<w;n+=1.2){const ax=x+n+(k%2)*.55;if(ax<end)timber(c,p,[ax,front,ht],[ax,front,ht+7],'#938b71',.85);}
 }
 const width=w*31;
 face(c,p,x,front,()=>{
  arch(c,22,0,78,60,'#e6ceb1');arch(c,27,0,68,54,'#463e32');arch(c,31,-1,60,49,'#78644b');
  const open=s.flags['heel-radius']?17:5;
  for(const [lx,rx] of [[31,60-open/2],[62+open/2,91]]){
   poly(c,[[lx,-2],[rx,-2],[rx,-38],[lx,-39]],'#88694b',trim);
   for(let k=lx+3;k<rx;k+=5)line(c,k,-35,k,-4,'#aa8859',.8);
   line(c,lx+1,-19,rx-1,-19,'#5c5039',3);
  }
  line(c,55-open/2,-23,70+open/2,-22,iron,3);oval(c,56-open/2,-22,2,2,'#dac595');
  for(const [wx,wy] of [[width*.56,-39],[width*.83,-36]]){
   arch(c,wx,wy+10,20,25,'#71634d');arch(c,wx+3,wy+7,14,19,'#e2b272');line(c,wx+10,wy-10,wx+10,wy+7,'#684a38',2);line(c,wx+3,wy-1,wx+17,wy-1,'#684a38',2);
  }
  line(c,104,-17,width-14,-17,iron,3.1);for(let i=108;i<width-10;i+=27)line(c,i,-17,i,-11,iron,1.8);
  chair(c,width*.65,4,11);chair(c,width*.78,5,15);chair(c,width*.9,3,19);
 });
 patch(c,p,[[x-.18,front+.1,eave],[end+.25,front+.1,eave],[end+.25,mid,ridge],[x-.18,mid,ridge]],'#6b8178',trim);
 patch(c,p,[[x-.18,y-.14,eave],[end+.25,y-.14,eave],[end+.25,mid,ridge],[x-.18,mid,ridge]],'#83958a',trim);
 for(let i=0;i<=8;i++){const frac=i/8,yy=mid+(front-mid)*frac,zz=ridge+(eave-ridge)*frac;timber(c,p,[x-.1,yy,zz+.4],[end+.14,yy,zz+.4],i%2?'#566e68':'#9ba89a',1.4);}
 timber(c,p,[x-.15,mid,ridge+1],[end+.2,mid,ridge+1],'#c8cfb2',3);
 for(const [cx,cy] of [[x+.8,mid-.24],[end-.65,mid-.3]]){
  patch(c,p,[[cx,cy,ridge-2],[cx+.38,cy,ridge-2],[cx+.38,cy,ridge+21],[cx,cy,ridge+21]],'#766959',trim);
  patch(c,p,[[cx+.38,cy,ridge-2],[cx+.38,cy+.42,ridge-4],[cx+.38,cy+.42,ridge+20],[cx+.38,cy,ridge+21]],'#9e8a6e',trim);
 }
}
export function heelFeature(c,p,map,f,s){
 if(map.id!=='heel-house')return false;
 if(f.kind==='building'&&f.x===2){threshold(c,p,f,s);return true;}
 if(f.kind==='crate'&&f.x===16){const [x,y]=p(18,7);c.save();c.translate(x,y);chair(c,-25,0,11);chair(c,2,4,16);chair(c,30,8,23);c.restore();return true;}
 return false;
}
export function heelFloor(c,p,map){
 if(map.id!=='heel-house')return;
 const ochres=['#baab92','#c5b79c','#a99e86','#c9b9a1'];
 for(let i=0;i<12;i++)for(let j=0;j<2;j++){
  const x=3+i*1.9,y=9.92+j*.85,z=.8;patch(c,p,[[x,y,z],[x+1.82,y,z],[x+1.82,y+.79,z],[x,y+.79,z]],ochres[(i*5+j*3)%4],'#8e8976');
 }
 for(const x of [5.6,6.2,20])timber(c,p,[x,9.8,1],[x,12,1],'#997c54',2);
}
