import {combReadings} from '../rules/comb-tide.mjs';
import {syncParty} from './party.mjs';
import {equip} from './gear.mjs';
import {combDuel} from './comb-duel.mjs';
import {quietComb} from './comb-quiet.mjs';
export function combCoastUse(ctx,e,close){
  const {state,ui,sound,world}=ctx,s=state.player,flags=s.flags,part=e.action.part;
  const ex=syncParty(world,s),four=['mara','ivo','selene','mira'].every(id=>ex.roster.includes(id));
  const show=(title,body,options=[])=>ui.show('comb-coast',title,body,[...options,['离开桩边',close]]);
  function note(flag,title,body){if(flag)flags[flag]=true;ctx.sync();sound('tide');show(title,body);}
  const fight=(id)=>four?combDuel(ctx,e,id,close):show('需要四副眼睛','从深水看不到桩后的回流。等掌潮、绘图和系索的人一同到场，或者循岸观察，仍可安然通过。');
  const slip=()=>note('comb-slip','靴筒里灌进一线水','白尖根本不是石脊。玛拉抓住干苔一侧，退回原脚印。回到露苔的上沿踏脚可找回那条避流线。');
  if(part==='dry')return show('苔是从哪一边干的？',flags['comb-slip']?'上次滑落的半个靴印还在。高处的盐壳没有水痕。':'潮脚的检修工把平石分两层：绿苔留在高沿，细白尖朝同一边倒。',[
    ['踏住干苔高沿',()=>note(flags['comb-slip']?'comb-righted':'comb-dry','踏脚没有动','鞋底贴住砂面。一线完整倒影绕过前面的牵环，无须碰触帘冠。')],['沿发白的水尖试一步',slip]]);
  if(part==='foam')return show('两股泡线',s.tide==='high'?'涨水把白尖向岸挤。两行碎泡之间的黑水反而照得见脸。':'退水把泡线拉细，透明小帆朝下游倾，留下一道平整倒影。',[
    ['沿完整倒影数空档',()=>note('comb-foam','第三下没有浪','帘梳把浮草送回梳缘，隔三次吐出一条静缝。记下碎泡与整片倒影的差别。')],['踩到连白的泡尖',slip]]);
  if(part==='ring')return show('牵环的上半截',flags['comb-foam']?'泡沫断开时，铁上那截湿线也跟着垂下。':'每次水起，旧环先抖后静。橘色小珠紧跟着松索漂来。',[
    ['等索垂下再松手',()=>note('comb-ring','环松、幼珠先过','绳下的小珠漂向背流。伊沃的前辈在铁面刻过一只张开的手。')],['现在就收紧',slip]]);
  if(part==='basket')return show('谁把虾笼推出了水？',flags['comb-basket-clear']?'再次浮起的笼口已经空了，篾上留下淡金色的膜。':'笼里没有牙痕。半透明帆梢顺流挂着虾须，越拉笼绳越绷。',[
    ['解开逆流那一结',()=>note('comb-basket','笼口朝向了静水','看见幼串从篾条间钻出。塞回去的虾从另一头自行游走。')],
    ...(!flags['comb-basket-clear']?[['四人下水解挂',()=>fight('comb-skein')]]:[])]);
  if(part==='shadow')return show('阳光下的第三张帆',flags['comb-basket']?'邻间虾笼指着同一条影子。':'风逆着吹，底下的幼珠仍同向漂。看水底，不必拨动帆。',[
    ['顺幼珠的影子记回流',()=>note('comb-shadow','记下了回流口','米拉把沉下去的珠影连起：它们在找背流的出口。冬岸的里桩也会留下这种漏斗形细纹。')] ]);
  if(part==='tools'){
    if(flags['comb-tool'])return show('卷绳上的旧结', '先前编好的工具仍归队伍。可从航海志的装备页换给同行者。');
    if(!flags['comb-shadow']&&!flags['comb-ring'])return show('两堆看似都能用的零件','照着旧环的松紧或湾底珠影先看一次，才知道该留哪个声音。');
    const choose=(id,who)=>{ex.stock[id]=(ex.stock[id]||0)+1;flags['comb-tool']=true;equip(world,s,ex.roster.includes(who)?who:ex.roster[0],id);note('',world.equipment[id].name,'已经佩上。空螺将下一轮换侧传给全队，双襻能在护住桩缝时多卸一次力。另一样零件还给船工。');};
    return show('只能从同一段浮索拆下一副','瑟琳按住空螺，听见回声先于浪响。伊沃把腕套穿上，向里桩拉时手背仍能屈伸。',[
      ['装一枚空螺音扣',()=>choose('comb-listener','selene')],['编一副双襻软腕套',()=>choose('comb-bracer','ivo')] ]);
  }
  quietComb({world,s,flags,ex,show,note,part,fight,readings:combReadings(s)});
}
