import {line,poly,oval} from './paint.mjs';
export function saltHouse(c,p,f){
 const w=f.w||3,h=f.h||3,a=(x,y,z=0)=>p(f.x+x,f.y+y,z),name=f.label||'';
 const fish=/鱼|伙房/.test(name),dorm=/寄宿|平铺|薪|房/.test(name),official=/会馆|公|理算|印|阁/.test(name);
 const top=official?42:dorm?31:27,deck=8;
 const A=a(0,0,top),B=a(w,0,top),D=a(0,h,top),E=a(w,h,top);
 poly(c,[D,E,a(w,h,deck),a(0,h,deck)],dorm?'#a89177':'#bbb39a','#6c776c');
 poly(c,[E,B,a(w,0,deck),a(w,h,deck)],'#8a998c','#687b72');
 for(let i=.12;i<w;i+=.83){line(c,...a(i,h,.5),...a(i,h,top),'#768071',2);line(c,...a(i,h,deck-1),...a(Math.min(i+.58,w),h,0),'#627268',1.1);}
 const rise=official?19:fish?6:13;
 const R=a(-.12,h*.23,top+rise),S=a(w+.18,h*.23,top+rise);
 poly(c,[a(-.2,-.1,top),a(w+.18,-.12,top),S,R],'#728882','#647970');
 poly(c,[R,S,a(w+.23,h+.23,top-5),a(-.24,h+.23,top-5)],official?'#677f7d':fish?'#7d9893':'#908f79','#596e67');
 for(let i=-.04;i<w;i+=.4)line(c,...a(i,h*.24,top+rise),...a(i,h+.2,top-5),'#c0c1a651',.85);
 line(c,...R,...S,'#c8c2a0',2.2);line(c,...a(-.1,h+.18,top-5),...a(w+.18,h+.18,top-5),'#5e7265',2);
 const x0=w*.08,x1=w*.66;
 poly(c,[a(x0,h,deck),a(x1,h,deck),a(x1,h,top*.68),a(x0,h,top*.68)],'#485d58','#6e775f');
 poly(c,[a(-.04,h-.05,top*.70),a(x1+.13,h-.05,top*.70),a(x1+.13,h+.65,top*.51),a(-.04,h+.65,top*.51)],official?'#64817e':'#b1ad8c','#788774');
 for(let i=.3;i<x1;i+=.7){line(c,...a(i,h+.59,top*.51),...a(i,h+.59),'#746e52',2);}
 const at=a(w*.69,h+.16,deck);
 if(fish){
  for(let j=0;j<5;j++){const xx=at[0]-13+j*6,yy=at[1]+j*1.8;oval(c,xx,yy-2,4.4,1.5,'#91a4a0');poly(c,[[xx-3,yy-2],[xx-7,yy-4],[xx-6,yy]],'#869b98');}
 }else if(official){
  const g0=a(w*.59,h,top*.88),g1=a(w*.9,h,top*.88);line(c,...g0,...g1,'#766a4f',2);
  for(let j=0;j<4;j++){const [xx,yy]=a(w*(.6+j*.074),h,top*.83);poly(c,[[xx,yy],[xx+3,yy+1],[xx+3,yy+11],[xx,yy+13]],j%2?'#bc9f72':'#ddcc9f','#8e8b70');}
 }else{
  for(let i=0;i<3;i++){const dx=at[0]-12+i*11,dy=at[1]+i*2;poly(c,[[dx-8,dy],[dx-1,dy-6],[dx+8,dy-1],[dx+2,dy+3]],'#d4d1b9','#a4a891');line(c,dx-8,dy+2,dx+2,dy+5,'#99876b',2);}
 }
 for(const t of [.24,.60]){const y=h*t;poly(c,[a(w,y,14),a(w,y+.47,14),a(w,y+.47,23),a(w,y,23)],'#627970','#718276');}
}
