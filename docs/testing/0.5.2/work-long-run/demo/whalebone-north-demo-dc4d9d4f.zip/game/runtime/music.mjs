import {regionalCue,regionalSeconds,regionalArrangement} from './headland-music/market-and-soundings.mjs';
// Each row is a four-beat bar. Parallel lists give the pitch above the tonic and
// the attack within that bar. Empty rows are written rests.
const at=[
 [0,1.5,2.5],[.5,1.5,3],[0,2],[0,.75,1.5,3],[0,1,2.5],[1,2,3],
 [0,1,2,3],[0,.5,2,3],[0,1.5,3],[0,.75,2.5],[.5,2],[]];
const themes={
 vigil:{root:146.83,beat:.78,voice:'bell',bass:[0,-5,-2,3,0,-5,5,3,-2,0,-5,0],
  tune:[[7,5,3],[2,5,7],[3,0],[3,5,7,10],[9,7,5],[3,2,0],[0,3,7,12],[10,7,5,3],[5,3,2],[7,5,3],[2,0],[]],
  answer:[null,null,7,3,null,7,10,null,5,3,null,null]},
 sailing:{root:164.81,beat:.66,voice:'wood',bass:[0,5,7,9,5,7,2,5,7,0,5,0],
  tune:[[0,7,9],[12,9,7],[5,2],[0,4,7,9],[12,14,9],[7,5,4],[2,5,9,11],[14,12,9,7],[5,9,7],[4,7,9],[5,0],[]],
  answer:[null,4,null,7,5,null,9,7,5,null,4,null]},
 winter:{root:174.61,beat:.83,voice:'reed',bass:[0,-5,2,0,-2,-5,3,2,-2,0,-5,0],
  tune:[[0,2,7],[5,3,2],[7,10],[2,3,5,8],[7,5,3],[2,7,5],[10,8,7,5],[3,2,3,7],[8,5,2],[0,2,7],[3,0],[]],
  answer:[null,null,2,null,7,3,0,5,null,3,null,null]},
 alarm:{root:130.81,beat:.53,voice:'fiddle',bass:[0,0,-1,-5,0,3,6,-1,3,0,-1,0],
  tune:[[0,0,7],[6,1,0],[3,6],[0,1,6,7],[10,7,6],[3,1,0],[0,3,6,10],[12,10,7,6],[7,6,1],[0,7,6],[1,0],[]],
  answer:[null,0,null,7,null,1,6,3,1,0,null,null]},
 coda:{root:146.83,beat:.91,voice:'bow',bass:[0,-5,3,5,3,0,-5,3,5,0,-5,0],
  tune:[[3,5,7],[10,7,5],[3,0],[0,3,5,7],[10,12,10],[7,5,3],[5,7,10,12],[15,12,10,7],[5,3,0],[3,5,7],[3,0],[]],
  answer:[null,null,3,null,5,3,7,10,3,null,null,null]}
};
export function formSeconds(theme){return regionalSeconds(theme)??themes[theme].beat*4*at.length;}
export function scoreFor(map,state,battle=false){
 if(battle)return 'alarm';
 if(state.cycle?.id==='afterwatch')return map.id==='next-bell'?'coda':'winter';
 if(map.id==='burial-cape'||map.id==='letter-niche')return 'coda';
 if(['anchor-yard','ratchet-loft','flood-stair'].includes(map.id)||state.flags['harbor-tilted']&&!state.flags['base-safe'])return 'alarm';
 const regional=regionalCue(map,state);if(regional)return regional;
 if(map.act>=3&&map.act<=5)return 'winter';
 if(map.act===2||state.flags['coffin-aboard'])return 'sailing';
 return 'vigil';
}
export function arrange(ctx,bus,name){
 const region=regionalArrangement(ctx,bus,name);if(region)return region;
 const part=themes[name],beat=part.beat,volume=ctx.createGain();
 volume.gain.value=.76;volume.connect(bus);
 const live=new Set();let timer,bar=0,when=ctx.currentTime+.045,ended=false;
 function tone(start,pitch,duration,wave,level,attack=.035){
  const voice=ctx.createOscillator(),gain=ctx.createGain(),f=part.root*2**(pitch/12);
  voice.type=wave;voice.frequency.setValueAtTime(f,start);
  const a=Math.min(attack,duration*.3);gain.gain.setValueAtTime(.0001,start);gain.gain.exponentialRampToValueAtTime(level,start+a);
  gain.gain.exponentialRampToValueAtTime(level*.35,start+duration*.67);gain.gain.exponentialRampToValueAtTime(.0001,start+duration);
  voice.connect(gain);gain.connect(volume);live.add(voice);
  voice.onended=()=>{live.delete(voice);voice.disconnect();gain.disconnect();};voice.start(start);voice.stop(start+duration+.01);
 }
 function lead(t,pitch,len){
  const v=part.voice;
  tone(t,pitch,len,v==='bell'||v==='bow'?'sine':'triangle',v==='fiddle'?.039:.043,v==='bow'?.14:.035);
  if(v==='bell')tone(t+.009,pitch+19,len*.46,'sine',.014);
  if(v==='bow'||v==='reed')tone(t+.018,pitch+12.03,len*.84,'sine',.013,.13);
  if(v==='wood')tone(t,pitch+12,len*.28,'sine',.014);
  if(v==='fiddle')tone(t+.01,pitch+7,len*.58,'triangle',.009);
 }
 function playBar(i,start){
  const row=part.tune[i];
  if(!row.length)return;
  const bass=part.bass[i]-12,raised=i>=3&&i<=8;
  tone(start,bass,beat*(raised?1.7:2.65),'sine',.062,.13);
  if(raised){tone(start+beat*2.05,bass+7,beat*1.15,'triangle',.026,.055);}
  row.forEach((pitch,j)=>{const attack=at[i][j],next=at[i][j+1]??3.9;
   const len=Math.min((next-attack)*.79,(name==='alarm'?1.15:2.4))*beat;lead(start+attack*beat,pitch,len);});
  const lower=part.answer[i];if(lower!==null)tone(start+2.28*beat,lower-5,beat*1.35,'sine',.022,.14);
  if(name==='alarm'&&i>=3&&i<=9)for(const k of [0,1.5,3])tone(start+k*beat,-21,beat*.23,'triangle',.044,.009);
 }
 function schedule(){
  if(ended)return;
  if(ctx.state==='running'){
   if(when<ctx.currentTime-.1)when=ctx.currentTime+.04;
   while(when<ctx.currentTime+.45){playBar(bar,when);bar=(bar+1)%at.length;when+=4*beat;}
  }
  timer=setTimeout(schedule,110);
 }
 schedule();
 return ()=>{ended=true;clearTimeout(timer);const t=ctx.currentTime;volume.gain.setTargetAtTime(.0001,t,.018);
  for(const node of live){try{node.stop(t+.12);}catch{}}setTimeout(()=>volume.disconnect(),180);};
}
