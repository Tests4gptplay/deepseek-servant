import {line,rand} from '../paint.mjs';
const locations=new Set(['edge-bleach','rib-survey','red-beacon','burial-cape']);
const runsByMap=new WeakMap();
function shoreRuns(map,tiles){
 const w=map.width,h=map.height,runs=[];
 const edges=[
  {n:w,wet:i=>tiles[0][i],point:i=>[i,0],out:[0,-1]},
  {n:h,wet:i=>tiles[i][0],point:i=>[0,i],out:[-1,0]},
  {n:w,wet:i=>tiles[h-1][i],point:i=>[i,h],out:[0,1]},
  {n:h,wet:i=>tiles[i][w-1],point:i=>[w,i],out:[1,0]}];
 for(const [side,edge] of edges.entries()){
  let start;
  for(let i=0;i<=edge.n;i++){
   const wet=i<edge.n&&edge.wet(i)==='water';
   if(wet&&start===undefined)start=i;
   else if(!wet&&start!==undefined){
    runs.push({side,a:edge.point(start),b:edge.point(i),out:edge.out,left:start===0,right:i===edge.n});start=undefined;
   }
  }
 }
 runsByMap.set(map,runs);return runs;
}
export function waterBeyondTheQuay(c,p,map,s,t,tiles,visible){
 if(!locations.has(map.id))return;
 const high=s.tide==='high',rgb=high?'88,144,153':'116,164,157';
 const runs=runsByMap.get(map)||shoreRuns(map,tiles);
 for(const {a,b,out,side,left,right} of runs){
  const ux=b[0]-a[0],uy=b[1]-a[1],length=Math.hypot(ux,uy),tx=ux/length,ty=uy/length;
  const outer=side<2?3.9:5.3;
  const end=(q,sign,atCorner)=>p(q[0]+out[0]*outer+(atCorner?sign*tx*outer:0),q[1]+out[1]*outer+(atCorner?sign*ty*outer:0));
  const A=p(...a),B=p(...b),C=end(b,1,right),D=end(a,-1,left);
  const anchor=p((a[0]+b[0])/2,(a[1]+b[1])/2);
  const pointAway=p((a[0]+b[0])/2+out[0]*outer,(a[1]+b[1])/2+out[1]*outer);
  const vx=B[0]-A[0],vy=B[1]-A[1],vl=Math.hypot(vx,vy),nx=-vy/vl,ny=vx/vl;
  const depth=nx*(pointAway[0]-anchor[0])+ny*(pointAway[1]-anchor[1]);
  if(Math.abs(depth)<.25)continue;
  const g=c.createLinearGradient(...anchor,anchor[0]+nx*depth,anchor[1]+ny*depth);
  for(const [stop,alpha] of [[0,1],[.13,.97],[.36,.73],[.68,.23],[1,0]])g.addColorStop(stop,'rgba('+rgb+','+alpha+')');
  c.beginPath();c.moveTo(...A);c.lineTo(...B);c.lineTo(...C);c.lineTo(...D);c.closePath();c.fillStyle=g;c.fill();
  for(let j=0;j<length*2;j++){
   const portion=(j+.2+rand(j,side+3)*.55)/(length*2),reach=.16+rand(j,side+87)*outer*.83;
   const x=a[0]+ux*portion+out[0]*reach,y=a[1]+uy*portion+out[1]*reach;
   const [sx,sy]=p(x,y);if(!visible(sx,sy,22))continue;
   const amp=(1-reach/outer)*.25,breath=Math.sin(t*.51+j*2.13)*.65;
   line(c,sx,sy+breath,sx+2+rand(j,side+38)*10,sy+breath-.3,'rgba(221,225,193,'+amp+')',.7);
  }
 }
}
