import {line,oval,poly} from '../paint.mjs';
import {box,plate} from '../voyage-shapes.mjs';

const timber=['#b28358','#855739','#674633'];
const iron='#475856';
function stroke(c,p,a,b,color,width){
  line(c,...p(...a),...p(...b),color,width);
}
function bowl(c,p,x,y,z,r,cream){
  const [a,b]=p(x,y,z);
  c.fillStyle='#617576';c.beginPath();c.moveTo(a-r,b);
  c.bezierCurveTo(a-r*.65,b+r*.86,a+r*.65,b+r*.86,a+r,b);c.fill();
  oval(c,a,b,r,r*.34,'#cdc6a7');oval(c,a,b-.3,r*.74,r*.23,cream);
}
function table(c,p,x,y,served){
  for(const [dx,dy] of [[.18,.12],[2.37,.12],[.18,1.06],[2.37,1.06]])
    box(c,p,x+dx,y+dy,.13,.14,1,14,['#785b41','#635341','#524d3c']);
  box(c,p,x,y,2.72,1.35,15,3.8,['#b87b52','#885b40','#66503e']);
  for(let i=1;i<5;i++)stroke(c,p,[x+i*.53,y,19],[x+i*.53,y+1.3,19],'#986443',1.05);
  for(const dx of [.12,2.05]){
    plate(c,p,x+dx,y+.10,.4,.2,19.2,'#626b5f','#4b574e');const a=p(x+dx+.20,y-.02,18);
    oval(c,...a,3.1,2.1,'#d2b17e');
  }
  plate(c,p,x+.34,y+.12,.58,.9,19.5,'#c9ceae','#8c987c');
  for(let i=0;i<3;i++)stroke(c,p,[x+.4+i*.13,y+.16,20],[x+.4+i*.13,y+.94,20],'#6a8880',1);
  bowl(c,p,x+.49,y+.46,20,6.6,'#deb77b');bowl(c,p,x+1.43,y+.40,20,8,'#e5c394');
  bowl(c,p,x+2.16,y+.91,20,5.9,served?'#bd9864':'#dccdb0');
  stroke(c,p,[x+1.30,y+.97,21],[x+1.88,y+.71,21],'#4c5147',2.1);
  oval(c,...p(x+1.24,y+.99,21),3.1,1.4,'#7e8e78');
}
function cauldron(c,p,x,y,steam,t){
  const [a,b]=p(x,y,23);
  oval(c,a,b+12,17,5.3,'#564e4173');c.fillStyle='#435855';c.beginPath();
  c.moveTo(a-15,b);c.bezierCurveTo(a-15,b+17,a+15,b+17,a+15,b);c.fill();
  oval(c,a,b,15,5,'#acb3a0');oval(c,a,b,12,3.4,'#d5b477');
  oval(c,a-16,b+2.5,2.9,2.2,iron);oval(c,a+16,b+2.5,2.9,2.2,iron);
  if(steam)for(let i=0;i<3;i++){
    const dx=a-7+i*6,offset=Math.sin(t*.9+i)*1.8;c.beginPath();c.moveTo(dx,b-3);
    c.bezierCurveTo(dx-6+offset,b-8,dx+5+offset,b-12,dx+offset,b-17-i*2);
    c.strokeStyle='#e6e2c1ab';c.lineWidth=1.5;c.stroke();
  }
}
function skiff(c,p,x,y,low,t){
  const outline=[[0,.40],[.55,0],[3.5,.02],[4.18,.58],[3.48,1.04],[.55,1.05]];
  const at=z=>outline.map(([dx,dy])=>p(x+dx,y+dy,z));
  poly(c,at(3),'#526f67','#3f5852');
  for(let i=1;i<=4;i++){
    const q=outline[i],n=outline[(i+1)%outline.length];
    poly(c,[p(x+q[0],y+q[1],3),p(x+n[0],y+n[1],3),p(x+n[0],y+n[1],11),p(x+q[0],y+q[1],11)],i<3?'#a8794f':'#79533b','#5a5547');
  }
  poly(c,at(11),'#cba77a','#806044');
  for(let n=.7;n<3.6;n+=.48)stroke(c,p,[x+n,y+.16,11.5],[x+n,y+.89,11.5],'#a17b58',1);
  for(const dx of [.77,2.94]){
    box(c,p,x+dx,y+.09,.21,.83,11.1,1.5,['#bb9667','#967c55','#796644']);
  }
  stroke(c,p,[x+1.97,y+.04,14],[x+2.11,y+.05,35],'#565a4a',2.6);
  stroke(c,p,[x+2.11,y+.05,35],[x+2.48,y+.05,35],'#696b56',2.5);
  cauldron(c,p,x+1.95,y+.55,low,t);
  stroke(c,p,[x+.35,y+.72,13],[x-.2,y+1.7,4],'#b89a67',1.7);
  const pin=p(x-.2,y+1.7);oval(c,...pin,3.6,2.2,'#736a51');
}
function fish(c,p,x,y,high){
  stroke(c,p,[x,y,1],[x,y,38],'#645542',3.6);
  stroke(c,p,[x,y,34],[x+.76,y,34],'#86643f',2.4);
  const [a,b]=p(x+.50,y+.02,high?30:23);
  line(c,a-4,b-6,a-4,b-1,'#b59765',1);line(c,a+5,b-6,a+5,b-1,'#b59765',1);
  oval(c,a,b+2,10.4,4.6,'#75908b');poly(c,[[a+6,b+2],[a+15,b-2],[a+15,b+7]],'#b58c62');
  oval(c,a-5.7,b,1.2,1.2,iron);
}
export function berthObjects(c,p,feature,state,time){
  const {id,x,y}=feature,flags=state.flags;
  switch(id){
    case 'pot-table-door':table(c,p,x-.40,y-.72,!!flags['pot-called']);return true;
    case 'pot-blue-load':skiff(c,p,x-5.4,y-8.1,state.tide==='low',time);return true;
    case 'pot-outer-ring':
    case 'pot-inner-ring':{
      const inner=id==='pot-inner-ring',used=!!flags[inner?'pot-kiln-berth':'pot-low-berth'];
      box(c,p,x,y,.53,.48,0,17,timber);const [a,b]=p(x+.27,y+.26,18);
      c.beginPath();c.ellipse(a,b-3,6,7,-.38,0,Math.PI*2);c.strokeStyle=used?'#be9756':'#60706c';c.lineWidth=2.5;c.stroke();c.lineWidth=1;
      if(used)for(let i=0;i<3;i++)stroke(c,p,[x+.18,y+.28,13+i*1.3],[x+1.45,y+.8,5+i*.4],'#c6a16a',1.5);
      return true;
    }
    default:return false;
  }
}
export function placeBerth(c,p,map,state,t,ordered){
  if(map.id!=='bread-underdoor')return;
  ordered.push([14.5,()=>fish(c,p,5.32,9.14,!!state.flags['pot-goose-face'])]);
  ordered.push([10.7,()=>skiff(c,p,1.75,3.78,true,t)]);
  ordered.push([21.2,()=>bowl(c,p,8.85,12.75,2,7,'#aaa689')]);
}
