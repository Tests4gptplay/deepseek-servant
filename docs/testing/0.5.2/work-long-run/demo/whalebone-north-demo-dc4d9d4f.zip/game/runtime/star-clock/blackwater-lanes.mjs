export const charts={
 high:{start:[0,3],end:[5,1],land:new Set(['1,2','2,1','3,1','4,3','5,3','2,4']),flow:{'2,3':[0,-1],'3,2':[1,0],'1,1':[0,-1]}},
 low:{start:[0,3],end:[5,1],land:new Set(['2,3','3,3','1,1','3,0','4,1','5,3']),flow:{'1,2':[1,0],'3,2':[1,0],'1,4':[0,-1]}}
};
export const directions=[['向北划',0,-1],['向东划',1,0],['向南划',0,1],['向西划',-1,0]];
export function rowOne(chart,boat,dx,dy){
 const q=[boat[0]+dx,boat[1]+dy],isOpen=([x,y])=>x>=0&&x<6&&y>=0&&y<5&&!chart.land.has([x,y].join(','));
 if(!isOpen(q))return {at:[...chart.start],outcome:'ground'};
 const stream=chart.flow[q.join(',')];if(stream){q[0]+=stream[0];q[1]+=stream[1];if(!isOpen(q))return {at:[...chart.start],outcome:'ground'};}
 return {at:q,outcome:q.join(',')===chart.end.join(',')?'landed':stream?'drift':'stroke'};
}
