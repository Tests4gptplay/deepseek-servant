import {face,rod,beam,plate,box,lamp,ring,sail,hanging,tar,brass,oak,poly,oval,rand} from './fixtures.mjs';
function lid(c,p,x,y,w,h,style,t){
 const z=11,crest=z+Math.min(25,h*5.5),e=y+h;
 box(c,p,x+.14,y+.12,w-.25,h-.23,-5,z+4,['#77827c','#645f51','#475858']);
 const sides=[['#728b89','#647e80','#8d9c91'],['#6b8688','#526f75','#88988d'],['#82958b','#627e80','#98a393'],['#79857c','#64716c','#949888']][style];
 const mid=y+h*.48;
 face(c,p,[[x,y,z],[x+w,y,z],[x+w,mid,crest],[x,mid,crest]],sides[0],'#566966');
 face(c,p,[[x,mid,crest],[x+w,mid,crest],[x+w,e,z],[x,e,z]],sides[1],'#4a6264');
 for(let row=0;row<5;row++){const k=row/5,l=(row+1)/5;
  for(let i=-1;i<w*2;i++){const a=Math.max(0,(i+(row%2)*.5)/2),b=Math.min(w,(i+1+(row%2)*.5)/2);if(b<=a)continue;
   const ay=mid+(e-mid)*k,by=mid+(e-mid)*l,az=crest+(z-crest)*k,bz=crest+(z-crest)*l;
   const cols=['#7d908b','#617e80','#6f8987','#80918a','#648082','#718985'];
   face(c,p,[[x+a,ay,az+.2],[x+b,ay,az+.2],[x+b-.018,by,bz],[x+a,by,bz+1]],cols[Math.floor(rand(i+22,row+style*9)*cols.length)],'#5e7775');
  }
 }
 rod(c,p,[x,mid,crest+1],[x+w,mid,crest+1],sides[2],3.3);
 rod(c,p,[x,e,z],[x+w,e,z],'#ad9980',2.1);
 const inset=x+w*.35;face(c,p,[[inset,e,2],[inset+1.5,e,2],[inset+1.5,e,9],[inset,e,9]],'#354c4c');
 for(let i=0;i<5;i++)rod(c,p,[inset+i*.28,e+.015,2],[inset+i*.28,e+.015,8],i%2?'#d2a466':'#807858',1.8);
 if(style===0){box(c,p,x+w*.58,mid-.18,.56,.53,crest,12,tar);box(c,p,x+w*.51,mid-.24,.75,.67,crest+12,3,brass);lamp(c,p,x+w*.81,e,8,t,true,.75);}
 if(style===1){box(c,p,x+w*.48,mid-.22,1.18,.65,crest,11,oak);for(const k of [.15,.54,.9])lamp(c,p,x+w*.48+k,mid+.38,crest+9,t,true,.52);}
 if(style===2){for(const k of [.24,.56]){const a=x+w*k;beam(c,p,[a,e,7],[a+.65,e,1],3);} }
 if(style===3){hanging(c,p,[x+.35,e,12],[x+w-.3,e,12],9,'#9c956d');for(let j=0;j<9;j++)rod(c,p,[x+.5+j*.53,e,10],[x+1+j*.49,e,2+(j%3)],'#95987e',1.1);}
}
export function roofBuildings(c,p,f,t){if(f.kind!=='building')return false;const style={7:0,18:1,2:2,11:3}[f.x];if(style===undefined)return false;lid(c,p,f.x,f.y,f.w,f.h,style,t);return true;}
export function roofThings(c,p,e,s,t){
 const x=e.x,y=e.y;
 if(e.id==='warm-sleeves'){beam(c,p,[x-.42,y+.3,0],[x-.42,y+.3,20],3);beam(c,p,[x+1.04,y+.3,0],[x+1.04,y+.3,20],3);hanging(c,p,[x-.42,y+.3,20],[x+1.04,y+.3,20],2,'#a39374');sail(c,p,[x-.16,y+.3,19],[x+.20,y+.3,19],14,'#ecd8ad',t);sail(c,p,[x+.31,y+.31,19],[x+.69,y+.31,19],8,'#b58067',t);return true;}
 if(e.id==='reverse-groove'){box(c,p,x-.2,y+.42,1.6,.26,0,5,oak);for(const [a,col] of [[.12,'#d7c69a'],[.48,'#a0a391']])rod(c,p,[x+a,y+.42,5],[x+a+.53,y+.68,5],col,1.8);return true;}
 if(e.id==='under-roof-knock'){box(c,p,x-.67,y+.6,1,.78,0,4,oak);plate(c,p,x-.57,y+.67,.82,.58,4,'#324746');
  for(const k of [.1,.39,.68])rod(c,p,[x-.55+k,y+.66,6],[x-.55+k,y+1.23,6],'#a48b69',2.7);
  if(s.flags['roof-shelter']){hanging(c,p,[x-.62,y+.7,9],[x+.25,y+1.3,6],4,'#d99771',3.2);lamp(c,p,x-.41,y+.72,6,t,true,.55);}return true;}return false;
}