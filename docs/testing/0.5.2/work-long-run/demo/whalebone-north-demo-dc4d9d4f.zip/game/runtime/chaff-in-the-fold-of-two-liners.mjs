import {poly,line,oval} from './heelturn-cabins.mjs';
export function liningInTheSteam(c,x,y,i){
 const bent=i===5?3:0;
 poly(c,[[x+7,y+14],[x+25,y+11],[x+43,y+15],[x+41,y+29],[x+31,y+34],[x+12,y+29]],'#7b634c','#685740');
 poly(c,[[x+9,y+15],[x+21,y+16],[x+27,y+11],[x+33,y+19],[x+42,y+17],[x+40,y+28],[x+29,y+30],[x+14,y+28]],'#b77c35');
 for(const [a,b] of [[15,19],[23,23],[29,17],[35,24],[19,26]]){
  const xx=x+a+(bent&&a===29?2:0),yy=y+b;
  poly(c,[[xx-4,yy+1],[xx-1,yy-2],[xx+4,yy-2],[xx+2,yy+1],[xx-2,yy+3]],'#ecbd57','#75532d');
  line(c,[[xx-3,yy+2],[xx+2,yy-1]],'#fae5a1',1);
 }
 line(c,[[x+7,y+31],[x+18,y+35],[x+34,y+33],[x+42,y+29]],'#574e3c',1.4);
 for(let j=0;j<4;j++)line(c,[[x+8+j*9,y+32+(j===1?3:0)],[x+10+j*9,y+29+(j===1?3:0)]],'#e7d2a5',1.25);
}
