import {poly,line,oval,rand} from './paint.mjs';

export function lateHorizon(c,w,h,map,t,state) {
 if(map.act<4 || map.biome?.includes('interior'))return false;
 const winter=map.act===5, funeral=map.id==='burial-cape',alarm=map.id==='anchor-yard'||map.id==='flood-stair';
 const dawn=funeral||map.id==='safe-keel'||map.id==='lee-cutter',horizon=h*(alarm?.23:.30);
 const sky=c.createLinearGradient(0,0,0,h);sky.addColorStop(0,alarm?'#4f5a6b':dawn?'#adb8c3':winter?'#94a8bd':'#809caa');sky.addColorStop(.27,alarm?'#c09478':dawn?'#f6d7a6':'#d6e2d9');sky.addColorStop(.43,alarm?'#5c777a':'#94b6b3');sky.addColorStop(1,'#527f86');c.fillStyle=sky;c.fillRect(0,0,w,h);
 if(!alarm)oval(c,w*(funeral?.27:.73),horizon*.43,funeral?18:13,funeral?18:13,'#ffedc7');
 const ridge=(y,scale,color,peaks)=>{
   const pts=[[-15,horizon+8]];for(let i=0;i<peaks.length;i++)pts.push([w*i/(peaks.length-1),y-peaks[i]*scale]);pts.push([w+10,horizon+9]);poly(c,pts,color);
 };
 if(alarm){
  ridge(horizon,1,'#59686c',[8,4,14,6,12,6,6,12,2]);for(let i=0;i<25;i++){const x=w*(i-.4)/24,y=horizon-8-13*Math.sin(i*.28),rise=8+rand(i,41)*21;poly(c,[[x-12,y],[x-10,y-rise],[x+2,y-rise-8],[x+12,y-rise+2],[x+11,y+2]],'#596368');if(i%5===0){line(c,x,y-5,x-5,y-rise-20,'#535f61',2);line(c,x-4,y-rise-14,x+18,y-rise-20,'#586267',2);}}
 }else{
  const a=winter?[5,20,21,56,81,46,55,11,27,78,64,20,10,31]:funeral?[5,14,26,21,6,10,16,9,22,13,7,3]:[7,16,37,74,58,15,9,43,62,27,12,32,14];
  ridge(horizon-8,h*.00088,'#879d9e',a.map(v=>v*1.5));ridge(horizon+2,h*.0011,winter?'#607e85':'#738e8c',a);
  for(let i=1;i<a.length-1;i++){if(a[i]<a[i-1]||a[i]<a[i+1])continue;const x=w*i/(a.length-1),y=horizon+2-a[i]*h*.0011;poly(c,[[x-15,y+14],[x,y],[x+18,y+9],[x+7,y+8],[x+3,y+6]],winter?'#e2e6d9':'#c8d2bd');}
  if(!winter&&!funeral&&map.id!=='safe-keel'){for(let i=0;i<3;i++){const x=w*(.13+i*.12),y=horizon+5+i*2;poly(c,[[x-19,y],[x-4,y-2],[x+1,y-8],[x+9,y-3],[x+17,y]],'#d6e6dd');}}
 }
 for(let i=0;i<63;i++){const x=(rand(i,44)*w+t*(.5+i%3))%(w+23)-10,y=horizon+9+rand(i,46)*(h-horizon);
  line(c,x,y,x+4+rand(i,28)*21,y,alarm?'#bcc8b248':'#e6ead987',.8);}
 return true;
}

export function nearPoint(c,x,y,t,active){
 if(!active)return;
 const k=.7+Math.sin(t*3)*.13;c.save();c.globalAlpha=k;
 oval(c,x,y+2,16,5,'#294d4f62');
 for(const d of [-1,1]){line(c,x+d*14,y+1,x+d*9,y+3,'#f4d899',1.6);line(c,x+d*14,y+1,x+d*11,y-2,'#f4d899',1.6);}
 c.restore();
}
