import {kitTable} from './field-kit/bench.mjs';
import {lessonSummary} from './passage-school.mjs';
import {ledger} from './vocation-book.mjs';
import {paths,nextXP,terms,selected} from '../rules/vocations.mjs';
import {syncParty,stats} from './party.mjs';
import {items,equip,consume} from './gear.mjs';
export function crewMenu(ctx,close){
 const {world,state,ui,sound}=ctx,s=state.player,ex=syncParty(world,s),defs=items(world);
 function roster(){ui.show('party','同行者',ex.roster.map(id=>{
   const h=ex.heroes[id],a=world.actors[id];return a.name+' · '+(selected(s,id)?.name||a.job||'同行者')+'　Lv'+h.level+'　体力 '+h.hp+'　气力 '+h.mp;
 }).join('\n'),[...ex.roster.map(id=>[world.actors[id].name,()=>inspect(id)]),['返回',close]]);}
 function inspect(id){
  const h=ex.heroes[id],d=world.actors[id],max=stats(world,id,h.level);
  const options=[['摊开整备布',()=>kitTable(ctx,id,defs,()=>inspect(id))]];
  for(const [key,n] of Object.entries(ex.stock)){
   const gear=defs[key];if(!gear||!(n>0)||(gear.owner&&gear.owner!==id))continue;
   if(gear.slot==='consumable')options.push(['服用'+gear.name+' ×'+n,()=>{if(!consume(world,s,id,key,max))ui.toast('此刻无需用药。');else sound('solve');inspect(id);}]);
   else if(h[gear.slot]!==key)options.push(['装备'+gear.name,()=>{equip(world,s,id,key);sound('touch');inspect(id);}]);
  }
  if(paths[id])options.push(['行当与修习',()=>ledger(ctx,id,()=>inspect(id))]);
  if(h.charm)options.push(['卸下'+defs[h.charm].name,()=>{ex.stock[h.charm]=(ex.stock[h.charm]||0)+1;delete h.charm;inspect(id);}]);
  const worn=[defs[h.weapon]?.name||h.weapon,defs[h.armor]?.name||h.armor,defs[h.charm]?.name].filter(Boolean).join(' ／ ');
  const protection=Object.entries(defs[h.charm]?.resists||{}).map(([k,n])=>terms[k]+' '+Math.round(n*100)+'%').join('、');
  ui.show('gear',d.name+' · '+(selected(s,id)?.name||d.job),'Lv'+h.level+'　经验 '+h.xp+'/'+(h.level===100?'已满':nextXP(d.growth?.xpBase||16,h.level))+'　体力 '+h.hp+'/'+max.hp+'　气力 '+h.mp+'/'+max.mp+'\n'+worn+(lessonSummary(s,id)?'\n'+lessonSummary(s,id):''),
   [...options,['回到队伍',roster]],'攻击 '+(max.attack+(defs[h.weapon]?.power||0))+'　护甲 '+(max.defense+(defs[h.armor]?.defense||0))+(protection?'　饰品防护 '+protection:''));
 }
 roster();
}
