import {dialogue} from '../dialogue.mjs';
import {cutRows,shine} from './lamp-light-on-the-cuts.mjs';
function readAtTheStone(ctx,returnToCloth){
 const {ui,state}=ctx,player=state.player,f=player.flags;
 const present=[f['epitaph-fault'],f['epitaph-rescue']];
 const words=present.map((made,i)=>made?cutRows[i]:i?'下幅布还压在石粉里。':'上幅布还压在石粉里。');
 const body=f['grave-signed']?'玛拉把收好的布搁在石边，腾出一只手移灯。':present.some(Boolean)?'新刻的那一行还粘着石屑。玛拉捏住松开的布边，另一只手把灯放低。':'布下的石面还没刻字。她把灯压到膝边，看见了布的经纬。';
 ui.show('graveside','石上的两行',body,[['把风灯放回原处',returnToCloth]]);
 const box=document.createElement('section');box.dataset.fieldSketch='stone';
 const canvas=document.createElement('canvas');canvas.width=1080;canvas.height=465;canvas.setAttribute('aria-label','白崖的石面、布罩和风灯。'+words.join(''));canvas.setAttribute('role','img');
 const lines=document.createElement('div');lines.className='stone-reading';
 for(const [i,word] of words.entries()){const line=document.createElement('span');line.textContent=word;line.dataset.cut=present[i]?'yes':'no';lines.append(line);}
 const control=document.createElement('label');control.className='stone-lamp-control';
 const label=document.createElement('span');label.textContent='灯的位置';const range=document.createElement('input');range.type='range';range.min='-2';range.max='2';range.step='0.1';range.value='0';range.setAttribute('aria-label','风灯左右位置');
 const place=document.createElement('output');
 function set(value){const v=Math.max(-2,Math.min(2,value));range.value=String(v);const position=v<-1.25?'贴左石角':v<-.35?'靠左':v>.35?(v>1.25?'贴右石角':'靠右'):'正中';place.textContent=position;range.setAttribute('aria-valuetext',position);shine(canvas,player,v);}
 range.oninput=()=>set(Number(range.value));range.onkeydown=e=>{if(e.key==='Escape'||e.key==='Enter'){e.preventDefault();e.stopPropagation();returnToCloth();}};
 let pointer=null;
 function point(e){const rect=canvas.getBoundingClientRect();set(((e.clientX-rect.left)/rect.width*720-360)/146);}
 canvas.addEventListener('pointerdown',e=>{if(pointer!==null)return;pointer=e.pointerId;canvas.setPointerCapture(pointer);point(e);});
 canvas.addEventListener('pointermove',e=>{if(pointer===e.pointerId)point(e);});
 for(const name of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(name,e=>{if(e.pointerId===pointer)pointer=null;});
 control.append(label,range,place);box.append(canvas,control,lines);ui.panel.querySelector('.options').before(box);set(0);range.focus({preventScroll:true});
}
export function clothAndStone(ctx,entity,done){
 const {state,ui}=ctx;
 const clothUI={...ui,show(mode,title,body,options,detail){
  function resume(){ui.show(mode,title,body,[...options,['放低风灯，沿石面看',()=>readAtTheStone(ctx,resume)]],detail);}
  resume();
 }};
 dialogue(clothUI,state,entity.dialogue||[],done);
}
