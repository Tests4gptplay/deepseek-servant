const names={mara:'玛拉',ivo:'伊沃'};
const holds={heron:'正拉木鹤的长颈索',seal:'正拉海豹的短背索'};
const point=(s,book,id)=>id===(book.active||'mara')?[s.x,s.y]:book.parked?.[id]||(id==='ivo'?[6,6]:[4,12]);
const checked=(x,lo,hi)=>Math.max(lo,Math.min(hi,x));
export function readTheWorkingStage(root,s){
 let group=root.querySelector('.stage-hands');
 if(s.map!=='twohand-puppet-loft'){if(group)group.remove();return;}
 if(!group){
  group=document.createElement('div');group.className='stage-hands';group.setAttribute('role','group');group.setAttribute('aria-label','吊板两端的实际位置');
  const strip=document.createElement('canvas');strip.width=176;strip.height=54;strip.setAttribute('aria-hidden','true');group.append(strip);
  const words=document.createElement('span');words.className='stage-hands-words';group.append(words);
  root.querySelector('.place').append(group);
 }
 const b=s.progress?.twoHandStage||{},active=b.active||'mara';
 const positions={ivo:point(s,b,'ivo'),mara:point(s,b,'mara')};
 const body='伊沃'+(holds[b.hold]||'手中没有绳')+'。玛拉的踏杆在'+['平位','一口','两口'][b.weight||0]+'。';
 group.querySelector('span').textContent=body;
 group.title='现在跟随'+names[active]+'。'+body;
 const cv=group.firstElementChild,ctx=cv.getContext('2d');
 ctx.clearRect(0,0,176,54);ctx.fillStyle='#193337';ctx.fillRect(0,0,176,54);
 const xy=([x,y])=>[6+checked(x,1,30)*5.15,3+checked(y,1,19)*2.35];
 ctx.strokeStyle='#8d8d70';ctx.lineWidth=1.3;ctx.beginPath();
 ctx.moveTo(...xy([4,5]));ctx.lineTo(...xy([27,5]));ctx.lineTo(...xy([27,15]));ctx.lineTo(...xy([4,15]));ctx.closePath();ctx.stroke();
 const [cx,cy]=xy([6,9]);ctx.fillStyle='#b19156';ctx.fillRect(cx,cy,17*5.15,4);
 for(const [which,cell] of [['heron',[10,6]],['seal',[21,6]]]){
  const [x,y]=xy(cell);ctx.fillStyle=b.hold===which?'#f5cd73':'#8b8a77';ctx.fillRect(x-1,y-8,2,b.hold===which?17:11);
 }
 for(const id of ['ivo','mara']){
  const [x,y]=xy(positions[id]);ctx.beginPath();ctx.fillStyle=id==='ivo'?'#8bdfd8':'#f6c586';ctx.strokeStyle='#142e32';ctx.lineWidth=2;
  if(id==='ivo'){ctx.moveTo(x,y-4.5);ctx.lineTo(x+4.5,y);ctx.lineTo(x,y+4.5);ctx.lineTo(x-4.5,y);ctx.closePath();}else ctx.arc(x,y,4,0,Math.PI*2);
  ctx.fill();ctx.stroke();
  if(id===active){ctx.beginPath();ctx.arc(x,y,6,0,Math.PI*2);ctx.strokeStyle='#fff3cf';ctx.lineWidth=1.2;ctx.stroke();}
 }
}
