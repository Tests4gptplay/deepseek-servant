// Master work uses the tool at the far end of the observed route.
export function masterWork(ctx,k,done,close){
 const s=ctx.state.player,tr=k.tr,i=tr.index,care=tr.track==='rescue',ui=ctx.ui;
 if(i<14||i===18)return done();
 const rig=tr.rig||(tr.rig={step:0,offset:0,samples:[]});
 const show=(name,body,opts,foot)=>ui.show('field-rig',name,body,[...opts,['放下器具，保留刻度',close]],foot);
 const bad=()=>{tr.mistakes=(tr.mistakes||0)+1;ctx.sound('touch');};
 if(i===14){
  const render=()=>show(care?'浮床配重':'双窗交会',care?'浮床向左压在栈桥边。向右移一格沙袋，中心指针便向右一格。两道白线之间才可送人。':'近窗与远窗各有一条水泥线。每换一站，近窗横移一格，远窗几乎不动。两线重合才可落针。',
   [[care?'沙袋往右':'测站向东',()=>{rig.offset=Math.min(3,rig.offset+1);render();}],[care?'沙袋往左':'测站向西',()=>{rig.offset=Math.max(-2,rig.offset-1);render();}],
   [care?'放浮床上桥':'落交会针',()=>{if(rig.offset!==2){bad();return render();}done();}]],'标尺　'+['● · · · │','· ● · · │','· · ● · │','· · · ● │','· · · · ◉','· · · · │ ●'][rig.offset+2]);return render();
 }
 if(i===15){
  const order=care?['垫住下轮','放松旧索','接起新索']:['插紧墙肩桩','放开漂绳','对准方位尺'];
  const render=()=>show(care?'双止动换索':'斜浪的基准索',care?'先留一道硬支点才可松开吃重的一端，最后给新索承重。':'墙上零桩先定，跑动的漂绳随后放掉，最后把角尺贴向两点。', [1,2,0].map(n=>[order[n],()=>{if(rig.step===n){rig.step++;ctx.sound('latch');if(rig.step===3)return done();}else bad();render();}]),'已经完成　'+(order.slice(0,rig.step).join(' → ')||'尚未动第一端'));return render();
 }
 if(i===16){
  const render=()=>show(care?'停梁听诊':'两站双钉',care?'先取动梁伴响。拉住止动片再取腕下的节律，免把木头的回音算作人心。':'西站先辨开钉距。把尺转到柱东，重取齐线读数。',[
   [care?'取样听腕':'记一笔钉距',()=>{const label=rig.step?(care?'三拍':'重合'):(care?'四响':'分开');if(!rig.samples.includes(label))rig.samples.push(label);ctx.sound('pilot');render();}],
   [care?'换止动片位置':'转向另一测站',()=>{rig.step=1-rig.step;render();}],
   [care?'递交两份听诊':'固化两站读数',()=>{if(rig.samples.length===2)return done();bad();render();}]],'记录　'+(rig.samples.join(' / ')||'未记录')+'　·　'+(rig.step?(care?'止动':'柱东'):(care?'动梁':'柱西')));return render();
 }
 if(i===17){
  const path=care?['让头端等在窗外','让脚端绕进凹阶','让头端循原弧入内']:['遮上湿毡','改到对侧窗孔','打开湿毡复听'];
  const render=()=>show(care?'窄窗回身':'湿毡回声',care?'窗的两侧不能同时站人，得给脚端留出退阶，最后头端沿空弧转入。':'先屏蔽湿毡的回声，再换孔对比，最后放开湿毡核对差别。',[2,0,1].map(n=>[path[n],()=>{if(n===rig.step){if(++rig.step===3)return done();ctx.sound('sash');}else bad();render();}]),'已走　'+(path.slice(0,rig.step).join(' → ')||'起点'));return render();
 }
 const final=care?['把双名回执交给家属','当地医务所保管双名回执']:['把盲区清样交给船长','当地测绘所保管盲区清样'];
 show(care?'病名归还':'留白的两份图',care?'持有人决定今后谁能取回小名和船名。':'同一条未测岸线保留空白，交到不同的人手里会改变下一班核图的方式。',final.map((text,i)=>[text,()=>{tr.custody=i?'station':'household';tr.custodyText=text;done();}]),'两种保管都接纳现有证词。');
}
