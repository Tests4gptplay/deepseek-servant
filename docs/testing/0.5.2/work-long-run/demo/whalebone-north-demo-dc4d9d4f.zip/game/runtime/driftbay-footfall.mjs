import {crossingSteps} from '../content/driftbay-crossings.mjs';
// All crossing evidence is produced by an actual successful step on this relief.
export function bayFootfall(map,s){
 const bay=map.driftbay;if(!bay)return;
 const {x,y,flags}=s,steps=s.progress.driftbaySteps;
 s.progress.driftbaySteps=(Number.isSafeInteger(steps)?steps:0)+1;
 for(const rule of crossingSteps[bay.id]||[]){
  if(!rule.when(x,y,flags))continue;
  for(const mark of rule.marks)flags[mark]=true;
  if(rule.clear)flags[rule.clear]=false;
 }
}
export function bayReading(map,s){
 if(!map.driftbay)return '';const f=s.flags,{x,y}=s;
 switch(map.driftbay.id){
 case 'scree':return y>11&&x>16?'贝壳在亮石上一路滚走。回到褐纹处分岔。':'湿沙挂在冰痕的背侧，褐纹慢慢往高处拐。';
 case 'roof':return f['driftbay-lee']?'檐下的沙留住了，能换肩。东边下行是连池。':f['driftbay-turn']?'脚印在下层往西折返。退到干沙上再听一听。':'高处的冰砂迎面飞，先绕过东侧石掌，再折回下檐。';
 case 'pools':return s.tide==='high'?'涨潮托起北侧伏木；低岸裙带菜没在水里。':'低潮露出南侧连池；高脊的伏木垂在沟底。';
 case 'throat':return y<8&&x<13?'细孔没有出口；大掌印往下游横切。':'小爪印藏在大掌印里面，沿浅沟弯过去。';
 case 'heights':return '紫脊上鸥收翅，风吹过它背后。沿这一侧绕向湾里。';
 case 'lens':return f['driftbay-fresh']?'上层清水沿芦根出海。三岔蚀孔像最初坡上的小掌。':f['driftbay-film']?'浮叶向上湾漂，盐草向内倒。向右上方沿活芦逆行。':'水面与海草走向相反。循咸苦的低洼折到芦根。';
 case 'cradle':return f['driftbay-pups']?'小爪夹在大爪之间，幼崽在干贝壳上翻身。':f['driftbay-spooked']?'海獭潜了。退回去，从低处的芦影背后走。':'亮道看得远，可你的人影也能投到对岸。';
 default:return '';
 }
}
