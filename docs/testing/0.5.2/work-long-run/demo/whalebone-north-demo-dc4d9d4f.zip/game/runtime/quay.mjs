import {line,poly,oval,arc,rand} from './paint.mjs';

export function funeralCart(c,x,y) {
 c.save();c.translate(x,y);
 oval(c,4,7,33,8,'#4b53455c');
 for(const [a,b] of [[-15,3],[13,12]]) {
   oval(c,a,b,5,7,'#5a5544');oval(c,a,b,3.2,5,'#b29969');
   line(c,a,b-5,a,b+5,'#776747',1.2);line(c,a-3,b,a+3,b,'#776747',1.2);
 }
 poly(c,[[-31,-4],[-9,-13],[27,1],[5,10]],'#c5a575','#675b44');
 poly(c,[[-31,-4],[5,10],[5,14],[-31,0]],'#80684c');
 poly(c,[[5,10],[27,1],[27,5],[5,14]],'#947e58');
 for(const n of [0,5])line(c,22-n,5+n,39-n,11+n,'#8b744e',2);
 poly(c,[[-22,-10],[-10,-17],[0,-17],[22,-6],[23,-2],[7,6]],'#7a5f49','#4f5246');
 poly(c,[[-22,-10],[7,6],[7,11],[-21,-3]],'#715943');
 poly(c,[[7,6],[23,-2],[23,2],[7,11]],'#5d5141');
 poly(c,[[-23,-12],[-9,-19],[0,-18],[23,-7],[24,-3],[7,4]],'#cabd9c','#736d54');
 poly(c,[[-13,-15],[-8,-17],[17,-4],[13,-1]],'#e8dcc0');poly(c,[[13,-1],[17,-4],[17,3],[13,6]],'#c8c2a6');
 for(let i=0;i<5;i++){line(c,-18+i*5,-10+i*2.3,-17+i*5,-12+i*2.3,'#967e5c',.7);}
 line(c,-15,-10,3,-2,'#ddd1ac',1);c.restore();
}
export function shore(c,p,x,y,side,t){
 const a=side==='south'?p(x,y+1):p(x+1,y);
 const b=p(x+1,y+1),n=rand(x,y);
 poly(c,[a,b,[b[0],b[1]+6],[a[0],a[1]+6]],'#75877d');
 line(c,a[0],a[1],b[0],b[1],'#dfd2a9',2.1);
 line(c,a[0],a[1]+7.7,b[0],b[1]+7.7,'#bbcdc0c0',1.1);
 const mid=[(a[0]+b[0])/2,(a[1]+b[1])/2];
 if(n>.2){line(c,mid[0]-6,mid[1]+9,mid[0]+5+Math.sin(t+x),mid[1]+9,'#e0e6cba0',1);}
}
export function mooring(c,x,y,t){
 c.save();c.translate(x,y);oval(c,2,2,6,2.4,'#6073638a');
 poly(c,[[-3,0],[-3,-11],[1,-13],[4,-10],[4,0],[0,2]],'#7a7360','#5a6457');
 oval(c,0,-11,4.5,2.1,'#c2b38d');arc(c,1,-5,3,-.2,2.9,'#c4a57a',1.5);
 c.restore();
}
export function coils(c,x,y){
 c.save();c.translate(x,y);c.lineWidth=1.3;c.strokeStyle='#a1845f';
 for(let k=0;k<4;k++){c.beginPath();c.ellipse(k*.6,k*.2,9-k*1.8,3.6-k*.65,-.18,0,Math.PI*2);c.stroke();}
 c.beginPath();c.moveTo(8,-2);c.quadraticCurveTo(14,-4,20,-1);c.quadraticCurveTo(23,2,28,-1);c.stroke();c.restore();
}
