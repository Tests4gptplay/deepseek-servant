import {line,oval,poly} from './heelturn-cabins.mjs';

const dark='#514335',reed='#b99e71',cut='#d4af78',green='#729a8b';
function solid(c,q,u,v,w,h,z,color){
 const a=q(u,v,z),b=q(u+w,v,z),d=q(u,v+h,z),e=q(u+w,v+h,z);
 poly(c,[b,e,q(u+w,v+h),q(u+w,v)],'#766246',dark);
 poly(c,[e,d,q(u,v+h),q(u+w,v+h)],'#8b714f',dark);poly(c,[a,b,e,d],color,dark);
}
function shoe(c,k,size,left){
 const [x,y]=k,sg=left?-1:1;
 poly(c,[[x-size*.72,y],[x-size*.38,y-size*.43],[x+size*.53,y-size*.31],[x+size*.78,y+size*.08],[x+size*.24,y+size*.32],[x-size*.58,y+size*.24]],left?'#b66b52':'#c9a06b',dark);
 line(c,[[x-2,y+1],[x+sg,y-5],[x+4,y]],'#5e5950',2);
}
function workbench(c,q){
 solid(c,q,.15,.05,2.25,.75,11,'#a68458');
 for(const a of [.38,1.16,1.87])shoe(c,q(a,.38,13),a===1.87?4:6,a===.38);
 const sh=q(2.03,.55,15);oval(c,sh,3.4,1.7,'#d9b880');line(c,[[sh[0]-2,sh[1]+1],[sh[0]+3,sh[1]+4]],'#6e603e');
}
function stove(c,q,night){
 solid(c,q,.2,.1,1.08,.67,13,'#737565');const k=q(.79,.42,14);
 oval(c,k,11,5,'#634e3f');oval(c,[k[0],k[1]-3],9,3,night?'#8c9788':'#cf9c64');
 line(c,[[k[0]-9,k[1]-2],[k[0]-5,k[1]-8],[k[0]+5,k[1]-9],[k[0]+9,k[1]-3]],'#55483b',1.8);
 line(c,[q(1.52,.12,21),q(2.58,.56,21)],reed,2);
 for(let i=0;i<7;i++){const a=q(1.5+i*.15,.13+i*.058,20);line(c,[a,[a[0],a[1]+4+(i%2)*2]],'#716253');oval(c,[a[0],a[1]+6+(i%2)*2],2,3,'#cfbba0');}
}
function loft(c,q){
 const a=q(.1,.14,21),b=q(3.1,.18,37);
 line(c,[q(.1,.14),q(.1,.14,35)],dark,3);line(c,[q(3.1,.18),q(3.1,.18,47)],dark,3);
 poly(c,[a,[a[0]+14,a[1]+9],[b[0]-15,b[1]+10],b,[b[0]-10,b[1]+13],[a[0]+21,a[1]+14]],'#648780','#465f58');
 for(let i=0;i<5;i++){const k=i/5;line(c,[[a[0]+(b[0]-a[0])*k+3,a[1]+(b[1]-a[1])*k+7],[a[0]+(b[0]-a[0])*k+7,a[1]+(b[1]-a[1])*k+11]],'#abaf8e');}
 shoe(c,q(.6,.65,4),5.5,true);shoe(c,q(.94,.67,4),5,false);
}
function bed(c,q,turned,night){
 const ex=turned?2.35:3.0,ey=turned?.94:.10;
 const v=(u,b,z)=>q(.2+ex*u-b*.28,.12+ey*u+b*.82,z);
 for(const [u,b]of [[0,0],[1,0],[0,1],[1,1]])line(c,[v(u,b,1),v(u,b,10)],dark,2.6);
 poly(c,[v(0,0,8),v(1,0,8),v(1,1,8),v(0,1,8)],'#c9baa0',dark);
 poly(c,[v(.1,.13,9),v(.85,.13,9),v(.85,.83,9),v(.1,.83,9)],night?'#6e8c84':'#abb4a0');
 for(const u of [0,1])line(c,[v(u,0,13),v(u,1,13)],cut,3.2);
 for(const b of [0,1])line(c,[v(-.07,b,10),v(1.07,b,10)],'#76573f',2.4);
 if(night){const k=v(.24,.78,4);oval(c,k,5,4,'#4a5551');oval(c,k,2,1.6,'#d2b079');}
}
function lane(c,q,f,quiet){
 const n=f.w-1,w=quiet?.95:1.5;
 poly(c,[q(.1,.03,2),q(n,.03,9),q(n,w,9),q(.1,w,2)],quiet?'#a89366':'#b19369',dark);
 for(let u=.4;u<n;u+=.83){const z=2+7*u/n;line(c,[q(u,.03,z),q(u,w,z)],'#736951',1.4);}
 for(const b of [.12,w-.10])line(c,[q(.1,b,4),q(n,b,11)],quiet?green:'#dad0a6',2);
 if(quiet){const k=q(n*.77,.68,10);c.beginPath();c.ellipse(k[0],k[1],17,7,.29,0,Math.PI*2);c.strokeStyle='#5d756b';c.stroke();}
}
export function heelFurniture(c,p,map,f,s){
 if(!f.kind.startsWith('heel-'))return false;
 const q=(u,v,z=0)=>p(f.x+u,f.y+v,z),night=map.act===6;
 if(f.kind==='heel-workbench')workbench(c,q);
 else if(f.kind==='heel-pantry')stove(c,q,night);
 else if(f.kind==='heel-loft')loft(c,q);
 else if(f.kind==='heel-longbed')bed(c,q,night||!!s.flags['heel-bed-turned'],night);
 else if(f.kind==='heel-lane'||f.kind==='heel-lane-quiet')lane(c,q,f,f.kind.endsWith('quiet'));
 else if(f.kind==='heel-water'||f.kind==='heel-stain'){
  const n=f.w-.35;for(let j=0;j<3;j++)line(c,[q(.1,.1+j*.15),q(n*.28,.55+j*.12),q(n*.63,.18+j*.2),q(n,.22+j*.18)],night?['#71999a','#9fbeb0','#5e8586'][j]:['#6e6653','#beb69b','#827a5e'][j],j===1?1.4:2.1);
 }else if(f.kind==='heel-plumb'){
  line(c,[q(.3,.3),q(.3,.3,37),q(.72,.32,37)],dark,2);
  line(c,[q(.72,.32,37),q(.72,.32,6)],'#e6d2a0',1.2);oval(c,q(.72,.32,5),3,2.2,'#5e665b');
 }else if(f.kind==='heel-lantern'){
  const k=q(.55,.45,10);solid(c,q,.16,.09,.52,.52,6,reed);oval(c,k,5,6,'#dbb676');line(c,[q(.2,.15,5),q(.2,.15,19),q(.8,.15,19)],dark,2);
 }else return false;
 return true;
}
