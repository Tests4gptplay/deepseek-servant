import {trajectory,crewSlot,liveMachine} from './anchor-release/fight.mjs';
import {underRig,rigSlot,liveRig} from './windloom-fight-art.mjs';
import {mudClapper} from './keelpot-clapper.mjs';
import {pairSigns} from './battle-pairs/signs.mjs';
import {fanFish} from './exchange-art.mjs';
import {figure,creature} from './figures.mjs';
import {heron,courseRig} from './social-fauna.mjs';
import {whelk} from './finale-sites.mjs';
import {arc,line,oval,poly} from './paint.mjs';

function strike(c,x,y,tx,ty,hero,kind,q){
 if(q<=0||['offer-line','take-line','offer-sight','sight-inside','sight-outside'].includes(kind))return;const v=1-q,inner=(a,b)=>a+(b-a)*q;
 if(kind==='skill'&&hero==='selene'){
   for(let i=0;i<3;i++)arc(c,x+8+i*10,y-16-5*i,8+i*3,-2.7+q*.5,-.25,'#a5e5df',2.1);oval(c,tx,ty,9+q*12,2.7,'#9ed6cfb0');
 }else if(hero==='mira'&&(kind==='attack'||kind==='skill')){
   const a=inner(x+5,tx),b=inner(y-21,ty);line(c,a-11,b+1,a+3,b,'#eed39a',2.3);if(kind==='skill')arc(c,tx,ty,5+q*8,0,6.3,'#d9c379',1.5);
 }else if(hero==='ivo'&&kind==='skill'){
   c.beginPath();c.moveTo(x+5,y-16);c.bezierCurveTo(x+42,y-55,tx-12,ty-24,tx,ty);c.strokeStyle='#dbc794';c.lineWidth=2;c.stroke();c.lineWidth=1;arc(c,tx,ty,5+q*3,.4,5.3,'#daca95',2);
 }else if(kind==='guard')arc(c,x+1,y-18,17,-1.35,1.35,'#c2ede2',2.5);
 else if(kind==='dodge'){for(let j=0;j<3;j++)line(c,x-j*3,y-10-j*5,x-12-j*3,y-9-j*5,'#acd8d2',1.3);}
 else if(kind==='salve'){poly(c,[[x-6,y-16],[x+5,y-21],[x+8,y-17],[x-3,y-12]],'#d9c8a1','#9ba78d');for(let i=0;i<3;i++)arc(c,x+1,y-17,6+i*3,-2.8+q*.3,-.1,'#9ccac3',1.4);}
 else if(kind==='tonic'){oval(c,x+2,y-25,3,5,'#b98354');arc(c,x,y-18,9+q*5,-2.8,-.3,'#c9dfad',2.2);}
 else{line(c,x+4,y-17,inner(x+15,tx),inner(y-35,ty),'#ead8a7',2.3);if(hero==='mara')arc(c,tx-4,ty+4,9+q*7,-1.65,1.0,'#ffe3ab',2.7);}
}
import {paintCombFight} from './comb-fight-art.mjs';
export function paintBattle(c,x,y,t,b){
 if(b.comb){paintCombFight(c,x,y,t,b);return;}
 const age=b.last?performance.now()-b.last.start:2000,attack=age>=0&&age<480?Math.sin(age/480*Math.PI):0;
 const enemy=age>170&&age<690&&b.last?.response?Math.sin((age-170)/520*Math.PI):0;
 const machineFight=b.spec.id==='anchor-clutch',snail=b.spec.id==='frost-whelk',ray=b.spec.id?.includes('ray');
 const px=x+(machineFight?61:28),py=y-(machineFight?11:7);
 if(b.windloom)underRig(c,x,y,t,b);
 if(machineFight)trajectory(c,x,y,b,t);
 pairSigns(c,x,y,b,t);
 for(let i=0;i<b.party.length;i++){
  const h=b.party[i];if(h.hp<=0)continue;
  const active=b.last?.a===i?attack:0,back=h.lane==='edge',[dx,dy]=b.windloom?rigSlot(b,h,i):machineFight?crewSlot(h,i):[[-27,-52,-82,-101][i]-(back?9:0),[-10,20,-8,23][i]-(back?9:0)];
  const hit=enemy&&b.last.response.hits.includes(h.id),ox=x+dx+(b.last?.kind==='dodge'?-8:12)*active-(hit?enemy*5:0),oy=y+dy-active*2;
  if(b.actor===i)oval(c,ox,oy+2,12,4,'#f3d8a587');
  figure(c,ox,oy,h.id,t,{scale:machineFight?1.32:1.2,mark:b.actor===i,stride:active*7});
  strike(c,ox,oy,px+6,py-18,h.id,b.last?.kind,active);
  if(hit){line(c,ox-8,oy-29,ox+5,oy-16,'#e6987b',2);line(c,ox-4,oy-29,ox+9,oy-20,'#f4ce91',1.1);}
 }
 c.save();c.translate(px+attack*2-enemy*3,py);
 if(machineFight)liveMachine(c,t,b);
 else if(b.windloom)liveRig(c,3,0,t,b);
 else if(b.spec.id==='keelpot-clapper')mudClapper(c,2,0,t,b.intent.kind);
 else if(b.spec.id==='sail-heron')heron(c,3,1,t,b.intent.kind==='shell'?'flare':b.intent.kind==='rush'?'lean':'rest');
 else if(b.spec.visual?.startsWith('training-'))courseRig(c,1,2,t,b.spec.visual==='training-tide',b.intent.kind==='shell');
 else if(b.spec.id==='shoal-fans')fanFish(c,5,-3,t,b.intent.phaseThreshold<=23||b.intent.kind==='whirl',1.45);
 else if(snail)whelk(c,3,1,t,b.intent.kind!=='shell');
 else if(ray){poly(c,[[-23,-5],[-7,-15],[0,-10],[11,-16],[24,-8],[8,-4],[1,0],[-7,-5]],'#688b90','#486269');line(c,-1,-8,-12,5,'#92aca4',2);}
 else {const gray=b.spec.visual==='gray-crab'||b.spec.id==='hemp-crab';c.scale(gray?1.22:1,b.intent.kind==='shell'?1.16:1);creature(c,0,0,t,gray?'#687e81':'#9b624e');
  if(gray)for(let j=0;j<4;j++)line(c,-10+j*5,-13,-3+j*4,-6,'#c3ac7e',1.2);}
 c.restore();
 if(!machineFight&&(b.intent.kind==='ram'||b.intent.kind==='rush'))line(c,px-10,py+1,x-14,y-5,'#edc783bc',1.5);
 if(attack&&b.last.hit)arc(c,px+6,py-18,9+attack*6,-1.45,1.02,'#ffe0a5',2.1);
}
