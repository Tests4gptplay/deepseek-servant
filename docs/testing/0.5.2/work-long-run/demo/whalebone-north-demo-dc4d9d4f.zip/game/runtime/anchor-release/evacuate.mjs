import {poly,line,oval,arc} from '../paint.mjs';
import {figure} from '../figures.mjs';
import {rod,socket} from './forged.mjs';
const teal='#46696d',hull='#6b5c4d',gold='#d3b37b',chalk='#ede0bc';
function gunwale(c,x,y,len){
 poly(c,[[x-len,y-8],[x+len-9,y-15],[x+len+4,y-11],[x+len-11,y+3],[x-len+9,y+11]],'#857258','#434e49');
 for(let i=1;i<6;i++){const a=x-len+i*(2*len-15)/6;line(c,a,y-6,a+9,y+4,'#aa906c',1.5);}
 rod(c,x-len,y-8,x+len-6,y-15,3,'#bda985');rod(c,x-len+9,y+10,x+len-9,y+3,4,hull);
}
function cot(c,x,y,occupied,colour){
 c.save();c.translate(x,y);oval(c,0,3,21,4,'#344c4a62');
 rod(c,-21,-1,16,-5,2);rod(c,-13,3,23,-1,2);
 poly(c,[[-17,-6],[12,-10],[20,-4],[-11,1]],'#cabb91','#676956');
 if(occupied){poly(c,[[-9,-9],[3,-12],[13,-10],[17,-5],[-9,-2]],colour,'#68695a');oval(c,-13,-7,3.7,3.1,'#ceac8b');line(c,-15,-9,-11,-10,'#97958b',1.8);line(c,1,-11,5,-5,'#e1cfaa',1.7);}
 for(const xx of [-15,15])arc(c,xx,-3,3.5,Math.PI,Math.PI*2,teal,1.4);c.restore();
}
function cargo(c,x,y,on){
 for(let i=0;i<3;i++){const a=x-13+i*10,y1=y-i%2*4;poly(c,[[a-6,y1-7],[a+1,y1-9],[a+5,y1-6],[a+5,y1+1],[a-5,y1+3]],on?'#9e8063':'#686d60','#4b5148');if(on)for(let n=0;n<3;n++)line(c,a-3+n*2,y1-6,a-2+n*2,y1-3,'#c0bd99',1);}
 if(on)for(let j=0;j<2;j++){const a=x+10+j*5;rod(c,a-5,y+3,a+15,y-20,1.5,'#b5986e');poly(c,[[a+10,y-18],[a+13,y-25],[a+18,y-27],[a+17,y-21]],'#dfc394','#6f715a');}
}
function sling(c,x,y,raised){rod(c,x-28,y+2,x-28,y-43,4);rod(c,x+16,y-2,x+16,y-47,4);rod(c,x-29,y-44,x+17,y-48,5);for(const d of [-20,8]){const end=y-(raised?23:8);line(c,x+d,y-45,x+d+1,end,'#a78e68',2);socket(c,x+d+1,end,3.5);}}
export function evacuation(c,a,b,id,f,t){
 if(!f['harbor-tilted'])return false;c.save();c.translate(a,b);
 switch(id){
 case 'count-first':{
  gunwale(c,4,-3,45);const safe=f['base-safe'];
  for(const [i,coat] of ['first-house','second-house'].entries()){const x=i?26:-25,y=safe?-6:6;figure(c,x,y,coat,t,{scale:.94});arc(c,x+4,y-12,3.4,0,6.3,i?'#ddd5b2':'#7eb3a3',1.9);}
  poly(c,[[-12,0],[1,-4],[13,-1],[2,4]],'#b9a385','#697466');break;}
 case 'press-workers':{
  const gone=f['workers-aboard'],can=f['north-lampstock']&&f['court-count']&&f['ledger-first'];
  gunwale(c,-3,-5,34);if(!gone){figure(c,23,4,'press-worker-a',t,{scale:1.1});if(can)cargo(c,-7,-5,true);}
  else{cargo(c,-6,-6,false);line(c,-22,7,16,1,chalk,1.5);}break;}
 case 'salt-workers-berth':{
  const from=f['workers-aboard'],here=f['workers-arrived'];c.translate(23,36);c.scale(1.19,1.19);gunwale(c,4,-1,48);
  if(from){figure(c,-29,here?2:-5,'press-worker-a',t,{scale:1.03});figure(c,-6,-8,'print-shop-tender',t,{scale:.93});
   cargo(c,here?16:5,here?5:-6,true);rod(c,26,0,42,-28,2,'#b09867');}
  rod(c,35,-2,35,-37,3.2);if(here){poly(c,[[30,-31],[40,-31],[39,-19],[32,-18]],'#e5bf78','#685840');oval(c,35,-24,2.6,4.2,'#fff0b9');}
  break;}
 case 'sling-wards':{
  const gone=f['stretchers-on'],can=f['west-stairs']&&f['north-linesman']&&f['court-count'];
  sling(c,8,-2,gone);if(!gone&&can){cot(c,-8,4,true,'#829d99');cot(c,11,-6,true,'#c39a86');figure(c,33,4,'west-window-tender',t,{scale:1.03});}
  else{line(c,-15,2,18,-3,chalk,1.5);line(c,-10,7,23,2,chalk,1.5);}break;}
 case 'set-stretcher':{
  const aboard=f['stretchers-on'],ferried=f['beds-ferried'];c.translate(10,42);c.scale(1.27,1.27);
  gunwale(c,4,3,58);rod(c,-54,-3,-39,-22,2,'#c5ac79');
  for(const [xx,yy] of [[-46,5],[40,-5]]){rod(c,xx,yy,xx,yy-18,2.1);arc(c,xx,yy-15,3,0,6.29,'#cfb783',1.5);}
  cot(c,-23,ferried?3:15,aboard,'#829d99');cot(c,18,ferried?-9:2,aboard,'#c39a86');
  if(aboard)figure(c,48,-3,'west-window-tender',t,{scale:.92});break;}
 case 'cut-ramp':{
  const laid=f['tilt-sighted'];for(let i=0;i<6;i++){const xx=-28+i*9;rod(c,xx,4-i*.6,xx+9,-6-i*.6,5,laid?'#bc9a6a':'#927455');}
  rod(c,-27,0,-27,-24,3);rod(c,23,-4,23,-30,3);line(c,-27,-20,23,-26,'#d7bd87',2);
  break;}
 default:c.restore();return false;
 }
 c.restore();return true;
}
