const partners={mara:'ivo',ivo:'mara',selene:'mira',mira:'selene'};
const ropeMember=new Set(['mara','ivo']);
const jobs={rope:'双桩短索',sight:'双点照准'};
const kindOf=h=>ropeMember.has(h.id)?'rope':'sight';
const conscious=(b,id)=>b.party.find(h=>h.id===id&&h.hp>0);
export const pairMove=action=>['offer-line','take-line','offer-sight','sight-inside','sight-outside'].includes(action);
export function learnedPairs(s){return {rope:!!s.flags['harbor-truth'],sight:!!s.flags['north-chart']};}
function partnerFor(b,h){return h&&b.pairsKnown?.[kindOf(h)]&&conscious(b,partners[h.id]);}
function openTo(b,h){const offer=b.pairTurns?.[kindOf(h)];return offer?.to===h.id&&conscious(b,offer.from)&&offer.round+1>=b.round?offer:null;}
export function options(b,h){
 const other=partnerFor(b,h);if(!other)return [];
 const k=kindOf(h),offer=openTo(b,h);
 if(k==='rope')return offer?[['接住'+other.name+'的短索 · 1气','take-line']]:[['把短索递给'+other.name+' · 1气','offer-line']];
 return offer?[['标在贴身一侧 · 1气','sight-inside'],['标在外沿一侧 · 1气','sight-outside']]:[['请'+other.name+'从另一头读水 · 1气','offer-sight']];
}
export function letPass(b,h){
 const k=kindOf(h),open=b.pairTurns?.[k];
 if(open&&(open.to===h.id||open.from===h.id))delete b.pairTurns[k];
}
export function usePair(b,h,action){
 if(!options(b,h).some(([,key])=>key===action))return;
 if(h.mp<1){b.log=h.name+'气力不够。守桩能让自己缓过来。';return;}
 const other=partnerFor(b,h),k=kindOf(h);h.mp--;
 if(action==='offer-line'||action==='offer-sight'){
  (b.pairTurns??={})[k]={from:h.id,to:other.id,round:b.round};
  return h.name+(k==='rope'?'把一头短索套上自己的桩，另一头递给':'盯住水上第一道折痕，报给')+other.name+'。';
 }
 letPass(b,h);
 if(action==='take-line'){
  b.lineBrace=[h.id,other.id];return other.name+'和'+h.name+'各守一桩。这一拍的撞击、横风会沿短索卸力。';
 }
 const far=b.intent.kind==='rush'||b.intent.kind==='whirl',pickedFar=action==='sight-outside';
 if(far!==pickedFar)return h.name+'下标太早。水折从'+(far?'外沿':'贴身处')+'走掉，重画得重新约好一人一头。';
 b.sightMarks=2;return other.name+'报第一点，'+h.name+'复核第二点。两道准线留给接下来两次进击。';
}
export function lineCover(b,h,element,loss){return b.lineBrace?.includes(h.id)&&['impact','wind'].includes(element)?Math.min(6,loss):0;}
export function takeMark(b){if(!(b.sightMarks>0))return 0;b.sightMarks--;return 3;}
export function fieldReading(b){
 const h=b.party[b.actor],living=b.party.filter(w=>w.hp>0),target=living[(b.round-1)%living.length];
 const far=b.intent.kind==='rush'||b.intent.kind==='whirl';
 const threat=b.intent.kind==='whirl'?'这一圈会扫过全队。':'冲力这一拍朝向'+target.name+'。';
 const lines=[b.intent.name+'　'+b.intent.tell,threat+(far?'水折从外沿划过去。':'水压在近身处拱高。'),
 b.party.map(w=>w.name+' '+(w.hp>0?(w.lane==='edge'?'外沿':'近桩'):'力竭')+'　体力'+w.hp+'/'+w.maxHp+'　气'+w.mp+'/'+w.maxMp).join('\n')];
 const other=partnerFor(b,h);
 if(other){const k=kindOf(h),open=openTo(b,h);
 lines.push(k==='rope'?(open?other.name+'的短索已经递来。接住后，两人各自可从这拍风或撞击里卸去至多6点。':'从西灯学来的双桩法。递索和接索各用一人的行动与1气。'):(open?other.name+'已经报来第一点。辨这一拍走近桩还是外沿，画对后接下来两次进击各多3点。':'米拉与瑟琳各从一头看水。约读和落标各用一人的行动与1气。'));}
 else lines.push('轮到的人可以在这里看清同伴位置，再回去选择出手。');
 if(b.lineBrace?.length)lines.push('两桩已绷紧，等待这一拍来力。');
 if(b.sightMarks>0)lines.push('余下准线 '+b.sightMarks+' 道。');
 return lines.join('\n\n');
}
export function showField(ctx,b,onAction,back){const h=b.party[b.actor];ctx.ui.show('pair-field',h.name+' · 站位与搭手',fieldReading(b),[...options(b,h).map(([label,id])=>[label,onAction(id)]),['回到出手',back]],'查看与返回不经过回合。');}
