import {plate,telescope,chronometer} from './brass-and-water.mjs';
const clamp=(n,min,max)=>Math.min(max,Math.max(min,n));
export function sight(ctx,close){
 const {state,ui,sound,sync}=ctx,s=state.player,goal=s.tide==='high'?5:1;let slit=3,note='';
 const turn=d=>{slit=clamp(slit+d,0,6);note='';show();};
 function read(){if(slit!==goal){note='窥筒只有半边白芒。赤星还在狭缝'+(slit<goal?'东':'西')+'边。';show();return;}
  s.flags['star-clock-sighted']=true;s.flags['star-clock-sight-'+s.tide]=true;sound('solve');sync();
  ui.show('star-instrument','赤星压过真子午线','米拉不看水里第二道星，等红色短芒从两根黄铜丝中间通过，才举手。逐苔在听见“到”的那一下掐住岸针。\n鞋盒里的“岸刻”有了实物来处。',[['封住刻线，回天窗下',close]]);plate(ui,'两根黄铜丝中间的红星',c=>telescope(c,slit,goal));
 }
 function show(){const where=slit===goal?'赤星现在位于两根铜丝正中。':'赤星和两粒白星在狭缝的'+(slit<goal?'东':'西')+'侧。';
  ui.show('star-instrument','裂环天窗',note||where,[['向西转一格',()=>turn(-1)],['向东转一格',()=>turn(1)],['压缝读中天',read],['放回指星轮',close]],'铅垂真线已定。偏红的短芒两侧各有一粒白星。');plate(ui,where,c=>telescope(c,slit,goal));}
 show();
}
export function mend(ctx,close){
 const {state,ui,sound,sync}=ctx,s=state.player;let hand=0,rate=0,note='';
 if(s.flags['star-clock-tested']){ui.show('star-instrument','三更都合上的钟','第一更四刻，第四更七刻，第七更十刻。旧鞋带的印记还在原位。',[['合上走时箱',close]]);plate(ui,'三张贴合的实测钟面',c=>chronometer(c,[4,7,10]));return;}
 const values=()=>[5+hand-rate,9+hand,13+hand+rate];
 const signed=n=>n>0?'+'+n:String(n);
 const move=(kind,d)=>{if(kind==='hand')hand=clamp(hand+d,-3,3);else rate=clamp(rate+d,-2,2);note='';show();};
 function trial(){const v=values();if(v[0]===4&&v[1]===7&&v[2]===10){
  s.flags['star-clock-tested']=true;sound('solve');sync();ui.show('star-instrument','钟没有丢掉第三更','粟铅把整只箱提起来再放下。摆走，岸刻与船刻都没有跳。米娘在门口伸出两只手。\n她这次肯带我们走一回收灯的水。',[['用旧鞋带捆好钟箱',close]]);plate(ui,'岸与船在四、七、十刻都重合',c=>chronometer(c,v));return;}
  s.flags['star-clock-tried']=true;note=v[1]===7?'当下两针齐。再走三更，船针到了'+v[2]+'，岸针是十。还得动慢签。':v[2]-v[1]===3?'两面钟现在走得一样快。第四更岸针在七，船针仍在'+v[1]+'。该把当下的针拨齐。':'鞋盒的纸留着四、七两次岸刻。先看三更里多走几格，再拨回当下。';sync();show();
 }
 function show(){const v=values();ui.show('star-instrument','错齿摆房的两面钟',note||'鞋盒原记　岸四／船五，三更后岸七／船九。再隔三更，岸钟须到十。',[
 ['船针退一格',()=>move('hand',-1)],['船针进一格',()=>move('hand',1)],['慢签收一格',()=>move('rate',-1)],['慢签放一格',()=>move('rate',1)],['提箱走三更',trial],['先放下箱子',close]],
 '船针 '+signed(hand)+'　／　每三更的慢签 '+signed(rate)+'　　铜针为岸刻，深针为船刻');plate(ui,'第一更、第四更、第七更，船刻 '+v.join('、'),c=>chronometer(c,v));}
 show();
}
