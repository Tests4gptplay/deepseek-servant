import {poly,line,oval} from './paint.mjs';
const wet='#5e8586',shale='#485f5b',rim='#cbb489';
function basin(c,x,y,r,kind,t){
  c.save();c.translate(x,y);c.scale(r,r*.57);
  const edge=[[-45,2],[-35,-15],[-20,-17],[-7,-23],[12,-19],[33,-13],[42,-1],[33,12],[16,16],[-3,19],[-24,16],[-41,10]];
  poly(c,edge,'#564f40','#665c46');
  const g=c.createLinearGradient(0,-18,0,19);g.addColorStop(0,'#456e72');g.addColorStop(.45,'#628d87');g.addColorStop(.75,'#78a99d');g.addColorStop(1,'#9fb8a2');
  poly(c,edge.map(([a,b])=>[a*.91,b*.83+1]),g,'#415d5e');
  for(let j=0;j<5;j++){
    const xx=-31+j*13,ny=(j%2?-5:5)+Math.sin(t*.72+j)*1.25;
    line(c,xx,ny,xx+5,ny-2,'#d1e4cc',1.2);
    if(j<4)line(c,xx+1,ny+4,xx+8,ny+3,wet,.9);
  }
  if(kind==='rock'){
    for(const [a,b] of [[-31,9],[-19,14],[27,-8],[33,3]]){poly(c,[[a-5,b+1],[a-4,b-4],[a+2,b-6],[a+7,b-2],[a+5,b+2]],shale,'#414e47');line(c,a-3,b-4,a+1,b-5,'#a6aa88',1.1);}
  }else{
    for(const [a,b] of [[-30,-11],[25,11]]){poly(c,[[a-3,b-1],[a-3,b-12],[a+2,b-13],[a+3,b]],'#8a7357',shale);oval(c,a,b-12,3.8,2,rim);}
    c.beginPath();c.moveTo(-30,-23);c.quadraticCurveTo(-4,-1,25,-2);c.strokeStyle='#c2aa7b';c.lineWidth=1.3;c.stroke();
  }
  c.restore();
}
const basins={
 'lower-tide':[[6.1,4.6,.65,'rock'],[10.9,9.27,.91,'rock'],[14.78,6.65,.7,'rock']],
 'lead-sound':[[10.72,10.62,.91,'net'],[18.75,9.57,.98,'rock'],[17.36,8.78,.56,'rock']],
 'moor-pocket':[[12.85,6.55,1.24,'net'],[10.72,9.57,.89,'rock'],[11.85,7.75,.86,'net']]
};
export function paintCombGround(c,p,map,s,t){
  for(const [x,y,r,kind] of basins[map.id]||[]){const [u,v]=p(x,y);basin(c,u,v,r,kind,t);}
}
export function fightingWater(c){
  const g=c.createLinearGradient(0,-22,0,27);g.addColorStop(0,'#355c66d9');g.addColorStop(.51,'#608c8ad9');g.addColorStop(1,'#87aaa0c9');
  poly(c,[[-115,-4],[-90,-18],[-39,-22],[2,-26],[57,-25],[81,-16],[90,-3],[80,11],[51,20],[-13,25],[-88,20],[-108,12]],g,'#496e71');
  for(const [a,b] of [[-107,8],[-68,16],[18,18],[74,8],[41,-21],[-48,-18]])line(c,a,b,a+10,b-1,'#c4d3b8',1.4);
}
