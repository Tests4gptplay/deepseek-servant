import {line,oval,poly} from '../paint.mjs';
import {box,plate} from '../voyage-shapes.mjs';

const oak=['#be9b68','#8c694f','#6a5043'];
function stroke(c,p,a,b,color,width=1){line(c,...p(...a),...p(...b),color,width);}

function carvedGoose(c,x,y,look){
  c.save();c.translate(x,y);if(look)c.scale(-1,1);
  c.fillStyle='#e6c58a';c.strokeStyle='#735944';c.lineWidth=1.4;c.beginPath();
  c.moveTo(-13,2);c.bezierCurveTo(-10,0,-10,-3,-6,-4);c.lineTo(-1,-5);
  c.bezierCurveTo(2,-7,-1,-18,5,-20);c.bezierCurveTo(8,-22,12,-20,12,-17);
  c.lineTo(11,-14);c.bezierCurveTo(6,-14,9,-8,9,-3);
  c.bezierCurveTo(9,4,1,7,-5,6);c.lineTo(-14,4);c.closePath();c.fill();c.stroke();
  poly(c,[[11,-19],[18,-17],[11,-15]],'#be8050','#855b42');
  oval(c,8,-18,1.1,1.1,'#3e4540');c.beginPath();c.moveTo(-7,0);c.quadraticCurveTo(-3,-4,2,-4);
  c.quadraticCurveTo(-1,2,-7,2);c.strokeStyle='#aa8059';c.stroke();
  line(c,-2,6,-2,13,'#7a6246',2);line(c,3,5,4,13,'#7a6246',2.2);
  line(c,-4,13,0,13,'#96774e',2);line(c,3,13,8,13,'#96774e',2);c.restore();
}
function grainWindow(c,p,x,y,flags){
  const lowered=!!flags['common-lowered'],turn=!!flags['common-turn-seen'],left=x+.02,back=y-.84;
  box(c,p,left,back,2.8,.24,1,37,['#b99d78','#aa8a67','#78614f']);
  for(let a=.18;a<2.8;a+=.39)stroke(c,p,[left+a,back+.25,2],[left+a,back+.25,37],'#90745c');
  const q=(u,z)=>p(left+u,back+.27,z);
  poly(c,[q(.45,15),q(2.22,15),q(2.22,33),q(.45,33)],'#433e35','#664c3b');
  for(const u of [.37,2.21])box(c,p,left+u,back+.27,.16,.16,13,22,oak);
  box(c,p,left+.31,back+.27,2.1,.49,13,3,oak);
  const sill=p(left+1.1,back+.60,17);
  for(let k=0;k<(turn?1:3);k++){
    const a=sill[0]+k*5,b=sill[1]+k*.8;
    oval(c,a,b,4.5,3.4,'#c6a47a');line(c,a-2,b-2.5,a+2,b-2.5,'#695947',1.1);
  }
  box(c,p,left-.12,back-.43,3.06,.86,36,3.8,['#b69a73','#8c775b','#6e6252']);
  for(const u of [0,2.70])seamPost(u);
  function seamPost(u){stroke(c,p,[left+u,back+.14,0],[left+u,back+.14,36],'#735b44',2.7);}
  const level=turn?15:6;
  if(lowered||turn){
    plate(c,p,left-.18,back+.68,3.14,.39,.4,turn?'#759b95':'#929d8b');
    stroke(c,p,[left-.16,back+.67,level],[left+2.89,back+.67,level],turn?'#b9dcce':'#8ba99c',2);
  }else{
    plate(c,p,left-.18,back+.54,3.14,.35,.3,'#a8a18a','#9b937b');
  }
  const post=p(left+.06,back+.18,38);line(c,post[0],post[1]+8,post[0],post[1]-16,'#706348',3);
  carvedGoose(c,post[0]+2,post[1]-24,turn);
}
function doorImpression(c,p,x,y,flags){
  const left=x+.58,back=y-.86;
  box(c,p,left,back,1.47,.18,0,40,['#a48765','#856950','#685548']);
  for(let n=0;n<5;n++)stroke(c,p,[left+n*.28,back+.20,1],[left+n*.28,back+.20,39],'#9d7c59',1);
  for(const z of [11,29])stroke(c,p,[left+.04,back+.21,z],[left+1.44,back+.21,z+3],'#6c6252',2.4);
  const [a,b]=p(left+1.02,back+.24,23);
  oval(c,a,b,4.3,3.6,'#b69962');c.beginPath();c.ellipse(a,b+5.4,4.1,6.2,-.18,0,Math.PI*2);
  c.strokeStyle='#3d4942';c.lineWidth=2.3;c.stroke();line(c,a-2,b+8,a-1,b+9,'#d0aa6b',1.2);
  const [cx,cy]=p(left-1.05,back+.50,10);
  poly(c,[[cx-10,cy-1],[cx+6,cy-7],[cx+13,cy-2],[cx-3,cy+5]],flags['common-home-after']?'#a4a99a':'#bc9e8f','#6f6860');
  if(flags['common-cloth-yes']||flags['common-home-after']){
    c.beginPath();c.ellipse(cx+1,cy-1,3.6,2,-.3,0,Math.PI*2);c.strokeStyle='#76674f';c.lineWidth=1.4;c.stroke();
  }
}
export function homeSquareObject(c,p,f,state){
 if(f.id==='common-turning-goose'){grainWindow(c,p,f.x,f.y,state.flags);return true;}
 if(f.id==='common-door-in-cloth'){doorImpression(c,p,f.x,f.y,state.flags);return true;}
 return false;
}
