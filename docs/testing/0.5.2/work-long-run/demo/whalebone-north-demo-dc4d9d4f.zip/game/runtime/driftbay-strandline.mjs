import {line,poly,oval,rand} from './paint.mjs';
// Objects gather where a concave bank actually meets the water; bare rock stays bare.
export function strandline(c,p,map,s,t,near){
 const {id,relief}=map.driftbay,h=relief.length,w=relief[0].length;
 for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){
  if(relief[y][x]==='~')continue;
  const shore=relief[y+1][x]==='~'||relief[y][x+1]==='~';
  if(!shore)continue;
  const [a,b]=p(x+.76,y+.76);if(!near(a,b,80))continue;
  const n=rand(x+32,y+8);
  if(n>.68){
   const wide=6+8*n,tall=2+4*rand(y,x);
   oval(c,a+2,b+1,wide*.95,tall*.52,'#283a3b75');
   poly(c,[[a-wide,b],[a-wide*.55,b-tall*.61],[a-1,b-tall],[a+wide*.71,b-tall*.73],[a+wide,b-.5],[a+wide*.53,b+tall*.32],[a-wide*.7,b+tall*.25]],id==='scree'?'#9d8878':'#788782','#556968');
   line(c,a-wide*.55,b-tall*.61,a-1,b-tall,'#c3c2a5',1.4);
  }else if(n>.35&&(id==='throat'||id==='pools'||id==='cradle')){
   for(let k=0;k<3;k++){const u=a+k*2-3;c.beginPath();c.moveTo(u,b);c.bezierCurveTo(u+4,b-3,u-5,b-6,u+Math.sin(t+k)*2,b-7-k*2);c.bezierCurveTo(u-7,b-5,u-3,b-4,u,b);
    c.fillStyle=k===1?'#677953':'#336053';c.fill();}
  }else if(n<.16){for(let k=0;k<3;k++){const u=a+k*2.5;oval(c,u,b-k%2,2.4,1.1,'#d9ccaa');line(c,u-1,b-k%2,u+1,b-k%2-1,'#9f947d');}}
 }
}
