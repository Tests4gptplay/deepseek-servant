import {line,poly,oval,arc} from '../paint.mjs';
import {figure} from '../figures.mjs';
import {rod,socket,gear,incoming} from './forged.mjs';
const jade='#385f64',seam='#d7ba86',skin='#c8906b',dark='#37433e';
function rope(c,x1,y1,x2,y2,depth){
 c.beginPath();c.moveTo(x1,y1);c.quadraticCurveTo((x1+x2)/2,(y1+y2)/2+depth,x2,y2);c.strokeStyle='#635440';c.lineWidth=3.2;c.stroke();c.strokeStyle='#dabf83';c.lineWidth=1.4;c.stroke();
}
export function pin(c,a,b,f,focus,u){
 c.save();c.translate(a+57,b-10);c.scale(1.22,1.22);const ready=f['common-release-word']&&f['both-bells'],engaged=ready&&focus==='bran-unpin',out=u>.999;
 oval(c,6,9,63,12,'#293a3b51');
 poly(c,[[-50,0],[-29,-11],[37,-8],[53,0],[36,11],[-34,11]],'#587278','#2e4247');
 poly(c,[[-50,0],[-34,11],[36,11],[36,19],[-35,18],[-50,7]],'#785f4c','#3b4541');
 rod(c,-39,3,-39,-28,6);rod(c,13,5,13,-29,7);rod(c,-39,-28,13,-29,8);
 for(const x of [-31,-14]){poly(c,[[x-4,-25],[x,-35],[x+6,-34],[x+7,-24]],'#9b957c','#384a49');socket(c,x+1,-29,4.7);}
 const shift=27*u,handle=2+shift;
 rod(c,-34+shift,-29,handle,-30,4,'#c3b078');
 arc(c,handle+3,-31,5,-2.85,2.65,'#e7c58b',2.5);
 if(out){oval(c,-30,-29,3.2,2.2,'#172d31');line(c,-34,-25,-27,-25,'#eed9a9',1.3);}
 if(f['bran-at-drum']&&!f['harbor-tilted']){
  const xx=30+u*5,hand=(engaged||u>0)?[handle+6,-29]:[18,-18];
  line(c,xx-3,-10,xx-8,4,dark,5);line(c,xx+4,-10,xx+8,3,dark,5);line(c,xx-9,5,xx-4,5,'#273638',3);
  poly(c,[[xx-9,-37],[xx+3,-40],[xx+9,-34],[xx+9,-17],[xx+13,-9],[xx+6,-5],[xx-11,-9],[xx-6,-19]],jade,'#283e41');
  poly(c,[[xx-8,-36],[xx-1,-39],[xx+3,-36],[xx,-31]],'#cfb17a');
  line(c,xx-3,-30,xx-5,-12,'#819e91',1.5);for(let y=-29;y< -13;y+=5)oval(c,xx+1,y,1,1,'#debc80');
  oval(c,xx-3,-44,6.25,7.9,skin);poly(c,[[xx-9,-45],[xx-10,-52],[xx-4,-55],[xx+4,-53],[xx+6,-50],[xx+4,-45],[xx+1,-49],[xx-5,-49]],'#b7ac91','#635f50');
  line(c,xx-8,-44,xx-4,-45,'#635648',1.4);line(c,xx-7,-40,xx-3,-39,'#805f4e',1);
  const elbow=[xx-4,-20-u*5];rod(c,xx-6,-34,...elbow,5,jade);rod(c,...elbow,...hand,4,jade);oval(c,hand[0],hand[1],3.4,2.6,skin);
  if(engaged||u>0)line(c,hand[0]-2,hand[1]-1,hand[0]-1,hand[1]+1,'#e3ba91',1.3);
 }
 c.restore();
}
export function station(c,a,b,id,f,t,staffed=true){
 c.save();c.translate(a+6,b-5);
 if(id==='mara-shoe'){
  const set=f['shoe-held'];rod(c,-33,1,27,-2,9);rod(c,-19,-2,17,-38,6);
  poly(c,[[-9,0],[8,0],[6,-10]],set?'#e2b378':'#8e7052','#504e45');
  const xx=set?6:-12;rod(c,xx,0,xx+4,-18,4,'#c8a173');arc(c,xx+5,-20,4,0,6.29,'#cbb58c',2);
 }else if(id==='ivo-bridle'){
  const set=f['bridle-free'];rod(c,-27,-5,27,-7,5);socket(c,7,-11,6);socket(c,-9,-10,5);rope(c,-29,-14,7,-12,set?14:1);rope(c,-7,-11,27,-17,set?3:1);
  if(set&&staffed){figure(c,-20,5,'ivo',t,{scale:1.27});rope(c,-12,-14,6,-10,5);}
 }else if(id==='selene-vent'){
  incoming(c,10,4,t,f['drum-vent']);rod(c,6,-2,12,-23,4);gear(c,12,-24,8,0);
  if(f['drum-vent']&&staffed){figure(c,-20,6,'selene',t,{scale:1.3});line(c,-9,-16,6,-20,'#c2d3af',2);}
 }else if(id==='mira-chalk'){
  const set=f['drum-chalk'];for(let i=0;i<3;i++){const x=-6+i*11;poly(c,[[x-5,-3],[x,-11],[x+5,-5],[x+1,-1]],['#e8ddbd','#514e49','#84b8af'][i],'#37484a');if(set)line(c,x-5,1,x+3,3,'#eee0b5',2.3);}
  if(set&&staffed){figure(c,28,5,'mira',t,{scale:1.24,flip:true});line(c,19,-14,10,-5,'#d6c99a',1.5);}
 }else if(id==='mara-floodgate'){
  const set=f['harbor-tilted'];rod(c,-29,-2,23,-4,6);for(let j=0;j<4;j++)rod(c,-20+j*11,-4,-20+j*11,set?-29:-15,3);
  rod(c,-25,-14,20,set?-35:-15,4,'#b49a66');socket(c,21,-9,7);
 }
 c.restore();
}
