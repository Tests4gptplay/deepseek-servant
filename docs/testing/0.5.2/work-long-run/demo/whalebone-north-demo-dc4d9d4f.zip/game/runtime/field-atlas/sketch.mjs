// Local bearings use only the player's position and previously used exits.
export function drawSheet(ui,map,state,first){
 const width=480,height=174,canvas=document.createElement('canvas');
 canvas.width=width*2;canvas.height=height*2;
 const c=canvas.getContext('2d');if(!c)return;
 c.scale(2,2);c.fillStyle='#eadab5';c.fillRect(0,0,width,height);
 const here={x:state.x,y:state.y},there=first?.exit||here;
 const rangeX=Math.max(11,Math.abs(there.x-here.x)+5),rangeY=Math.max(5,Math.abs(there.y-here.y)+3);
 const spacing=Math.min(26,(width-84)/rangeX,(height-58)/rangeY);
 const middleX=(here.x+there.x)/2,middleY=(here.y+there.y)/2;
 const point=(x,y)=>[width/2+(x-middleX)*spacing,78+(y-middleY)*spacing];
 const line=(x1,y1,x2,y2)=>{c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();};
 const triangle=(a,b)=>{c.fillStyle='#233d43';c.beginPath();c.moveTo(a,b-7);c.lineTo(a+6,b+5);c.lineTo(a-6,b+5);c.closePath();c.fill();};
 const cross=(a,b)=>{c.strokeStyle='#a33f32';c.lineWidth=3.2;line(a-6,b-6,a+6,b+6);line(a-6,b+6,a+6,b-6);};
 c.save();c.beginPath();c.rect(27,14,width-54,119);c.clip();
 c.strokeStyle='#bdad86';c.lineWidth=.8;
 for(let x=0;x<map.width;x+=2){const [a]=point(x,0);line(a,14,a,133);}
 for(let y=0;y<map.height;y+=2){const [,b]=point(0,y);line(27,b,width-27,b);}
 c.strokeStyle='#8c795d';c.lineWidth=1.5;
 const edge=point(0,0);c.strokeRect(...edge,(map.width-1)*spacing,(map.height-1)*spacing);
 for(const [from,x,y] of state.fieldChart?.legs||[]){
  if(from!==map.id||first&&x===there.x&&y===there.y)continue;
  const [a,b]=point(x,y);c.fillStyle='#eadab5';c.strokeStyle='#3d6b70';c.lineWidth=2;
  c.beginPath();c.arc(a,b,5,0,Math.PI*2);c.fill();c.stroke();
 }
 const [x,y]=point(here.x,here.y),[a,b]=point(there.x,there.y);
 if(first){
  c.strokeStyle='#995447';c.lineWidth=2;c.setLineDash([4,5]);line(x,y,a,b);c.setLineDash([]);
  if(here.x===there.x&&here.y===there.y){c.beginPath();c.arc(a,b,11,0,Math.PI*2);c.stroke();}
  else cross(a,b);
 }
 triangle(x,y);c.restore();
 c.fillStyle='#365855';c.strokeStyle='#365855';c.lineWidth=1.8;line(15,41,15,21);line(15,21,11,29);line(15,21,19,29);
 c.font='bold 12px sans-serif';c.fillText('北',9,15);
 c.strokeStyle='#a69673';c.lineWidth=1;line(10,140,width-10,140);
 triangle(20,154);c.fillStyle='#273f40';c.font='15px sans-serif';c.fillText('脚下',32,161);
 if(first){cross(105,155);c.fillStyle='#6c362c';c.fillText('下一段出口',118,161);}
 c.fillStyle='#3d615e';c.strokeStyle='#3d615e';c.lineWidth=1.4;
 const scale=spacing*2,origin=width-26-scale;line(origin,157,origin+scale,157);line(origin,153,origin,161);line(origin+scale,153,origin+scale,161);
 c.font='12px sans-serif';c.textAlign='center';c.fillText('两格',origin+scale/2,153);
 const img=document.createElement('img');img.src=canvas.toDataURL('image/png');img.setAttribute('data-field-sketch','');
 img.alt='本地航页。三角是脚下，圆圈是走过的其他出口。'+(first?'红叉是下一段出口，虚线指方位。':'');
 img.style.cssText='display:block;width:min(100%,480px);height:auto;margin:8px 0;border:1px solid #b3a17e;border-radius:3px';
 ui.panel.querySelector('p').after(img);
}
