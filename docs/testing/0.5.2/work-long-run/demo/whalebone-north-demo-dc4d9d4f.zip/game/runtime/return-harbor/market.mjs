import {line,oval,poly} from '../paint.mjs';
import {box,plate} from '../voyage-shapes.mjs';

const timber=['#bc9264','#8a694c','#645944'];
const seam=(c,p,a,b,ink,w=1)=>line(c,...p(...a),...p(...b),ink,w);
const colors=[
 {wall:'#cab994',side:'#ab9a7b',wood:'#715849',roof:'#88776a',far:'#716c61',shut:'#64877f'},
 {wall:'#cabba1',side:'#afa18a',wood:'#765f50',roof:'#a9755c',far:'#865e50',shut:'#8c665e'},
 {wall:'#b5b7a5',side:'#909f92',wood:'#6c6753',roof:'#71877c',far:'#60766e',shut:'#899a76'}
];
function storeHouse(c,p,x,y,w,h,index){
 const a=colors[index%3],height=47+(index%3)*6,front=y+h,top=height+17,ridge=y+h*.47;
 box(c,p,x,y,w,h,0,height,[a.wall,a.wall,a.side]);
 const q=(u,z)=>p(x+u,front+.015,z);
 for(const z of [2,8,27,height-2])seam(c,p,[x,front+.03,z],[x+w,front+.03,z],z===27?a.wood:'#a3967f',z===27?2:.95);
 for(let i=.13;i<w;i+=1.36)seam(c,p,[x+i,front+.03,27],[x+i,front+.03,height-2],a.wood,2.1);
 function window(u){
  poly(c,[q(u,30),q(u+.67,30),q(u+.67,height-7),q(u,height-7)],'#425955',a.wood);
  seam(c,p,[x+u+.33,front+.05,30],[x+u+.33,front+.05,height-7],'#bdad89',1.1);
  seam(c,p,[x+u,front+.05,36],[x+u+.67,front+.05,36],'#b09b79',1);
  for(const v of [u-.18,u+.69])poly(c,[q(v,29),q(v+.13,29),q(v+.13,height-6),q(v,height-6)],a.shut);
  box(c,p,x+u-.08,front,.83,.13,28,2,timber);
 }
 for(let u=.42;u<w-.92;u+=1.36)window(u);
 const d=Math.min(w*.28,1.35),door=(u,z)=>q(d+u,z);
 poly(c,[door(0,1),door(.92,1),door(.92,20),door(.69,23),door(.22,23),door(0,19)],'#64564a',a.wood);
 for(let i=1;i<5;i++)seam(c,p,[x+d+i*.17,front+.06,1],[x+d+i*.17,front+.06,19],'#88735a');
 const latch=door(.75,10);oval(c,...latch,1.6,1.4,'#bd9763');
 box(c,p,x+d-.12,front,1.16,.37,0,2,['#aaa48b','#8c8d77','#727b6a']);
 for(let u=2.35;u<w-.62;u+=1.15){
   poly(c,[q(u,9),q(u+.77,9),q(u+.77,20),q(u,20)],'#687b70',a.wood);
   for(let z=11;z<21;z+=3)seam(c,p,[x+u,front+.03,z],[x+u+.77,front+.03,z],a.shut,1.5);
 }
 const L=x-.20,R=x+w+.20;
 poly(c,[p(L,y-.24,height+2),p(R,y-.24,height+2),p(R,ridge,top),p(L,ridge,top)],a.far,a.wood);
 poly(c,[p(L,ridge,top),p(R,ridge,top),p(R,front+.26,height+1),p(L,front+.26,height+1)],a.roof,a.wood);
 for(let i=.35;i<w;i+=.53)seam(c,p,[x+i,ridge,top+.4],[x+i,front+.27,height+1],a.far,.85);
 seam(c,p,[L,front+.27,height],[R,front+.27,height],'#514f43',2.4);
 box(c,p,x+w*.73,ridge-.22,.38,.42,top-5,14,['#af9980','#8c7866','#715f53']);
 box(c,p,x+w*.73-.045,ridge-.26,.48,.50,top+7,3,['#bbaa8b','#927e66','#7c6e5e']);
}
function sack(c,p,x,y,size,col){
 const [cx,cy]=p(x,y);const a=size*8,b=size*5;
 oval(c,cx,cy+1,a+1,b*.62,'#59544755');c.fillStyle=col;c.strokeStyle='#7c6951';c.lineWidth=1;
 c.beginPath();c.moveTo(cx-2,cy-b*2);c.bezierCurveTo(cx-a*1.5,cy-b,cx-a*.9,cy,cx,cy+1);
 c.bezierCurveTo(cx+a*1.2,cy+1,cx+a*1.2,cy-b,cx+2,cy-b*2);c.closePath();c.fill();c.stroke();
 line(c,cx-2,cy-b*2,cx+2,cy-b*2,'#655746',1.2);
}
function awning(c,p,x,y,w,h,palette){
 const height=28,pole='#735b45';
 for(const [u,v] of [[0,0],[w,0],[0,h],[w,h]])seam(c,p,[x+u,y+v,0],[x+u,y+v,height+(v?0:6)],pole,2.7);
 for(let i=0;i<7;i++){
   const l=x+w*i/7,r=x+w*(i+1)/7,fill=palette[i%2];
   poly(c,[p(l,y,36),p(r,y,36),p(r,y+h,28),p(l,y+h,28)],fill);
   poly(c,[p(l,y+h,28),p(r,y+h,28),p(r,y+h,24),p((l+r)/2,y+h,22),p(l,y+h,24)],fill);
 }
 box(c,p,x+.14,y+h-.60,w-.27,.50,8,5,timber);
 for(let i=0;i<5;i++)sack(c,p,x+.28+i*w*.15,y+h-.46,1+i%2*.12,i%2?'#bb9866':'#bfae82');
}
export function wardBuildings(c,p,map,f){
 if(map.id!=='oven-shadow-square')return false;
 if(f.kind==='building'){
   const count=f.w>13?3:2;
   for(let i=0;i<count;i++)storeHouse(c,p,f.x+i*f.w/count,f.y+(i%2)*.25,f.w/count-.16,f.h-(i%2)*.23,Math.floor(f.x/3)+i);
   return true;
 }
 return f.kind==='crate'||(f.kind==='sign'&&f.x===17&&!f.id);
}
export function marketPlaces(c,p,map,state,list){
 if(map.id!=='oven-shadow-square')return;
 for(let y=9;y<17;y++)for(let x=6;x<37;x++){
   if((x+y)%3===0)continue;
   const a=(x*7+y*11)%9;if(a<3&&y>13)continue;
   const x0=x+.05+(a%3)*.05,y0=y+.10+(a%2)*.08;
   plate(c,p,x0,y0,.69+(a%3)*.05,.56+(a%2)*.09,.25,['#a6a797','#a7a697','#b1ae97','#a5a696'][a%4],'#999d8d');
 }
 const add=(x,y,draw)=>list.push([x+y,draw]);
 add(9,17,()=>awning(c,p,7.4,15.44,2.45,1.16,['#b56e54','#d8be8f']));
 add(11,19,()=>awning(c,p,10.18,16.93,2.16,1.54,['#668781','#c7c6a3']));
 add(9,21,()=>{for(let k=0;k<9;k++)sack(c,p,7.75+k%3*.38,19.1+Math.floor(k/3)*.34,1.4-k%2*.18,k%3?'#b9a279':'#a58b61');});
}
