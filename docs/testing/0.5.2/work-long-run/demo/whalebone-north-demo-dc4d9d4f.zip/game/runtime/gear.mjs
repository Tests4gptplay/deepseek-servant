import {passageKit} from './passage-school.mjs';
import {relics} from '../rules/vocations.mjs';
export const kit = {
 'work-iron':{name:'殓工短锤',slot:'weapon',power:2},'rope-knife':{name:'割索刀',slot:'weapon',power:1,break:3},
 canvas:{name:'帆布外衣',slot:'armor',defense:1},oilskin:{name:'夹层油布甲',slot:'armor',defense:3},
 'deep-lens':{name:'反光水尺',slot:'charm',resists:{tide:.22,shock:.18}},
 'brine-dose':{name:'回暖盐膏',slot:'consumable',heal:4,restore:5},
 tonic:{name:'盐橘药剂',slot:'consumable',heal:14,restore:2}
};
export function items(world){return {...kit,...passageKit,...relics,...world.equipment,...world.items};}
export function equip(world,s,id,key){
 const bag=s.expedition.stock,gear=items(world)[key],hero=s.expedition.heroes[id];
 if(!hero||!gear||(gear.owner&&gear.owner!==id)||!['weapon','armor','charm'].includes(gear.slot)||!(bag[key]>0))return false;
 const old=hero[gear.slot];if(key===old)return false;
 bag[key]--;if(old)bag[old]=(bag[old]||0)+1;hero[gear.slot]=key;return true;
}
export function consume(world,s,id,key,limits){
 const item=items(world)[key],bag=s.expedition.stock,hero=s.expedition.heroes[id];
 if(!hero||item?.slot!=='consumable'||!(bag[key]>0))return false;
 const hp=Math.min(limits.hp,hero.hp+(item.heal||0)),mp=Math.min(limits.mp,hero.mp+(item.restore||0));
 if(hp===hero.hp&&mp===hero.mp)return false;
 bag[key]--;hero.hp=hp;hero.mp=mp;return true;
}
