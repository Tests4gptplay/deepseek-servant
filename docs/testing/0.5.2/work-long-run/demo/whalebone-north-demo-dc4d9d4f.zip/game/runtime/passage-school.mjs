// Practical experience is earned once when gameplay changes a recorded fact.
// The four columns represent the different work each companion learns on that voyage.
export const passages=[
 ['coffin-aboard','送棺上舟',[23,28,12,10]],
 ['vigil-finished','接稳棺灯',[32,22,20,14]],
 ['shift-receipted','两班工签交足',[38,49,26,28]],
 ['early-castoff','抄过末班缆点',[49,58,35,29]],
 ['roof-shelter','找到内舱住户',[66,51,48,45]],
 ['beds-countersigned','逐户安置横铺',[65,75,81,52]],
 ['ear-received','低舷的闸钥抵手',[58,89,52,74]],
 ['harbor-truth','重走两道求援灯',[92,111,58,79]],
 ['shortfall-proved','亲证过仓差数',[94,78,131,106]],
 ['rye-boats-done','履行春种家约',[112,94,142,83]],
 ['north-ready','检齐航备离港',[139,162,171,160]],
 ['north-chart','实测成了自己的图',[146,135,165,208]],
 ['wren-crossed','图主亲自验航',[129,164,108,207]],
 ['maker-known','取到旧签图',[187,168,131,172]],
 ['fresh-proved','辨出冬岸淡水',[156,146,243,184]],
 ['bond-settled','冬粮有了实保',[175,196,221,151]],
 ['winter-proof','四项越冬证实',[208,190,245,206]],
 ['base-safe','倾港脱险',[210,214,184,189]]
];
const members=['mara','ivo','selene','mira'];
export const passageKit={
 'apron-hammer':{name:'双面垫楔锤',slot:'weapon',owner:'mara',power:5,break:4},
 'watch-line':{name:'横绳制动刀',slot:'weapon',owner:'ivo',power:3,break:5},
 'brine-staff':{name:'双液潮杖',slot:'weapon',owner:'selene',power:5,break:1},
 'bearing-bow':{name:'两点照准弩',slot:'weapon',owner:'mira',power:4,break:4}
};
const kits={'shift-receipted':'apron-hammer','harbor-truth':'watch-line','north-ready':'brine-staff','north-chart':'bearing-bow'};
export function learnPassages(world,s,before,addXP){
 if(s.cycle||s.flags['grave-signed'])return [];
 const ex=s.expedition,old=ex.passageBook||{learned:{},credited:{}},fresh=passages.filter(([flag])=>!before[flag]&&s.flags[flag]&&!old.learned[flag]);
 if(!fresh.length&&!Object.keys(old.learned).length)return [];
 const learned={...old.learned},credited={...old.credited};
 for(const [flag] of fresh){
  learned[flag]=true;const key=kits[flag];if(key)ex.stock[key]=(ex.stock[key]||0)+1;
 }
 for(const id of ex.roster){
  const j=members.indexOf(id);if(j<0)continue;
  const earned=passages.reduce((sum,[flag,,xp])=>sum+(learned[flag]?xp[j]:0),0);
  const diff=earned-(credited[id]||0);if(diff>0){if(!ex.seamanship?.quiet)addXP(world,id,ex.heroes[id],diff);credited[id]=earned;}
 }
 ex.passageBook={learned,credited};return fresh.map(([,label])=>label);
}
export function lessonSummary(s,id){
 const ledger=s.expedition.passageBook;if(!ledger)return '';
 const known=passages.filter(([flag])=>ledger.learned[flag]);
 return known.length?'实作航历　'+known.length+' 项 · 本行已学 '+(ledger.credited[id]||0)+' 经验\n最近一项　'+known.at(-1)[1]:'';
}
const campaignPressure={
 'echo-ray':[72,6], 'sail-heron':[79,7], 'husk-moths':[138,12], 'shoal-fans':[168,14],
 'spin-smelt':[202,15], 'brine-spine':[227,18], 'mudskate':[264,17], 'frost-whelk':[222,17], 'anchor-clutch':[385,24]
};
export function sailedEncounter(s,spec){
 const profile=campaignPressure[spec.id],learned=s.expedition.passageBook?.learned;
 if(!profile||!learned||s.cycle||s.flags['grave-signed']||s.expedition.seamanship?.quiet)return spec;
 const count=Object.keys(learned).length;if(count<3)return spec;
 const strength=Math.max(...Object.values(s.expedition.heroes).map(h=>h.level));
  const extra=Math.max(0,strength-18),hp=Math.round(profile[0]*(1+extra*.029)),attack=Math.round(profile[1]*(1+extra*.019)),ratio=hp/spec.hp;
 return {...spec,hp,attack,phases:spec.phases?.map(p=>({...p,fromHp:Math.max(1,Math.round(p.fromHp*ratio))})),sailed:true};
}
