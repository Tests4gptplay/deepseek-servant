import {line,oval} from './paint.mjs';
export function hour(map,state){
 if(map.id==='wake-court'||map.id==='wick-house')return state.flags['vigil-finished']?'dawn':'vespers';
 if(map.id==='upper-spar'||map.id==='whale-roofs')return 'dawn';
 if(map.id==='signal-gallery'&&state.flags['night-lamp']&&!state.flags['early-castoff'])return 'vespers';
 return 'day';
}
export function light(c,w,h,phase,inside){
 if(phase==='day')return;
 if(phase==='vespers'){
  const g=c.createLinearGradient(0,0,w*.48,h);g.addColorStop(0,inside?'#26354b35':'#28365675');g.addColorStop(.48,'#93695726');g.addColorStop(1,'#353f511c');c.fillStyle=g;c.fillRect(0,0,w,h);
  if(!inside)for(let i=0;i<7;i++){const xx=w*(.13+i*.105),yy=h*(.06+(i%3)*.029);oval(c,xx,yy,.8,.8,'#dbd2b879');}
 }else{const g=c.createLinearGradient(0,h,w,0);g.addColorStop(0,'#668f901c');g.addColorStop(.55,'#e7bc8720');g.addColorStop(1,'#d99d7440');c.fillStyle=g;c.fillRect(0,0,w,h);}
}
export function frontOpacity(p,f,camX,camY,area){
 if(f.kind!=='building')return 1;
 const w=f.w||1,h=f.h||1,x=f.x,y=f.y;
 const [a,b]=p(camX+.5,camY+.5),left=p(x,y+h)[0],right=p(x+w,y)[0],back=p(x,y)[1],near=p(x+w,y+h)[1];
 if(a<left-4||a>right+4||b<back-67||b>near+6||camX+camY+1.05>=x+y+w+h-.8)return 1;
 const soft=Math.min(1,(a-left+4)/15,(right+4-a)/15,(near+6-b)/10);
 return Math.max(area==='hold'?.44:.36,1-Math.max(0,soft)*.66);
}
