export const basinCrossings={
 'season-ring>box-in-the-loft@35,11':f=>f['pot-low-wanted']?'苇蜓已答应把船留下屋。窑头还要另起灶，从另一只冬眼去帮她索回能送进窄门的旧锅。':'两家共用一条灶船。先在两只冬眼之间听灰砚和苇蜓各说一遍，再决定哪家要换地方过冬。',
 'season-ring>cold-kiln-yard@16,15':f=>f['pot-kiln-wanted']?'灶船要留上坝，当班人的午饭照送。灰砚得把唯一带走的米箱搬上高坡，从船尾去陪他转角。':'下屋、上坝分不开一条船。去冬眼边找灰砚和苇蜓，听完两家的话，再跟着真要换生活的人走。',
 'pebble-saddle>pale-print@37,12':f=>f['pan-boat-chosen']?'米拉已经留下榉叶作舟床。去干鞍扶住船肋；铜版在这个冬天没有被磨去。':'先在鞍背把图版给当地人看。两边的水都量过，再让米拉说准她肯失去哪一样。',
 'pebble-saddle>keel-cradle@14,16':f=>f['pan-blank-chosen']?'米拉已选了退定钱和留白。跟当地人去压一回铜版、磨掉内喉；榉叶仍是她的船。':'干鞍不能凭空托起一只粮船。看过两边的水位，在鞍背决定是否要把榉叶留下。',
 'keel-cradle>wreck-slope@30,15':f=>!f['pan-rail-route']?'粮艇还没走过榉叶的船肋。在干鞍翻合弯肋，陪第一艇滑到另一边。':'舟床已经能托艇，北面还在等信号。回红窗下的检修孔，把近窗复位，再从干鞍出发。',
 'pale-print>wreck-slope@25,15':f=>!f['pan-guest-route']?'退回定钱还没把误线磨掉。擦过铜版后请粟殼掌最后一桨，送蹊泥回到外池。':'旧喉已经走通。沿内门回红标，近窗重新照着水面，再让领水人从这里带往东坎。'
};
export const basinReadings={
 'silt-tongue/pan-trace-wrong':f=>f['grave-signed']?'冬航后送信的差事已经交了。去干滩听跟船的人讲讲那趟夜路。':f['pan-letter-sealed']?'蹊泥亲手封好了信。留着蜡口，陪他把那封没有让别人看的信送到。':'问问泥舌上等家信的孩子。他肯摊开信纸，那几道歪印才轮得到米拉细看。',
 'silt-tongue/pan-hold-seal':f=>f['grave-signed']?'送信的船已经过冬。回到冬岸，听收信人说他后来怎样认出船。':f['pan-letter-read']?'孩子已把信给米拉看过，扣回蜡口也不能收回那一眼。去找他一起描手绘的歪水线。':'要留下这只蜡口，先听蹊泥亲口说他想怎样递信。',
 'pale-print/pan-bright-copy':f=>f['pan-edge-worn']||f['pan-crossed']?'铜上的里潭刻线已经亲手磨掉，揭纸也不会长回来。去喉口找粟殼，让领水的人送这一班。':'米拉还收着制版的定钱。到旧版架前先交回铜钱，再取墨拓一回原线。',
 'pale-print/pan-guest-inlet':f=>f['grave-signed']||f['remote-lit']?'那趟信船已靠过岸。旧喉仍在，回红标去看领水人今日带哪一班。':'铜版上还刻着会把客船引进蟹穴的线。先拓下旧印，再把里潭刻线磨掉，粟殼才会带这一程。'
};
