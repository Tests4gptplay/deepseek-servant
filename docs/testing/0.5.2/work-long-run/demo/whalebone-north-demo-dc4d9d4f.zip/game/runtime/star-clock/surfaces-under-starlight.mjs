import {poly,line,oval,rand} from '../paint.mjs';

const precinct=new Set(['star-clock-quay','meridian-shutter','pendulum-cellar','night-oar-road','mothglass-landing']);
const blue=(r,g,b)=>'rgb('+[r,g,b].map(v=>Math.round(v)).join(',')+')';
export function underStars(map){return precinct.has(map.id);}
export function outdoorWatch(map){return underStars(map)&&map.id!=='pendulum-cellar';}
export function starSurface(c,p,m,x,y,kind,tide,time){
 if(!underStars(m))return false;
 const q=(a,b,z=0)=>p(x+a,y+b,z),at=(a,b,u,v,ink,w=1)=>line(c,...q(a,b),...q(u,v),ink,w);
 const stone=m.id==='meridian-shutter',light=m.id==='star-clock-quay',shop=m.id==='pendulum-cellar',glass=m.id==='mothglass-landing';
 const n=rand(x,y+35),wash=Math.sin(x*.20+y*.23)*3+Math.cos(x*.23-y*.31)*2;
 const corners=[q(0,0),q(1,0),q(1,1),q(0,1)];
 if(kind==='water'){
  const horizontal=(x+y)*.34,timeWave=Math.sin(horizontal+time*.31);
  const color=light?blue(67+wash,90+wash,96+wash):shop?blue(38+wash,56+wash,54+wash):blue(35+wash,59+wash,72+wash);
  poly(c,corners,color,color);
  const sparkle=(n>.83&&Math.sin(x*.35-y*.22)>.12);
  if(sparkle){const [a,b]=q(.20+.27*n,.46);line(c,a-3,b+timeWave*.55,a+3+n*7,b,light?'#c2b48e94':'#a3bcbd91',.8);}
  if(n>.4&&n<.65)at(.25,.40,.56,.36,light?'#98a59760':'#799aa15b',.55);
  return true;
 }
 if(kind==='wood'){
  const damp=rand(Math.floor(x/3),y);
  const tint=shop?[96,73,54]:light?[104,87,69]:glass?[58,75,70]:[60,72,73];
  for(let j=0;j<3;j++){
   const base=rand(Math.floor((x+j%2)/3),y*3+j)*7+wash+damp*3;
   const ink=blue(...tint.map(k=>k+base));poly(c,[q(0,j/3),q(1,j/3),q(1,(j+1)/3),q(0,(j+1)/3)],ink,ink);
   at(0,j/3,1,j/3,shop?'#4e423a':'#344849',.9);
   if((x+j+y)%4===0){const br=.14+.68*rand(x*j+5,y+9);at(br,j/3,br,(j+1)/3,'#344342',1);}
   if(n>.33)at(.1,j/3+.10,.74,j/3+.12,shop?'#b4956c50':'#9bafa35a',.6);
  }
  if((x+y)%3===0){const [a,b]=q(.15,.17);oval(c,a,b,1.2,.66,'#273c3c');}return true;
 }
 const tint=stone?[92,108,111]:shop?[91,82,64]:light?[117,119,103]:glass?[69,88,87]:[63,80,84];
 const bed=blue(...tint.map(k=>k+wash+1.3*n));poly(c,corners,bed,bed);
 const joint=(x+Math.floor(y/2))%3===0;
 if(stone||kind==='stone'){
  at(0,.02,1,.02,stone?'#53666b':'#61716a',.85);
  if(joint)at(.04,0,.04,1,stone?'#566a6b':'#65756d',.8);
  if(n>.62){at(.07,.07,.48,.07,'#c3c7b174',.70);at(.45,.33,.58,.39,'#53676b',.7);at(.58,.39,.68,.34,'#596a6b',.8);}
 } else if(n>.58){
  at(.19,.50,.44,.54,'#9daea269',.75);at(.4,.52,.6,.48,'#738b89',.65);
 }
 return true;
}

export function lampsAcrossTheWater(c,w,h,m,t){
 if(!outdoorWatch(m))return;
 const far=h*.31,sunset=m.id==='star-clock-quay',landing=m.id==='mothglass-landing';
 const haze=c.createLinearGradient(0,far-16,0,far+42);haze.addColorStop(0,'#acafaa00');haze.addColorStop(.48,sunset?'#d7b49335':'#adc0c12c');haze.addColorStop(1,'#9cb9b400');
 c.fillStyle=haze;c.fillRect(0,far-16,w,58);
 const points=landing?[.08,.12,.32,.38,.73]:m.id==='night-oar-road'?[.18,.53,.81]:[.07,.21,.24,.27,.56,.61,.82,.86];
 for(let j=0;j<points.length;j++){
  const x=points[j]*w, y=far+5+rand(j,m.id.length)*9;
  line(c,x-4,y,x+4,y,'#394e57',1.5);line(c,x,y,x-.6,y-3-j%2,'#64777b',.65);
  const lit=j%3!==1;if(!lit)continue;
  const warmth=j%4?'#e6c992':'#a9c4b3';oval(c,x,y-.5,1.13,.8,warmth);
  for(let k=0;k<3;k++){const v=y+4+k*3;line(c,x-1.2-k*.3+Math.sin(t*.2+j),v,x+1.6+k*.3,v,'#d0bf8b53',.65);}
 }
}
