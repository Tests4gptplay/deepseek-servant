const speakers = new Map([
  ['玛拉', ['mara', /别碰|我来扛|我不会|先拉|给我让|要由我|停手|把决定写上我的名字|把错图也带着/, /我记得|安葬|养父|还给你|我陪你|谢谢|念过死亡名单|借我你那把歪尺/]],
  ['伊沃', ['ivo', /不能再|不许|别松|关了|别割|抓紧|封航|锚链|我关的是求救航门/, /对不起|那晚|记得|我欠|求救|孩子|我当年只交|我今天练的|这份错都归我/]],
  ['瑟琳', ['selene', /别碰|别动|不能|先关|涨潮|没粮|立刻|别给我写|别让她只剩/, /家里|我家|母亲|一口热|谢谢|让他们|还活着/]],
  ['米拉', ['mira', /不对|看这里|别走|刻错|不是这|不能|改线|两针歪字/, /原来|第一次|终于|留给|一寸|记下|没敢收钱|只拿得出两扇/]],
  ['布兰', ['bran', /下锚|不许|不准|不得|封航|不能|打开|解锚|我想听你说哪十二袋|是我的印/, /我欠|我怕|抱歉|孩子|那年|答应|我会守到下一潮/]],
  ['惟芦', ['weilu', /那支歌留在我这里|我不唱|不唱给|我来决定/, /粥当然不会慢|跟那个永远唱不对的人|我自己的话也留在我自己嘴里/]],
]);

export function showPortrait(panel, mode, title, body) {
  const person = mode === 'dialogue' && speakers.get(title);
  let image = panel.querySelector('.speaker-portrait');
  if (!person) {
    image?.remove();
    delete panel.dataset.portrait;
    delete panel.dataset.expression;
    return;
  }
  const [actor, firm, soft] = person;
  const expression = firm.test(body) ? 'firm' : soft.test(body) ? 'soft' : 'calm';
  if (!image) {
    image = document.createElement('img');
    image.className = 'speaker-portrait';
    image.alt = '';
    image.setAttribute('aria-hidden', 'true');
    image.width = 320;
    image.height = 352;
    panel.prepend(image);
  }
  if (panel.dataset.portrait !== actor || panel.dataset.expression !== expression) {
    image.src = new URL('../../assets/dialogue-portraits/' + actor + '-' + expression + '.png', import.meta.url).href;
  }
  panel.dataset.portrait = actor;
  panel.dataset.expression = expression;
}
