import {line,oval,poly} from '../paint.mjs';
import {box,plate} from '../voyage-shapes.mjs';

const pine=['#ceae7c','#9a7859','#665947'];
const join=(c,p,a,b,color,width=1)=>line(c,...p(...a),...p(...b),color,width);
function greenSash(c,p,x,y,open){
 const at=(u,z)=>p(x+u,y,z);
 box(c,p,x-.25,y-.2,2.22,.22,0,39,['#c7bca0','#ac9a7e','#7f7966']);
 for(let r=0;r<4;r++)
   join(c,p,[x-.24,y+.03,r*8+4],[x+1.97,y+.03,r*8+4],'#998971');
 poly(c,[at(.22,9),at(1.68,9),at(1.68,34),at(.22,34)],'#425f58','#6c6b55');
 for(const u of [.18,.90,1.65])join(c,p,[x+u,y+.03,8],[x+u,y+.03,35],'#a69569',2.6);
 join(c,p,[x+.16,y+.05,22],[x+1.69,y+.05,22],'#b29d70',2.4);
 if(open){
   poly(c,[at(.23,10),at(1.63,10),at(1.63,20),at(.23,20)],'#a3c3a1');
   poly(c,[at(.21,21),at(1.64,21),p(x+1.64,y+.49,26),p(x+.21,y+.49,26)],'#86a18e','#5b7566');
 }else{
   for(let z=10;z<22;z+=3)join(c,p,[x+.23,y+.04,z],[x+1.63,y+.04,z],'#7e9985',1.5);
 }
 box(c,p,x+.02,y,1.85,.42,7,3,pine);
 const glow=open?'#accea95c':'#7ea28e40';
 for(let i=0;i<3;i++)join(c,p,[x+.25+i*.20,y+.66+i*.22,1],[x+.94+i*.18,y+.75+i*.22,1],glow,1.5);
}
function stern(c,p,x,y,mud,sleeves,wind){
 const edge=[[0,.48],[.47,0],[2.73,.05],[3.25,.55],[2.72,.99],[.45,.96]];
 const shape=z=>edge.map(([u,v])=>p(x+u,y+v,z));
 poly(c,shape(1),'#4d7572','#42635e');
 for(let i=1;i<5;i++){
   const a=edge[i],b=edge[i+1];
   poly(c,[p(x+a[0],y+a[1],2),p(x+b[0],y+b[1],2),p(x+b[0],y+b[1],12),p(x+a[0],y+a[1],12)],i===3?'#92724f':'#a7825b','#665d46');
 }
 poly(c,shape(12),'#c8a779','#786849');
 for(let u=.52;u<2.8;u+=.37)join(c,p,[x+u,y+.16,12.1],[x+u,y+.84,12.1],'#a08460',.9);
 for(const u of [.69,1.94])box(c,p,x+u,y+.13,.17,.71,12,2,pine);
 if(mud){
   join(c,p,[x+.48,y+.963,5],[x+2.70,y+.99,5.8],'#444e41',3.6);
   for(let i=0;i<7;i++)join(c,p,[x+.53+i*.30,y+.99,5.1],[x+.59+i*.3,y+.99,2.6+(i%3)],'#576151',1.1);
 }
 if(sleeves!==null){
   const [a,b]=p(x+.42,y+.32,13),[d,e]=p(x+2.62,y+.38,13);
   line(c,a,b,a,b-25,'#675847',2);line(c,d,e,d,e-22,'#675847',2);
   c.beginPath();c.moveTo(a,b-24);c.quadraticCurveTo((a+d)/2,(b+e)/2-14,d,e-21);c.strokeStyle='#716954';c.lineWidth=1.4;c.stroke();
   function cloth(t,col,lift){
     const cx=a+(d-a)*t,cy=b+(e-b)*t-19,length=lift?5:13;
     poly(c,[[cx-4,cy],[cx+3,cy-.8],[cx+7+wind,cy+length-2],[cx+3+wind,cy+length],[cx+wind,cy+length-3],[cx-4+wind,cy+length-1]],col,'#657467');
     line(c,cx,cy,cx+wind+2,cy+length-3,'#bcc5aa',1);
   }
   cloth(.32,'#678e96',false);cloth(.71,'#dcd8b9',sleeves);
 }
}
function hearth(c,p,x,y,opened){
 const [a,b]=p(x+.55,y+.52,6);
 for(const [u,v,z] of [[0,0,11],[.87,.12,15],[.33,.67,5]]){
   join(c,p,[x+u,y+v,1],[x+.48,y+.35,z+4],'#5f5b4d',4);
 }
 oval(c,a,b-10,10.8,4.2,'#7e796a');oval(c,a,b-11.4,8.6,2.9,'#383f38');
 if(opened)plate(c,p,x+.88,y+.55,.64,.25,1,'#bc9d71');
 join(c,p,[x+.25,y+.78,1],[x+.91,y+.9,1],'#aacebd',2);
}
export function returnShoreObject(c,p,f,state,time){
 const {x,y}=f,F=state.flags;
 switch(f.id){
  case 'common-green-window':greenSash(c,p,x-.45,y-.72,!!F['return-bogged']);return true;
  case 'common-mud-stripe':stern(c,p,x-.83,y+.65,!!F['return-bogged'],null,0);return true;
  case 'common-sleeves-on-hull':stern(c,p,x-1.08,y+.72,false,!!F['common-landed-wake'],Math.sin(time*.85)*1.3);return true;
  case 'common-three-legs':hearth(c,p,x-.30,y-.30,!!F['common-high-door']);return true;
  default:return false;
 }
}
