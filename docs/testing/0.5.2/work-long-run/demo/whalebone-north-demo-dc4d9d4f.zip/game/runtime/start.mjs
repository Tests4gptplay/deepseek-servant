import {withTideCombs} from '../rules/comb-tide.mjs';
import {withCourses} from '../rules/trials.mjs';
import { mount } from './ui.mjs';
const root = document.querySelector('#game');
try {
  const {world} = await import('../content/world.mjs');
  mount(root, withTideCombs(withCourses(world)));
} catch (error) {
  root.className='fault';
  const heading=document.createElement('h1');
  const details=document.createElement('p');
  heading.textContent='航图未能载入';
  details.textContent='请通过同源网页服务打开，检查内容包与版本。'+error.message;
  root.replaceChildren(heading,details);
}
