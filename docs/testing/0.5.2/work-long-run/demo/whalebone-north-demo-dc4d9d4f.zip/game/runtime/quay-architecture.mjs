import {poly,line,oval} from './paint.mjs';
import {box,wood,bed,tub} from './voyage-shapes.mjs';
import {bakehouse,servingWindow,coalRack,handcart} from './harbor-crafts.mjs';
import {shoreMaps} from './whale-workplaces.mjs';
import {pilotMaps} from './winter-pilot-rig.mjs';
import {figure} from './figures.mjs';

const old=new Set(['bread-turn','willow-tea','sill-walk']);
export const featured=id=>old.has(id)||shoreMaps.has(id)||pilotMaps.has(id);
const slate=['#89978c','#596f6d','#465b5d'],brick=['#bd987d','#936e5e','#74594f'];
function facade(c,p,x,y,w,h,n,short){
 const z=short?14:24+n%3*6,depth=Math.min(1.65,h*.45),breadth=Math.max(2,Math.min(4,w*.78));
 const shades=n%3===0?['#c0b095','#ab9075','#847863']:n%3===1?['#b9beaa','#909c8c','#6e8279']:['#bb9f8e','#a07b70','#80655f'];
 box(c,p,x,y,breadth,depth,0,z,shades);
 const A=p(x-.12,y-.11,z+2),B=p(x+breadth+.12,y-.11,z+2),C=p(x+breadth+.2,y+depth+.22,z+1),D=p(x-.16,y+depth+.22,z+1);
 const L=p(x-.13,y+depth*.39,z+(short?7:13+n%3*2)),R=p(x+breadth+.17,y+depth*.39,z+(short?7:13+n%3*2));
 poly(c,[A,B,R,L],n%2?slate[0]:brick[0]);poly(c,[L,R,C,D],n%2?slate[1]:brick[1],n%2?slate[2]:brick[2]);
 for(let i=.28;i<breadth;i+=.44)line(c,...p(x+i,y+depth*.39,z+(short?7:13+n%3*2)),...p(x+i,y+depth+.2,z+1),n%2?'#97aaa066':'#c998796e',1.1);
 line(c,...D,...C,'#d3bb94',2);const faces=y+depth+.005;
 for(let a=.32;a<breadth-.35;a+=1.23){const d=a+.53;poly(c,[p(x+a,faces,7),p(x+d,faces,7),p(x+d,faces,z-4),p(x+a,faces,z-4)],n%2?'#486261':'#565c53','#dbc79f');line(c,...p(x+a,faces,z*.56),...p(x+d,faces,z*.56),'#bbaa8a',1.4);}
 const q=p(x+breadth-.31,faces,6);oval(c,...q,2.7,2.1,'#e4be79');
}
export function quayArchitecture(c,p,m,f,s){
 if(!featured(m.id))return false;
 if(['water','path','pier','rope'].includes(f.kind)){
  if(f.kind==='pier'){const nx=f.w||1,ny=f.h||1;for(let i=.12;i<nx;i+=.62)line(c,...p(f.x+i,f.y+.12,1),...p(f.x+i,f.y+ny-.12,1),'#7f715b72',1.25);}
  if(f.kind==='rope'){const count=Math.max(2,Math.min(6,Math.ceil((f.w||1)/3)));let prev;
   for(let n=0;n<count;n++){const x=f.x+.3+((f.w||1)-.6)*n/(count-1),y=f.y+.45,v=p(x,y,13);line(c,...p(x,y),...v,'#87765d',2.6);
    if(prev){c.beginPath();c.moveTo(...prev);c.quadraticCurveTo((prev[0]+v[0])/2,(prev[1]+v[1])/2+4,...v);c.strokeStyle='#bdaa80';c.lineWidth=1.6;c.stroke();}prev=v;}
  }
  return true;
 }
 if(!['building','wall'].includes(f.kind))return false;
 const n=f.x+f.y,w=f.w||1,h=f.h||1,front=f.y>s.y+1;
 if(m.id==='red-beacon'&&f.kind==='building'){const y=f.y+.85;facade(c,p,f.x+.24,y,2.7,2.5,n,true);servingWindow(c,p,f.x+3.6,y+.1,1.7,!!s.flags['remote-lit']);return true;}
 if(f.kind==='wall'){const width=Math.min(w,7);for(let j=0;j<Math.ceil(width/1.3);j++)box(c,p,f.x+j*1.26,f.y+h*.33,1.24,.46,0,7+(j%2)*3,slate);return true;}
 const shift=front?.45:Math.max(.45,h*.25);
 facade(c,p,f.x+.35,f.y+shift,w,h,n,front);
 if(w>5){facade(c,p,f.x+w*.58,f.y+(front?.2:shift-.33),w*.45,h,n+3,front);}
 return true;
}
export function oldQuarters(c,p,m,s,t,ordered){
 if(!old.has(m.id))return;
 const add=(x,y,fn)=>ordered.push([x+y+.47,fn]);const person=(x,y,id)=>add(x,y,()=>{const a=p(x,y);figure(c,...a,id,t,{scale:1.04});});
 if(m.id==='bread-turn'){
  add(9,8.6,()=>{box(c,p,8.6,8.25,1.4,.7,0,11,wood);for(let i=0;i<3;i++){const q=p(8.9+i*.3,8.65,13);oval(c,...q,6,3.5,'#d9be8d');}const q=p(9.4,8.4,14);line(c,q[0],q[1],q[0]+14,q[1]-3,'#a57756',3);});add(11.2,10.5,()=>coalRack(c,p,10.8,10.3,true));add(16.3,9.7,()=>handcart(c,p,16,9.5,true));person(17.3,8.9,'oven-master');
  for(const [x,y] of [[11.3,8.5],[19,11.1],[17.9,12.7]])add(x,y,()=>{const a=p(x,y);tub(c,...a,10,'#b8a68a');oval(c,a[0],a[1]-10,7,3,'#e5d6ad');});
 }else if(m.id==='willow-tea'){
  for(const [x,y] of [[6,8.4],[13.5,8.2],[20,8.4]]){add(x,y,()=>servingWindow(c,p,x,y,2.1,!!s.flags['sill-open']));person(x+1.2,y+1.2,'tea-keeper');}
  for(const [x,y] of [[10.5,10.8],[15.5,10.9]])add(x,y,()=>{box(c,p,x,y,1.6,.74,0,8,wood);const a=p(x+.56,y+.28,10);oval(c,...a,4.2,2.6,'#a4c1a4');});
 }else{
  for(const [x,y] of [[9.7,9.4],[15.8,9.2],[21.2,9.1]])add(x,y,()=>{servingWindow(c,p,x,y-.45,1.65,!!s.flags['head-turned']);const a=p(x+.2,y+.27);line(c,a[0]-13,a[1],a[0]+11,a[1]-5,'#eadbc0',2.3);});
  add(11.8,11.25,()=>bed(c,p,11.8,11.25,true));person(16.8,10.2,'walker');person(20,9.7,'night-lifter');
 }
}
