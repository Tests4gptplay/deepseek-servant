import {poly,line,oval,box,stroke,face,sag,timber,stone} from './form.mjs';
export function marketGallery(c,p,t){
 const y=.80,deck=40;
 for(const x of [9.60,13.88]){
  box(c,p,x,y+.04,.28,.30,-2,43,['#a58b65','#887152','#665e4b']);
  stroke(c,p,[x+.15,y+.11,17],[x+.77,y+.27,39],'#897b5e',3.5);
  stroke(c,p,[x+.13,y+.12,15],[x-.48,y+.28,39],'#8b7c60',3);
  for(const z of [5,23,34])stroke(c,p,[x,y+.36,z],[x+.27,y+.36,z],'#aba284',1.5);
 }
 box(c,p,9.08,y-.15,5.72,.81,37,5,['#c6af8c','#a58a67','#7b745c']);
 for(let x=9.22;x<14.72;x+=.43)stroke(c,p,[x,y-.12,42.3],[x,y+.61,42.3],'#9a8668',.95);
 for(const [a,b] of [[9.13,12.01],[13.02,14.75]]){
  for(let x=a;x<b+.01;x+=.44)stroke(c,p,[x,y+.58,42],[x,y+.58,58],'#78694e',2.7);
  stroke(c,p,[a,y+.58,58],[b,y+.58,58],'#b69d70',2.9);stroke(c,p,[a,y+.58,49],[b,y+.58,49],'#a89470',1.65);
 }
 stroke(c,p,[9.50,y-.08,40],[9.5,y-.08,74],'#847457',2.4);stroke(c,p,[13.72,y-.08,40],[13.72,y-.08,80],'#847457',2.4);
 sag(c,p,[9.5,y-.08,72],[13.72,y-.08,78],7,'#807859',1.2);
 for(const [i,col] of ['#b9c3ad','#b29273','#c8b695','#879f99'].entries()){
  const x=9.96+i*.79,z=70+i*.85,dy=Math.sin(t*.57+i)*.025;
  face(c,p,[[x,y-.08,z],[x+.40,y-.08,z+.35],[x+.42,y+.02+dy,z-12],[x+.02,y+.02+dy,z-13]],col,'#899480');
  stroke(c,p,[x+.08,y-.06,z-1],[x+.10,y+.04+dy,z-11],'#e4dbc188',.85);
 }
}
export function marketStair(c,p){
 const x=12.04,y=1.24,w=.94,length=2.48,count=11;
 for(let i=0;i<count;i++){
  const a=y+i*length/count,b=y+(i+1)*length/count,top=40-i*3.55;
  face(c,p,[[x,a,top],[x+w,a,top],[x+w,b,top],[x,b,top]],i%2?'#c7ae87':'#b8a17e','#8a806a');
  face(c,p,[[x,b,top],[x+w,b,top],[x+w,b,top-3.5],[x,b,top-3.5]],'#99876b');
  stroke(c,p,[x,b,top],[x+w,b,top],'#e1c698',1.6);
 }
 for(const u of [x-.035,x+w+.035]){
  for(const i of [0,5,10]){const v=y+i*length/count,z=40-i*3.55;stroke(c,p,[u,v,z-1],[u,v,z+15],'#877558',2.5);}
  stroke(c,p,[u,y,56],[u,y+length,15],'#af9670',2.9);
 }
}
