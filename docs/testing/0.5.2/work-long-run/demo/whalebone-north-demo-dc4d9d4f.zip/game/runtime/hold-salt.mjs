import {line,poly,oval,arc} from './paint.mjs';
import {glow,table} from './interior-furniture.mjs';
import {saltHouse} from './salt-quay.mjs';
function bunk(c,x,y,w){
 const width=Math.min(48,Math.max(24,w*7));
 for(const xx of [-width*.55,width*.55])line(c,x+xx,y+1,x+xx,y-26,'#735b46',3.4);
 for(const z of [2,15]){
  poly(c,[[x-width*.62,y-z-5],[x+width*.26,y-z-10],[x+width*.67,y-z-3],[x-width*.26,y-z+3]],'#c7bba1','#7a7563');
  line(c,x-width*.59,y-z-4,x-width*.26,y-z+3,'#a28a69',2);
  oval(c,x-width*.30,y-z-5,5.8,2.2,'#e1d3b1');
 }
}
function hatch(c,x,y,open,t){
 const lift=open?18:0;
 poly(c,[[x-16,y+1],[x-16,y-38],[x+10,y-48],[x+12,y-9]],'#394d4a','#6c725f');
 const g=[[x-13,y-2-lift],[x-13,y-33-lift],[x+8,y-41-lift],[x+9,y-10-lift]];poly(c,g,'#787c68','#575d4f');
 for(let n=0;n<4;n++)line(c,x-11+n*5,y-34-lift-n*1.7,x-11+n*5,y-5-lift-n*1.7,'#b2a487',1);
 arc(c,x-2,y-18-lift,3.8,0,Math.PI*2,'#a39370',1.5);
 line(c,x-19,y-38,x+13,y-51,'#b8aa87',3);
 if(open){glow(c,x-2,y-5,18,'#59a5a73d');line(c,x-12,y+1,x+10,y-6,'#8ead9c',2);}
}
function saltBin(c,x,y,w,d){
 const sx=Math.min(45,12+w*3),sy=Math.min(19,6+d);
 poly(c,[[x-sx,y],[x-5,y-sy],[x+sx,y-2],[x+8,y+sy]],'#ac997a','#7c735e');
 poly(c,[[x-sx,y],[x-5,y-sy-8],[x+sx,y-2],[x+8,y+sy-4]],'#dad5bd','#a8aa98');
 line(c,x-sx,y+1,x+8,y+sy,'#937b5d',3);line(c,x+8,y+sy,x+sx,y-1,'#a48a65',3);
 for(const f of [-.6,0,.6])line(c,x+f*sx,y-2,x+f*sx+4,y-4,'#f1e7cd',1);
}
export function maritime(c,p,map,f,mode,s,t){
 const label=f.label||f.name||'',k=f.kind,w=f.w||1,h=f.h||1,[x,y]=p(f.x+w/2,f.y+h/2);
 if(mode==='hold'){
  if(k==='building'){if(/床|铺|房|药/.test(label))bunk(c,x,y,w);else hatch(c,x,y,s.flags['gate-safe']||s.flags['lift-proved'],t);return true;}
  if(k==='crane'){hatch(c,x-13,y+4,s.flags['gate-safe']||s.flags['lift-proved'],t);hatch(c,x+13,y-6,s.flags['gate-safe'],t);return true;}
  if(k==='crate'&&/重|风箱|支架/.test(label)){const shift=(s.flags['lift-proved']||s.flags['gate-safe'])?-10:0;
   for(let i=0;i<3;i++){let dx=x-17+i*13,dy=y+i*2+shift;poly(c,[[dx-6,dy],[dx-6,dy-10],[dx+3,dy-15],[dx+8,dy-11],[dx+8,dy-1]],'#977e5f','#635d4c');line(c,dx,dy-13,dx,dy-34,'#7e7a62',1.3);}return true;}
  if(k==='rope'&&/帆|磨白/.test(label)){for(let j=0;j<3;j++)arc(c,x-6,y-j*2,9,0,Math.PI*2,'#a68b64',1.1);line(c,x+2,y-2,x+21,y-17,'#aa9678',1.8);return true;}
 }
 if(map.biome==='salt-market'){
  if(k==='building'&&mode!=='room'){saltHouse(c,p,f);return true;}
  if(k==='crate'&&/仓格|格|秤|样|筐/.test(label)){saltBin(c,x,y,w,h);return true;}
  if(k==='crate'&&/枕|药/.test(label)){table(c,x,y);return true;}
  if(k==='pier'&&/淹|潮痕/.test(label)){for(let i=0;i<5;i++){const a=p(f.x+i*.42,f.y),b=p(f.x+i*.42+.28,f.y+h);
    line(c,...a,...b,s.tide==='high'?'#77a1a0':'#ad9877',2.7);}return true;}
 }
 return false;
}
export function waterMarks(c,p,map,s,t){
 const high=s.tide==='high',opened=s.flags['gate-safe'];
 for(const f of map.features||[]){
  if(f.kind!=='water')continue;const w=f.w||1,h=f.h||1;
  line(c,...p(f.x,f.y+.05,high?5:0),...p(f.x+w,f.y+.05,high?5:0),'#9cbdaf',2);
  for(let i=.4;i<w;i+=1.3){
   const y=f.y+Math.min(h*.7,1.4)+(opened?Math.sin(t+i)*.15:0);
   line(c,...p(f.x+i,y),...p(f.x+i+.48,y+.02),opened?'#d2d8ba':'#93b7ad',1.1);}
 }
}
