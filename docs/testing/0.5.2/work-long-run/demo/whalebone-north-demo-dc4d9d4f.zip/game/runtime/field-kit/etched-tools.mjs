const pale='#e1d7b5',edge='#243d3a',steel='#859b94',dark='#4e645d',wood='#aa774d',copper='#b38a51';
function shape(c,path,fill,stroke=edge,lw=1.7){const p=new Path2D(path);c.fillStyle=fill;c.fill(p);if(stroke){c.strokeStyle=stroke;c.lineWidth=lw;c.stroke(p);}}
function stroke(c,path,color,width=1.5){c.strokeStyle=color;c.lineWidth=width;c.stroke(new Path2D(path));}
function stud(c,x,y,r=2){c.beginPath();c.arc(x,y,r,0,7);c.fillStyle=copper;c.fill();c.strokeStyle=edge;c.lineWidth=.8;c.stroke();stroke(c,'M'+(x-r*.5)+' '+(y-.5)+'l'+r+' 0',pale,.65);}
export function fieldTool(c,id){
 c.save();c.rotate(-.13);
 if(['work-iron','apron-hammer','trawl-mallet'].includes(id)){
  shape(c,'M-58 10 Q-55 5 -44 4 L33 -2 L35 5 L-47 14 Q-55 17 -58 10Z',wood);stroke(c,'M-51 10Q-28 8 28 2','#d7ad78',1.2);
  if(id==='trawl-mallet'){shape(c,'M19 -15L24 -21 L41 -19 L46 -14 L45 12 L39 17 L21 14 L18 9Z','#75847b');stroke(c,'M22 -15L41 -14 M22 -10 L42 -8 M24 7L42 10','#aeb8a5');}
  else if(id==='apron-hammer'){shape(c,'M18 -15 L24 -20 L38 -20 L40 -10 L35 -5 L31 12 L18 21 L15 18 L24 2 L22 -4 L14 -8Z',steel);stroke(c,'M17 -12L25 -17L37 -17 M19 15L29 6',pale);}
  else{shape(c,'M18 -14L25 -18L41 -13L42 -7L36 -5L32 6L32 13L22 15L21 7L25 -4L17 -7Z',steel);stroke(c,'M20 -12L25 -15L37 -12',pale);}
  stud(c,29,-7);for(let i=0;i<5;i++)stroke(c,'M'+(-46+i*3)+' 6l3 7','#634b3c',1.3);
 }else if(id==='rope-knife'||id==='watch-line'){
  shape(c,'M-50 12L-31 8L-5 1L0 8L-32 18L-47 20Z',wood);
  shape(c,id==='rope-knife'?'M-6 0Q12 -5 50 -20Q43 -4 28 -2L1 8Z':'M-4 0L43 -14Q39 0 30 0Q26 3 32 4L38 3Q33 14 20 6L0 9Z',steel);
  stroke(c,'M0 3Q21 -3 42 -12',pale,.95);stud(c,-14,7);stud(c,-36,14);stroke(c,'M-5 -1L1 11','#c5a471',2.2);
 }else if(id==='bearing-bow'){
  shape(c,'M-54 10L40 -3L43 0L-48 17Z',wood);shape(c,'M10 1Q-1 -13 -7 -28L0 -27Q6 -12 18 0Q24 11 24 22L19 24Q19 11 10 1Z',dark);
  stroke(c,'M-6 -27L-21 8L22 23','#d4caa1',1.25);stroke(c,'M-24 4L47 -6',pale);stud(c,14,1);shape(c,'M29 -4L30 -12L33 -12L34 -4Z',copper);
 }else if(id==='brine-staff'){
  shape(c,'M-57 13L30 -10L32 -5L-55 18Z',wood);shape(c,'M20 -9L32 -20L40 -17L36 -7L27 -2Z',steel);
  shape(c,'M28 -14L33 -23L38 -23L38 -18L34 -11Z','#71b4aa');shape(c,'M34 -12L42 -19L46 -17L41 -10L35 -6Z','#b3c9a3');stroke(c,'M-43 13L16 -5','#dbba82',1);stud(c,26,-8);
 }else if(id==='line-brake'||id==='deep-clip'){
  shape(c,id==='line-brake'?'M-37 -8Q-31 -16 -19 -16L11 -9Q25 -6 27 7L22 17L-12 17L-35 6Z':'M-38 -10L-30 -15L25 -4L38 -9L43 -4L28 8L-12 3L20 12L38 8L34 16L20 19L-37 2Z',id==='line-brake'?'#996c4e':steel);
  if(id==='line-brake')for(let i=0;i<4;i++)stroke(c,'M'+(-25+i*9)+' -13q-5 12 -3 25','#d8ae77',3);stud(c,15,3);stud(c,-24,-3);
 }else shirt(c,id);
 c.restore();
}
export function shirt(c,id){const oil=id==='oilskin',mat=id==='mat-guard',plate=id==='sighting-bracer'||id==='moth-board';const fabric=oil?'#a68a4d':mat?'#af9b6e':plate?'#85968c':'#9b9e88';
 shape(c,'M-15 -20Q-25 -20 -31 -14L-44 1L-33 8L-25 2L-23 22Q0 28 24 20L22 0L34 6L41 -5L28 -17L15 -22Q0 -17 -15 -20Z',fabric);stroke(c,'M-15 -19Q-7 -5 1 -3Q11 -9 15 -21M0 -2L2 20 M-22 17Q-2 22 21 15',pale);if(plate){shape(c,'M8 -16Q23 -22 34 -5L26 5L16 3Z',steel);stud(c,21,-9);stud(c,27,-5);}
 for(let i=0;i<5;i++){stroke(c,'M'+(-18+i*8)+' 0l2 16',mat?'#6b7257':'#7c8574',.75);if(mat)stroke(c,'M-20 '+(i*3)+'l40 -6','#ded0a0',1);}
 if(oil)for(let i=0;i<3;i++)stud(c,3,i*6+3,1.15);
}
export {shape,stroke,stud,pale,edge,steel,dark,wood,copper};
