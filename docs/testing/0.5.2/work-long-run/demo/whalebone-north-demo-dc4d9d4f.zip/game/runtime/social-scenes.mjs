import {seed,line,poly,oval,arc} from './paint.mjs';
import {box,plate,bed,tub,mast} from './voyage-shapes.mjs';
import {roomPiece,drying,windowFrame,screen} from './social-furniture.mjs';
import {heron,courseRig} from './social-fauna.mjs';

const rooms={
 'mourning-wash':['screen','wash','loom'],'mourning-room':['screen','lasts','wash'],'mourning-loft':['window','paper','boxes'],
 'stove-gallery':['stove','bowls','stove'],'late-canteen':['cot','wash','stove'],'cradle-room':['stove','cot','screen'],
 'sleeve-room':['loom','weights','loom'],'loom-run':['screen','loom','loom'],'bed-jetty':['cot','screen','cot'],
 'shutter-school':['window','paper','window'],'testimony-room':['window','paper','screen'],'haul-office':['cot','weights','paper'],
 'pallet-drain':['screen','wash','weights','wash'],'water-steps':['wash','wash','screen','cot']
};
const outdoors=new Set(['shift-square','meal-barge','port-desk','eight-landing','net-heron','wet-arcade','rain-step','awning-rafters','weight-well','counter-gantry']);
const muted=['#688581','#ad8270','#819396','#a18a66','#b19c79','#7a818d','#9b7268','#7d9180'];
function frontage(c,p,f,index,t){
 const {x,y,w,h}=f, roof=muted[index%8],rise=20+(index%3)*5,eaves=27,n=p(x+w*.48,y+h+.03,0);
 box(c,p,x+.15,y+.15,w-.3,h-.3,0,eaves,['#beac8d','#b7a383','#87907e']);
 const A=p(x-.04,y-.04,eaves),B=p(x+w+.04,y-.04,eaves),D=p(x-.09,y+h,eaves),E=p(x+w+.07,y+h,eaves),R=p(x-.18,y+h*.43,eaves+rise),S=p(x+w+.15,y+h*.43,eaves+rise);
 poly(c,[A,B,S,R],'#85928a','#65756c');poly(c,[R,S,E,D],roof,'#596e64');line(c,...R,...S,'#c7b594',2.2);
 for(let j=.42;j<w;j+=.69)line(c,...p(x+j,y+h*.43,eaves+rise),...p(x+j,y+h,eaves+.3),'#c1b396',1.1);
 for(const q of [.17,.75]){const a=p(x+w*q,y+h,20);poly(c,[[a[0]-4,a[1]-2],[a[0]+5,a[1]+1],[a[0]+5,a[1]+10],[a[0]-4,a[1]+6]],index%2?'#a6b5a0':'#667d75','#85795f');line(c,a[0],a[1],a[0],a[1]+8,'#c4aa83',1);}
 const [a,b]=n;poly(c,[[a-7,b-2],[a-7,b-23],[a+5,b-18],[a+5,b+3]],roof,'#625d4f');oval(c,a+3,b-7,1.1,1.1,'#dcc18a');
 const tag=p(x+w*.62,y+h+.07,23);c.save();c.translate(...tag);c.fillStyle='#e1d3ae';c.fillRect(-4,-4,9,10);c.fillStyle='#514e43';c.font='8px serif';c.fillText(String(index+1),-2,4);c.restore();
 const px=x+w*.22,py=y+h+.03;
 if(index%4===0)tub(c,...p(px,py),7,'#809589');else if(index%4===1)mast(c,p,px,py,20,roof,t);
 else if(index%4===2){let v=p(px,py);poly(c,[[v[0]-6,v[1]-1],[v[0]+6,v[1]+2],[v[0]+4,v[1]+6],[v[0]-5,v[1]+3]],'#a07859');for(let j=0;j<5;j++)line(c,v[0]-4+j*2,v[1],v[0]-6+j*3,v[1]-4-j%2,'#71846a',1.6);}
 else bed(c,p,px-.13,py-.06,false,true);
}
function clothBridge(c,p,f,t){
 const {x,y,w,h}=f;
 if(w>=h){for(let i=.2;i<w;i+=1.5){const q=p(x+i,y+.4);line(c,...q,q[0],q[1]-17,'#75624c',2);line(c,q[0],q[1]-15,...p(x+Math.min(w,i+1.5),y+.4,15),'#c8b18b',1.1);}}
 else for(let i=.3;i<h;i+=1.1){let v=p(x+.35,y+i);line(c,v[0]-3,v[1]-8,v[0]+2,v[1]-7,'#bad1be',2);}
}
export function socialFeature(c,p,m,f,s,t){
 const seq=rooms[m.id];if(!seq&&!outdoors.has(m.id))return false;
 const {kind:k,x,y,w=1,h=1}=f,parts=m.features.filter(v=>['building','crate','wall','water'].includes(v.kind)),i=parts.indexOf(f),cx=x+w*.51,cy=y+h*.53;
 if(m.id==='bed-jetty'&&k==='water'){
  const xx=x+.8+(s.flags['float-cot']?.14:.8),yy=y+.70;for(let j=0;j<5;j++)box(c,p,xx,yy+j*.23,2.42,.2,1,3,['#a39676','#776e56','#626959']);
  for(const q of [.34,1.8])line(c,...p(xx+q,yy-.02,5),...p(xx+q,yy+1.1,5),'#c4ad82',2.4);
  if(s.flags['float-cot'])bed(c,p,xx+.26,yy+.03,false);line(c,...p(xx+.07,yy,5),...p(x+.25,y-.23,8),'#bca77c',1.5);return true;
 }
 if(m.id==='mourning-wash'&&k==='water'){
  const xx=x+.38,yy=y+.48,ww=w-.78,hh=h-.88;
  box(c,p,xx,yy,ww,hh,0,8,['#91a09b','#6d7e76','#5d716e']);
  plate(c,p,xx+.16,yy+.15,ww-.31,hh-.30,8.5,'#799894','#bac6b1');
  for(let j=0;j<4;j++){const tx=xx+.53+j*(ww-.8)/4,ty=yy+hh-.53;plate(c,p,tx,ty,.85,.43,10,'#b49c7b','#7a7764');for(let n=0;n<5;n++)line(c,...p(tx+.12+n*.13,ty+.05,11),...p(tx+.12+n*.13,ty+.38,11),'#8d806a',1);}
  for(const [dx,dy] of [[.5,.5],[ww-.65,hh-.6]]){tub(c,...p(xx+dx,yy+dy,9),10,'#a1967c');}
  return true;
 }
 if(seq&&i>=0){
  const piece=seq[i]||'paper';if(k==='water'&&m.id!=='mourning-wash'){if(/water-steps|pallet-drain/.test(m.id))return false;return true;}
  for(let j=0;j<Math.min(3,Math.floor(w/2.2));j++){const dx=(j-(Math.min(3,Math.floor(w/2.2))-1)*.5)*1.6;roomPiece(c,p,cx+dx,cy+(j%2)*.33,piece==='bowls'?'bowl':piece,t,(i+j)%8);}
  return true;
 }
 if(m.id==='eight-landing'&&k==='building'){frontage(c,p,f,i,t);return true;}
 if(k==='rope'&&['eight-landing','mourning-wash','mourning-room','wet-arcade','meal-barge'].includes(m.id)){drying(c,p,x,y,w,m.id.startsWith('mourning')?8:m.id==='wet-arcade'?1:3,t);return true;}
 if(k==='building'&&['meal-barge','wet-arcade','shift-square','port-desk'].includes(m.id)){frontage(c,p,f,Math.abs(seed(f.label))%8,t);return true;}
 if(m.id==='net-heron'&&k==='wall'){windowFrame(c,p,cx,cy,w,true);for(let j=0;j<5;j++)line(c,...p(cx-1+j*.4,cy,31),...p(cx-.85+j*.4,cy,8),'#adad8f',1.4);return true;}
 if(m.id==='weight-well'&&k==='crate'){roomPiece(c,p,cx,cy,'weights',t);roomPiece(c,p,cx-1.1,cy+.7,'weights',t);return true;}
 if(k==='pier'&&['bed-jetty','net-heron','loom-run','port-desk','counter-gantry','awning-rafters','water-steps'].includes(m.id)){clothBridge(c,p,f,t);return true;}
 return false;
}
const objects={
 'smoke-fold':'cloth','cool-ladle':'ladle','live-berths':'paper','inner-memento':'boxes','counter-tag':'weights','inner-pan':'scale','outer-pan':'scale','low-pin':'pin','gantry-pawl':'pin','shift-caller':'paper','lining-bucket':'wash','return-pot':'stove','sleeve-weight':'weights','coiling-peg':'pin','lift-testframe':'cot','bait-pan':'bowl','counter-sleeve':'cloth','old-high-water':'gauge','bed-clock':'gauge','float-dummy':'cot','rain-cup':'wash','false-spout':'spout','awning-loweye':'ring','awning-higheye':'ring','separate-lines':'window','heron-move':'ring','private-button':'token'
};
export function socialItem(c,p,m,e,s,t){
 const x=e.x+.52,y=e.y+.4,[a,b]=p(x,y);
 if(e.id==='heron-standoff'){
  const clear=s.flags['net-open'],lured=clear&&s.flags['heron-bait']&&!s.flags['sail-heron'],px=a+(lured?68:clear?39:46),py=b-9;
  line(c,px-36,py+5,px+20,py-1,'#6d6952',4);line(c,px-24,py+5,px-19,py+15,'#887856',2);
  c.save();c.translate(px,py);c.scale(1.23,1.23);heron(c,0,0,t,lured?'lean':clear?'rest':'flare',true);c.restore();return true;
 }
 if(e.action?.type==='practice'){courseRig(c,a,b,t,e.id!=='yard-school',false);return true;}
 const style=objects[e.id];if(!style||e.kind==='npc')return false;
 if(['paper','boxes','weights','cot','stove','wash','bowl','window'].includes(style)){roomPiece(c,p,x,y,style,t,1);return true;}
 if(style==='cloth'){screen(c,p,x-.36,y,.8,'#a9a696',true);return true;}
 if(style==='ladle'){tub(c,a,b,9,'#ae9b73');line(c,a-8,b-19,a+7,b-8,'#987956',2.3);oval(c,a+7,b-8,3.2,2,'#d9c49a');}
 if(style==='gauge'){line(c,a,b+1,a,b-24,'#7e6a55',3);for(let i=0;i<5;i++)line(c,a-3,b-4-i*4,a+4,b-3-i*4,i===2?'#b3d2bc':'#bdac8b',1.2);oval(c,a,b-(s.tide==='high'?17:7),4,2,'#94b1a3');}
 if(style==='scale'){line(c,a,b,a,b-27,'#71614c',3);line(c,a-13,b-25,a+13,b-24,'#a58e68',2.6);for(const d of [-1,1]){line(c,a+d*10,b-24,a+d*12,b-11,'#8a8069',1.1);oval(c,a+d*12,b-10,5,2.1,'#849386');}}
 if(style==='ring'||style==='pin'){line(c,a-9,b+1,a+5,b-8,'#826f52',3);arc(c,a+3,b-8,5,0,6.3,'#d1a76d',2.3);}
 if(style==='spout'){poly(c,[[a-6,b-18],[a+6,b-20],[a+7,b-15],[a-1,b-13],[a-2,b-5],[a-7,b-4]],'#809793','#5b7773');}
 if(style==='token'){oval(c,a,b,5,2.3,'#c1ae84');for(let i=0;i<2;i++)oval(c,a-2+i*3,b, .7,.6,'#695a47');}
 return true;
}
