import {wardScreens} from './voyage-floor.mjs';
import {poly,line,oval,arc} from './paint.mjs';
import {plate,box,wood,iron,mast,bed,tub,wheel} from './voyage-shapes.mjs';

function glacier(c,p,f){
 const x=f.x,y=f.y,w=f.w||3,h=f.h||3,top=[p(x+.08*w,y+.42*h,16),p(x+.37*w,y+.13*h,39),p(x+.76*w,y+.2*h,29),p(x+.95*w,y+.57*h,16),p(x+.55*w,y+.88*h,18)];
 poly(c,[top[3],top[4],top[0],p(x+.08*w,y+.42*h,1),p(x+.52*w,y+.94*h),p(x+.98*w,y+.6*h)],'#78949b');
 poly(c,top,'#cdd7cf','#92a9a9');poly(c,[top[0],top[1],top[2],p(x+.54*w,y+.56*h,24)],'#e7e7d7');
 line(c,...top[1],...p(x+.48*w,y+.58*h,9),'#92a9ad',1.5);
}
function flame(c,x,y,t){
 oval(c,x,y,11,4,'#564c41');c.fillStyle='#8d7561';c.fillRect(x-8,y-15,16,14);
 poly(c,[[x-5,y-2],[x-5,y-9],[x+5,y-9],[x+5,y-2]],'#4e4a41');
 poly(c,[[x-4,y-2],[x-2,y-8],[x+1,y-6+Math.sin(t*4)],[x+3,y-10],[x+3,y-2]],'#f2b066');
}
function crank(c,p,x,y,t,open){
 box(c,p,x-.6,y-.35,1.15,.68,0,7,iron);const [a,b]=p(x,y);
 line(c,a-11,b-4,a-11,b-46,'#778880',6);line(c,a-10,b-44,a+16,b-37+(open?7:0),'#b89061',4);
 const dy=open?Math.sin(t*2.4)*4:0;wheel(c,a+8,b-18,13,open?t*.7:.3,9);
 line(c,a+13,b-34+dy,a+13,b-17+dy,'#c0b08d',3);
}
function cotRoom(c,p,f,s){
 const x=f.x,y=f.y;
 if(f.kind==='building'){
  box(c,p,x+.3,y+.6,2.6,.8,0,14,['#a7b2a7','#7d8d81','#596d67']);
  for(let i=0;i<3;i++){const a=p(x+.8+i*.72,y+1,15);tub(c,...a,7,'#85ada9');}return true;
 }
 if(f.kind==='crate'&&y<5){wardScreens(c,p,x+.3,y+.24);for(const [i,j] of [[0,0],[3,0],[0,2],[3,2]])bed(c,p,x+.35+i,y+.3+j,!!s.flags['beds-arrived']&&j===2);return true;}
 if(f.kind==='crate'){for(let i=0;i<2;i++)bed(c,p,x+.5+i*1.2,y+.6,false,true);return true;}
 if(f.kind==='path')return true;
 return false;
}
export function winterFeature(c,p,m,f,s,t){
 if(m.act!==5)return false;
 const k=f.kind,x=f.x,y=f.y,w=f.w||1,h=f.h||1;
 if(m.id==='winter-ward')return cotRoom(c,p,f,s);
 if((m.id==='lee-ridge'||m.id==='lee-mouth')&&k==='wall'){glacier(c,p,f);return true;}
 if(m.id==='fresh-gallery'&&k==='wall'){for(let i=0;i<w;i+=3)glacier(c,p,{x:x+i,y,w:3,h});return true;}
 if(m.id==='fresh-gallery'&&k==='crate'){for(let j=0;j<2;j++)for(let i=0;i<3;i++){const a=p(x+.75+i*1.15,y+.7+j);tub(c,...a,9,s.flags['water-casks']?'#c4bd96':'#92b5ae');}return true;}
 if(m.id==='cold-pump'&&(k==='crate'||k==='wall')){
  if(k==='crate'){crank(c,p,x+w*.5,y+h*.5,t,!!s.flags['pump-free']);}else{for(let i=0;i<w;i+=2.3){box(c,p,x+i,y+.5,2,.8,0,20,iron);const a=p(x+i+.8,y+.9,18);arc(c,...a,9,.18,2.85,'#b3aa8b',2);}}return true;
 }
 if(m.id==='winter-court'&&k==='rope'){
  for(let i=0;i<5;i++){const[a,b]=p(x+i*2.1,y+.5);line(c,a,b,a,b-27,'#776c57',2);for(let j=0;j<4;j++){line(c,a+j*4,b-25,a+j*4+5,b-10,'#718782',.9);line(c,a+j*4,b-10,a+j*4+5,b-24,'#718782',.9);}}return true;
 }
 return false;
}
export function winterItem(c,p,m,e,s,t){
 if(m.act!==5)return false;const x=e.x+.5,y=e.y+.5,[a,b]=p(x,y),flags=s.flags;
 switch(e.id){
 case 'outer-wind':case 'inner-wind':mast(c,p,x,y,33,'#ba785d',t,e.id==='outer-wind');return true;
 case 'salt-wick':case 'clear-runnel':{const salt=e.id==='salt-wick';tub(c,a,b,12,salt?'#9ea8a2':'#82b8b2');line(c,a-8,b-13,a+11,b-10,'#665e4e',2.5);line(c,a+2,b-10,a+1,b-2,'#e5ddbd',2.8);if(salt)for(let j=0;j<7;j++)oval(c,a-7+(j%4)*4,b-7+Math.floor(j/4)*2.4,1.4,1,'#e4dec8');return true;}
 case 'high-berth':case 'low-berth':case 'moor-chain':{const high=e.id==='high-berth';mast(c,p,x,y,high?44:34,high?'#b98460':'#708d85',t,0);for(let j=0;j<7;j++)line(c,a-5,b-7-j*3.4,a+4,b-7-j*3.4,j%2?'#e7dec2':'#8a5f4d',1.4);if(flags['moor-proved'])arc(c,a+3,b-17,6,0,6.2,'#d0b57a',2.4);return true;}
 case 'bed-gauge':bed(c,p,x-.45,y-1.06,false);for(const d of [-1,1])line(c,a+d*13,b+9,a+d*11,b+4,'#d7b273',2);return true;
 case 'ward-extra':{const xx=p(x,y);tub(c,...xx,7,flags['winter-extra']?'#90b5ac':'#7a7563');return true;}
 case 'winter-proof':box(c,p,x-.45,y-.24,.9,.5,0,14,wood);for(let j=0;j<4;j++)oval(c,a-8+j*5,b-13,1.7,1.1,flags['winter-proof']?'#b56b53':'#d2c09c');return true;
 case 'pump-salve':case 'lure-ice':{mast(c,p,x,y,19,'#c29160',t,.3);tub(c,a+6,b+1,6,flags['warm-cloth']?'#b98c57':'#7f9c90');return true;}
 case 'hospital-clamp':crank(c,p,x,y,t,!!flags['spare-pump']);return true;
 case 'long-bench':box(c,p,x-.72,y-.24,1.6,.46,0,8,wood);flame(c,a+27,b-5,t);return true;
 default:return false;
 }
}
