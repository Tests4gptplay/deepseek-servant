import {poly,line,oval,face,stroke,plate,box,sag,timber,stone} from './form.mjs';
import {shadeTree,harborBoat,steps} from './shore.mjs';
import {vapor} from './trades.mjs';
import {dapple,tidalGate,workLanding,wickBench,homeSill} from './landings.mjs';
import {gantry} from './craft.mjs';
import {marketGallery,marketStair} from './gallery.mjs';
const stairs={
 'wharf-scale':[[24.5,16.45,'y',-1]],'rope-market':[[10.5,16.35,'y',-1]],
 'lower-tide':[[1.60,4.52,'x',-1],[23.29,5.50,'x',1]],
 'coffin-hoist':[[18.5,14.36,'y',-1]]};
function stoneEdge(c,p,x,y,w){
 box(c,p,x,y,w,.36,-11,12,stone);
 for(let i=.08;i<w-.1;i+=.78){stroke(c,p,[x+i,y+.37,0],[x+i+.04,y+.37,-5],'#6c8279',1);stroke(c,p,[x+i+.32,y+.37,-5],[x+i+.33,y+.37,-10],'#6b8078',.8);}
 stroke(c,p,[x,y+.37,-5],[x+w,y+.37,-5],'#82988a',1);
}
function upperArcade(c,p,s,t){
 for(const [x,w] of [[2.8,6.7],[14.3,4.55]]){
  face(c,p,[[x,.9,3],[x+w,.9,3],[x+w,.9,30],[x,.9,30]],'#6e827b');
  for(let i=.20;i<w-.5;i+=1.35){const a=x+i,b=a+1.06,base=1.8;
   face(c,p,[[a,.92,base],[a,.92,17],[a+.16,.92,22],[a+.38,.92,24],[b-.32,.92,24],[b-.1,.92,21],[b,.92,17],[b,.92,base]],'#455d5f','#9d9c81');}
  box(c,p,x,.53,w,.68,28,4,['#bfac86','#a08c70','#7f8270']);
 }
 // A real overhead landing bridges the two shops; its open throat reveals the actual market stair.
 const A=[9.65,.90,32],B=[14.27,.90,32];
 stroke(c,p,A,B,'#76684e',5.5);stroke(c,p,[9.65,.88,34],[14.27,.88,34],'#c2ad83',1.9);
 for(let i=9.79;i<14.3;i+=.62)stroke(c,p,[i,.88,35],[i,.88,44],'#85775e',1.8);
 stroke(c,p,[9.70,.88,44],[14.3,.88,44],'#ad9874',2);
}
function grate(c,p,x,y,w,h){
 plate(c,p,x,y,w,h,.7,'#526661','#7b8674');
 for(let i=.04;i<w;i+=.18)stroke(c,p,[x+i,y+.02,1.2],[x+i,y+h-.02,1.2],'#a7a387',1.5);
}
function sill(c,p,x,y,w){plate(c,p,x,y,w,.30,1,'#c8b895','#8f927a');for(let i=.15;i<w;i+=.29)stroke(c,p,[x+i,y+.03,1.4],[x+i-.06,y+.28,1.4],'#a19b81',.85);}
export function portFloor(c,p,m,s){
 const id=m.id;
 if(id==='wharf-scale'){
  dapple(c,p,3.51,15.18);for(const y of [10.72,12.15])for(let x=.2;x<23.7;x+=1.1)stroke(c,p,[x,y,.65],[x+.76,y+.012,.65],'#958d724d',1.7);
  for(const [x,y] of [[3.4,12],[6.4,12],[9.4,12]]){const q=p(x,y,1);oval(c,...q,3.8,.85,'#c7b988');}
 }else if(id==='rope-market'){
  for(let x=1.3;x<23;x+=1.1)plate(c,p,x,8.85,.8,.19,.7,'#ad9a7959');
  grate(c,p,8.20,5.35,1.06,.36);sill(c,p,10.07,15.74,1.05);
 }else if(id==='lower-tide'){
  grate(c,p,11.84,7.06,.43,5.3);grate(c,p,17.2,6.45,3.2,.34);
  for(let i=0;i<5;i++){const q=p(17.3+i*.55,10.50-i*.20,.4);oval(c,...q,3.7+i*.5,1.6,'#667f7154');}
 }else if(id==='coffin-hoist'){
  for(const x of [15.39,16.12])for(let y=9.3;y<14.95;y+=.63){stroke(c,p,[x,y,1],[x,y+.51,1],'#685e47',1.6);}
 }else if(id==='wake-court'){sill(c,p,10.87,6.13,1.22);sill(c,p,10.91,6.57,1.11);}
 else if(id==='wick-house'){sill(c,p,7.04,12.08,1.10);plate(c,p,6.94,11.57,1.32,.45,.7,'#a67c5e','#856954');}
}
export function portPlaces(c,p,m,s,t,queue){
 const id=m.id;if(!['wharf-scale','rope-market','lower-tide','coffin-hoist','wake-court','wick-house'].includes(id))return;
 const add=(depth,paint)=>queue.push([depth,paint]);const nearTree=(x,y,d)=>add(d,()=>{c.save();const a=p(s.x+.5,s.y+.5),b=p(x,y);if(Math.abs(a[0]-b[0])<35&&a[1]>b[1]-58&&a[1]<b[1]+5)c.globalAlpha*=.42;shadeTree(c,p,x,y,t);c.restore();});
 for(const [x,y,axis,up] of stairs[id]||[])add(x+y+.16,()=>steps(c,p,x,y,axis,up,s,t));
 if(id==='wharf-scale'){
  add(19.6,()=>stoneEdge(c,p,.64,14.88,6.5));nearTree(3.51,15.18,18.8);
  add(23.65,()=>harborBoat(c,p,4.93,16.12,3.7,.99,s,t));add(23.80,()=>sag(c,p,[7.8,15.01,5],[7.21,16.36,s.tide==='high'?7:1],3,'#8d7d5c',1.6));
 }else if(id==='rope-market'){
  add(25.6,()=>{sag(c,p,[13.0,5.05,39],[18.84,11.90,44],8,'#8f8064',1.15);for(const [x,y] of [[14.3,6.55],[16.0,8.52],[17.9,10.8]]){const q=p(x,y,39);line(c,q[0],q[1],q[0],q[1]+4,'#79674f',1);poly(c,[[q[0]-4,q[1]+4],[q[0]+3,q[1]+4],[q[0]+2,q[1]+10],[q[0]-2,q[1]+10]],'#cfac73','#887458');}});
 }else if(id==='lower-tide'){
  add(10.2,()=>upperArcade(c,p,s,t));add(16.9,()=>marketGallery(c,p,t));add(15.2,()=>marketStair(c,p));add(6.0,()=>workLanding(c,p,.38,3.02,1.85));add(28.3,()=>tidalGate(c,p,s));add(23.2,()=>stoneEdge(c,p,8.8,13.88,7.9));
  add(35.7,()=>{const z=s.tide==='high'?2:-5;for(let u=0;u<3;u++){const q=p(19.3+u*.65,11.52+u*.23,z);line(c,q[0]-8,q[1],q[0]+8,q[1]-1,'#b6d0b9aa',1.65);}});
 }else if(id==='coffin-hoist'){
  add(24.5,()=>gantry(c,p,s,t));add(30.1,()=>harborBoat(c,p,9.4,15.4,5.7,1.4,s,t,true));add(30.45,()=>sag(c,p,[15.08,14.77,6],[14.46,16.03,s.tide==='high'?10:3],5,'#827354',1.9));
 }else if(id==='wake-court'){
  nearTree(8.20,5.62,13.96);add(18.2,()=>{const q=p(10.47,6.54,6);oval(c,...q,6,2.6,'#98775a');for(let k=0;k<3;k++)line(c,q[0]-3+k*2,q[1],q[0]-3+k*2,q[1]-5-k%2,'#d7c293',1.5);});
 }else if(id==='wick-house'){
  add(10.40,()=>wickBench(c,p));add(20.75,()=>homeSill(c,p));add(7.9,()=>{box(c,p,2.34,3.42,2.03,.42,0,17,timber);for(let i=0;i<5;i++){const q=p(2.58+i*.34,3.68,18);oval(c,...q,3.2,1.2,'#dcccaa');line(c,q[0],q[1],q[0],q[1]-4-i%3,'#e9dcb4',1.7);}});
  add(19,()=>{const q=p(12.10,4.88,16);vapor(c,...q,t,'#e4d8b17a',.80);});
 }
}
