import {line,oval,arc,poly} from '../paint.mjs';
import {rod,engine} from './forged.mjs';
export function gearPhase(b){
 const i=b.spec.phases.findIndex(p=>p.tell===b.intent.tell||p.fromHp===b.intent.phaseThreshold);
 return ['white','black','reverse'][i]||'white';
}
export function crewSlot(h,i){
 const edge=h.lane==='edge'?11:0;
 return [[-32-edge,1-edge*.32],[-56-edge,25-edge*.32],[-83-edge,-14-edge*.32],[-107-edge,12-edge*.32]][i];
}
function path(c,points,col,width,dash=false){
 c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));
 c.strokeStyle=col;c.lineWidth=width;if(dash)c.setLineDash([5,5]);c.stroke();c.setLineDash([]);
}
function arrow(c,x,y,dx,dy,col){
 const len=Math.hypot(dx,dy),u=dx/len,v=dy/len;poly(c,[[x,y],[x-8*u+4*v,y-8*v-4*u],[x-8*u-4*v,y-8*v+4*u]],col);
}
export function trajectory(c,x,y,b,t){
 const phase=gearPhase(b),k=b.intent.kind,pulse=(1+Math.sin(t*2.2))*.5;
 c.save();c.translate(x,y);
 poly(c,[[-131,24],[-98,-13],[-41,-20],[73,-19],[105,3],[58,27],[-62,43]],'#304c4d72','#6f7a68');
 for(const y0 of [-2,12])rod(c,-120,y0+14,71,y0-8,2,'#8b927e');
 for(let i=0;i<3;i++){const xx=45+i*9;line(c,xx,-4,xx+4,-8,i<['white','black','reverse'].indexOf(phase)+1?'#e7bd7c':'#7d8070',3);}
 if(phase==='reverse'){
  const pts=[[45,-7],[33,-20],[-8,-22],[-48,-12],[-65,3],[-39,12],[-8,9]];
  path(c,pts,'#284c52',9);path(c,pts,'#94ccbf',3);arrow(c,-65,3,-17,15,'#efd6a4');arrow(c,-8,9,31,-3,'#b5e5d0');
  for(const [xx,yy] of [[-30,-19],[-16,11]])line(c,xx,yy-4,xx+5,yy+1,'#f1d5a2',2.3);
 }else if(k==='shell'){
  const near=5+pulse*4;for(const dir of [-1,1]){const xx=18+dir*(14+near);path(c,[[xx+dir*9,-20],[xx,-20],[xx-dir*8,-11],[xx-dir*8,-5]],'#3a4643',7);path(c,[[xx+dir*8,-20],[xx,-20],[xx-dir*8,-11]],'#e0b27c',2);}
  oval(c,19,-9,5.3,3.5,'#e1ce8c');
 }else if(k==='rush'||k==='whirl'){
  const pts=[[50,-10],[18,-17],[-15,-12],[-52,-1],[-74,8]];
  path(c,pts,phase==='black'?'#413f3b':'#829a90',9);path(c,pts,phase==='black'?'#d9aa75':'#ecdbc1',2.8,true);
  for(const [x0,y0] of [[-32,-6],[-69,6]])arrow(c,x0,y0,-15,6,'#eed2a4');
 }else{
  for(const [xx,yy] of [[-7,0],[11,-3],[29,-5]]){rod(c,xx,yy-38-pulse*3,xx,yy-8,2.8,'#eee3c2');arrow(c,xx,yy-2,0,12,'#e7c89c');oval(c,xx,yy,5.5,1.5,'#ead19b');}
 }
 c.restore();
}
export function liveMachine(c,t,b){
 const phase=gearPhase(b),kind=b.intent.kind,sw=(1+Math.sin(t*2.2))*.5;
 engine(c,1,1,t,phase,kind,false,1.17);
 c.save();c.translate(-12,-79);
 rod(c,-18,13,-23,31,3,'#8a8169');rod(c,18,11,21,29,3,'#8a8169');
 poly(c,[[-25,-10],[19,-13],[28,-6],[25,12],[-23,15],[-30,6]],'#304c4e','#bdab82');
 if(phase==='white'&&kind==='ram'){
  for(const x of [-13,0,13]){line(c,x,-8,x,-1+sw*3,'#e8d8b5',2);poly(c,[[x-4,-1+sw*3],[x+4,-1+sw*3],[x+3,4+sw*3],[x,8+sw*3],[x-3,4+sw*3]],'#efe1c4');}
 }else if(phase==='black'&&kind==='shell'){
  for(const d of [-1,1]){const x=d*(13-sw*3);path(c,[[x+d*5,-6],[x,-6],[x-d*6,-1],[x-d*5,5],[x-d,7]],'#e0b075',3.3);}oval(c,0,0,2.7,3,'#e1cf95');
 }else if(phase==='reverse'){
  const a=[[-14,-4],[8,-6],[14,-2],[12,2],[3,5],[-13,6]];path(c,a,'#acd7c5',2.6);arrow(c,-16,6,-7,0,'#dfbd85');arrow(c,10,-6,7,0,'#c8d7b6');
 }else{
  const col=phase==='white'?'#e6dfc4':'#e1aa70';path(c,[[18,-4],[5,-3],[-7,0],[-17,5]],col,3.5);arrow(c,-18,6,-11,4,col);
 }
 c.restore();
}
