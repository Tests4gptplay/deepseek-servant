import {openHeelCabin} from './heelturn-cabins.mjs';
import {heelFurniture} from './heelturn-household-tools.mjs';

const wood='#966c49',edge='#3c3b35',light='#d3aa71',salt='#cee0cf';
function shape(c,points,fill,border=edge){
 c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();
 c.fillStyle=fill;c.fill();if(border){c.strokeStyle=border;c.lineWidth=1.25;c.stroke();}
}
function path(c,points,color,w=1){
 c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.strokeStyle=color;c.lineWidth=w;c.stroke();
}
function bead(c,x,y,rx,ry,color){c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);c.fillStyle=color;c.fill();}
function jamb(c,p,f,night){
 const a=f.x+.30,b=f.y+.55,m=f.w-.5;
 const v=(u,z)=>p(a+u,b,z);
 // The black water band stays level in the hull's old frame. The door grew a diagonal.
 const pole=(u,z,lean)=>{
  shape(c,[v(u,0),v(u+.18,0),v(u+.18+lean,z),v(u+lean,z)],wood);
  path(c,[v(u+.07,2),v(u+.07+lean,z-2)],light,1.1);
 };
 pole(0,42,.24);pole(m,54,.44);
 shape(c,[v(.22,41),v(m+.43,53),v(m+.43,60),v(.20,48)],'#74583c');
 shape(c,[v(.29,3),v(m-.12,4),v(m+.18,49),v(.52,37)],'#7a6950');
 for(let i=0;i<7;i++){const u=.47+i*(m-.7)/7;path(c,[v(u,6),v(u+.16,33+i*1.7)],i%2?'#a48b65':'#574f3d');}
 const wet=f.x>20?19:32;
 path(c,[v(.25,wet),v(m*.46,wet+.6),v(m+.28,wet)],'#30494b',4);
 path(c,[v(.23,wet+1.4),v(m*.3,wet+2),v(m*.6,wet+1),v(m+.28,wet+2)],salt,1.1);
 if(night){path(c,[v(.2,11),v(m*.42,15),v(m+.4,23)],'#7bbac2',3);path(c,[v(.22,12.8),v(m*.42,16.4),v(m+.4,24.5)],'#d2eeeb',1);}
 const [x,y]=v(m*.7,23);bead(c,x,y,4,2.6,'#3d372f');bead(c,x+1,y-.6,2.8,1.25,'#d2aa75');
}
function stair(c,p,f){
 const x=f.x+.15,y=f.y+.35;
 for(let i=0;i<3;i++){
  const ax=x+i*.72,ay=y-i*.09,z=4+i*8;
  const pts=[p(ax,ay,z),p(ax+.65,ay,z),p(ax+.65,ay+.72,z),p(ax,ay+.72,z)];
  shape(c,[pts[2],pts[3],p(ax,ay+.72,z-4),p(ax+.65,ay+.72,z-4)],'#665641');
  shape(c,pts,i===2?'#c3a178':'#ac8559');
  const [px,py]=p(ax+.35,ay+.4,z+1);bead(c,px,py,2,1.3,'#536164');
 }
 const a=p(x+2.35,y-.10,31),b=p(x+3.44,y-.1,42);
 path(c,[a,b],'#434c45',1.7);bead(c,b[0],b[1],3.1,1.8,'#bda572');
}
function skid(c,p,f,turned){
 const x=f.x+.2,y=f.y+.6;
 for(const offset of [0,.36]){
  const q=[];for(let i=0;i<=13;i++){const a=Math.PI*.5*i/13;q.push(p(x+.25+3.0*Math.sin(a),y+offset+1.24*(1-Math.cos(a)),1));}
  path(c,q,'#534b39',3.1);path(c,q,'#c1a575',.75);
 }
 const ux=turned?2.2:2.8,uy=turned?1.30:.22;
 const corners=[p(x+.4,y+.38,3),p(x+.4+ux,y+.38+uy,3),p(x+.15+ux,y+.95+uy,3),p(x+.15,y+.95,3)];
 shape(c,corners,'#916c46');path(c,[corners[0],corners[1]],'#c8a270',2);
}
export function heelturnJoinery(c,p,map,f,s){
 if(openHeelCabin(c,p,map,f)||heelFurniture(c,p,map,f,s))return true;
 if(!['heel-frame','heel-stair','heel-skid'].includes(f.kind))return false;
 if(f.kind==='heel-frame')jamb(c,p,f,map.act===6);
 else if(f.kind==='heel-stair')stair(c,p,f);
 else skid(c,p,f,!!s.flags['heel-bed-turned']||map.act===6);
 return true;
}
