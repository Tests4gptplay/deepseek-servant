import {liningInTheSteam} from './chaff-in-the-fold-of-two-liners.mjs';
import {poly,line,oval} from './heelturn-cabins.mjs';
const ink='#413f37',umber='#775c42',teal='#4c7072',wax='#9c4939',flax='#c7ac79';
function type(c,x,y,str,size=11,color=ink){
 c.font=size+'px "Noto Sans CJK SC",sans-serif';c.fillStyle=color;c.fillText(str,x,y);
}
function paper(c,rec){
 const corners=[[-119,-70],[104,-74],[118,-60],[113,62],[82,74],[-107,66],[-122,37]];
 poly(c,corners,'#d9c293',umber);poly(c,[[-113,-63],[14,-66],[4,62],[-108,56]],'#e9d9ae');
 poly(c,[[14,-66],[107,-66],[104,49],[4,62]],'#c4ad7f');line(c,[[14,-66],[4,62]],'#a28d66',2);
 line(c,[[-100,-40],[92,-43]],teal,1.5);type(c,-98,-48,'栖鸥　领白麦六袋',15);
 type(c,-98,-20,'舟　四',13);type(c,22,-20,'泊　五号',13);
 for(let i=0;i<5;i++){const y=-6+i*10;line(c,[[-96,y],[-50+i%3*7,y-1],[-22,y+1]],'#91836c',1);line(c,[[22,y],[51,y-2],[70+i%3*6,y]],'#95856b',1);}
 oval(c,[77,28],13,12,wax);line(c,[[71,22],[82,20],[82,34],[72,34],[73,23]],'#e2c291',1.5);
 if(rec?.draft==='accused'||rec?.accused){line(c,[[-108,42],[98,32]],'#a15644',2);oval(c,[-103,46],2.6,2.6,ink);}
}
function rail(c,rec,wet){
 const cfg=rec?.hull||{},inside=cfg.inside;
 poly(c,[[-125,12],[-105,-53],[41,-63],[64,-29],[39,22],[-91,45]],inside?'#a87a4d':'#bc985f',umber);
 for(let row=0;row<4;row++)line(c,[[-109,-30+row*17],[-61,-40+row*19],[29,-49+row*18]],'#896545',1);
 poly(c,[[48,-62],[113,-54],[120,46],[64,60],[42,23],[65,-28]],'#89958c',ink);
 for(let i=0;i<6;i++){const x=-97+i*36,y=-8-i%2*5;
  oval(c,[x,y],7,5,ink);oval(c,[x+1,y],3,2.4,'#d4ba82');
  if(inside){if(i<4)line(c,[[x+2,y+5],[x+5,y+11],[x+1,y+18]],'#e2bb78',2.7);
   else line(c,[[x,y+5],[x,y+16]],'#d6d5b7',2.3);}
 }
 const rise=cfg.level==='low'?29:-36;line(c,[[-114,rise],[-23,rise-9],[101,rise-4]],'#dec576',4);
 for(let i=0;i<11;i++)line(c,[[-105+i*18,rise-2],[-105+i*18,rise-7-(i%3)]],umber,1);
 if(wet)for(let i=0;i<3;i++)line(c,[[-120,35+i*5],[-38,27+i*5],[36,31+i*5],[111,27+i*5]],'#80b1ad',1.7);
 type(c,-116,60,inside?'木规背面':'木规正面',11,'#f0dfb8');type(c,38,63,wet?'水盖舷眼':'水退露舷',11,'#f0dfb8');
}
function liner(c,rec){
 const cfg=rec?.basket||{};
 for(let i=0;i<6;i++){
  const x=-105+(i%3)*72,y=-52+Math.floor(i/3)*53;
  poly(c,[[x+3,y],[x+53,y+3],[x+48,y+37],[x+16,y+42],[x-3,y+26]],'#c7b395',umber);
  for(let k=1;k<8;k++){const a=x+k*6;line(c,[[a,y+7],[a-2,y+22],[a+2,y+31]],'#a99576',.8);}
  line(c,[[x+3,y+6],[x+29,y+10],[x+47,y+6]],teal,2.3);
  if(cfg.inside&&i>3)liningInTheSteam(c,x,y,i);
 }
 const off=cfg.level==='low'?0:-51;line(c,[[-117,28+off],[-117,16+off],[-110,15+off]],wax,3);
 type(c,-112,65,cfg.inside?'翻开的袋底':'袋底外侧',11,'#f0dfb8');type(c,41,65,cfg.level==='low'?'热锅边':'冷水边',11,'#f0dfb8');
}
export function expandedSample(c,w,h,id,s){
 const key=id?.replace('quaybill-','');if(!['sheet','desk','basket','hull'].includes(key))return;
 const scale=Math.min(w<760?(w-62)/270:(w*.5)/270,h*(w<760?.29:.34)/158,1.92);
 const x=w<760?w*.5:w*.315,y=w<760?h*.297:h*.47;c.save();c.translate(x,y);c.scale(scale,scale);
 poly(c,[[-137,-85],[128,-85],[136,-76],[135,82],[-133,83],[-140,74]],'#283b38db','#ac986c');
 if(key==='hull')rail(c,s.progress?.quaybill,s.tide==='high');
 else if(key==='basket')liner(c,s.progress?.quaybill);
 else paper(c,s.progress?.quaybill);
 c.restore();
}
