import {strandline} from './driftbay-strandline.mjs';
import {contours,outline,wash,seam} from './driftbay-contours.mjs';
import {line,oval,poly,rand} from './paint.mjs';
const color={
 scree:['#9c7359','#c99b73','#655848','#e0c29b','#969891','#c8ccbb'],
 roof:['#576863','#a69a78','#354b53','#e5ce92','#576576','#a4a89a'],
 pools:['#777e64','#acaa7a','#374d50','#c9bd83','#617678','#aeb39a'],
 throat:['#595b4a','#8e8960','#344a47','#c1ae7a','#495e5c','#959c83'],
 heights:['#796a7e','#b4a192','#49455a','#e6c1a3','#777084','#c1b7bd'],
 lens:['#597971','#b9b79a','#345a60','#d4d8ab','#72898a','#becab9'],
 cradle:['#8d7756','#bb9d67','#485743','#e2c280','#677666','#bcba8e']};
function strand(c,p,x,y,phase,n,marsh){
 const [a,b]=p(x,y);for(let k=0;k<n;k++){
  const off=(k-n/2)*1.1,h=(marsh?18:9)*(.45+rand(k+x*23,y*11));
  c.beginPath();c.moveTo(a+off,b);c.quadraticCurveTo(a+off+4,b-h*.5,a+off+2+Math.sin(phase*.75+k)*2,b-h);
  c.strokeStyle=marsh?(k%2?'#a28e52':'#576d4b'):(k%2?'#6d744f':'#2c625d');c.lineWidth=k%3===0?1.8:1;c.stroke();}
 c.lineWidth=1;
}
export function bayGround(c,p,map,s,t,visible){
 const {id,relief}=map.driftbay,{shore,rock,trail}=contours(map),pal=color[id],high=s.tide==='high';
 // Submerged ledges, foam and a continuous basalt bank have distinct elevations.
 seam(c,p,shore,-10,'#9bbeb34f',high?23:29);seam(c,p,shore,-8,'#dee3c2ac',high?4.8:3);
 wash(c,p,shore,-5,pal[2]);wash(c,p,shore,1,pal[0]);seam(c,p,shore,1,'#ccb58c96',2);
 const q=p(map.width*.54,map.height*.41),g=c.createLinearGradient(q[0]-170,q[1]-150,q[0]+170,q[1]+170);
 g.addColorStop(0,pal[1]);g.addColorStop(.54,pal[0]);g.addColorStop(1,pal[1]);wash(c,p,trail,1,g);
 wash(c,p,rock,4,pal[2]);wash(c,p,rock,10,pal[4]);seam(c,p,rock,10,pal[5]+'b8',1.6);
 c.save();outline(c,p,rock,10);c.clip('evenodd');
 const [a,b]=p(map.width*.5,map.height*.5);
 for(let k=-45;k<=45;k++){const yy=b+k*11,tilt=Math.sin(k*.31)*13;c.beginPath();c.moveTo(a-1300,yy-105);
  c.bezierCurveTo(a-550,yy+tilt,a+120,yy-67+tilt,a+1200,yy+118);
  c.strokeStyle=k%5===0?pal[5]+'94':k%2?pal[2]+'50':pal[5]+'43';c.lineWidth=k%5===0?3.2:1.2;c.stroke();}
 c.restore();
 for(let y=0;y<map.height;y++)for(let x=0;x<map.width;x++){const [u,v]=p(x+.5,y+.51);if(!visible(u,v,58))continue;
  const key=relief[y][x],n=rand(x+11,y),h=rand(y+66,x);
  if(key==='~'){
   if(n>.7){const lag=Math.sin(t*.73+x*.67+y*.2),length=6+16*h;line(c,u+lag*3,v,u+length+lag*3,v-.9,'#c9e0ca72');}
   if((id==='lens'||id==='throat'||id==='pools')&&n>.84)strand(c,p,x+.4,y+.6,t,3,false);
  }else if(key==='.'&&n>.27){
   const stretch=id==='scree'?18:7,shift=h*9;line(c,u-stretch+shift,v+2,u+4+shift,v-.5,pal[3]+'8a',1.1);
   if(n>.66)for(let k=0;k<3;k++){const tx=u-4+rand(x+33*k,y)*9;oval(c,tx,v+k%2,2.3-k*.3,1,pal[k%2?0:2]+'c0');}
   if(id==='cradle'&&y>11&&n>.58||id==='lens'&&x>18&&n>.63)strand(c,p,x+.6,y+.48,t,5,true);
  }
 }
 strandline(c,p,map,s,t,visible);
}
