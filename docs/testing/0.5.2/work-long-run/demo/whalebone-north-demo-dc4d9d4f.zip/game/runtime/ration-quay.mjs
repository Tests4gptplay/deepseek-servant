import {line,poly,oval,arc} from './paint.mjs';
import {chair} from './interior-furniture.mjs';
import {figure} from './figures.mjs';
function bag(c,x,y,size=1){
 c.save();c.translate(x,y);c.scale(size,size);
 oval(c,0,1,9,3,'#67725b6e');poly(c,[[-8,0],[-9,-6],[-6,-10],[3,-11],[8,-7],[9,-2],[5,1],[-3,2]],'#beaa7a','#877a57');
 line(c,-6,-4,5,-2,'#9a885f',1);line(c,1,-10,5,-13,'#8a7b57',1);c.restore();
}
function litter(c,x,y){
 line(c,x-22,y+1,x+11,y+11,'#766044',2);line(c,x-10,y-6,x+24,y+4,'#77634c',2);
 poly(c,[[x-15,y-2],[x-6,y-6],[x+19,y+2],[x+9,y+7]],'#c8bc9e','#9a8e75');
 poly(c,[[x-8,y-2],[x-4,y-4],[x+10,y],[x+8,y+4]],'#8c9d98');
}
function barge(c,x,y,ward,loaded,t){
 const bob=Math.sin(t*.8)*1.2;c.save();c.translate(x,y+bob);
 oval(c,7,9,83,12,'#315b5b66');
 const hull=[[-83,-7],[-62,-16],[37,-19],[77,-15],[90,-20],[79,-3],[49,7],[-50,10],[-70,5]];
 poly(c,hull,ward?'#645448':'#715440','#4c5149');
 poly(c,[[-77,-8],[-61,-13],[38,-16],[76,-13],[64,-6],[43,-2],[-46,4]],'#b29670','#685f4e');
 line(c,-63,4,50,3,'#aa8b62',2);line(c,-47,8,47,6,'#796f54',1.3);
 line(c,-22,-2,-21,-54,'#76654d',2.8);line(c,-21,-52,-59,-11,'#807760',.95);line(c,-21,-51,51,-10,'#83765a',1);
 poly(c,[[-21,-50],[-2,-47],[-10,-42],[-21,-43]],ward?'#c5c2aa':'#738a70','#7a826d');
 if(ward){
  for(const dx of [2,15,28]){line(c,dx,-8,dx,-27,'#877b61',1.7);}
  poly(c,[[1,-26],[11,-32],[39,-26],[31,-21]],'#c4c3aa','#78857b');litter(c,6,-5);
 }else if(loaded){for(let i=0;i<8;i++)bag(c,-49+(i%5)*13,-6-(i>4?6:0),.69);}
 c.restore();
}
export function rationProp(c,p,f,s,t){
 const [x,y]=p(f.x+(f.w||1)/2,f.y+(f.h||1)/2),label=f.label||f.name||'',crew=s.flags['crew-first'],grain=s.flags['grain-first'];
 if(f.kind==='boat'){barge(c,x,y,false,!!s.flags['berth-fixed'],t);return true;}
 if(f.kind==='crate'&&/干粮/.test(label)){
  const n=grain?6:crew?12:16;
  for(let i=0;i<n;i++){const j=i%5;bag(c,x-30+j*13+(i>9?4:0),y+Math.floor(i/5)*4-j*.6);}
  return true;
 }
 if(f.id==='shift-chair'){
  if(grain){for(const [dx,dy] of [[-13,1],[9,7],[31,12]])chair(c,x+dx,y+dy);figure(c,x+23,y+2,'off-shift',t,{scale:.83});}
  else if(crew){figure(c,x-12,y-1,'returning-cook',t,{scale:.9});line(c,x+2,y-1,x+16,y-5,'#80674e',3);oval(c,x+8,y-7,6,3,'#c2a36e');}
  else chair(c,x+7,y+2,true);
  return true;
 }
 return false;
}
export function berthState(c,p,map,s,t){
 const infirmary=s.flags['grain-first'],crew=s.flags['crew-first'];
 const pt=p(20.7,15.35);barge(c,pt[0]+(infirmary?49:0),pt[1]+(infirmary?9:0),true,false,t);
 const [x,y]=p(18.5,12.8);litter(c,x,y);
 if(crew){figure(c,x+24,y-6,'waiting-orderly',t);figure(c,x-11,y+14,'waiting-nurse',t,{flip:true});}
 if(infirmary){for(let i=0;i<4;i++)bag(c,x+17+i*9,y-4+i*.4,.75);}
}
