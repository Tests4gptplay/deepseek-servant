import {poly,line,oval,rand} from '../paint.mjs';
import {localWorks} from './charts.mjs';
import {edge,planking,builtEdge,surface,intertidal,post,rectangle} from './surfaces.mjs';

function grill(c,p,x,y,w,h,iron){
 const r=rectangle(x,y,w,h);builtEdge(c,p,r,5,['#425855','#64766a']);surface(c,p,r,0,'#567a76','#5d6c5d');
 for(let a=x+.10;a<x+w-.03;a+=iron?.26:.43){
  const bar=rectangle(a,y+.04,iron?.11:.22,h-.08);
  surface(c,p,bar,0,iron?'#a0aa96':'#a48868','#606e64');
 }
 for(const b of [y+.12,y+h-.18])edge(c,p,[x,b],[x+w,b],iron?'#d0c9ab':'#c7af86',2);
 if(iron){const [a,b]=p(x+.24,y+.45);oval(c,a,b-1,3,2.1,'#ddd1a1');}
}
function launch(c,p,x,y,w,h,id){
 const nose=.55,r=[[x,y+h*.45],[x+nose,y+.08],[x+w-.7,y+.01],[x+w,y+h*.35],[x+w-.26,y+h*.87],[x+1.15,y+h],[x+.28,y+h*.77]];
 builtEdge(c,p,r,6,id==='upper-spar'?['#405952','#697c66']:['#544c43','#866b55']);
 planking(c,p,r,'float');
 edge(c,p,[x+.28,y+h*.77],[x+1.15,y+h],id==='wren-deck'?'#e2a264':'#abbd9a',3);
 edge(c,p,[x+1.15,y+h],[x+w-.26,y+h*.87],id==='upper-spar'?'#708574':'#9d7050',3.4);
 for(const a of [x+w*.20,x+w*.67])edge(c,p,[a,y+.22],[a,y+h-.18],'#bf9869',3);
 if(id==='upper-spar'){post(c,p,x+.52,y+.38,16,true);post(c,p,x+w-.25,y+.38,12,true);}
 else if(id==='flour-skiff'){const [a,b]=p(x+w-.7,y+.23);for(let j=0;j<3;j++){oval(c,a+j*3.6,b-j*1.3,3.5,1.7,'#d0d5b6');}}
 else {edge(c,p,[x+w*.2,y+h*.6],[x+w*.73,y+h*.2],'#695b46',2.8);edge(c,p,[x+w*.73,y+h*.2],[x+w*.85,y+h*.12],'#c2a170',4);}
}
function strand(c,p,r,id,s){
 const [x,y,w,h,kind]=r,ring=rectangle(x,y,w,h);
 intertidal(c,p,ring,kind==='cradle'?'bank':kind,s.tide);
 if(kind==='mud'){
  for(let a=x+.40;a<x+w-.6;a+=.85){edge(c,p,[a,y+.62],[a+.90,y+.51],'#685f45',2.7);edge(c,p,[a+.02,y+.51],[a+.28,y+.66],'#bea678',1.1);}
 }else if(kind==='reef'){
  for(let j=0;j<Math.floor(w*2);j++){const a=x+.18+j*.47,b=y+.85+rand(j+21,9)*.13;const [u,v]=p(a,b);oval(c,u,v,2.6,1.5,id==='breathing-scree'?'#cf9a80':'#e6dfbf');}
 }else if(kind==='cradle'){
  for(const b of [y+.16,y+.74])edge(c,p,[x+.24,b],[x+w-.14,b],'#766044',3);
  for(let a=x+.36;a<x+w-.20;a+=.60){const [u,v]=p(a,y+.51);line(c,u-8,v-4,u,v+1,'#816548',2);line(c,u,v+1,u+7,v-6,'#947857',2);}
  if(!s.flags['pan-leaf-spent'])edge(c,p,[x+.3,y+.53],[x+w-.32,y+.53],'#b8a670',2.4);
 }else if(kind==='stairs'){edge(c,p,[x+.15,y+h-.04],[x+w-.17,y+h-.04],'#537972',2);}
}
export function paintLocal(c,p,m,s){
 const r=localWorks[m.id];if(!r)return;const [x,y,w,h,k]=r;
 if(k==='slats')grill(c,p,x,y,w,h,m.id==='lower-tide');
 else if(k==='fender'){
  planking(c,p,rectangle(x,y,w,h),'quay');
  for(let a=x+.75;a<x+w-.25;a+=3.75){const [u,v]=p(a,y+h-.05);oval(c,u,v+1.6,5.2,3.8,'#615d4f');oval(c,u,v+1.2,2.5,1.9,'#8e927b');post(c,p,a+.42,y+h-.13,7,true);}
 }else if(['galley','tender','ward'].includes(k))launch(c,p,x,y,w,h,m.id);
 else strand(c,p,r,m.id,s);
}
export function localReplacement(m,f){
 const r=localWorks[m.id];
 if(!r||r[0]!==f.x||r[1]!==f.y||r[2]!==f.w||r[3]!==f.h)return false;
 return ['pier','water','boat','rope'].includes(f.kind);
}
