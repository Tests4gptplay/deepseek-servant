import {poly,line,oval,arc} from './paint.mjs';

export function plate(c,p,x,y,w,h,z,fill,edge){
 poly(c,[p(x,y,z),p(x+w,y,z),p(x+w,y+h,z),p(x,y+h,z)],fill,edge);
}
export function box(c,p,x,y,w,h,z,height,colors){
 const [top,left,right]=colors;
 poly(c,[p(x,y+h,z),p(x+w,y+h,z),p(x+w,y+h,z+height),p(x,y+h,z+height)],left);
 poly(c,[p(x+w,y,z),p(x+w,y+h,z),p(x+w,y+h,z+height),p(x+w,y,z+height)],right);
 plate(c,p,x,y,w,h,z+height,top,left);
}
export const wood=['#b08c64','#765a49','#564c45'], iron=['#87958a','#556660','#424f51'];
export function mast(c,p,x,y,z,cloth,t,wind=1){
 const [a,b]=p(x,y);line(c,a,b,a,b-z,'#423f37',4);line(c,a-1,b-2,a-1,b-z,'#a18c6c',1);
 const end=wind?25:6, rise=wind?4+Math.sin(t*2.5+x)*2:18;
 poly(c,[[a,b-z+3],[a+end*.6,b-z+rise*.2],[a+end,b-z+rise],[a+end-3,b-z+rise+4],[a,b-z+8]],cloth,'#5e6158');
 oval(c,a,b-z,2,2,'#e5cfa6');
}
export function bed(c,p,x,y,occupied=false,folded=false){
 const w=folded?.6:1.78,h=.86;
 for(const i of [0,w])for(const j of [0,h])line(c,...p(x+i,y+j),...p(x+i,y+j,8),'#554338',2.8);
 box(c,p,x,y,w,h,6,3,wood);box(c,p,x+.04,y+.06,w-.08,h-.12,9,3,['#dccbad','#a89b84','#7c8274']);
 if(folded)return;
 plate(c,p,x+.46,y+.06,1.2,h-.12,13,occupied?'#a86d59':'#6e9894');
 for(let j=0;j<3;j++)line(c,...p(x+.58+j*.07,y+.05,13.5),...p(x+.58+j*.07,y+h-.05,13.5),'#d8c8a0',1);
 box(c,p,x+.07,y+.12,.28,h-.25,12,2,['#efe1bd','#bdab91','#9b947f']);
 if(occupied){const a=p(x+.32,y+.43,15);oval(c,...a,3.5,2.8,'#9e7459');}
}
export function tub(c,x,y,r,water='#6b9290'){
 oval(c,x,y,r,r*.4,'#514c40');c.fillStyle='#896b54';c.fillRect(x-r,y-8,r*2,8);oval(c,x,y-8,r,r*.43,'#bba17e');oval(c,x,y-8,r-2,(r-2)*.43,water);
}
export function parchment(c,x,y,side,done=false){
 poly(c,[[x-22,y-5],[x-11,y-14],[x+21,y-8],[x+11,y+1]],'#e4cb96','#795f49');
 for(let i=0;i<3;i++)line(c,x-13+i*7,y-7,x-4+i*7,y-10,'#b4a383',.6);
 const points=side?[[x-14,y-7],[x-8,y-6],[x-5,y-10],[x+2,y-9],[x+9,y-6]]:[[x-13,y-6],[x-4,y-8],[x+2,y-7],[x+9,y-10]];
 for(let i=1;i<points.length;i++)line(c,...points[i-1],...points[i],side?'#476f71':'#985f48',1.8);
 if(done){oval(c,x+12,y-7,3,1.3,'#9c6252');}
}
export function bob(c,x,y,n,measured){
 const depth=measured?n*2.2:5;line(c,x,y-32,x,y-32+depth,'#918971',1.5);
 for(let i=1;i<=Math.min(n,Math.floor(depth/3));i++)line(c,x-2,y-31+i*2.3,x+2,y-31+i*2.3,'#cda76f',1.15);
 const h=y-32+depth;poly(c,[[x,h-3],[x+3,h+2],[x,h+7],[x-3,h+2]],'#727f78','#4a5a57');
}
export function wheel(c,x,y,r,turn,teeth=12,hot=false){
 const edge=hot?'#c98659':'#a4a697',metal=hot?'#715447':'#536669';
 c.save();c.translate(x,y);c.scale(1,.84);c.rotate(turn);
 for(let i=0;i<teeth;i++){c.rotate(2*Math.PI/teeth);poly(c,[[-2.3,-r+1],[-2.5,-r-2.8],[1.2,-r-4],[3,-r+1]],edge,'#47534c');}
 oval(c,0,0,r,r,metal);arc(c,0,0,r-1,0,Math.PI*2,edge,2.5);oval(c,0,0,r*.65,r*.65,'#343f3e');
 for(let i=0;i<6;i++){c.rotate(Math.PI/3);line(c,0,0,0,-r*.77,edge,2.6);}
 oval(c,0,0,r*.22,r*.22,edge);c.restore();
}
