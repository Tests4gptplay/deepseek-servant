import {poly,line,oval,arc} from '../paint.mjs';
import {box,plate} from '../voyage-shapes.mjs';

function fabric(c,p,x,y,furled){
  for(const [dx,dy,h] of [[0,.05,40],[3.05,.05,40],[.1,1.15,25],[3,1.15,25]]){
    line(c,...p(x+dx,y+dy),...p(x+dx,y+dy,h),'#5e5140',3.4);
    line(c,...p(x+dx+.02,y+dy,5),...p(x+dx+.02,y+dy,h-1),'#c2a46b',1);
  }
  const bands=9;
  for(let i=0;i<bands;i++){
    const a=x+i*3/bands,b=x+(i+1)*3/bands;
    if(furled){
      poly(c,[p(a,y+.08,38),p(b,y+.08,38),p(b,y+.30,34),p(a,y+.30,34)],i%3?'#be8643':'#e3b76c','#a07143');
      continue;
    }
    const z=27-Math.sin((i+.5)*Math.PI/bands)*3;
    poly(c,[p(a,y+.05,40),p(b,y+.05,40),p(b,y+1.12,z),p(a,y+1.12,z)],['#dba758','#eac787','#d9aa65'][i%3],'#b88750');
    const l=p(a,y+1.12,z),r=p(b,y+1.12,z);
    c.beginPath();c.moveTo(...l);c.lineTo(...r);c.lineTo(r[0],r[1]+3);
    c.quadraticCurveTo((r[0]+l[0])/2,(r[1]+l[1])/2+9,l[0],l[1]+3);c.closePath();
    c.fillStyle=i%2?'#a76940':'#bc804a';c.fill();
  }
  for(const offset of [.15,2.8]){
    const a=p(x+offset,y+1.12,furled?25:24),b=p(x+offset-.28,y+1.37,4);
    line(c,...a,...b,'#b89155',1.7);oval(c,...b,2.5,1.3,'#776b53');
  }
}
function palm(c,p,x,y,rest){
  box(c,p,x+.05,y+.08,1.85,.82,0,8,['#ab8366','#785d4d','#57463f']);
  plate(c,p,x+.13,y+.13,1.67,.70,8.7,'#637d73','#465d56');
  const [a,b]=p(x+.97,y+.48,9);
  oval(c,a,b,19,7,'#435d56');oval(c,a-10,b-2,7.8,4.1,'#dacba7');
  oval(c,a+12,b+1,6.5,3.3,rest?'#dfd0af':'#bfa988');
  for(let i=0;i<4;i++)line(c,a-16+i*3,b-5,a-14+i*3,b,'#a99c85',.8);
  c.beginPath();c.moveTo(a-8,b-3);c.quadraticCurveTo(a-1,b+6,a+8,b+1);
  c.strokeStyle='#e8cc9a';c.lineWidth=2;c.stroke();c.lineWidth=1;
  const [bx,by]=p(x+1.48,y+.16,11);
  oval(c,bx,by,8.2,3.6,'#70573e');arc(c,bx,by-1,7.2,Math.PI,Math.PI*2,'#c79a62',1.4);
  for(let n=0;n<5;n++)line(c,bx-6+n*3,by-1,bx-4+n*2.3,by+2,'#e1b67b',1);
}
function privateCurtain(c,p,x,y,open){
  const top=35;line(c,...p(x,y,top),...p(x,y+1.7,top),'#675743',3);
  for(let i=0;i<6;i++){
    const left=y+i*1.7/6,right=y+(i+1)*1.7/6;
    const inner=open?y+.15+(i+.2)*.075:left,outer=open?inner+.09:right;
    poly(c,[p(x,left,top-1),p(x,right,top-1),p(x+.03,outer,5+i%2),p(x+.03,inner,5)],['#88776f','#b19a86','#9c8275'][i%3],'#8d796b');
  }
  const pt=p(x+.06,y+(open?.53:1.63),18);arc(c,...pt,3.1,0,Math.PI*1.85,'#dfc18b',1.3);
}
function oven(c,p,x,y,out){
  box(c,p,x+.15,y+.08,1.55,.72,0,11,['#b48d71','#805f50','#655145']);
  const [a,b]=p(x+.83,y+.53,12);oval(c,a,b,18,8,'#765745');oval(c,a,b-3,14,5,'#4e4c43');
  for(let i=0;i<4;i++){const u=a-12+i*8;line(c,u,b+4,u+5,b+1,'#ccb198',1.1);}
  if(out){poly(c,[[a-11,b-3],[a+7,b-7],[a+15,b-3],[a-2,b+1]],'#837e6f','#4f5149');}
  else{
    for(let i=0;i<3;i++){oval(c,a-8+i*8,b-2-(i%2)*3,4.3,1.9,'#d69c55');line(c,a-10+i*8,b-2-(i%2)*3,a-6+i*8,b-3-(i%2)*3,'#a56e40',.8);}
    poly(c,[[a-5,b+5],[a-3,b],[a,b+2],[a+2,b-2],[a+5,b+4]],'#e1a05e');
  }
  const paddle=p(x+1.45,y+.8,13);line(c,paddle[0]-6,paddle[1],paddle[0]+7,paddle[1]-15,'#b3885c',2.4);
}
export function funeralObject(c,p,f,flags){
  const x=f.x,y=f.y;
  switch(f.id){
    case 'keen-amber-awning':fabric(c,p,x,y,false);break;
    case 'keen-folding-sun':fabric(c,p,x-1.1,y,!!flags['keen-evening']);break;
    case 'keen-empty-palm':palm(c,p,x,y,!!flags['keen-rest']);break;
    case 'keen-private-curtain':privateCurtain(c,p,x,y,!!flags['keen-place']);break;
    case 'keen-last-pan':oven(c,p,x,y,!!flags['keen-open-bench']);break;
    default:return false;
  }
  return true;
}
