import {line,oval,poly,arc} from '../paint.mjs';
import {box,plate} from '../voyage-shapes.mjs';
import {cabinet,shortWheels} from './workshop.mjs';

const timber=['#b39164','#816148','#58493c'];
function boat(c,p,x,y,high){
 const pts=[[0,.55],[.33,.04],[2.02,-.03],[2.68,.23],[2.36,.77],[.39,.86]];
 const z=high?7:2;
 poly(c,pts.map(([a,b])=>p(x+a,y+b,z)), '#706c54','#464d44');
 poly(c,[p(x+.37,y+.84,z),p(x+2.36,y+.76,z),p(x+2.24,y+.67,z+7),p(x+.4,y+.75,z+7)],'#9d7c52','#544e40');
 for(let i=0;i<5;i++)line(c,...p(x+.48+i*.32,y+.17,z+3),...p(x+.46+i*.32,y+.7,z+3),'#ceb184',1.3);
}
export function quayProp(c,p,f,s){
 const {x,y}=f;
 if(f.id==='drawer-skiff-bottom'){
  boat(c,p,x,y,s.tide==='high');
  if(s.flags['drawer-water-mode']&&s.flags['drawer-floated']){cabinet(c,p,x+.35,y-.05,s.tide==='high'?13:5,6,true);}
  return true;
 }
 if(f.id==='drawer-blue-marks'){
  if(s.tide==='low')for(const [dx,dy]of [[-.15,.16],[.31,.4]]){
   const [a,b]=p(x+dx,y+dy,1);poly(c,[[a-4,b],[a+3,b-2],[a+8,b],[a,b+3]],'#456c78','#789b9e');
  }
  return true;
 }
 if(f.id==='drawer-watch-boat'){
  boat(c,p,x-.35,y-.08,true);
  const [a,b]=p(x+.13,y+.25,6);
  line(c,a,b,a+4,b-29,'#665744',2.5);poly(c,[[a+4,b-29],[a+16,b-26],[a+9,b-20],[a+3,b-22]],s.flags['drawer-wage-back']?'#d4be81':'#83a8a1','#546f69');return true;
 }
 if(f.id==='drawer-plum-tray'){
  box(c,p,x,y,1.3,.7,1,13,timber);plate(c,p,x-.05,y-.05,1.4,.8,15,'#b78e64','#775f4c');
  for(let i=0;i<15;i++){const a=p(x+.15+(i%5)*.21,y+.1+Math.floor(i/5)*.18,17);oval(c,...a,2.5,1.9,i%3===0?'#ba816b':'#91666b');}
  return true;
 }
 return false;
}

const subjects=new Map([
 ['drawer-turn-upper','wheels'],['drawer-cross-lip','wheels'],['drawer-heel','stone'],
 ['drawer-catch-corner','high'],['drawer-blue-sill','low'],['drawer-ivo-names','ledger'],
 ['drawer-cabinet-off','shelf'],['drawer-split-strips','shelf'],['drawer-ride-the-watch','wage']
]);
export const caseFocus=shot=>subjects.get(shot?.id);
function hand(c,x,y,angle,cloth,reach=0){
 c.save();c.translate(x+reach,y);c.rotate(angle);
 poly(c,[[-72,-9],[-20,-9],[-11,-4],[-12,9],[-67,14]],cloth,'#514b44');
 poly(c,[[-19,-7],[-7,-6],[2,-11],[10,-11],[12,-7],[5,-2],[21,-5],[26,-2],[22,1],[7,5],[-1,10],[-14,9]],'#c79477','#785d50');c.restore();
}
export function caseStudy(c,w,h,shot,s,t,reduce){
 const kind=caseFocus(shot);if(!kind)return;
 const narrow=w<620,scale=Math.min(narrow?(w-32)/307:1.12,(h*.25)/119);
 c.save();c.translate(narrow?w*.5:w-Math.max(179,w*.14),narrow?h*.31:Math.max(115,h*.235));c.scale(scale,scale);
 const grad=c.createLinearGradient(-150,-59,151,56);grad.addColorStop(0,'#354b4af5');grad.addColorStop(1,'#74644df3');
 c.fillStyle=grad;c.fillRect(-152,-59,304,118);c.strokeStyle='#c1ab77';c.lineWidth=1.3;c.strokeRect(-152,-59,304,118);
 c.save();c.beginPath();c.rect(-150,-57,300,114);c.clip();const phase=reduce?0:Math.sin(t*2.2);
 const p=(x,y,z=0)=>[-53+(x-y)*34,12+(x+y)*11-z];
 if(kind==='wheels'){
  for(let i=0;i<3;i++)line(c,-123,27+i*7,91,10+i*7,'#b2986e',2);
  shortWheels(c,p,.52+phase*.085,-.03,true);
  hand(c,121,-8,Math.PI,'#738b9a',phase*2);
 }else if(kind==='stone'){
  oval(c,-24,17,50,16,'#5b615e');c.fillStyle='#8e9386';c.fillRect(-74,-1,100,17);oval(c,-24,-2,50,17,'#bab8a5');
  arc(c,-25,-7,11,.4,4.9,'#666e68',3);line(c,-24,-4,-60,-29,'#8b704b',5);hand(c,-95,-28,-.15,'#8a735e',phase*2);
 }else if(kind==='high'||kind==='low'){
  for(let j=0;j<7;j++)line(c,-140,7+j*6,125,4+j*6,kind==='high'?'#83adaa':'#958c72',j%3===0?2:1);
  if(kind==='high'){
   box(c,p,.4,-.5,2.05,.8,11,8,['#719398','#406975','#315460']);
   for(let i=0;i<2;i++)box(c,p,.46+i*1.62,-.52,.13,.87,-2,15,timber);
   hand(c,83,29,Math.PI,'#788777',phase*2);
  }else for(let i=0;i<2;i++){const x=-41+i*57;poly(c,[[x-8,12],[x+9,7],[x+25,13],[x+7,19]],'#568292','#adc4b5');}
 }else if(kind==='shelf'){
  cabinet(c,p,-.03,-.45,2,6,true);const n=p(2.36,.1,3);
  for(let i=0;i<3;i++)poly(c,[[n[0]+i*6,n[1]],[n[0]+19+i*6,n[1]-9],[n[0]+21+i*6,n[1]-6],[n[0]+i*6,n[1]+3]],'#cbb98b','#826e51');
  hand(c,109,13,Math.PI,'#748779',phase*2);
 }else if(kind==='wage'){
  hand(c,-75,-3,0,'#708a91',phase);hand(c,66,11,Math.PI,'#9f805c',-phase);
  for(let i=0;i<3;i++){oval(c,-14+i*12,5-i%2*4,5.5,3.2,'#d1a55c');line(c,-15+i*12,5-i%2*4,-12+i*12,4-i%2*4,'#81663e',1.2);}
 }else{
  poly(c,[[-88,-29],[28,-37],[78,22],[-63,36]],'#d7c69d','#746650');
  for(let i=0;i<5;i++)line(c,-68,-20+i*9,30,-26+i*9,'#a79774',1);
  arc(c,-13,-5,8,0,5.9,'#876650',1.7);arc(c,-12,12,7,0,4.6,'#365d62',2);
  hand(c,80,5,Math.PI,'#6c8191',phase);line(c,53,4,-6,-8,'#4d4a3c',2.8);
 }
 c.restore();c.restore();
}
