import {line,poly,oval,arc} from './paint.mjs';
import {box,wood,bed,tub,plate,parchment,wheel} from './voyage-shapes.mjs';
import {cauldron} from './social-fauna.mjs';
const dyes=['#638b88','#b27d68','#c5b48d','#829587','#9999a1','#975d50','#bd9c6b','#627984'];
export function drying(c,p,x,y,w,coat=0,t=0){
 const length=Math.max(2,w);const a=p(x+.15,y+.35),b=p(x+length-.15,y+.35);
 for(const end of [a,b])line(c,...end,end[0],end[1]-32,'#665848',3);
 c.beginPath();c.moveTo(a[0],a[1]-30);c.quadraticCurveTo((a[0]+b[0])/2,(a[1]+b[1])/2-20,b[0],b[1]-30);c.strokeStyle='#736956';c.lineWidth=1.5;c.stroke();c.lineWidth=1;
 for(let j=0;j<Math.min(15,length*1.5);j++){const u=(j+.65)/(Math.min(15,length*1.5)+.3),[v,z]=p(x+.15+(length-.3)*u,y+.36),hi=z-30+20*u*(1-u),d=Math.sin(t+j)*1.1;
  const color=coat===8?['#d1c7ac','#b8b39d','#e3d6bc'][j%3]:dyes[(j+coat)%8];
  poly(c,[[v-7,hi],[v+6,hi+3],[v+7+d,hi+12+j%5],[v+1+d,hi+14],[v-6+d,hi+10]],color,'#746e62');line(c,v-3,hi+2,v-3+d,hi+9,'#e1d9bb',.7);line(c,v-5,hi-1,v-5,hi+2,'#b78d58',1.5);}
}
export function loom(c,p,x,y,n=0){
 for(const dx of [0,1.75])for(const dy of [0,.9]){line(c,...p(x+dx,y+dy),...p(x+dx,y+dy,23),'#715b47',3);}
 for(const dy of [0,.9])line(c,...p(x,y+dy,23),...p(x+1.75,y+dy,23),'#947557',4);
 for(let i=0;i<19;i++){const q=p(x+.1+i*.084,y,22),v=p(x+.1+i*.084,y+.64,11);line(c,...q,...v,i%4===0?'#e6d6af':dyes[(n+Math.floor(i/4))%8],1);}
 plate(c,p,x+.11,y+.53,1.54,.32,11,dyes[n%8],'#67594c');box(c,p,x+.25,y+1.1,1.2,.31,0,7,wood);
}
export function screen(c,p,x,y,w,hue,open=false){
 const size=open?w*.38:w;for(const dx of [0,w])line(c,...p(x+dx,y),...p(x+dx,y,34),'#71604a',3);
 line(c,...p(x,y,34),...p(x+w,y,34),'#967b5e',3);
 poly(c,[p(x+.07,y,31),p(x+size,y,31),p(x+size,y,6),p(x+.07,y,4)],hue,'#756958');
 for(let k=.15;k<size;k+=.19)line(c,...p(x+k,y,30),...p(x+k+.05,y,7),'#d6c9a588',1);
}
export function windowFrame(c,p,x,y,w,far=false){
 const [a,b]=p(x,y);c.save();c.translate(a,b);const ww=Math.min(32,8+w*2);poly(c,[[-ww,0],[-ww,-42],[ww,-32],[ww,10]],'#746d5b','#575b51');
 for(let i=0;i<2;i++){const xx=-ww+3+i*ww;poly(c,[[xx,-35+i*5],[xx+ww-4,-31+i*5],[xx+ww-4,-10+i*5],[xx,-14+i*5]],far?'#81a9ad':'#d7ceac','#907f64');}
 line(c,-ww,-21,ww,-11,'#8e795e',2);c.restore();
}
export function table(c,p,x,y,type,n=0){
 box(c,p,x,y,1.68,.8,0,11,wood);const[a,b]=p(x+.82,y+.39,12);
 if(type==='paper'){parchment(c,a,b,Boolean(n%2));for(let i=0;i<3;i++)oval(c,a+12+i*3,b-1-i,2,1.2,'#8d6a4e');}
 else if(type==='bowl'){for(let i=0;i<4;i++){const q=p(x+.24+i*.34,y+.42,14);oval(c,...q,4,2.1,'#665748');oval(c,q[0],q[1]-1.3,3.5,1.6,'#c9b68f');}}
 else if(type==='weights'){for(let i=0;i<3;i++){const q=p(x+.3+i*.44,y+.36,12);poly(c,[[q[0]-5,q[1]],[q[0]-3,q[1]-9],[q[0]+2,q[1]-10],[q[0]+6,q[1]-1]],'#68736c','#465550');arc(c,q[0],q[1]-9,2.5,3.1,6.3,'#e0cba4',1);}}
 else for(let i=0;i<3;i++)box(c,p,x+.14+i*.49,y+.18,.31,.47,12,3,['#c8aa82','#9a7b60','#746853']);
}
export function roomPiece(c,p,x,y,kind,t,n=0){
 if(kind==='stove'){cauldron(c,...p(x,y),t,n===0);tub(c,...p(x+.87,y+.46),7,n===0?'#809c99':'#bb986c');}
 else if(kind==='wash'){for(let i=0;i<3;i++){const q=p(x+i*.82,y);tub(c,...q,13,i===1?'#908b7b':'#839a96');line(c,q[0]-9,q[1]-11,q[0]+6,q[1]-9,'#c2ad86',2.6);}}
 else if(kind==='cot')bed(c,p,x-.6,y-.3,Boolean(n));else if(kind==='loom')loom(c,p,x-.75,y-.3,n);
 else if(kind==='screen')screen(c,p,x-.8,y,1.8,dyes[n%8],Boolean(n%2));else if(kind==='window')windowFrame(c,p,x,y,3,Boolean(n));
 else if(kind==='wheel')wheel(c,...p(x,y,16),15,t*.18,8);else table(c,p,x-.7,y-.4,kind,n);
}
