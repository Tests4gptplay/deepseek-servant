import {poly,oval,line,rand} from './paint.mjs';
export const bays={
 scree:['#e9d6b2','#91b6bf','#497d8a','#445065','#788589','#bbac8a','#f5dfb4'],
 roof:['#e1d0a8','#849ba9','#426a73','#253848','#4f6266','#8a8e78','#dccca4'],
 pools:['#e1be9b','#92beb6','#315b69','#394957','#65776e','#a3a48b','#e5d4aa'],
 throat:['#bfcdbe','#779c9d','#284d56','#283b49','#4b625b','#898975','#cebd93'],
 heights:['#d9c5cd','#9cb1c5','#597f95','#4b4962','#797688','#b8aa99','#eadcef'],
 lens:['#d6e6ce','#8ebbb5','#2a6969','#34515c','#61706e','#b3b29b','#e4e9bf'],
 cradle:['#dbb680','#96b4a2','#3a6260','#374a4c','#606e5e','#a89872','#e5cf90']};
export function baySky(c,w,h,bay,t){
 const [light,sky,sea,rock]=bays[bay.id],y=h*.235,g=c.createLinearGradient(0,0,0,h);
 g.addColorStop(0,sky);g.addColorStop(.17,light);g.addColorStop(.255,sea);g.addColorStop(1,rock);c.fillStyle=g;c.fillRect(0,0,w,h);
 const cx=w*(bay.id==='lens'?.27:.73);oval(c,cx,y*.47,22,22,light+'b8');
 for(let k=0;k<3;k++){const contour=[[-5,y+9]];
 for(let i=0;i<=38;i++){const x=i*w/35,amp=k*9+6;
 const level=(bay.id==='roof'||bay.id==='throat')?(i<8||i>24?1.95:.75):1;
 contour.push([x,y-Math.abs(Math.sin(i*.27+k*1.8))*amp*level-rand(i+83,k)*4]);}
 contour.push([w+12,y+13]);poly(c,contour,[sky,sea,rock][k]+'b8');}
 for(let i=0;i<47;i++){const a=rand(i,21)*w,v=rand(i,11),b=y+14+v*.32*h;line(c,a+Math.sin(t*.58+i)*3,b,a+9+v*22,b,light+'5c',1);}
 if(bay.id==='scree'||bay.id==='heights')for(let i=0;i<23;i++){
  const x=((i*71+t*25)%(w+25))-20,b=y*(.22+rand(i,17)*.68);line(c,x,b,x+4+i%5,b-1,light+'a6');}
 if(bay.id==='throat'||bay.id==='cradle'){const margin=Math.min(w*.22,135);
 poly(c,[[0,0],[margin,0],[margin*.7,y*.3],[margin*.39,y*.46],[margin*.28,y*.86],[0,y]],rock+'c7');}
}
