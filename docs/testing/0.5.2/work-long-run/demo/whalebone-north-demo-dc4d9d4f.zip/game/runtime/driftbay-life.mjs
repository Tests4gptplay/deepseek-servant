import {oval,line,poly} from './paint.mjs';
function otter(c,x,y,flip,scale,beat,wet){c.save();c.translate(x,y);c.scale(flip*scale,scale);
 oval(c,0,1,12,2.9,wet?'#b4d8bf':'#243d4066');const rise=wet?Math.sin(beat)*1.3:0;
 c.translate(0,rise);c.fillStyle='#413b32';c.beginPath();c.moveTo(-7,-4);c.quadraticCurveTo(-17,-1,-20,-4);c.quadraticCurveTo(-17,1,-6,-1);c.fill();
 oval(c,-.5,-5,10,4.5,'#5a483a');oval(c,7.4,-8.3,4.9,4.4,'#5c493b');oval(c,5.9,-11.7,1.7,1.6,'#332f2c');
 oval(c,10,-7.7,3.1,1.8,'#ddbc88');oval(c,10,-9.4,.85,.95,'#1f302f');
 if(!wet){line(c,-6,-3,-8+Math.sin(beat)*2,0,'#332e2a',2);line(c,5,-3,5-Math.sin(beat)*2,0,'#332e2a',2);}
 else line(c,-13,1,3,1,'#e3edde',1.1);c.restore();}
function bird(c,x,y,beat){const h=Math.sin(beat)*3;poly(c,[[x-13,y-4+h],[x-5,y-6],[x,y-1],[x+6,y-5],[x+14,y-3-h],[x+5,y-2],[x,y+2],[x-4,y-2]],'#eee7d4','#66747c');}
function clampTrail(path,unit){const u=Math.max(0,Math.min(path.length-1.0001,unit)),i=Math.floor(u),r=u-i;
 const [a,b]=path[i],[x,y]=path[i+1];return [a+(x-a)*r,b+(y-b)*r,(x-y)-(a-b)>=0?1:-1];}
export function bayLife(c,p,map,s,t,ordered){const {id,life}=map.driftbay;
 const path=id==='pools'&&s.tide==='high'?[[6,9],[10,11],[13,7],[17,6],[22,4]]:life;
 const still=id==='cradle'&&s.flags['driftbay-pups'],wet=id==='throat'||id==='lens';
 if(id==='cradle'&&s.flags['driftbay-spooked']&&!s.flags['driftbay-reedwalk']&&!still){const [a,b]=p(23.7,7.4);for(let n=0;n<3;n++){c.beginPath();c.ellipse(a,b,5+5*n,1.75+1.4*n,0,0,Math.PI*2);c.strokeStyle='#b2ceba';c.stroke();}return;}
 const travelPhase=t||((s.progress.driftbaySteps||0)*.26);
 for(let n=0;n<3;n++){
  const offset=(((travelPhase*.36+n*.38)%(2*(path.length-1)))+2*(path.length-1))%(2*(path.length-1));
  const out=offset<path.length-1,u=still?path.length-1-.6*n:out?offset:2*(path.length-1)-offset;
  const [x,y,dir]=clampTrail(path,u),bump=n===1?.19:n===2?-.22:0,q=p(x+.45+bump,y+.5,n===0?0:-1);
  ordered.push([x+y+1.025,()=>id==='heights'?bird(c,q[0],q[1]-17-n*6,t*2+n):otter(c,...q,dir*(out?1:-1),n===0?1.46:.96,t*3+n,wet)]);
 }
 for(let i=0;i<path.length;i++){const [x,y]=path[i],[a,b]=p(x+.48,y+.55);
  for(let k=0;k<3;k++){const dx=k*3-3,dy=k%2?1:-1;oval(c,a+dx,b+dy,1.4,1,'#463f37ba');
   oval(c,a+dx+1.7,b+dy-.9,.7,.65,'#4a473a');}}
}
export function bayObject(c,a,b,t,e){
 if(!e.id?.startsWith('driftbay-')||e.kind==='npc')return false;
 if(/splitrope|dispute/.test(e.id)){for(let i=0;i<3;i++){c.strokeStyle=i===1?'#b49659':'#604a36';c.lineWidth=2;c.beginPath();c.ellipse(a,b-3-i,10+i,3.5,0,0,Math.PI*2);c.stroke();}c.lineWidth=1;return true;}
 if(/reed|wrack|watchden/.test(e.id)){for(let n=0;n<8;n++){const x=a-8+n*2.2;
  line(c,x,b,x+3+Math.sin(t*.7+n)*1.4,b-8-2*(n%4),n%2?'#a6935e':'#605f44',1.5);}return true;}
 if(/poolwait|trunk/.test(e.id)){poly(c,[[a-17,b-3],[a+14,b-11],[a+19,b-7],[a-13,b+1]],'#6e5a44','#463f39');line(c,a-12,b-3,a+13,b-8,'#b4a07d',2);return true;}
 for(let n=0;n<7;n++){const x=a-8+n*2.8,y=b+(n%3)-2;oval(c,x,y,2.8,1.4,n%2?'#ded3ae':'#706951');}return true;
}
