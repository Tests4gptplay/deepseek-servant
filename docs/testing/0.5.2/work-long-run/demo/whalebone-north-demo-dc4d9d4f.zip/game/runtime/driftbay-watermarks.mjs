import {line,oval,poly} from './paint.mjs';
export function movingWater(c,p,map,s,t,ordered){
 const {id}=map.driftbay;
 if(id==='pools'){const high=s.tide==='high',x=20.5,y=5.1;
  ordered.push([x+y+1,()=>{const [a,b]=p(x,y),tilt=high?-.24:1.04;
   c.save();c.translate(a,b+Math.sin(t*.7)*1.2);c.rotate(tilt);
   poly(c,[[-35,1],[-29,-5],[-12,-7],[14,-5],[23,-8],[31,-6],[23,-2],[35,2],[32,4],[7,3],[-22,6]],'#6b5745','#4d493d');
   line(c,-28,1,15,-3,'#cfb488',2.8);line(c,-16,2,25,0,'#947450',1.7);c.restore();}]);}
 if(id==='lens'){
  const path=[[8,13],[11,15],[15,14],[18,11],[20,10],[22,7],[25,6]];
  for(let n=0;n<18;n++){const u=(6+n/3-(t*.26)%6)%6,i=Math.floor(u),b=path[i+1],a=path[i],f=u-i;
   const x=a[0]+(b[0]-a[0])*f+.42,y=a[1]+(b[1]-a[1])*f+.27,[sx,sy]=p(x,y);
   line(c,sx-4,sy+.8,sx+3,sy-.8,'#d7f1d5aa',1.3);}
  for(let n=0;n<5;n++){const f=(n*.2+t*.06)%1,[ax,ay]=p(15.2+f*2.8,14.3-f*2.6);
   oval(c,ax,ay,3.4,1.4,'#98904f');line(c,ax-10,ay+1,ax-4,ay,'#b6ccb3',.8);}
 }
}
