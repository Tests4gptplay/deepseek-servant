import {line,oval,poly} from '../paint.mjs';
import {fruitRack,coffinCoat} from './market.mjs';
import {foldStand} from './fold.mjs';
import {person,plank,pass,cup,shutter} from './watch.mjs';
function at(c,x,y,fn,scale=1){c.save();c.translate(x,y);c.scale(scale,scale);fn();c.restore();}
function coin(c,x,y,n){for(let i=0;i<n;i++){oval(c,x+i*3.6,y-i%2,2.8,1.35,'#b99156');line(c,x-1+i*3.6,y-.8-i%2,x+1+i*3.6,y-.8-i%2,'#ecd59a',.75);}}
function boot(c,x,y,heel=1){c.save();c.translate(x,y);c.scale(heel,1);poly(c,[[-4,-7],[1,-7],[2,-3],[7,-2],[7,0],[-4,0]],'#5b5046','#463d34');line(c,-2,-5,1,-5,'#c7af83',1);c.restore();}
function sheet(c,x,y,h=20){c.save();c.translate(x,y);line(c,-10,-h,12,-h-4,'#664f37',2.1);
 poly(c,[[-9,-h],[10,-h-3],[9,-6],[2,-4],[-5,-6],[-10,-5]],'#7b928b','#536663');line(c,-6,-h+2,-6,-9,'#9eafa1',1.2);line(c,6,-h,5,-8,'#627978',1.2);c.restore();}
export function station(c,id,s,{phase=1,held=false,detail=false}={}){
 const f=s.flags,q=k=>Boolean(f['saltcoat-'+k]);const t=phase;
 const folk=(x,who,pose='rest',beat=1,face=1)=>at(c,x,0,()=>person(c,who,pose,beat,face));
 const bench=(w=32)=>plank(c,0,0,w);
 const rack=()=>fruitRack(c,{paid:q('fruit-paid'),teaching:q('learnt'),settled:q('airgap'),turn:t});
 const cloth=()=>coffinCoat(c,{dry:q('dressed')||q('taught'),publicCloth:q('taught'),opened:q('airgap'),turn:t});
 const bowl=(covered=false,hot=true)=>{bench(30);cup(c,0,-7,covered,hot);};
 if(['notice','high-edge','low-edge'].includes(id)){if(id==='notice'||detail){cloth();}else if(id==='high-edge'){sheet(c,0,1,15);line(c,-6,-10,1,-10,'#e2d9b7',1.4);}else{at(c,0,0,cloth,.72);}return true;}
 switch(id){
 case 'cart-helper':folk(0,'apprentice',q('noticed')?'hold':'rest');break;
 case 'lease':folk(0,'vendor','offer',q('one-turn')?1:.3);if(detail)at(c,30,1,rack,.68);break;
 case 'turn-hem':case 'empty-frame':foldStand(c,{settled:q('airgap'),held,release:t,learner:id==='empty-frame'&&q('learnt')});
  if(id==='empty-frame'&&q('public')||detail&&q('learnt'))folk(38,'apprentice','work',q('learnt')?1:0,-1);break;
 case 'own-turn':sheet(c,-1,0,24);if(q('private'))line(c,4,-15,12,-19,'#c6aa81',1.8);if(q('public'))folk(15,'apprentice','work');break;
 case 'private-fee':bench();coin(c,-5,-8,q('fruit-paid')?3:1);break;
 case 'wrong-word':case 'hear-refrain':bowl(false,false);break;
 case 'candle-seller':folk(0,'waker','seat');break;
 case 'private-dress':case 'public-dress':cloth();if(detail||id==='public-dress'&&q('taught')){if(id==='public-dress')folk(33,'waker','work',1,-1);else sheet(c,-36,2,24);}break;
 case 'direct-porter':folk(0,'waker','hold');break;
 case 'hot-cup':bowl(true);if(q('warm-seat'))cup(c,10,-6,false,false);break;
 case 'plain-cup':bowl(false);if(q('shared-water')||detail){cup(c,8,-5,false,false);folk(20,'waker','seat',1,-1);}break;
 case 'ask-first':shutter(c,{open:.75});if(q('taught'))folk(19,'apprentice',q('help-asked')?'hold':'rest',1,-1);break;
 case 'noon-pass':case 'singer-choice':bench(28);if(!q('seat-given'))pass(c,0,-9);if(detail){folk(-16,'singer',q('invited-crowd')?'stop':q('paid-answer')?'hold':'offer');}break;
 case 'hear-singer':folk(0,'singer',q('invited-crowd')?'stop':q('cover-choice')?'rest':'offer');break;
 case 'family-promoter':bench(41);if(q('declined')){boot(c,-6,-6);boot(c,4,-5);line(c,4,-9,9,-13,'#aa9474',1.4);}break;
 case 'near-shoes':case 'lead-shift':bench();boot(c,-10,-8);boot(c,-1,-6);if(q('shift-in')||detail)folk(21,'apprentice','hold',1,-1);break;
 case 'meet-sill':folk(-3,'watcher','hold');if(detail)at(c,23,0,()=>shutter(c,{open:.35}));break;
 case 'sight-test':shutter(c,{open:q('view-ready')?.18+.67*t:.18,curtain:true});if(detail)sheet(c,24,0,26);break;
 case 'pay-the-shift':bench(27);coin(c,q('paid-leave')?-13:3,-11,3);if(q('cover-choice')||detail)folk(-19,'singer',q('paid-leave')?'hold':'offer',t);break;
 case 'give-the-pass':bench(27);if(q('window-choice')||detail)folk(19,'watcher',q('seat-given')?'hold':'offer',t,-1);
  pass(c,q('seat-given')?1+10*t:1,-12,q('seat-given'));break;
 case 'pass-guide':folk(0,'waker','seat');break;
 case 'shut-sidewindow':shutter(c,{open:q('private-goodbye')?.8*(1-t):.72});break;
 case 'handsignal':shutter(c,{open:q('seat-given')?.85:.25,hand:q('window-goodbye')||held&&q('seat-given'),beat:q('window-goodbye')?t:.36});break;
 case 'castoff-porter':folk(0,'waker','hold');break;
 case 'last-hem':if(q('dressed')){sheet(c,-2,1,q('private-echo')?10:17);}break;
 case 'last-door':if(q('help-asked'))folk(0,'apprentice','hold');break;
 case 'last-window':if(q('private-goodbye'))shutter(c,{open:.03,lit:false});break;
 case 'last-hand':if(q('window-goodbye')){folk(0,'watcher','signal',1,-1);}break;
 case 'last-breakfast':if(q('shared-refrain')&&q('sailed')){bench(36);cup(c,-6,-8,false);if(q('breakfast-echo')||held)cup(c,7,-5,false,false);}break;
 case 'fresh-flowers':folk(0,'waker','work');for(let i=0;i<3;i++){line(c,7+i*2,-11,7+i,-4,'#6c815d',1);oval(c,7+i*2,-11,1.7,1.5,['#d9af81','#a66e6c','#cbbb93'][i]);}break;
 default:return false;
 }
 return true;
}
