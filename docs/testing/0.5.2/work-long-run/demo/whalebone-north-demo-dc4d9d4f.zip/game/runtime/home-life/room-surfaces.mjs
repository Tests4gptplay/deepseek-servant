import {poly,line,oval} from '../paint.mjs';
import {plate} from '../voyage-shapes.mjs';

export const interiors={
  'mat-bed':{board:'#8f6e54',seam:'#6a5547',light:'#dbc49e',rug:'#456c69',trim:'#bea674',warp:'#80a29a',x:12.6,y:9.55,w:8.1,h:3.45,window:13},
  'felt-hour':{board:'#988068',seam:'#736052',light:'#d9cfac',rug:'#9b8773',trim:'#c7bb9d',warp:'#695e58',x:9.2,y:9.25,w:10.2,h:3.1,window:8},
  'sponge-sill':{board:'#816f61',seam:'#62574e',light:'#bfccaa',rug:'#6a7870',trim:'#b5a383',warp:'#97a997',x:10,y:9.6,w:8.2,h:2.5,window:15},
  'kettle-nook':{board:'#a47c58',seam:'#795a46',light:'#e6bc83',rug:'#985f46',trim:'#d8b985',warp:'#b7875f',x:13.2,y:9.4,w:8.7,h:3.7,window:16},
  'oar-bunk':{board:'#786d5b',seam:'#5c564a',light:'#b3c3ae',rug:'#4f6c68',trim:'#b09d76',warp:'#85978a',x:7.4,y:9.6,w:14.2,h:3.2,window:15.5}
};
function strip(c,p,x,y,w,h,colors){
  plate(c,p,x,y,w,h,1.1,colors.rug,colors.seam);
  for(const d of [.08,.14,h-.15,h-.08])line(c,...p(x+.04,y+d,1.2),...p(x+w-.04,y+d,1.2),colors.trim,d<.1||d>h-.1?2:1);
  for(let row=0;row<2;row++){
    const yy=y+(row?h-.40:.40);
    for(let i=.55;i<w-.25;i+=.74){
      poly(c,[p(x+i-.22,yy,1.4),p(x+i,yy-.16,1.4),p(x+i+.22,yy,1.4),p(x+i,yy+.16,1.4)],colors.warp);
    }
  }
  for(let n=.12;n<h-.04;n+=.16){
    line(c,...p(x-.11,y+n+.03,1),...p(x+.035,y+n,1),colors.trim,1);
    line(c,...p(x+w-.03,y+n,1),...p(x+w+.12,y+n-.03,1),colors.trim,1);
  }
  const lineY=y+h*.53;
  for(let i=.7;i<w-.35;i+=1.53)line(c,...p(x+i,lineY,1.4),...p(x+i+.14,lineY-.08,1.4),colors.warp,.9);
}
export function houseRoomFloor(c,p,map){
  const material=interiors[map.id];if(!material)return;
  const min=6.9,max=15.15,left=.35,right=map.width-.35;
  plate(c,p,left,min,right-left,max-min,.30,material.board);
  let row=0;
  for(let y=min;y<max;y+=.56){
    line(c,...p(left,y,.38),...p(right,y,.38),material.seam,1);
    for(let x=left+.6+(row%3)*1.42;x<right;x+=4.9){
      line(c,...p(x,y,.4),...p(x,Math.min(y+.53,max),.4),material.seam,.85);
      const dot=p(x+.07,y+.07,.5);oval(c,...dot,1,.60,material.light+'80');
    }
    row++;
  }
  const {window,x,y,w,h}=material;
  poly(c,[p(window-1,min,.57),p(window+1.6,min,.57),p(window+4.1,13.7,.57),p(window+1.5,13.7,.57)],material.light+'39');
  for(const dx of [0,.8])line(c,...p(window+dx,min,.6),...p(window+2.5+dx,13.7,.6),material.seam+'48',1.3);
  strip(c,p,x,y,w,h,material);
  if(map.id==='oar-bunk'){
    for(let xx=5;xx<map.width-3;xx+=3.4)plate(c,p,xx,7.3,.13,7.3,.79,'#b3976b82');
  }
}
