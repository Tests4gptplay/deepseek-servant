import {shape,stroke,stud,pale,edge,steel,dark,wood,copper} from './etched-tools.mjs';
const glass=new Set(['blue-glass','split-prism','deep-lens','glaze-torque']);
const textiles=new Set(['moth-veil','deep-wrap','trawl-parka','windloom-felt','thaw-wrap']);
export function smallFind(c,key){
 if(key==='star-seam-rule'){c.beginPath();c.ellipse(0,0,30,19,-.22,0,7);c.lineWidth=5;c.strokeStyle=copper;c.stroke();stroke(c,'M-21 14L21 -14',pale,1.3);for(let j=-2;j<=2;j++)stroke(c,'M'+(j*8)+' -15l2 4',pale,1);stud(c,0,0,2);return;}
 if(key==='tonic'||key==='brine-dose'){
  const jar=key==='brine-dose';shape(c,jar?'M-20 -12Q-23 -8 -22 -2L-19 15Q-5 23 18 17L22 -6L18 -12Z':'M-9 -15L-8 -23L8 -23L8 -15Q23 -9 21 12Q17 23 0 24Q-20 22 -22 8Q-23 -8 -9 -15Z',jar?'#93684e':'#8f9265');
  shape(c,jar?'M-20 -14Q-3 -20 19 -15L20 -8Q0 -2 -21 -8Z':'M-8 -23L-8 -29L7 -30L9 -24Z',jar?'#c1af87':wood);
  stroke(c,jar?'M-13 -3Q-1 0 12 -4M-10 11Q0 14 11 10':'M-12 -9Q-18 1 -13 7 M-14 14Q-5 21 7 18','#ded1a2',2);
  shape(c,'M-6 -3L8 -4L9 7L-5 9Z','#d2bb90');stroke(c,'M-2 1l7 0M-1 4l4 -1',dark,.8);return;
 }
 if(textiles.has(key)){
  const color={'moth-veil':'#8ba5a2','thaw-wrap':'#a0a186','deep-wrap':'#627f8c','windloom-felt':'#b69c78','trawl-parka':'#779086'}[key];
  shape(c,'M-38 6Q-32 -13 -15 -18Q5 -20 17 -7L39 7Q29 17 10 17Q2 12 -8 16L-32 16Z',color);
  for(let i=0;i<6;i++){stroke(c,'M'+(-28+i*6)+' '+(5-i%3*5)+'q10 9 22 10',i%2?'#d2c8a3':'#667d76',1);if(key==='moth-veil')stroke(c,'M'+(-25+i*8)+' -6l4 18','#c1ccc0',.7);}
  if(key==='thaw-wrap'){for(const dx of [-4,5]){shape(c,'M'+dx+' -21l3 -4l3 5l-3 5Z','#c0a875');}}return;
 }
 if(glass.has(key)){
  stroke(c,'M-23 0Q-40 -25 -11 -28Q8 -30 19 -14','#a88b65',2);
  if(key==='split-prism'||key==='blue-glass'){
   shape(c,'M-30 -8L-8 -16L3 -7L-1 10L-21 15L-31 6Z',key==='blue-glass'?'#568991':'#7d9a91');shape(c,'M2 -6L20 -15L33 -6L29 9L9 14Z','#8ea897');stroke(c,'M-24 -3L-9 -10 M10 -3L21 -8',pale,2.2);
  }else if(key==='glaze-torque'){stroke(c,'M-22 -9C-37 8 -11 26 10 19Q35 11 19 -9',edge,9);stroke(c,'M-22 -9C-37 8 -11 26 10 19Q35 11 19 -9','#c9c6a6',6);stud(c,-21,-11,3);stud(c,18,-10,3);}
  else{shape(c,'M-33 5L19 -14L31 -4L-20 16Z','#7f9c8e');for(let i=0;i<6;i++)stroke(c,'M'+(-18+i*6)+' '+(3-i*2)+'l4 4',pale);stud(c,19,-5);}
  return;
 }
 if(key==='scree-boot'){shape(c,'M-17 -17L4 -19L9 -3Q12 5 25 10Q36 19 13 20L-20 16L-24 11Z',wood);stroke(c,'M-21 13Q3 20 24 16',edge,3);for(let j=0;j<3;j++)stroke(c,'M-12 '+(-10+j*5)+'l14 -3','#dfbd89');return;}
 if(['hemp-knot','shoulder-sling','cork-wrist'].includes(key)){
  const cord='M-41 4Q-29 -21 -1 -7Q23 11 5 17Q-12 20 -18 4Q-23 -22 -1 -18Q12 -19 17 -4Q21 11 37 -2';
  stroke(c,cord,edge,7);stroke(c,cord,key==='shoulder-sling'?'#ba9369':'#c2a66f',4.3);
  if(key==='cork-wrist'){shape(c,'M10 -11L24 -14L28 -1L15 3Z',wood);stud(c,20,-5);}return;
 }
 stroke(c,'M-26 -5Q-31 -29 -9 -31Q17 -32 16 -12',dark,2.1);
 if(key==='windloom-eyelet'){shape(c,'M-12 11L-8 -11Q4 -22 15 -10L21 8Q6 18 -12 11Z',copper);for(let j=0;j<5;j++){stud(c,-4+j*4,-4+(j%2)*5,1);}}
 else if(key==='whalefall-bone-clasp'){for(let j=0;j<5;j++)shape(c,'M'+(-21+j*8)+' 10l1 -17q3 -8 6 -4l-1 17Z','#c1b895');}
 else if(key==='tooth-cleat'){shape(c,'M-26 -1L18 -12L25 -5L15 9L9 8L6 12L2 10L-3 15L-17 10Z',steel);stud(c,15,-5);}
 else {const bell=key==='seed-bell';shape(c,bell?'M-12 9Q-7 -17 3 -18Q14 -11 17 5L23 11Q2 20 -17 13Z':'M-16 -7L0 -17L14 -11L19 7L6 16L-13 13Z',bell?copper:steel);stud(c,bell?2:-3,bell?9:0,3);stroke(c,'M-8 -5q5 -8 12 -7',pale);}
}
