import {arc,line,oval,poly} from './paint.mjs';
import {box,wood,plate,bed,wheel,tub} from './voyage-shapes.mjs';
import {bakehouse,servingWindow,washRun,coalRack,handcart,skiff,seedBed} from './harbor-crafts.mjs';
import {cauldron} from './social-fauna.mjs';
import {screen,table} from './social-furniture.mjs';

import {deckObject,stones} from './harbor-house-tools.mjs';

// Stations stand alongside the actual walking and reaching points in the authored rooms.
const rooms={
 'bread-turn':[[11,8,'oven'],[13,8,'bread'],[20,12.8,'cart'],[20,7,'clinic'],[24,13.4,'coal']],
 'willow-tea':[[6,8,'teaWindow'],[12,7,'tea'],[18,8,'kettle'],[22,9,'tea']],
 'sill-walk':[[14,8,'chalk'],[17,10,'stretcher'],[22.4,9,'lowWall']],
 'rain-parlor':[[12.1,7.4,'sill'],[14.4,7,'bench'],[18.8,10.2,'alley'],[19.8,11,'curtain']],
 'boiler-stair':[[8,8,'kettle'],[12.4,7.6,'upper'],[16.4,10.8,'lower'],[18.8,11.5,'cups']],
 'laundry-pit':[[7,10,'seaPipe'],[10.6,9.6,'lower'],[16.8,9.1,'rainPipe'],[19.5,10.2,'roots']],
 'voice-deck':[[8,8,'earpipe'],[13.5,8.8,'earpipe'],[21,9.5,'earshelf']],
 'tile-bend':[[9,7.5,'bend'],[16,8,'felt'],[19.8,9.1,'bendOther']],
 'hush-bay':[[11.6,9,'wetRing'],[15.5,8.6,'skiff'],[19.2,10,'oars']],
 'outside-row':[[8,9,'gate'],[13.2,10,'rail'],[17,10.8,'skiff'],[19,9.7,'wetRing']],
 'sun-ladle':[[9,8.7,'lasts'],[13,9.7,'ladles'],[17,8.5,'lasts'],[21.6,10.3,'green']],
 'sailglass':[[11.8,8,'glass'],[16,8,'glassLow'],[19.1,10,'green']]
};
export const houseMaps=new Set(Object.keys(rooms));
function object(c,p,x,y,type,s,t){
 const q=s.flags,a=p(x,y),X=a[0],Y=a[1],wet=s.tide==='high';
 switch(type){
  case 'oven':bakehouse(c,p,x,y,true,t);break;
  case 'bread':case 'coal':coalRack(c,p,x-.8,y-.35,type==='bread');break;
  case 'cart':handcart(c,p,x+(q['crumb-road']?.7:0),y,!!(q['crumb-cart']||q['crumb-road']));break;
  case 'clinic':servingWindow(c,p,x-.8,y,2.1,q['crumb-bench']);bed(c,p,x+.55,y+.4,false,true);break;
  case 'sill':case 'teaWindow':servingWindow(c,p,x-.9,y,2.0,type==='teaWindow'||q['want-window']||q['window-booked']);break;
  case 'alley':servingWindow(c,p,x-.3,y,1.7,q['want-alley']||q['alley-booked'],true);break;
  case 'curtain':screen(c,p,x-.6,y,1.6,'#9d8476',!!q['want-alley']);break;
  case 'tea':{
   table(c,p,x-.85,y-.3,'bowl');const [u,v]=p(x-.1,y,15);oval(c,u,v,7,3,'#e6cf9a');poly(c,[[u+1,v-3],[u+5,v-4],[u+4,v]],'#5c6659');for(let i=0;i<3;i++)oval(c,u-18+i*4,v-3-i,4.5,2.6,'#536957');break;
  }
  case 'kettle':cauldron(c,X,Y,t,true);{const r=p(x+.78,y+.17);tub(c,...r,9,'#946e4c');}break;
  case 'chalk':stones(c,p,x,y);for(let i=0;i<2;i++)line(c,...p(x-.12,y+.38,5+i*8),...p(x+1.4,y+.38,5+i*8),'#f0e5c7',2.6);break;
  case 'lowWall':stones(c,p,x,y,true);break;
  case 'bench':box(c,p,x-.9,y-.22,1.8,.48,0,8,wood);break;
  case 'stretcher':{const here=(a,b,z=0)=>q['feet-first']?p(x+b-.4,y+a-.8,z):p(x+a-.8,y+b-.4,z);bed(c,here,0,0);for(const yy of [0,.85])line(c,...here(-.36,yy,11),...here(2.14,yy,11),'#bb996c',3);break;}
  case 'upper':case 'lower':washRun(c,p,x-.75,y-.32,type==='upper',s.tide,t);break;
  case 'cups':case 'ladles':{const spoons=type==='ladles';for(let j=0;j<=1;j++)line(c,...p(x+j*1.8-.9,y),...p(x+j*1.8-.9,y,29),'#85715a',3);
   line(c,...p(x-.98,y,27),...p(x+1.03,y,27),'#ad9a75',2);for(let i=0;i<3;i++){const u=x-.62+i*.58,z=22-i*5;line(c,...p(u,y,26),...p(u,y,z-7),'#b6a47e',1.5);const b=p(u,y,z-8);oval(c,...b,spoons?5:4.2,3,spoons?'#c6b189':'#b6c2ad');if(!spoons)arc(c,b[0],b[1]-1,3.5,0,Math.PI,'#716f58',1.4);}break;
  }
  case 'seaPipe':case 'rainPipe':{const sea=type==='seaPipe',open=sea?q['sample-sea']:q['sample-rain'];let col=sea?'#718384':'#99aa83';
   for(const w of [7,4.6])line(c,...p(x-1.05,y-.58,10),...p(x+.32,y+.12,10),w===7?'#51665f':col,w);
   oval(c,X+6,Y-6,4,5,'#374f50');washRun(c,p,x-.3,y+.4,false,s.tide,t);
   if(open||sea===wet)for(let i=0;i<5;i++)oval(c,X+6+i*.6,Y-5+(i*2+t*9)%12,1.3,1.8,sea?'#b9d2cb':'#cce2d2');break;}
  case 'roots':for(let i=0;i<7;i++){const b=p(x+i*.16,y,20);line(c,...b,b[0]+(i%3-1)*4,b[1]+18-i%4,'#78845e',1.7);}break;
  default: deckObject(c,p,x,y,type,s,t);

 }
}
export function housePlaces(c,p,m,s,t,ordered){
 const set=rooms[m.id];if(!set)return;
 for(const [xx,yy,type] of set){
   let x=xx,y=yy;
   if(type==='stretcher'&&s.flags['feet-first']){x=11.65;y=10.55;}
   if(m.id==='sun-ladle'&&type==='lasts'&&xx<10){x=7.65;y=10.42;}
   if(m.id==='sun-ladle'&&type==='green'&&s.flags['leaves-fed']){x=11.72;y=9.55;}
   if(m.id==='sailglass'&&type==='glassLow'){x=18.57;y=9.62;}
   ordered.push([x+y+.55,()=>object(c,p,x,y,type,s,t)]);
  }
}
export function houseFeature(c,p,m,f,s,t){
 if(!houseMaps.has(m.id))return false;
 const {kind:k,x,y,w=1,h=1,label=''}=f,xx=x+w*.53,yy=y+h*.65;
  // A street can mention a nearby house. Its walkable footprint stays a street.
  if(k==='path'||k==='pier')return true;
 if(k==='hearth'){if(m.id==='bread-turn')bakehouse(c,p,xx,yy,true,t);else cauldron(c,...p(xx,yy),t,true);return true;}
 if(k==='boat'){skiff(c,p,xx,yy,s.tide,t);return true;}
 if(k==='crate'&&m.id==='sun-ladle'){for(let j=0;j<3;j++)seedBed(c,p,x+1+j*1.9,yy,!!s.flags['leaves-fed']);return true;}
 if(k==='wall'&&m.id==='tile-bend'){for(let j=0;j<Math.min(6,w);j++)stones(c,p,x+.4+j,yy);return true;}
 if(k==='table'){object(c,p,xx,yy,'tea',s,t);return true;}
 if(k==='rope'&&/试听|陶圈|试用栏|影线|试水杯/.test(label)){for(let j=0;j<2;j++)object(c,p,x+2+j*3,yy,/栏/.test(label)?'rail':/杯|影/.test(label)?'cups':'wetRing',s,t);return true;}
 return false;
}
export function houseFloor(c,p,m,s){
 if(!houseMaps.has(m.id))return;
 if(m.id==='sailglass'||m.id==='sun-ladle'){
  const diffuse=s.flags['sun-scatter'];const xx=m.id==='sailglass'?13:15,yy=9;
  poly(c,[p(xx-1,yy-1,.5),p(xx+1,yy-1,.5),p(xx+(diffuse?5:2.7),yy+3,.5),p(xx+(diffuse?1:2.1),yy+3,.5)],diffuse?'#eed69460':'#ffe6a799');
 }
 if(['sill-walk','bread-turn','boiler-stair'].includes(m.id)){
  for(let j=0;j<5;j++){const xx=8.5+j*1.1;line(c,...p(xx,8.1,.5),...p(xx,12.4,.5),j%2?'#aa977d':'#d5c4a6',1.6);}
 }
}