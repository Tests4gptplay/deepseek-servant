import {addXP} from './party.mjs';
import {nextXP} from '../rules/vocations.mjs';

export function fieldBook(s){
 const ex=s.expedition;
 if(!ex.seamanship)ex.seamanship={quiet:false,lessons:{},credited:{},trail:null};
 return ex.seamanship;
}
export function raiseBy(world,id,hero,steps,limit){
 const end=Math.min(limit,hero.level+steps);if(end<=hero.level)return 0;
 const old=hero.level,base=world.actors[id]?.growth?.xpBase||16;
 const remainder=hero.xp;let xp=0;for(let i=hero.level;i<end;i++)xp+=nextXP(base,i);
 addXP(world,id,hero,Math.max(0,xp-remainder));
 return hero.level-old;
}
const courses=world=>[...new Map(Object.values(world.quests).filter(q=>q.endFlag&&q.endFlag!=='watch-second-end'&&q.stages?.length>=2).map(q=>[q.endFlag,q])).values()];
export function earnVoyage(world,s,before){
 if(s.cycle||before['grave-signed'])return [];
 const ledger=fieldBook(s),added=[];
 for(const q of courses(world)){
  if(before[q.endFlag]||!s.flags[q.endFlag]||ledger.lessons[q.endFlag])continue;
  ledger.lessons[q.endFlag]=ledger.quiet?'held':'learned';added.push(q.name);
 }
 const total=Object.values(ledger.lessons).filter(v=>v==='learned').length;
 for(const id of s.expedition.roster){
  const previous=ledger.credited[id]||0;if(total<=previous)continue;
  const h=s.expedition.heroes[id];
  if(previous===0&&total>1){const floor=Math.min(55,1+total);raiseBy(world,id,h,Math.max(0,floor-h.level),55);}
  else raiseBy(world,id,h,total-previous,55);
  ledger.credited[id]=total;
 }
 return added;
}
export function trainingMode(ctx,back){
 const {ui,state}=ctx,s=state.player,b=fieldBook(s);
 const options=[[b.quiet?'恢复随航实作授级':'改为随航见习',()=>{b.quiet=!b.quiet;trainingMode(ctx,back);} ],['回到航海志',back]];
 ui.show('training','同行授业簿',b.quiet?'见习中。每次完成的航务仍会记录，已记为见习的经历保留原等级。战斗、手记与配装仍由你选。':'伙伴随首次完成的航务逐段增长本领。上限为 Lv55。若想凭初阶行当走完全线，可以从现在改作见习。',options,'实作 '+Object.values(b.lessons).filter(v=>v==='learned').length+' 项 · 见习 '+Object.values(b.lessons).filter(v=>v==='held').length+' 项');
}
export function paidDrill(world,s,index){
 const gains={};for(const id of s.expedition.roster){
  const h=s.expedition.heroes[id],n=index>=14?1:h.level<65?8:h.level<83?6:h.level<91?4:3;
  gains[id]=raiseBy(world,id,h,n,index>=14?100:94);
 }
 return gains;
}
