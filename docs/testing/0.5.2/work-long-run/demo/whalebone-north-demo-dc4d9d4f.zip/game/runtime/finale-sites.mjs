import {graveObject} from './grave.mjs';
import {ratchetCase} from './voyage-floor.mjs';
import {poly,line,oval,arc} from './paint.mjs';
import {plate,box,iron,wood,mast,bed,wheel,parchment} from './voyage-shapes.mjs';
import {figure} from './figures.mjs';

export function machine(c,x,y,t,phase='white',kind='ram',stopped=false){
 const spin=stopped?0:t*(phase==='reverse'?-.8:.55),arm=stopped?0:Math.sin(t*2),black=phase==='black';
 c.save();c.translate(x,y);
 poly(c,[[-42,4],[-16,-12],[39,-8],[56,5],[24,17],[-18,16]],'#48595a','#334749');
 poly(c,[[-42,4],[-18,16],[24,17],[25,23],[-23,22],[-42,11]],'#6c7365');
 for(const d of [-1,1]){line(c,d*28,5,d*25,-32,'#7f7563',7);line(c,d*28+2,5,d*25+2,-32,'#b3a181',2);}
 line(c,-28,-27,33,-30,'#4d5757',7);wheel(c,3,-18,21,spin,14,phase==='reverse');wheel(c,-22,-11,10,-spin*1.65,9);
 const top=-41+(kind==='ram'?arm*3:0);line(c,10,-24,26,top,'#645747',5);
 poly(c,[[21,top-3],[32,top-6],[36,top],[27,top+5]],black?'#475453':'#ded7bc','#686e62');
 if(black){const v=kind==='shell'?0:8;poly(c,[[21,-40],[10,-39],[1,-49],[2,-57],[10,-61],[9,-53],[16,-47],[23,-47],[25,-58],[31,-56],[30,-47],[37,-24],[32,-20],[25,-35]],'#3d4646','#a19479');poly(c,[[27,-29],[41+v,-23],[48+v,-13],[43+v,-8],[37+v,-10],[40+v,-15],[31,-17]],'#404948','#ba9670');line(c,2,-52,8,-58,'#d9b181',2);}
 const jaw=black?(kind==='shell'?3:10):7;line(c,20,-7,32-jaw,-3,'#766c58',4);arc(c,33-jaw,-6,5,0,Math.PI,'#b89e77',2.8);
 for(let i=0;i<4;i++)line(c,-38,11+i*1.4,-10,13+i*1.4,phase==='reverse'?'#bc8161':'#a99870',1.2);
 if(!stopped){const d=kind==='rush'||kind==='whirl'?1:-1;for(let i=0;i<4;i++){const xx=-40-i*8;line(c,xx,10+d*i,xx-4,10+d*i+(d<0?-1:2),phase==='black'?'#dfae6f':'#c4e4db',1.7);}}
 c.restore();
}
export function whelk(c,x,y,t,open=false){
 c.save();c.translate(x,y);oval(c,0,3,20,5,'#465c5859');oval(c,4,0,17,6,'#859d88');
 poly(c,[[-12,-3],[-13,-11],[-5,-19],[4,-29],[16,-9],[11,-1]],'#be947e','#665e52');
 for(let i=0;i<4;i++)arc(c,0,-8-i*2,3+i*1.4,-2.8,1.5,'#e4c7a0',1.2);
 for(let i=0;i<3;i++){const dx=Math.sin(t*3.4+i)*2;line(c,12,-3,22+i*2+dx,-4-i*3,'#627569',1.6);}
 if(open)oval(c,6,-4,6,2.9,'#d4b28d');c.restore();
}
export function finalFeature(c,p,m,f,s,t){
 if(m.act!==6)return false;const k=f.kind,x=f.x,y=f.y,w=f.w||1,h=f.h||1;
 if(m.id==='ratchet-loft'){
  if(k==='crane'||k==='crate'){ratchetCase(c,p,f,t);return true;}
  if(k==='wall'){for(let i=0;i<w;i+=2.4)box(c,p,x+i,y+.2,1.9,.6,0,23,iron);return true;}
 }
 if(m.id==='flood-stair'&&k==='pier'){for(let i=0;i<w;i+=1.38){box(c,p,x+i,y+.16,1.20,h*.8,0,4+i*.22,wood);for(const e of [.18,.89])line(c,...p(x+i+.1,y+e,6+i*.22),...p(x+i+1.2,y+e,6+i*.22),'#d1ac78',1.1);}return true;}
 if(m.id==='burial-cape'&&k==='crate'){
   const [a,b]=p(x+w*.55,y+h*.58);box(c,p,x+.5,y+.65,1.78,.83,3,5,wood);
   for(const u of [-1,1]){arc(c,a+u*19,b+1,6,0,6.29,'#676653',2);line(c,a+u*16,b-1,a+u*21,b-15,'#82765b',2);}
   return true;
  }
  if(m.id==='letter-niche'&&(k==='building'||k==='crate')){for(let j=0;j<2;j++)for(let i=0;i<3;i++){box(c,p,x+.25+i*.95,y+.2+j*.84,.84,.68,0,16,wood);const a=p(x+.6+i*.95,y+.54+j*.84,17);if(j||i!==1)parchment(c,...a,i%2);}return true;}
 return false;
}
export function finalItem(c,p,m,e,s,t){
 const x=e.x+.5,y=e.y+.5,[a,b]=p(x,y),f=s.flags;
 if(e.id==='cold-whelk'){if(f['pump-free']){oval(c,a,b,10,2,'#80aaa3');}else whelk(c,a,b,t);return true;}
 if(e.id==='rescue-porters'||e.id==='court-roll'||e.id==='press-workers'||e.id==='sling-wards'){
  if(!f['harbor-tilted'])return false;
  const gone=e.id==='press-workers'?f['workers-aboard']:e.id==='sling-wards'?f['stretchers-on']:f['base-safe'];
  if(!gone){for(const n of [-1,1])figure(c,a+n*20,b+4,'evac-'+e.id+n,t,{scale:.86});if(e.id==='sling-wards')bed(c,p,x+.35,y-.2,true);}
  return false;
 }
 if(m.act!==6)return false;
 if(m.id==='burial-cape'&&graveObject(c,p,e,s,t))return true;
 switch(e.id){
 case 'clutch-fight':machine(c,a+22,b-10,t,'white','ram',!!f['clutch-still']);return true;
 case 'mara-shoe':case 'ivo-bridle':case 'selene-vent':case 'mira-chalk':case 'mara-floodgate':{box(c,p,x-.42,y-.23,.85,.46,0,7,iron);const done=f[e.action?.id];wheel(c,a,b-12,8,done?.8:0,8);line(c,a,b-14,a+(done?12:-9),b-23,'#bc9b69',3);return true;}
 case 'cut-ramp':for(let j=0;j<4;j++)line(c,a-17+j*8,b+7,a-13+j*8,b-4,'#8c6d57',2.8);mast(c,p,x+.34,y,18,'#c98561',t,.7);return true;
 case 'set-stretcher':bed(c,p,x-.8,y-.3,!!f['stretchers-on']);return true;
 case 'count-first':case 'salt-workers-berth':{const n=e.id==='count-first'?(f['base-safe']?4:2):(f['workers-arrived']?3:0);
  for(let j=0;j<n;j++)figure(c,a-27+j*11,b+8+(j%2)*4,'landed-'+j,t,{scale:.79});return e.kind!=='npc';}
 case 'unsigned-space':box(c,p,x-.6,y-.25,1.1,.5,0,13,wood);parchment(c,a,b-12,1,!!f['grave-signed']);return true;
 default:return false;
 }
}
