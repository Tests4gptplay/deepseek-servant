import {arc, line, oval, poly} from './paint.mjs';
import {box, plate, wood, iron, mast, bed} from './voyage-shapes.mjs';
import {cord, tideStep} from './whale-rigging.mjs';

// The narrow walking strips follow the four published map plans. Put wet and
// heavy structures on either side so characters keep a clear way through.
function channel(c,p,x,y,w,h,s,t,kind){
 const high=s.tide==='high',z=high?1:-2;
 const colors=kind==='flood'?['#658e8c','#729c99','#9ab8ab']:['#517d85','#648f93','#a3b8a9'];
 poly(c,[p(x,y,z),p(x+w,y,z),p(x+w,y+h,z),p(x,y+h,z)],colors[0]);
 for(let k=0;k<3;k++){
  const yy=y+(k+.6)*h/3,raw=[];
  for(let i=0;i<=18;i++)raw.push(p(x+w*i/18,yy+Math.sin(i*.74+t*.33+k)*.075,z+.5));
  for(let i=1;i<raw.length;i++){if((i+k)%4!==0)line(c,...raw[i-1],...raw[i],k===1?colors[2]:colors[1],k===1?1.3:2);}
 }
 line(c,...p(x,y+h,z),...p(x+w,y+h,z),high?'#c7d4bc':'#9aab98',2);
}
function timber(c,p,x,y,w,h,z=4){
 box(c,p,x,y,w,h,0,z,['#c0a981','#826f59','#5e5d53']);
 for(let i=.18;i<w;i+=.34)line(c,...p(x+i,y+.03,z+.4),...p(x+i,y+h-.03,z+.4),'#8f7e657d',1.3);
}
function piles(c,p,x,y,n,gap=2){
 for(let j=0;j<n;j++){const xx=x+j*gap;box(c,p,xx,y,.16,.22,-5,22,wood);const a=p(xx+.07,y+.09,18);oval(c,...a,3.8,2.1,'#ccb993');
  if(j+1<n)cord(c,p(xx+.08,y+.11,14),p(xx+gap+.08,y+.11,14),5,'#d0bb8f',2.2);}
}
function workingHull(c,p,x,y,s,t,purpose){
 const up=(s.tide==='high'?7:2)+Math.sin(t*1.1+x)*1.0,px=(a,b,z=0)=>p(x+a,y+b,up+z);
 const rim=[[-3.05,-.05],[-2.2,-.68],[1.65,-.70],[3.05,-.09],[2.08,.62],[-1.85,.64]];
 poly(c,rim.map(([a,b])=>px(a,b,-2)),'#40666b');
 poly(c,[px(-3.05,-.05,11),px(-1.85,.64,9),px(2.08,.62,9),px(3.05,-.09,12),px(2.27,.53,-1),px(-1.35,.60,-1)],purpose==='pantry'?'#965f4d':'#526973','#44545a');
 poly(c,rim.map(([a,b],i)=>px(a,b,i===0||i===3?12:9)),purpose==='pantry'?'#d0a477':'#c2b295','#665e52');
 poly(c,[px(-2.53,-.03,11),px(-1.92,-.48,10),px(1.64,-.49,10),px(2.51,-.07,12),px(1.89,.42,10),px(-1.70,.46,10)],'#4e6363');
 for(const dx of [-1.79,-.56,.70,1.75])line(c,...px(dx,-.46,11),...px(dx,.45,11),'#b29572',3.2);
 if(purpose==='pantry'){
  for(const dx of [-1.25,.55])for(const dy of [-.42,.42])line(c,...px(dx,dy,11),...px(dx,dy,35),'#6b6654',2.8);
  poly(c,[px(-1.38,-.62,34),px(.73,-.62,34),px(.73,.02,40),px(-1.38,.02,40)],'#bf8a68','#835e50');
  poly(c,[px(-1.38,.02,40),px(.73,.02,40),px(.73,.65,31),px(-1.38,.65,31)],'#a96e58','#805c4f');
  for(const dx of [-1.11,-.56,0,.51])line(c,...px(dx,.01,40),...px(dx,.65,31),'#dec09a',2.2);
  const bowl=px(1.30,.05,13);oval(c,...bowl,9,4,'#d4c09c');
 }else{
  const q=(a,b,z=0)=>px(a,b,z+12);bed(c,q,-1.48,-.33,!!s.flags['hearth-bed-arrived']);
  const pole=px(1.22,-.35,38);line(c,...px(1.22,-.35,9),...pole,'#817362',2.7);
  poly(c,[pole,[pole[0]+13,pole[1]-1],[pole[0]+9,pole[1]+5],[pole[0]+1,pole[1]+5]],'#bed0b8');
  for(const u of [.91,1.45,1.81])line(c,...px(u,-.31,12),...px(u+.7,.75,6),'#c4b287',2.3);
 }
 cord(c,px(2.68,.10,12),p(x+3.5,y+1.35,13),s.tide==='high'?5:2,'#d7be90',2.5);
}
function floodWindow(c,p,x,y,w){
 const face=y+.72;box(c,p,x,y,w,.72,-1,35,['#a49a80','#969882','#738478']);
 const dark='#435e60';for(let j=.28;j<w-.65;j+=1.02){const a=x+j;
  poly(c,[p(a,face,9),p(a+.70,face,9),p(a+.70,face,26),p(a,face,26)],dark,'#c4b899');
  line(c,...p(a+.35,face,9),...p(a+.35,face,26),'#a0aa90',2);
  line(c,...p(a-.08,face+.02,9),...p(a+.84,face+.02,9),'#d5c098',3);}
 line(c,...p(x-.16,face,35),...p(x+w+.16,face,35),'#735f54',4);
}
export function shoreSections(c,p,m,s,t,ordered){
 const place=m.id;
 if(!['spoon-skiff','ladle-cut','ash-sound','low-sill'].includes(place))return;
 const add=(x,y,fn)=>ordered.push([x+y+.43,fn]);
 if(place==='spoon-skiff'){
  channel(c,p,3.2,6.05,23.1,1.65,s,t,'ebb');timber(c,p,5.2,8.45,20.9,.94,3);
  for(const x of [8.7,17.8,25]){timber(c,p,x,7.46,.80,1.20,4);add(x,8.35,()=>piles(c,p,x+.05,8.28,2,.67));}
  add(10.2,7.15,()=>workingHull(c,p,10.2,7.15,s,t,'pantry'));
  add(21.3,6.76,()=>{const a=p(21.3,6.76,6);mast(c,p,21.3,6.76,38,'#b6c8a3',t);for(let i=0;i<3;i++)oval(c,a[0]+i*6,a[1]-5+i,6,2,'#d1c598');});
  add(16.0,11.9,()=>{for(const u of [14.3,17.6])line(c,...p(u,12.15),...p(u,12.15,24),'#766854',3.2);
   const a=p(14.3,12.15,22),b=p(17.6,12.15,22);cord(c,a,b,5,'#d3bd91',2.4);
   for(let j=0;j<8;j++){const x=14.4+j*.41;line(c,...p(x,12.15,20-j%3),...p(x+.5,12.15,6),'#8aa69a',1.65);line(c,...p(x+.5,12.15,20),...p(x,12.15,6+j%2),'#859f94',1.5);}
  });
 }else if(place==='ladle-cut'){
  channel(c,p,3.3,6.85,25,1.62,s,t,'flood');channel(c,p,10.4,12.75,12.6,.96,s,t,'flood');
  timber(c,p,4.6,9.46,23.5,.75,4);for(const x of [8.7,16.1,22.3])timber(c,p,x,8.32,.68,1.19,5);
  add(12,7.01,()=>floodWindow(c,p,9.6,6.66,5));add(20.5,7.01,()=>floodWindow(c,p,18.65,6.66,3.65));
  add(21.6,8.36,()=>workingHull(c,p,21.6,8.02,s,t,'rescue'));
  add(17.2,12.42,()=>piles(c,p,11.6,12.42,5,2.22));
 }else if(place==='ash-sound'){
  channel(c,p,8.4,11.74,12.6,1.45,s,t,'ebb');
  for(let i=0;i<4;i++){const x=11.25+1.1*i,z=3+i*3;box(c,p,x,10.9,1.03,1.04,0,z,['#b6b4a2','#8e9182','#6e8179']);}
  add(13,11.18,()=>tideStep(c,p,12.25,11.74,s.tide==='high'));
  add(17.2,8.54,()=>{for(const [x,z] of [[15.1,35],[18.5,43],[19.75,38]])line(c,...p(x,8.43),...p(x,8.43,z),'#726653',4);
   cord(c,p(15.1,8.43,35),p(18.5,8.43,43),5,'#bfac83',2.6);cord(c,p(18.5,8.43,43),p(19.75,8.43,38),2,'#bfac83',2);
   const a=p(16.5,8.43,27);line(c,...p(16.5,8.43,35),...a,'#9d9373',2);oval(c,...a,11,6,'#b87f5a');});
 }else{
  timber(c,p,7.6,10.02,19.7,.65,3);
  for(const x of [10.15,16.2,22.4]){
   add(x,7.87,()=>{box(c,p,x,7.85,.28,.60,0,38,wood);box(c,p,x+3.22,7.85,.28,.60,0,38,wood);
    box(c,p,x-.14,7.85,3.8,.62,37,5,['#baa27e','#8f7c61','#665e50']);
    line(c,...p(x+.18,8.13,26),...p(x+1.15,8.13,38),'#8e7b62',3);});
  }
  for(const offset of [-.23,.23])line(c,...p(11.1,11.5+offset,2),...p(19.75,11.5+offset,2),'#8d8473',2);
  const pivot=p(16.05,10.9,3);oval(c,...pivot,22,8,'#655f52');arc(c,pivot[0],pivot[1],15,0,Math.PI,'#d1b88e',2);
 }
}

