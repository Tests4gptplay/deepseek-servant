import {poly,line,oval,arc} from './paint.mjs';
import {plate,box} from './voyage-shapes.mjs';
import {figure} from './figures.mjs';
import {add,board,cart,cottage,coop,dryingRack,flare,lantern,net,quayEdge,reedBed,steps,stroke,surface,timber,tracks} from './household-art.mjs';
const places=new Set(['pelt-lane','heel-house','screen-slope','curtain-tow','split-houselight','moon-dorm','net-dorm','rut-mouth','antler-swell','calf-lichen','paper-beasts','reed-flies']);
export const courtPlace=id=>places.has(id);
const shore=new Set(['curtain-tow','net-dorm','rut-mouth','antler-swell','calf-lichen','reed-flies']);
const ramp=new Set(['heel-house','screen-slope','split-houselight','moon-dorm']);
function animal(c,x,y,t,young=false){
 c.save();c.translate(x,y);const k=young?.68:1;c.scale(k,k);
 const fur=young?'#caad85':'#8d7961',lineColor='#4e544b';
 for(const [dx,shift]of [[-15,2],[-10,-1],[9,1],[13,-2]]){const pace=Math.sin(t*1.6+dx)*1.8;line(c,dx,-9,dx+pace,shift-2,fur,3.2);line(c,dx+pace,shift-2,dx+3+pace,shift,lineColor,2.1);}
 poly(c,[[-20,-21],[-10,-24],[4,-24],[13,-19],[16,-26],[19,-29],[24,-25],[31,-22],[30,-19],[21,-19],[17,-10],[6,-8],[-9,-10],[-18,-13]],fur,lineColor);
 poly(c,[[-18,-19],[-23,-21],[-25,-18],[-19,-16]],'#bcaa8b',lineColor);
 poly(c,[[17,-26],[12,-31],[16,-31],[21,-27]],'#bda587',lineColor);oval(c,24.2,-24.1,1.2,1.1,'#303e3a');
 if(!young){for(const sign of [-1,1]){const a=20+sign*2;line(c,a,-28,a+sign*4,-40,'#dac5a1',2);line(c,a+sign*4,-37,a+sign*9,-43,'#c6b590',1.6);line(c,a+sign*4,-36,a+sign*1,-43,'#c6b590',1.5);}}
 c.restore();
}
function curve(c,p,points,offset,shade,width){
 const path=points.map(([x,y])=>p(x,y+offset,2.5));c.strokeStyle=shade;c.lineWidth=width;c.lineJoin='round';c.lineCap='round';
 c.beginPath();c.moveTo(...path[0]);for(let i=1;i<path.length-1;i++){const mid=[(path[i][0]+path[i+1][0])/2,(path[i][1]+path[i+1][1])/2];c.quadraticCurveTo(...path[i],...mid);}c.lineTo(...path.at(-1));c.stroke();
}
const turnout=[[4,11.3],[9,11.3],[12.5,11],[16,9.2],[19,9.3],[23.5,11.6],[29,11.7]];
export function courtGround(c,p,m,s,t){
 surface(c,p,1,5,m.width-2,m.height-6,false,t,true);
 if(shore.has(m.id)){
  const high=s.tide==='high',top=high?9.2:12.05;surface(c,p,1.2,top,m.width-2.4,m.height-top-1.2,true,t,true);
  for(let i=0;i<7;i++){const xx=3+i*4.5;stroke(c,p,[xx,top-.09],[xx+2.6,top-.1],'#c7cebb',1.6);}
  reedBed(c,p,4,top+1,25,3,t);
  if(m.id==='rut-mouth'||m.id==='antler-swell'||m.id==='calf-lichen'){
   tracks(c,p,[[2.5,10.1],[8,9.7],[13,8.5],[18,7.8],[24,8.4],[29,9.6]]);
   tracks(c,p,[[5,12.2],[10,12.7],[14.6,14.1],[18.5,14.4],[21.4,12.85],[23,11.3],[25,10.9]],true);
  }
 }
 if(ramp.has(m.id)){curve(c,p,turnout,0,'#796f59',23);curve(c,p,turnout,0,'#b8a789',19);
  for(const a of [-.24,.24])curve(c,p,turnout,a,'#847c6b',1.85);}
 if(m.id==='split-houselight'){steps(c,p,19,7.65,9,1.6);board(c,p,21.7,7.65,9.2,1.63,22);surface(c,p,17.7,13.25,14.6,2.4,true,t,true);}
 if(m.id==='curtain-tow'||m.id==='net-dorm'){board(c,p,3,10.65,m.width-6,1.14,1,true);tracks(c,p,[[7,12.3],[12,13.1],[16,13.7],[20,13.4],[24,11.8],[28,11.7]],true);}
}
function raisedCourt(c,p,m,s,t,q,blend){
 const open=blend('ridge-rooms'),wheel=blend('ramp-passed'),unhook=blend('moon-loose'),room=m.id==='moon-dorm';
 const focus=room?20.5:17.8;
 const structures=room?[[8,3.7],[17.6,4.6],[24.6,3.7]]:[[7.8,3.5],[16.2,3.8],[24.5,4.0]];
 for(const [x,w] of structures)add(q,x,8.85,()=>cottage(c,p,x,6.35,w,2.48,{h:room?51:43,door:.17,window:.60,lit:open>.15||!room,open:room&&open>.48,roof:room?'#82959a':'#78867d'}));
 if(room){add(q,focus,10.04,()=>{steps(c,p,focus-.7,9.1,6,1.3);board(c,p,focus+1.1,9.1,1.25,1.30,15);
  const a=p(focus-.5,9.15,15);flare(c,...a,39,'rgba(251,190,106,'+(.10+.20*open)+')');
  net(c,p,10.45,10.25,1.65,unhook);lantern(c,...p(focus+1.99,10),41,false,t);});
 }else{add(q,focus,10.45,()=>{cart(c,p,focus+(wheel-.5)*2.4,10.33-wheel*.42,(wheel-.3)*.13);
  if(wheel<.98){const a=p(focus+1.7,10.3);line(c,a[0]-14,a[1]-5,a[0]+9,a[1]+3,'#9a7956',3);}
 });add(q,24,10,()=>{steps(c,p,24,9.25,6,1.4);lantern(c,...p(25.6,10.6),28,false,t);});}
}
function shoreRoom(c,p,m,s,t,q,blend){
 const room=m.id==='net-dorm',open=blend(room?'sill-rooms':'sill-clear'),closed=blend('sill-choked');
 for(const [x,w] of [[6.5,3.8],[15.1,4.2],[21,3.4]])add(q,x,9.3,()=>cottage(c,p,x,6.9,w,2.35,{h:37,roof:'#637e80',wall:'#afa38a',lit:x!==15.1||open>.35,open:room&&open>.38&&x>20}));
 for(const x of [10.65,16.65,22.3])add(q,x,11,()=>{net(c,p,x-.6,10.25,room?1.85:2.6,x===16.65?open:room?open:.72);lantern(c,...p(x+1.1,10.65),26,true,t);});
 const xx=18.7+open*2.4,yy=12.8-open*.84;add(q,xx,yy,()=>{animal(c,...p(xx,yy),t,true);if(closed>.4&&open<.5)reedBed(c,p,xx-.65,yy-.4,1.3,1.1,t);});
}
function trackShore(c,p,m,s,t,q,blend){
 const young=m.id==='calf-lichen',open=blend(young?'rut-low-calves':'rut-high-back'),base=young?19.8:19.05;
 for(let i=0;i<(young?3:2);i++){const x=base+i*1.08+open*.9,y=(young?11.7:9.82)+Math.sin(i*.9+open*1.9)*.78;add(q,x,y,()=>animal(c,...p(x,y),t+i*.6,young&&i!==2));}
 for(const [x,y] of [[8.4,9.4],[15.5,8.65],[24,10.4]])add(q,x,y,()=>{const a=p(x,y);poly(c,[[a[0]-17,a[1]],[a[0]-8,a[1]-6],[a[0]+5,a[1]-11],[a[0]+14,a[1]-4],[a[0]+9,a[1]+1]],'#858d7d','#6c7d70');reedBed(c,p,x-.6,y+.35,1.4,.8,t);});
}
function puppetCourt(c,p,m,s,t,q,blend){
 const show=blend('play-finished'),salt=m.id==='reed-flies',x=salt?17.9:17.3;
 add(q,x,10.25,()=>{
  board(c,p,x-2,8.8,4.15,1.55,5);
  for(const k of [-1.8,1.97])stroke(c,p,[x+k,10.05],[x+k,10.05,48],'#746453',3);
  poly(c,[p(x-1.8,10.04,45),p(x+1.96,10.04,45),p(x+1.96,10.04,20),p(x-1.8,10.04,20)],show?'#efd3a1':'#d9c99f','#817b67');
  const [a,b]=p(x+.19,10.07,31);flare(c,a-7,b,27,'rgba(254,202,116,.32)');
  const sway=Math.sin(t*2)*3*(.25+.75*show);line(c,a-9,b+13,a-7,b+sway,'#846e52',1);
  poly(c,[[a-15,b-2+sway],[a-9,b-6+sway],[a-1,b-4+sway],[a+5,b+sway],[a-2,b+4+sway],[a-10,b+3+sway]],'#9b7056','#715843');
  for(let i=0;i<3;i++)line(c,a-9+i*4,b+3+sway,a-11+i*4,b+6+sway,'#755f4d',1.1);
  line(c,a+3,b-1+sway,a+11,b-6+sway,'#816650',1);lantern(c,...p(x-1.1,9.5),24,false,t);
 });
 if(salt)add(q,21.3,11.2,()=>{const a=p(21.3,11.2);for(let i=0;i<9;i++){const xx=a[0]+Math.sin(t*.54+i*2.7)*17,yy=a[1]-13+Math.cos(t*.7+i*1.4)*6;oval(c,xx,yy,1.25,.86,'#ecdb8b');}});
}
function meetingDoors(c,p,s,t,q,blend){
 // The two passages share the residents' entrance. Their distant exits stay anchored
 // at the corresponding rooms; both thresholds can be read from the meeting place.
 const high=blend('ridge-rooms'),low=blend('sill-rooms');
 surface(c,p,10.15,11.48,2.1,1.08,true,t,true);
 for(let i=0;i<4;i++)quayEdge(c,p,10.4+i*.47,12.47,.47);
 add(q,11.3,11.34,()=>{net(c,p,10.5,11.4,1.48,low);const [u,v]=p(10.43,11.6);
   lantern(c,u,v,19,true,t);tracks(c,p,[[10.1,12.08],[10.9,12.24],[11.7,12.15],[12.25,11.8]],true);});
 add(q,14.2,10.05,()=>{
  steps(c,p,13.35,9.7,6,1.23);board(c,p,15.13,9.68,1.06,1.25,15);
  const x=14.05,y=9.56;for(const k of [0,1.43])stroke(c,p,[x+k,y],[x+k,y,49],'#6c5b49',3.5);
  stroke(c,p,[x-.07,y,50],[x+1.5,y,50],'#b2966e',3);
  const end=18+high*26;
  poly(c,[p(x+.03,y,48),p(x+1.38,y,48),p(x+1.38,y,end-1),p(x+.03,y,end)],'#c4b594','#807d6a');
  const [u,v]=p(x+.7,y,34+high*6);
  if(high<.7){oval(c,u,v,6.8,6.1,'#ede3bb');oval(c,u+2.4,v-1.8,5.1,4.8,'#c4b594');}
  lantern(c,...p(15.55,10.04),36,false,t);
 });
}

function yardDetails(c,p,m,t,q){
 if(!shore.has(m.id)){
  for(const [x,y]of [[8.2,9.25],[16.15,9.4],[24.2,9.25]])add(q,x,y,()=>{coop(c,p,x,y);coop(c,p,x-.33,y+.11);});
  add(q,13.05,9.2,()=>dryingRack(c,p,13.05,9.2,1.66,false));
  if(m.id==='moon-dorm')add(q,20.9,10.15,()=>{const p1=p(20.9,10.15),p2=p(21.45,10.15);line(c,...p1,...p2,'#a67459',3);});
 }else if(m.id==='net-dorm'||m.id==='curtain-tow'){
  for(const [x,y]of [[8.48,9.68],[15.25,9.8],[22.45,9.42]])add(q,x,y,()=>{coop(c,p,x,y);});
  add(q,18.86,9.5,()=>dryingRack(c,p,18.86,9.5,1.35,true));
  for(const [x,w] of [[5.3,3.8],[11.9,2.6],[20.4,3.2]])quayEdge(c,p,x,12.02,w);
 }
}

export function courtObjects(c,p,m,s,t,q,blend){
 yardDetails(c,p,m,t,q);
 if(m.id==='curtain-tow'||m.id==='net-dorm')shoreRoom(c,p,m,s,t,q,blend);
 else if(m.id==='rut-mouth'||m.id==='antler-swell'||m.id==='calf-lichen')trackShore(c,p,m,s,t,q,blend);
 else if(m.id==='paper-beasts'||m.id==='reed-flies')puppetCourt(c,p,m,s,t,q,blend);
 else{
  raisedCourt(c,p,m,s,t,q,blend);
  if(m.id==='split-houselight'){
   meetingDoors(c,p,s,t,q,blend);
   add(q,28,8.6,()=>{cottage(c,p,26.8,6.3,3.7,2.25,{h:50,lit:true,open:!!s.flags['ridge-rooms'],roof:'#80918d'});lantern(c,...p(28.6,9.8),41,false,t);});
   add(q,29.7,13.8,()=>{net(c,p,29.1,13,2.5,blend('sill-rooms'));board(c,p,29.6,13.5,2.6,1.1,1,true);lantern(c,...p(30.7,14.3),29,true,t);});
  }
 }
 for(const x of [8.3,17.1,25.5])add(q,x,10.25,()=>lantern(c,...p(x,10.25),26,shore.has(m.id),t));
}
const hardware=new Set(['ramp-splay','ramp-watch','curtain-block','curtain-gather','curtain-walk','moon-unhook','moon-open','netdorm-night','netdorm-open','swell-pass','calf-turn','calf-small','rut-plan','stage-show','flies-reflect']);
export function courtItem(c,p,m,e,s,t){
 if(!courtPlace(m.id))return false;if(hardware.has(e.id))return true;
 if(e.kind==='npc'||e.action?.type==='battle')return false;
 const a=p(e.x+.5,e.y+.5,8);oval(c,...a,2.5,1.7,'#d8c494');return true;
}


