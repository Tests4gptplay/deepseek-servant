import {shopWork} from './keelpot-working-quay.mjs';
import {poly,line,oval} from './heelturn-cabins.mjs';
const brine='#628e8b',timber='#78583e',lineColor='#474e47',pale='#e0c998';
const area=new Set(['keelpot-yard','keelpot-neck','keelpot-side','keelpot-landing']);
function pot(c,q,x,y,r,red){
 const [cx,cy]=q(x,y,3),cloth=red?'#995b47':'#526f87';
 oval(c,[cx,cy],r*.91,r*.38,'#43585778');
 c.beginPath();c.moveTo(cx-r*.55,cy-r*1.28);c.bezierCurveTo(cx-r*1.26,cy-r*.94,cx-r*.95,cy-.5*r,cx-r*.53,cy-.12*r);
 c.quadraticCurveTo(cx,cy+.12*r,cx+r*.55,cy-r*.12);c.bezierCurveTo(cx+r,cy-r*.58,cx+r,cy-r*.99,cx+r*.48,cy-r*1.28);
 c.fillStyle=red?'#ab7451':'#b39060';c.fill();c.strokeStyle=lineColor;c.lineWidth=1.5;c.stroke();
 oval(c,[cx,cy-r*1.27],r*.65,r*.28,cloth);line(c,[[cx-r*.60,cy-r*.98],[cx+r*.60,cy-r*.98]],pale,1.5);
 line(c,[[cx-r*.60,cy-r*.85],[cx-r*.29,cy-r*.52],[cx-r*.22,cy-r*.12]],'#d8b485',1.4);
}
function crib(c,q,x,y,w,h){
 const a=q(x,y,5),b=q(x+w,y,5),d=q(x,y+h,5),e=q(x+w,y+h,5);
 poly(c,[a,b,e,d],'#617a67',timber);
 for(let i=0;i<=7;i++){
  const dx=w*i/7;line(c,[q(x+dx,y,7),q(x+dx,y+h,5)],i%2?'#b1ad78':'#73835c',2.4);
  for(let j=1;j<=3;j++){
   const [px,py]=q(x+dx,y+h*j/4,8);oval(c,[px,py],2.4,1.6,j%2?'#d0cba5':'#969d87');
  }
 }
 for(const v of [0,h])line(c,[q(x,y+v,8),q(x+w,y+v,8)],'#cebd7c',2.7);
}
function boat(c,q,s,far){
 const f=s.progress.keelpotFreight;
 if(far!==!!s.flags['keelpot-launched']){
  for(let i=0;i<3;i++)line(c,[q(.6+i*.8,.9),q(1.4+i*.8,1.05)],'#b7d4c7',1.5);
  return;
 }
 const hw=far?4.8:5.6;
 const a=q(.2,1),b=q(1.2,.1),d=q(hw-.4,.05),end=q(hw+.25,.64),e=q(hw-.1,1.53),g=q(.8,1.57);
 poly(c,[a,b,d,end,e,g],timber,lineColor);poly(c,[q(.5,1,5),q(1.35,.25,6),q(hw-.5,.25,7),q(hw-.1,.64,7),q(hw-.5,1.28,5),q(.95,1.3,5)],'#aa885d','#514c3b');
 for(const x of [hw*.30,hw*.62])line(c,[q(x,.22,9),q(x,1.32,9)],pale,4);
 line(c,[q(.12,.9,6),q(-.16,.65,1),q(-.24,.15,3)],'#c1b997',1.7);
 const cargo=f?.boat||[];
 if(cargo.includes('rack'))crib(c,q,1.1,.32,hw-2,.87);
 else cargo.forEach((key,i)=>pot(c,q,1.5+i*1.65,.8,7.9,key==='rust'));
}
function bank(c,q,f,s){
 const water=s.tide==='high',wet=water?'#76a99b':'#8c9e7f',w=f.w,h=f.h;
 poly(c,[q(0,0),q(w,0),q(w,h),q(0,h)],water?'#689d98':'#898b6d');
 for(let j=1;j<=5;j++){
  const k=h*(j-.35)/5;
  line(c,[q(.1,k),q(w*.28,k+.09),q(w*.54,k-.09),q(w*.93,k)],j%2?wet:'#c4cab0',1.3);
 }
 if(!water)for(let i=1;i<Math.min(8,w*2);i++)oval(c,q(w*i/9,h*.63),2+i%3,1.6,'#617866');
}
function cut(c,q,f){
 const w=f.w-.2,h=f.h-.25,z=42;
 poly(c,[q(.12,.12),q(w,.12),q(w,h),q(.12,h)],'#ad9670',timber);
 poly(c,[q(.12,.12),q(w,.12),q(w,.12,z-3),q(.12,.12,z)],'#c6b595','#6b6854');
 poly(c,[q(.12,.12),q(.12,h),q(.12,h,z-8),q(.12,.12,z)],'#8a8569','#625e4f');
 for(let i=.65;i<w;i+=1.1)line(c,[q(i,.12,0),q(i,.12,z-4)],'#9c9074',1.3);
 const top=q(w*.53,.2,25);oval(c,top,10.8,6.1,'#6c7568');line(c,[q(w*.5,.3,16),q(w*.8,.55,13)],'#c7a773',3);
 for(let i=0;i<3;i++)pot(c,q,.65+.56*i,.72,5,i===2);
}
export function paintKeelpot(c,p,map,f,s,t){
 if(!area.has(map.id))return false;
 const q=(x,y,z=0)=>p(f.x+x,f.y+y,z);
 if(f.kind==='building'){cut(c,q,f);shopWork(c,q,f,map);}
 else if(f.kind==='water')bank(c,q,f,s);
 else if(f.kind==='path'){
  for(const y of [.2,f.h-.25])line(c,[q(.1,y),q(f.w*.45,y+.04),q(f.w-.1,y)],'#c7b18c',1.25);
 }else if(f.kind==='kp-boat')boat(c,q,s,map.id==='keelpot-landing');
 else if(f.kind==='kp-jar'){
  const received=map.id==='keelpot-landing',v=s.progress.keelpotFreight||{},list=received?(s.flags['keelpot-fish-first']&&s.flags['keelpot-landed']?['blue','rust']:v.ashore||[]):['blue','rust'].filter(k=>!(v.boat||[]).includes(k)&&v.shoulder!==k&&!(v.ashore||[]).includes(k)&&!(s.flags['keelpot-landed']&&s.flags['keelpot-fish-first']));
  for(const k of ['blue','rust'])if(list.includes(k))pot(c,q,.5+(k==='rust'?.9:0),.6,10,k==='rust');
 }else if(f.kind==='kp-crib'){
  const v=s.progress.keelpotFreight||{},delivered=!!s.flags['keelpot-landed'],far=map.id==='keelpot-landing';
  for(const [i,k] of ['near','sea'].entries()){
   const sent=(v.ashore||[]).includes(k)||(s.flags['keelpot-seed-first']&&delivered);
   if(far?sent:!sent&&!v.boat?.includes('rack')&&v.shoulder!==k)crib(c,q,.15+1.8*i,.2,1.6,1.1);
  }
 }else if(f.kind==='kp-ledge'){
  for(let i=0;i<4;i++)poly(c,[q(.3+i*.8,.28),q(.85+i*.8,.2),q(1+i*.8,.8),q(.42+i*.8,1)],i%2?'#8d9c8e':'#a9ac96','#67776e');
 }else if(f.kind==='kp-foam'||f.kind==='kp-burrow'){
  for(let i=0;i<7;i++){const u=.25+i*.43,v=.35+.27*Math.sin(i*1.4),[px,py]=q(u,v,2);
   oval(c,[px,py],4,2,brine);if(!s.flags['keelpot-sheltered'])oval(c,[px+Math.sin(i+t)*1.5,py-2-(i%3)],1.7,.95,'#dce8d4');}
 }else if(f.kind==='kp-sluice'||f.kind==='kp-gauge'){
  for(const a of [.25,1.65])line(c,[q(a,.3),q(a,.3,22)],timber,3);
  line(c,[q(.23,.30,5),q(1.72,.31,s.flags['keelpot-channel']?20:8)],'#d3b47d',4);
  for(const z of [8,17])line(c,[q(.18,.32,z),q(.40,.32,z)],'#e8e0bf',2);
 }else return false;
 return true;
}
