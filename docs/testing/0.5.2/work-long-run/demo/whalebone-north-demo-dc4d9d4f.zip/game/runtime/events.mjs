import {musicBench} from './salt-song/the-two-audiences.mjs';
import {crossKitchen} from './lullaby-partners.mjs';
import {useStarTable} from './star-clock/boat-by-the-stars.mjs';
import {anchorCue} from './anchor-release/scene.mjs';
import {clothAndStone} from './graveside/a-hand-at-the-stone.mjs';
import {stageAtWork} from './second-shadow/two-bodies-one-stage.mjs';
import {readingSignedHearing} from './quaybill-prior-hearing.mjs';
import {quaybillUse} from './quaybill-casework.mjs';
import {keelpotFreight} from './keelpot-freight.mjs';
import {saltcoatCue} from './saltcoat-scene/index.mjs';
import {priorWitnessClue} from './route-reading/prior-witnesses.mjs';
import {shoulderHeight} from './whale-breath.mjs';
import {earnVoyage} from './seamanship.mjs';
import {practice} from './practice.mjs';
import { allows, enter, setFlags, takeAction } from './state.mjs';
import { dialogue } from './dialogue.mjs';
import {routeClue} from './route-reading/index.mjs';
import {workshopCue} from './workshop-sounds.mjs';
import {learnPassages} from './passage-school.mjs';
import { stats,syncParty,addXP } from './party.mjs';
import { items } from './gear.mjs';
import { encounter } from './encounter.mjs';

import {combCoastUse} from './comb-coast.mjs';
export function interactions(ctx) {
  const { world, state, ui, sound, sync } = ctx;
  const close = () => { state.scenicFocus=null;ui.hide();sync(); };
  function use(target) {
    if (!target) { ui.toast('靠近人物、物件或路口即可互动。'); return; }
    const e = target.value, s = state.player;
    state.scenicFocus=target.kind==='exit'?null:{map:s.map,id:e.id,x:e.x,y:e.y};
    if (!allows(s, e.requires) && !readingSignedHearing(s,e)) {
      const tide = (e.requires || []).find(k => k.startsWith('tide:'));
      const tip = tide && !allows(s,tide) ? '水线越过了阶沿。在候潮铜钟旁等待另一潮。' : routeClue(s,e) || '手续还没齐。附近的工人和器具上留有线索。';
      ui.show('gate', e.name || e.label || '通路', priorWitnessClue(s,e) || e.lockedText || tip, [['返回', close]]);
      return;
    }
    if (target.kind === 'exit') {
      if (enter(world, s, e)) { sound('gate'); close(); ui.toast(world.maps[s.map].name); }
      else ui.toast('目的地未能载入。');
      return;
    }
    if(e.action?.type==='salt-song'){musicBench(ctx,e,close);return;}
    if(e.action?.type==='star-clock'){useStarTable(ctx,e,close);return;}
    if(e.action?.type==='twohand-stage'){stageAtWork(ctx,e,close);return;}
    if(e.action?.type==='lullaby-crossing'){crossKitchen(ctx,e,close);return;}
    if(e.action?.type==='quaybill'){quaybillUse(ctx,e,close);return;}
    if(e.action?.type==='keelpot-freight'){keelpotFreight(ctx,e,close);return;}
    if(e.action?.type==='comb-coast'){combCoastUse(ctx,e,close);return;}
    if(e.action?.type==='practice'){practice(ctx,e,close);return;}
    const before={...s.flags};
    const a = e.action, stamp = 'event:' + s.map + ':' + e.id;
    const after = () => dialogue(ui, state, e.after || [], close);
    const finish = () => { if(workshopCue(e.id)||saltcoatCue(e.id)||anchorCue(e.id))state.scenicMotion={map:s.map,id:e.id,x:e.x,y:e.y,at:performance.now()/1000,fromHeight:shoulderHeight(before),fromFlags:before};s.flags[stamp] = true; sync(); const learned=learnPassages(world,s,before,addXP);earnVoyage(world,s,before); if(learned.length)ui.toast('实作航历 · '+learned.join('、')); after(); };
    if (s.flags[stamp] && e.after?.length && !['tide','battle'].includes(a?.type)) { after(); return; }
    const act = () => {
      if (!a) { s.flags[stamp]=true;close();return; }
      if(a.type==='cycle'&&a.id==='afterwatch'){ctx.openVoyage();return;}
      if (a.type === 'recruit') { setFlags(s,'party:'+a.id);setFlags(s,a.set);finish();return; }
      if (a.type === 'rest') {
        const ex=syncParty(world,s);for(const id of ex.roster){const h=ex.heroes[id],max=stats(world,id,h.level);h.hp=max.hp;h.mp=max.mp;}
        setFlags(s,a.set);finish();return;
      }
      if (a.type === 'item'&&items(world)[a.id]&&!s.flags['collected:'+e.id]) {
        const stock=syncParty(world,s).stock;stock[a.id]=(stock[a.id]||0)+(Number(a.value)||1);
      }
      if (a.type === 'puzzle') {
        const ask = (hint = '') => {
          const options = (a.options || []).map((option, i) => [typeof option === 'string' ? option : option.text, () => {
            if (i !== a.answer) { sound('touch'); ask(a.hint || '指针没有对准。可以重新调节。'); return; }
            setFlags(s, a.id); setFlags(s, a.set); sound(workshopCue(e.id)||'solve'); finish();
          }]);
          ui.show('puzzle', e.name, [a.prompt, hint].filter(Boolean).join('\n'), [...options, ['放下', close]]);
        };
        ask();
      } else if (a.type === 'battle') {
        const spec = world.encounters?.[a.id] || world.encounters?.[a.value] || {};
        encounter(ctx, { ...spec, entityId:e.id }, () => {
          s.victories++; setFlags(s, a.id); setFlags(s, a.set); finish();
        }, close);
      } else {
        takeAction(s, e); sound(workshopCue(e.id)||(a.type === 'tide' ? 'tide' : 'solve')); finish();
      }
    };
    sound('touch'); if(e.id==='grave-cover-edge'){clothAndStone(ctx,e,act);return;} dialogue(ui, state, e.dialogue || [], act);
  }
  return { use, close };
}
