import {line,poly,oval,arc} from './paint.mjs';
import {glow} from './interior-furniture.mjs';
export function vigilWalls(c,p,s,t){
 // An oil-dark blue dado, a shelf of bobbins and a hanging cloth make the room legible from the doorway.
 const face=(x,y,u,v,h,z,col)=>poly(c,[p(x,y,z),p(u,v,z),p(u,v,h),p(x,y,h)],col);
 face(0,.09,16,.09,19,1,'#626c63');face(.07,0,.07,14,19,1,'#596763');
 line(c,...p(0,.1,19),...p(16,.1,19),'#d0b38d',1.7);line(c,...p(.1,0,19),...p(.1,14,19),'#c3a47d',1.6);
 const x=4.7,yy=.18;
 poly(c,[p(x,yy,28),p(x+2.8,yy,28),p(x+2.8,yy+.35,27),p(x,yy+.35,27)],'#836c51','#625440');
 for(let j=0;j<7;j++){const [xx,y]=p(x+.2+j*.39,yy+.12,29);
  oval(c,xx,y-3.7,3.1,2.2,j%3===0?'#8ca8a6':'#c6ab84');line(c,xx-1.7,y-1,xx+1.7,y-1,'#735f4b',.8);}
 for(const [a,len,col] of [[2.6,2.5,'#d9ccb2'],[5.55,1.8,'#96a6a1']]){
  const corners=[p(.11,a,52),p(.11,a+len,52),p(.11,a+len,25),p(.11,a+len*.7,29),p(.11,a+len*.42,22),p(.11,a,26)];
  poly(c,corners,col,'#9a927b');line(c,...p(.1,a-.09,54),...p(.1,a+len+.12,54),'#755e45',3);
  for(const d of [.22,.68])line(c,...p(.13,a+len*d,50),...p(.13,a+len*d,27),'#8a958940',1);
 }
 const [x1,y1]=p(12,.18,21);glow(c,x1,y1,55,'#e8ad6c46');
 for(let j=0;j<4;j++){const [a,b]=p(11.5+j*.56,.25,25);line(c,a,b,a,b+9+j%2*3,'#635c4b',1.5);oval(c,a,b+11,2.6,3.5,'#77745f');}
}
export function vigilFixtures(c,p,s,t,queue){
 const [x,y]=p(12.8,11.8);queue.push([24.3,()=>{
  // The bier occupies the southern solid alcove, with both handles clear for the bearers.
  const pl=(ax,ay,z=0)=>p(11+ax,11+ay,z);
  poly(c,[pl(.15,.35),pl(3.4,.35),pl(3.4,1.25),pl(.15,1.25)],'#6253438c');
  for(const k of [.32,2.72]){line(c,...pl(k,.4),...pl(k,.4,12),'#71563f',3);line(c,...pl(k,1.1),...pl(k,1.1,12),'#71563f',3);}
  poly(c,[pl(.12,.25,12),pl(3.05,.25,12),pl(3.05,1.24,12),pl(.12,1.24,12)],'#93795a','#685946');
  const lid=[pl(.36,.4,22),pl(2.58,.4,22),pl(2.86,.65,21),pl(2.82,.97,20),pl(2.57,1.04,20),pl(.37,1.04,20),pl(.24,.78,21)];
  poly(c,lid,'#d6c9a9','#9e8b6b');line(c,...pl(.5,.49,22),...pl(2.44,.49,22),'#eee1c1',1.4);line(c,...pl(1.72,.43,23),...pl(1.72,1.02,20),'#899992',2.8);
  for(const q of [.36,2.6]){const [xx,yy]=pl(q,1.28,10);arc(c,xx,yy,2.4,0,Math.PI,'#ad9266');}
 }]);
 queue.push([4+9,()=>{
  const [a,b]=p(2.35,10.3);line(c,a-16,b,a-16,b-25,'#765c45',3);line(c,a+15,b+5,a+15,b-20,'#765c45',3);
  for(let j=0;j<4;j++){line(c,a-19,b-22+j*4,a+17,b-17+j*4,j%2?'#8ba3a0':'#b19979',1.8);}
  oval(c,a-7,b+3,8,3.2,'#8b7354');oval(c,a-7,b+1,6.6,1.6,'#758c89');}
 ]);
}
