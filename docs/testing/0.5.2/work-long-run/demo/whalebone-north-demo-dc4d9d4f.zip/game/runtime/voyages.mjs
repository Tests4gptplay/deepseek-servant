import {decode,SAVE_KEY} from './state.mjs';
import {afterwatchKey,beginAfterwatch,storeAfterwatch,loadAfterwatch,firstVoyageCopy,saveAfterwatch} from '../content/cycle-journal.mjs';

export const shelfKey=SAVE_KEY+'.active-book';
export const nextBackup=afterwatchKey+'.bak';
function memory(raw) {
 let value=raw;
 return {getItem:()=>value,setItem:(_,text)=>{value=text;}};
}
function stamp(state){
 const {x,y,facing,map,...remaining}=state;
 const ordered=v=>Array.isArray(v)?v.map(ordered):v!==null&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,ordered(v[k])])):v;
 return JSON.stringify(ordered(remaining));
}
export function voyages(storage,world){
 const raw=()=>storage.getItem(afterwatchKey);
 const primary=()=>storage.getItem(SAVE_KEY);
 const same=(a,b)=>stamp(decode(world,a))===stamp(decode(world,b));
 function validate(text){
  const view=memory(text);let next;
  try{next=loadAfterwatch(view,world);}catch{throw Error('次航册无法解读。原件可在存档面板导出，或用完整次航备份恢复。');}
  if(!next)throw Error('次航册为空。');
  return {next,primary:JSON.parse(text).primary};
 }
 function activate(book){storage.setItem(shelfKey,book);}
 function commit(text,book,backup=false){
  const old=raw();
  if(backup&&old!==null)storage.setItem(nextBackup,old);
  storage.setItem(afterwatchKey,text);
  try{activate(book);}catch(error){
   if(old===null)storage.removeItem(afterwatchKey);else storage.setItem(afterwatchKey,old);
   throw error;
  }
 }
 function start(player){
  const live=JSON.stringify(player),first=primary();
  let input=live;
  if(first!==null){
   let old;
   try{old=decode(world,first);}catch{throw Error('本机首航原档需要恢复。请从存档面板先导出原档。');}
   if(old.cycle)throw Error('首航槽中出现次航文件，请先导出原档。');
   if(same(first,live))input=first;
  }
  beginAfterwatch(world,input);
  const previous=raw(),view=memory(previous);
  if(previous!==null&&!same(validate(previous).primary,input))throw Error('已有另一份首航的次册。可导出原件，或在存档面板选择续读原次航。');
  const next=storeAfterwatch(view,world,input);
  if(previous===null)commit(view.getItem(), 'afterwatch');else activate('afterwatch');
  return next;
 }
 function save(player){return saveAfterwatch(storage,world,player);}
 function portable(player){
  const view=memory(raw());saveAfterwatch(view,world,player);return view.getItem();
 }
 function bring(text,repair=false){
  const incoming=validate(text),old=raw(),first=primary();
  let previous;
  if(old!==null){
   try{previous=validate(old);}catch(e){if(!repair){e.code='DAMAGED_SECOND';throw e;}}
   if(previous&&!same(previous.primary,incoming.primary))throw Error('本机已有另一份首航的次册。请先分别保留两份导出。');
  }
  if(first!==null&&!same(first,incoming.primary)&&!previous)throw Error('导入次册的首航与本机首航不同。可在空白浏览器资料中读入。');
  commit(text,'afterwatch',old!==null);return incoming.next;
 }
 function second(){const next=loadAfterwatch(storage,world);if(!next)throw Error('还没有已封存的次航。');activate('afterwatch');return next;}
 function first(){
  const archived=firstVoyageCopy(storage,world);if(!archived)throw Error('次航册里没有封存首航。');
  const current=primary();
  if(current!==null){
   try{if(same(current,validate(raw()).primary)){const state=decode(world,current);activate('first');return state;}}catch{}
  }
  activate('archive');return archived;
 }
 function resume(){
  const book=storage.getItem(shelfKey);
  if(book==='afterwatch')return loadAfterwatch(storage,world);
  if(book==='archive')return firstVoyageCopy(storage,world);
  return null;
 }
 return {raw,primary,start,save,portable,bring,second,first,resume,activate,validate};
}
