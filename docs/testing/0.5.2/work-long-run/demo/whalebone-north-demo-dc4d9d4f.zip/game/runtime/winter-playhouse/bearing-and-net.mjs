import {patch,timber,face,poly,line,oval} from './joinery.mjs';
const brass='#c9ae70',oak='#70543c',tar='#394c4a';
function sightPost(c,p,x,y,flags,tall){
 const [a,b]=p(x,y);c.save();c.translate(a,b);
 const h=tall?111:62,r=tall?11:9;
 poly(c,[[-18,1],[-4,-10],[19,-2],[3,8]],'#8f7956',tar);
 for(const [dx,dy] of [[-15,1],[14,-2],[0,6]]){line(c,dx,dy,0,-h+20,oak,3);line(c,dx,dy,0,-h+22,'#c5a571',.8);}
 line(c,0,1,0,-h,tar,4);oval(c,0,-h,r,r,brass);oval(c,0,-h,r-3,r-3,'#55706c');line(c,-r,-h,r,-h,'#ead7a4',.9);line(c,0,-h-r,0,-h+r,'#ead7a4',.9);
 const right=flags['wren-black']?1:-1;
 poly(c,[[0,-h+12],[right*20,-h+14],[right*12,-h+21],[0,-h+19]],right>0?'#394546':'#ded9b8',oak);
 for(let z=12;z<h-22;z+=7)line(c,-2,-z,z%2?3:5,-z,brass,1);c.restore();
}
function cleat(c,p,x,y){
 const [a,b]=p(x,y);c.save();c.translate(a,b);
 poly(c,[[-14,1],[-3,-5],[14,-1],[3,4]],'#8d704d',oak);
 line(c,-10,-5,9,-13,tar,4);line(c,-5,-3,-5,-10,oak,3);line(c,5,-7,5,-15,oak,3);
 oval(c,-2,-10,8,2,'#ceb27d');c.restore();
}
function silver(c,x,y,t){
 c.save();c.translate(x,y+Math.sin(t*.9)*2);
 const grad=c.createLinearGradient(0,-10,0,9);grad.addColorStop(0,'#d7e6d7');grad.addColorStop(.34,'#8ac1b7');grad.addColorStop(.64,'#497f83');grad.addColorStop(1,'#648d88');
 c.beginPath();c.moveTo(-35,1);c.bezierCurveTo(-24,-10,2,-14,23,-5);c.quadraticCurveTo(29,-4,38,-13);c.lineTo(36,1);c.lineTo(42,10);c.quadraticCurveTo(29,5,23,5);c.bezierCurveTo(2,12,-21,9,-35,1);c.fillStyle=grad;c.fill();
 for(let i=0;i<6;i++)line(c,-16+i*5,-6,-12+i*5,-9+(i%3),'#d6e4d3',1);
 oval(c,-24,-1,1.5,1.5,tar);c.restore();
}
function net(c,p,x,y,w,d,s,t){
 const open=!!s.flags['trawl-clear'],lift=!!s.flags['trawl-sail-up'];const [ax,ay]=p(x+1,y+.4);const [bx,by]=p(x+w,y+d);
 const a=[ax,ay-36],b=[bx,by-(lift?55:34)],middle=(a[0]+b[0])*.5;
 const bag=open?9:26;poly(c,[a,b,[b[0]-5,b[1]+9],[middle,(a[1]+b[1])/2+bag],[a[0]+2,a[1]+9]],'#759a846e','#6b8277');
 for(let i=0;i<=16;i++){
  const u=i/16,px=a[0]+(b[0]-a[0])*u,py=a[1]+(b[1]-a[1])*u,depth=5+bag*Math.sin(Math.PI*u);
  line(c,px,py,px+4,py+depth,'#8da899',1);if(i<16)line(c,px+4,py+depth,px+(b[0]-a[0])/16,py+(b[1]-a[1])/16,'#809a88',.9);
  if(i%3===0)oval(c,px,py,3.4,2.5,i%2?'#b88a55':'#d8b679');
 }
 for(const [px,py] of [[ax,ay],[bx,by]]){line(c,px,py,px,py-65,oak,4);oval(c,px,py-66,3,3,brass);}
 if(lift)poly(c,[[bx,by-62],[bx-4,by-30],[bx-37,by-27]],'#a96853',oak);
 if(!open)silver(c,middle,(a[1]+b[1])*.5+14,t);else{
  for(let i=0;i<4;i++)line(c,middle+4+i*10,by+11+i%2,middle+11+i*10,by+10+i%2,'#bdcdb4',1.1);
 }
}
export function bearingFeature(c,p,map,f,s,t){
 if(map.id==='bow-parallax'&&f.kind==='wall'&&f.x===2){sightPost(c,p,5.9,7.65,s.flags,true);cleat(c,p,3.3,7.4);return true;}
 if(map.id==='bow-parallax'&&f.kind==='crate'&&f.x===22){sightPost(c,p,24,6.5,s.flags,false);return true;}
 if(map.id==='brine-spine'&&f.kind==='wall'&&f.x===2){net(c,p,2.5,5.5,4.4,2.05,s,t);return true;}
 if(map.id==='brine-spine'&&f.kind==='crate'&&f.x===13){net(c,p,13.2,3.4,4,3.35,s,t);return true;}
 return false;
}
export function bearingFloor(c,p,map){
 if(map.id!=='bow-parallax')return;
 for(let n=0;n<=22;n++){const x=4+n,y=9.6;timber(c,p,[x,y,1],[x,y+(n%5===0?.7:.35),1],'#cdbd8e',n%5===0?2:1);}
 timber(c,p,[3.6,9.55,1],[27,9.55,1],'#775e3f',1.55);
}
