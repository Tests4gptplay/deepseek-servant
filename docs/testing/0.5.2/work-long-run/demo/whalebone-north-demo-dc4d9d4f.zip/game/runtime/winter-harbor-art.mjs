import {poly,line,oval,arc} from './paint.mjs';
import {box,wood,bed,tub,parchment} from './voyage-shapes.mjs';
function sack(c,x,y,shade){
 poly(c,[[x-8,y],[x-11,y-7],[x-7,y-13],[x-3,y-16],[x+4,y-16],[x+8,y-11],[x+10,y-5],[x+7,y]],shade,'#796950');
 line(c,x-3,y-14,x+3,y-14,'#675e4a',1.3);line(c,x-6,y-9,x-8,y-4,'#d3bf95',1);
}
function barge(c,a,b,t,delivered){
 c.save();c.translate(a,b+Math.sin(t*.8)*1.1);
 oval(c,-1,7,108,15,'#385e666b');
 const hull=[[-116,-18],[-94,-7],[-69,-1],[59,7],[87,4],[113,-12],[98,7],[65,18],[-66,12],[-99,1]];
 poly(c,hull,'#77523e','#494e48');
 for(const k of [0,5,9]){c.beginPath();c.moveTo(-106,-10+k);c.bezierCurveTo(-53,8+k,54,18+k,101,0+k);c.strokeStyle=k?'#ad8662':'#c3a474';c.lineWidth=k?1.3:2;c.stroke();}
 poly(c,[[-116,-18],[-65,-33],[54,-28],[113,-12],[72,4],[-65,-3]],'#b29972','#5e584a');
 for(let i=0;i<11;i++)line(c,-79+i*15,-27+i*0.4,-85+i*15,-8+i*.6,'#8d765d',1.2);
 poly(c,[[-59,-19],[-39,-28],[36,-23],[57,-13],[36,-6],[-40,-10]],'#655847','#c3ab7c');
 for(const [j,h] of [[0,7],[1,3]])for(let i=0;i<h;i++)sack(c,-44+i*13+j*11,-13-j*8+i*.32,delivered&&i>3?'#b38965':'#c6ae80');
 poly(c,[[51,-26],[71,-31],[90,-25],[72,-17]],'#a9a28b','#615b4e');poly(c,[[51,-26],[72,-17],[73,-7],[51,-15]],'#8b775c');poly(c,[[72,-17],[90,-25],[89,-15],[73,-7]],'#706554');
 for(const k of [-65,39]){line(c,k,-11,k-2,-60,'#5a5143',3);line(c,k-2,-60,k+17,-70,'#8e795c',3);line(c,k+16,-68,k+16,-30,'#bbae85',1.3);arc(c,k+16,-28,3,0,Math.PI,'#574f42',1.4);}
 line(c,-89,-10,-124,3,'#d0ba90',2);line(c,71,-10,107,15,'#b9a478',2);
 poly(c,[[37,-57],[40,-60],[55,-57],[50,-52],[39,-53]],delivered?'#c8a569':'#8c6556');c.restore();
}
function pharmacy(c,p,x,y,paired){
 const [a,b]=p(x,y);box(c,p,x-.7,y-.38,1.4,.74,0,13,wood);
 poly(c,[[a-23,b-12],[a-23,b-47],[a+21,b-47],[a+21,b-12]],'#726453','#524c45');
 for(let row=0;row<3;row++){for(let i=0;i<5;i++){const xx=a-16+i*7,yy=b-20-row*9;
  c.fillStyle=['#a6b3a1','#c6ad82','#958f91'][(row+i)%3];c.fillRect(xx-2.3,yy-4,5,6);line(c,xx,yy-6,xx,yy-3,'#e0ceac',2);}
  line(c,a-23,b-17-row*9,a+21,b-17-row*9,'#a88865',2);}
 for(const k of [-1,1])poly(c,[[a+k*(paired?2:7),b-9],[a+k*(paired?9:14),b-12],[a+k*(paired?11:16),b-8],[a+k*(paired?4:9),b-6]],'#dcc586','#847358');
}
function linen(c,p,x,y,soft,t){
 const [a,b]=p(x,y);tub(c,a-14,b,13,'#8aa8a4');
 for(let i=0;i<3;i++)line(c,a+7+i*3,b-4,a+12+i*3,b-15,'#796e57',1.6);
 for(const xx of [-26,27])line(c,a+xx,b-4,a+xx,b-39,'#75654c',2.9);
 line(c,a-26,b-34,a+27,b-32,'#bda988',1.4);
 for(let i=0;i<3;i++){
  const xx=a-22+i*15,d=Math.sin(t*1.2+i)*1.8;
  poly(c,[[xx,b-34],[xx+12,b-33],[xx+13+d,b-15-i*1.5],[xx+d,b-17]],i===1&&soft?'#c19a83':['#b3bbb0','#939f97','#d6c7a5'][i],'#7e8679');
  line(c,xx+2+d,b-21,xx+10+d,b-19,soft?'#f2deab':'#aaa58c',1.3);}
}
function flue(c,a,b,open,t,side){
 c.save();c.translate(a,b);
 poly(c,[[-16,-2],[-16,-27],[12,-31],[19,-25],[17,-3]],'#796d5e','#535449');
 poly(c,[[-11,-27],[-9,-53],[5,-55],[8,-30]],'#93816b','#5a5b50');line(c,-12,-53,8,-55,'#bfab86',3);
 for(let j=0;j<4;j++)line(c,-9,-31-j*6,6,-33-j*6,'#b09b7c',1);
 line(c,-16,-16,18,-19,'#4b5149',3);line(c,-11,-19,8,open?-9:-28,'#cab083',3);oval(c,-11,-19,2.8,2.8,'#76664f');
 const flame=open?'#e7b06e':'#a8b98c';poly(c,[[-6,-3],[-7,-12],[-2,-9],[1,-17+Math.sin(t*3)*2],[5,-8],[4,-3]],flame);
 for(let i=0;i<5;i++){const q=(t*.31+i*.2)%1;c.save();c.globalAlpha=(1-q)*(open?.41:.24);oval(c,-1+side*q*20+Math.sin(q*8)*2,-57-q*29,3+q*6,2+q*5,open?'#c1c5ae':'#778783');c.restore();}c.restore();
}
function lowWindow(c,a,b,high,marked){
 c.save();c.translate(a,b);poly(c,[[-34,1],[-34,-39],[31,-45],[31,-5]],'#a28b72','#635e50');
 for(let row=0;row<4;row++){line(c,-34,-7-row*8,30,-13-row*8,'#857764',1.2);for(let i=0;i<5;i++){const x=-26+i*14+(row%2)*6;if(x<30)line(c,x,-7-row*8-(x+30)*.09,x,-15-row*8-(x+30)*.09,'#7e7363',1);}}
 poly(c,[[-19,-23],[-19,-34],[2,-36],[2,-25]],'#455757','#c1b18f');line(c,-8,-34,-8,-25,'#beae8d',1.7);
 const y=high?-18:-7;line(c,-32,y,28,y-6,'#8db9b8',2.2);
 if(marked)poly(c,[[5,-20],[17,-21],[17,-15],[5,-14]],'#ccaa77','#7a6956');c.restore();
}
export function winterHarborFeature(c,p,map,f,s,t){
 const id=map.id,x=f.x+(f.w||1)*.5,y=f.y+(f.h||1)*.55,[a,b]=p(x,y);
 if(id==='grain-tender'&&f.kind==='boat'){barge(c,a,b,t,!!s.flags['bond-signed']);return true;}
 if(id==='grain-tender'&&f.kind==='crate'){for(let i=0;i<6;i++)sack(c,a+(i%3)*14-15,b+Math.floor(i/3)*6,i%2?'#c4ae82':'#b8a27a');return true;}
 if(id==='wick-throat'&&(f.kind==='crate'||f.kind==='wall'&&f.x>0)){flue(c,a,b,f.x<12?!!s.flags['flue-east']:!!s.flags['flue-west'],t,f.x<12?-1:1);return true;}
 if(id==='fifth-brick'&&f.kind==='wall'){lowWindow(c,a,b,s.tide==='high',!!s.flags['brick-wet']);return true;}
 return false;
}
export function winterHarborItem(c,p,map,e,s,t){
 const x=e.x+.5,y=e.y+.5,[a,b]=p(x,y),f=s.flags;
 switch(e.id){
 case 'drug-box':pharmacy(c,p,x,y,!!f['token-traced']);return true;
 case 'stove-tag':flue(c,a,b,!!f['stove-heard'],t,-1);return true;
 case 'rice-holder':bed(c,p,x+.25,y+.45,true);return false;
 case 'first-hem':case 'brother-linen':linen(c,p,x+.4,y-.45,!!f['hem-tested'],t);return e.id==='brother-linen';
 case 'flue-loop':case 'flue-east':case 'flue-west':flue(c,a,b,!!f[e.id==='flue-loop'?'flue-back':e.id],t,e.id==='flue-west'?1:-1);return true;
 case 'wick-runner':case 'street-candle':{const hot=!!f['flue-east']||!!f['flue-west'];for(const k of [-1,1]){line(c,a+k*7,b-1,a+k*7,b-16,'#d9cb9a',3);oval(c,a+k*7,b-20+Math.sin(t*4+k)*1.2,2.2,4.8,hot||k<0?'#f3c07d':'#a5c698');}return true;}
 case 'loss-tally':case 'bran-terms':box(c,p,x+.12,y-.65,1.28,.65,3,9,wood);parchment(c,a+16,b-13,1,!!f['bond-signed']);sack(c,a+36,b-5,'#c5b28b');return e.id==='loss-tally';
 case 'brick-tide':case 'brick-wet':case 'brick-dry':lowWindow(c,a,b,s.tide==='high',!!f[e.action.id]);return true;
 default:return false;
 }
}
