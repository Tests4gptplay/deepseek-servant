import {arc,line,oval,poly} from './paint.mjs';
import {box,plate,wood,bed,parchment,wheel} from './voyage-shapes.mjs';
import {servingWindow,bakehouse,coalRack} from './harbor-crafts.mjs';
import {table,screen} from './social-furniture.mjs';

const stations={
 'watch-calendar':[[6.5,7.1,'desk'],[10,7.7,'calendar'],[15,8.7,'hookcoat']],
 'lamp-back':[[8.3,7.6,'oil'],[12.7,7.5,'paint'],[17.2,7.6,'step'],[19.3,9.5,'glass']],
 'ferrule-shed':[[6.2,6.3,'glass'],[8.7,7,'vice'],[15.15,8.38,'bells'],[14.12,9.12,'drawer'],[17.3,7.7,'bellrack']],
 'bell-quarter':[[8,7.5,'oven'],[13.1,8.5,'bellrack'],[17,8.4,'coat']],
 'next-bell':[[5.6,6.5,'calendar'],[8.8,6.9,'pair'],[12,7.2,'desk']]
};
const bark=['#a89b81','#857661','#685e55'];
function bell(c,a,b,size,blue=false){
 c.save();c.translate(a,b);c.scale(size,size);const brass=blue?'#97b8ae':'#c7a774';
 arc(c,0,-19,2.9,Math.PI,Math.PI*2,'#a18563',2);
 c.beginPath();c.moveTo(-8,2);c.bezierCurveTo(-8,-2,-5,-5,-5,-13);c.bezierCurveTo(-4,-23,5,-22,6,-13);c.bezierCurveTo(6,-5,7,-2,10,1);c.closePath();
 c.fillStyle=brass;c.fill();c.strokeStyle='#715f4e';c.stroke();oval(c,.7,2,9.6,2.2,'#726657');oval(c,1,3,2.3,3.1,'#b39063');c.restore();
}
function paint(c,p,x,y,k,s,t){
 const f=s.flags,[a,b]=p(x,y);
 switch(k){
 case 'desk':table(c,p,x-.82,y-.3,'paper');break;
 case 'calendar':{
  box(c,p,x-.62,y-.17,1.27,.35,0,23,bark);
  for(let i=0;i<2;i++){let u=p(x-.37+i*.53,y+.19,23);
   poly(c,[[u[0]-7,u[1]-2],[u[0]+5,u[1]+1],[u[0]+5,u[1]+14],[u[0]-7,u[1]+11]],i?'#d8ccaa':'#b99f80','#746b56');
   for(let j=0;j<3;j++)line(c,u[0]-4,u[1]+3+j*2.4,u[0]+2,u[1]+5+j*2.4,'#847c66',.9);
  }break;}
 case 'hookcoat':case 'coat':{for(const d of [-.6,.6])line(c,...p(x+d,y),...p(x+d,y,31),'#78634e',3);
  line(c,...p(x-.7,y,29),...p(x+.75,y,29),'#a18b68',3);poly(c,[[a-11,b-21],[a-3,b-28],[a+9,b-22],[a+14,b-12],[a+8,b-9],[a+6,b-11],[a+5,b-1],[a-7,b-4],[a-8,b-15],[a-13,b-10],[a-17,b-14]],'#74958a','#526c62');if(f['watch-signal'])line(c,a-7,b-13,a+4,b-10,'#c99e6d',2);break;}
 case 'oil':box(c,p,x-.45,y-.3,1,.6,0,12,wood);for(let i=0;i<3;i++){const u=p(x-.2+i*.23,y,15);oval(c,...u,4,5,'#82998c');}break;
 case 'paint':servingWindow(c,p,x-.75,y,1.8,true);{const u=p(x,y,25);arc(c,...u,8,f['watch-inside']?1.4:3.3,f['watch-inside']?5:5.5,'#88b4bd',3);arc(c,u[0]-4,u[1]-3,9,3.4,6.1,'#ab6251',3);}break;
 case 'step':for(let j=0;j<3;j++)box(c,p,x-.45,y+.46-j*.21,.92,.24,0,4+j*4,wood);break;
 case 'glass':case 'vice':{
  box(c,p,x-.78,y-.39,1.58,.82,0,13,wood);
  if(k==='glass'){for(let i=0;i<4;i++){const u=p(x-.4+i*.30,y,15);poly(c,[[u[0]-5,u[1]-1],[u[0]+1,u[1]-7-i%2*3],[u[0]+5,u[1]-3],[u[0]+4,u[1]+1]],'#8eb5ad','#647e7a');}}
  else{box(c,p,x-.22,y-.10,.5,.36,13,6,['#959e91','#6c7d74','#526660']);line(c,...p(x-.56,y+.2,17),...p(x+.59,y+.2,17),'#b5aa8d',2.4);}break;}
 case 'bells':case 'pair':case 'bellrack':{const zz=k==='pair'?35:28;
  for(const dx of [-.78,.85])line(c,...p(x+dx,y),...p(x+dx,y,zz+5),'#715e4b',3.5);
  line(c,...p(x-.83,y,zz+3),...p(x+.87,y,zz+3),'#ad9671',4);
  for(let j=0;j<2;j++){const u=p(x-.42+j*.88,y,zz);const drop=f['watch-bells']?j*6:2;
   line(c,...u,u[0],u[1]+5+drop,'#948668',1.5);bell(c,u[0],u[1]+17+drop,j?.65:.91,j===1);}break;}
 case 'drawer':box(c,p,x-.79,y-.39,1.6,.85,0,17,bark);for(let k=0;k<3;k++){const u=p(x-.58+k*.5,y+.47,13);line(c,u[0]-5,u[1],u[0]+5,u[1]+3,'#c9a37c',2.1);}if(f['watch-bells']){let u=p(x+.36,y+.66,12);bell(c,...u,.51);}break;
 case 'oven':bakehouse(c,p,x,y,true,t);break;
 }
}
export function nightPlaces(c,p,m,s,t,ordered){for(const [x,y,k]of stations[m.id]||[])ordered.push([x+y+.55,()=>paint(c,p,x,y,k,s,t)]);}
export function nightFeature(c,p,m,f,s,t){
 if(!stations[m.id])return false;const x=f.x+(f.w||1)*.52,y=f.y+(f.h||1)*.68;
 if(m.id==='ferrule-shed'&&f.kind==='building'){for(let j=0;j<3;j++)paint(c,p,x-1.5+j*1.3,y,j===1?'bellrack':'drawer',s,t);return true;}
 if(m.id==='watch-calendar'&&f.kind==='building'){bed(c,p,x-.9,y-.55);screen(c,p,x-.7,y-.9,2.1,'#8d9988');return true;}
 if(f.kind==='crate'){paint(c,p,x,y,{ 'watch-calendar':'hookcoat','lamp-back':'glass','ferrule-shed':'vice','bell-quarter':'coat','next-bell':'drawer'}[m.id],s,t);return true;}
 return false;
}
