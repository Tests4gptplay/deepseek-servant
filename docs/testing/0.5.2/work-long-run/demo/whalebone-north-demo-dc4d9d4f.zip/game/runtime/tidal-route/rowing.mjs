import {poly,line,oval,arc} from '../paint.mjs';
import {footing} from './charts.mjs';
const edge='#354a49',rope='#d9c493';
function shell(c,length,width,colors){
 const [body,rail,deck]=colors,L=length,W=width;
 oval(c,2,2,L*.91,W*1.19,'#345c6270');
 const rim=[[-L,0],[-L*.63,-W*.77],[-L*.18,-W],[L*.55,-W*.69],[L+.8,-W*.12],[L*.6,W*.82],[-L*.22,W],[-L*.74,W*.67]];
 poly(c,rim.map(([x,y])=>[x,y+3.9]),body,edge);poly(c,rim,rail,edge);
 poly(c,rim.map(([x,y])=>[x*.86,y*.71]),deck,'#5a5847');
 for(let j=-2;j<=2;j++){const x=j*L*.235;line(c,x,-W*.64,x,W*.65,'#71654f',1.1);line(c,x+1.5,-W*.54,x+1.5,W*.57,'#d2b584',.85);}
 for(const x of [-.40,.18]){poly(c,[[x*L-2,-W*.77],[x*L+2,-W*.79],[x*L+2,W*.78],[x*L-2,W*.79]],'#bd9a6a','#625a45');}
 line(c,-L*.73,W*.6,-L*.18,W*.95,rope,.8);line(c,L*.76,-W*.4,L*.94,-W*.2,'#e7cc9a',1.1);
}
function sitter(c,x,y,kind,flip=false,stroke=0){
 c.save();c.translate(x,y);const size=kind==='child'?.73:kind==='elder'?.92:1;c.scale((flip?-1:1)*size,size);
 const main=kind==='mara'||kind==='yuanzi',coat=kind==='mara'?'#28505a':kind==='yuanzi'?'#8d604f':kind==='child'?'#ab7b4e':'#577d77';
 line(c,-2,-6,6,-3,'#484c47',3);line(c,6,-3,10,-4,'#443e36',1.8);
 poly(c,[[-7,-7],[-6,-17],[-2,-20],[3,-18],[4,-10],[8,-7],[5,-4],[-2,-5]],coat,edge);
 if(kind==='elder')poly(c,[[-8,-18],[-3,-23],[3,-20],[6,-13],[3,-8],[-2,-13],[-7,-12]],'#b6b6a0','#637b74');
 if(kind==='child')poly(c,[[-7,-18],[-4,-21],[4,-18],[6,-14],[2,-13],[-4,-16]],'#ccb576');
 if(main)poly(c,[[-7,-17],[-3,-20],[3,-18],[1,-15],[-5,-14]],'#c4c6ae','#758583');
 oval(c,0,-22.5,3.8,4.3,'#d2ab88');poly(c,[[-4,-23],[-3,-27],[1,-28],[4,-26],[4.6,-23],[1,-24],[-2,-22]],'#5b4538');
 if(kind==='yuanzi')poly(c,[[-5,-25],[-4,-28],[2,-29],[5,-25],[3,-25]],'#b67949');
 if(kind==='mara'){line(c,-4,-22,-6,-16,'#5a4337',2.3);line(c,1,-15,-5,-8,'#c4a575',1);}
 line(c,1,-16,5+stroke*2,-11,coat,2.7);line(c,5+stroke*2,-11,9+stroke*3,-10-stroke*2,'#d1ac88',1.8);c.restore();
}
function sacks(c){
 for(const [x,y] of [[11,-3.4],[19,-3.2],[13,2.6],[22,2.1]]){oval(c,x,y,5.2,3.4,'#dfbd81');line(c,x-2,y-3.5,x+1.4,y-3.4,'#806951',1.2);line(c,x-1.6,y-2.4,x-.6,y+1.8,'#a57049',1.2);}
 line(c,10,-5.4,24,4.2,'#be8050',1.4);
}
export function paintWaterVoyager(c,x,y,m,s,state,t,viewport){
 if(footing(m,s.x,s.y)!=='rowing')return false;
 const travel=state.waterPassage?.owner===s&&state.waterPassage.map===m.id?state.waterPassage:null,dx=travel?.dx??s.facing[0],dy=travel?.dy??s.facing[1];
 const heading=Math.atan2((dx+dy)*14,(dx-dy)*31),scale=viewport<620?1:1.06;
 const age=travel&&t?performance.now()-travel.at:99999,stroke=age>=0&&age<520?Math.sin(age/520*Math.PI):0;
 const ebb=t?Math.sin(t*.91)*.65:0;
 c.save();c.translate(x,y+ebb);c.scale(scale,scale);
 c.save();c.rotate(heading);
 if(stroke>0){for(let i=0;i<3;i++){const u=-25-i*5;line(c,u,2+i*1.8,u-6-i,6+i*2.1,'#d9e5c8',1.3);line(c,u,-3-i*1.8,u-7,-7-i*2,'#b7d6c9',1.2);}}
 shell(c,36.5,10.5,m.id==='keel-in-shadow'?['#384d48','#ab744c','#ceae75']:['#4b403c','#a75340','#c9a36f']);
 if(m.id==='keel-in-shadow'&&s.flags['return-ration']&&!s.flags['return-home'])sacks(c);
 const o=-8+stroke*15;line(c,-3,-1,o+13,-26,'#69573e',2.3);line(c,o+9,-19,o+15,-28,'#edc98b',4.2);
 line(c,-3,1,-o-12,24,'#786343',2.3);line(c,-o-9,18,-o-14,26,'#e0ba78',4);
 if(stroke>.25)arc(c,o+11,-20,3+stroke*3,.2,2.9,'#daecd5',1.1);
 c.restore();
 const seats=[[-6,-1,s.cycle?.id==='afterwatch'?'yuanzi':'mara']];
 if(m.id==='keel-in-shadow'&&s.flags['return-riders']&&!s.flags['return-home'])seats.push([12,-1,'elder'],[23,2,'child']);
 if(m.id==='hulls-not-in-line'&&s.flags['common-charter-spent'])seats.push([14,2,'elder']);
 const cos=Math.cos(heading),sin=Math.sin(heading),depth=seats.map(([u,v,k])=>[u*cos-v*sin,u*sin+v*cos,k]);
 for(const [u,v,k] of depth.sort((a,b)=>a[1]-b[1]))sitter(c,u,v-1,k,k==='child'?dx-dy>=0:dx-dy<0,k==='mara'||k==='yuanzi'?stroke:0);
 poly(c,[[-2,-34],[1,-38],[4,-34],[1,-30]],'#f1ce8d','#776849');c.restore();return true;
}
export function tiedBoat(c,p,cx,cy,w,h,colors){
 const [x,y]=p(cx,cy);c.save();c.translate(x,y);c.rotate(.37);shell(c,w,h,colors);c.restore();
}
