import {poly,line,oval,rand} from './paint.mjs';
import {wildCoast} from './coastal-ground.mjs';

function edgeProfile(m,x,y,nx,ny,i,side){
 const phase=m.width*.17+m.height*.08+side*1.35;
 const ridge=.18+.09*Math.sin(i*.78+phase);
 const face=.34+.5*(1+Math.sin(i*.47+phase))+.23*(1+Math.sin(i*1.33+side));
 const foot=face+.35+.27*rand(i*4,side+37),drop=11+Math.round(5*Math.sin(i*.32+side)+5*rand(i*4,side));
 const spread=d=>[x+nx*d,y+ny*d];
 return {lip:spread(-.035),ridge:spread(ridge),face:spread(face),foot:spread(foot),drop};
}
function section(c,p,a,b,facing,seed,t){
 const v=(d,k,z=0)=>p(...d[k],z);
 poly(c,[v(a,'foot',-a.drop),v(b,'foot',-b.drop),v(b,'face',4-b.drop),v(a,'face',4-a.drop)],'#638882');
 poly(c,[v(a,'ridge',1),v(b,'ridge',1),v(b,'face',4-b.drop),v(a,'face',4-a.drop)],facing?'#65766e':'#718076');
 poly(c,[v(a,'lip',.1),v(b,'lip',.1),v(b,'ridge',1),v(a,'ridge',1)],'#8c9884');
 const rock=[(a.face[0]+b.face[0])*.5,(a.face[1]+b.face[1])*.5,5-(a.drop+b.drop)*.5];
 if(rand(seed,7)>.74)poly(c,[v(a,'ridge',-.2),p(...rock),v(a,'face',4-a.drop)],facing?'#6c7c72':'#788579');
 if(rand(seed,13)>.62){const A=v(a,'face',6-a.drop*.7),B=v(b,'face',5-b.drop*.72);line(c,A[0],A[1],A[0]+(B[0]-A[0])*.64,A[1]+(B[1]-A[1])*.64,'#839185',.8);}
 if(rand(seed,48)>.68){const P=v(a,'ridge',1);for(let j=0;j<3;j++)line(c,P[0]-2+j*1.7,P[1],P[0]-4+j*1.6,P[1]-2-rand(seed,j)*4,'#849173',1.0);}
 if(Math.floor(seed)%4!==0){line(c,...v(a,'foot',-a.drop+.8+Math.sin(t+seed)*.5),...p((a.foot[0]+b.foot[0])*.5,(a.foot[1]+b.foot[1])*.5,-(a.drop+b.drop)*.5),'#b6c8b2',1.1);}
 if(seed%3===0){const pos=p(...a.face,3-a.drop);oval(c,pos[0]+5,pos[1]+3,4+.15*a.drop,1.6,'#607c77');}
}
export function coastCliffs(c,p,m,t,colors,visible){
 if(!wildCoast(m.id))return;
 const w=m.width,h=m.height;
 const sides=[{n:w,x:i=>i,y:()=>h,dx:0,dy:1,inside:i=>[i,h-1]},
  {n:h,x:()=>w,y:i=>i,dx:1,dy:0,inside:i=>[w-1,i]},
  {n:h,x:()=>0,y:i=>i,dx:-1,dy:0,inside:i=>[0,i]}];
 for(const [side,d] of sides.entries()){
  let prev;
  for(let k=0;k<=d.n*2;k++){
   const i=k*.5,here=edgeProfile(m,d.x(i),d.y(i),d.dx,d.dy,i,side);
   if(prev){const q=d.inside(Math.min(d.n-1,Math.floor(i-.01)));if(colors[q[1]][q[0]]!=='water'&&visible(...p(...here.lip),140))section(c,p,prev,here,side!==0,k+side*4,t);}
   prev=here;
  }
 }
}
