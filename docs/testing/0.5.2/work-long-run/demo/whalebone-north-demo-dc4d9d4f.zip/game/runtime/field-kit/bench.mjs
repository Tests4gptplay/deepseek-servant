import {selected,terms} from '../../rules/vocations.mjs';
import {stats} from '../party.mjs';
import {equip,consume} from '../gear.mjs';
import {loadoutRatings} from './ratings.mjs';
import {layItemOnCloth} from './work-cloth.mjs';
const compartments={weapon:'手中器具',armor:'护身衣具',charm:'随身护物',consumable:'药包'};
const labels={attack:'攻击',defense:'护甲',pierce:'破甲'};
function origin(world,id,item){
 if(item.context)return item.context;
 for(const map of Object.values(world.maps))for(const e of map.entities){
  if(e.action?.type==='item'&&e.action.id===id)return map.name+' · '+e.name;
 }
 return '';
}
function reading(defs,hero,base,career,id){
 const item=defs[id];
 if(item.slot==='consumable')return ['体力　'+hero.hp+' → '+Math.min(base.hp,hero.hp+(item.heal||0))+' / '+base.hp,'气力　'+hero.mp+' → '+Math.min(base.mp,hero.mp+(item.restore||0))+' / '+base.mp];
 const before=loadoutRatings(defs,hero,base,career),after=loadoutRatings(defs,{...hero,[item.slot]:id},base,career);
 const fields=item.slot==='weapon'?['attack','pierce']:item.slot==='armor'?['defense']:[];
 const rows=fields.map(key=>labels[key]+'　'+before[key]+' → '+after[key]);
 if(item.slot==='charm')for(const key of Object.keys(terms)){
  const a=Math.round((before.resists[key]||0)*100),b=Math.round((after.resists[key]||0)*100);
  if(a||b)rows.push(terms[key]+'防护　'+a+'% → '+b+'%');
 }
 return rows;
}
export function kitTable(ctx,id,defs,back){
 const {ui,world,state,sound}=ctx,s=state.player,who=world.actors[id].name;
 const current=()=>s.expedition.heroes[id],stock=()=>s.expedition.stock;
 const owned=slot=>Object.keys(defs).filter(k=>defs[k].slot===slot&&(!defs[k].owner||defs[k].owner===id)&&(stock()[k]>0||current()[slot]===k));
 function chooseSlot(){
  const available=Object.keys(compartments).filter(k=>owned(k).length);
  ui.show('kit-list',who+'的整备布','从包里取一件，与正穿戴的放在一起。',[
   ...available.map(slot=>[compartments[slot],()=>unroll(slot)]),['卷起整备布',back]]);
 }
 function unroll(slot){
  const gear=owned(slot),h=current();
  ui.show('kit-list',compartments[slot],slot==='consumable'?'每份药都封在纸套里。取出来可以先看用量。':'已穿戴　'+(defs[h[slot]]?.name||'空'),[
    ...gear.map(k=>[defs[k].name,()=>inspect(k)]),['换一个布袋',chooseSlot]]);
 }
 function inspect(key){
  const h=current(),item=defs[key],slot=item.slot,base=stats(world,id,h.level),on=h[slot]===key,medicine=slot==='consumable',qty=stock()[key]||0;
  const rows=reading(defs,h,base,selected(s,id),key),from=origin(world,key,item),action=[];
  const fits=medicine?(h.hp<base.hp&&(item.heal||0)>0||h.mp<base.mp&&(item.restore||0)>0):!on;
  const use=medicine?'打开一份服用':'换上这件';
  if(qty>0&&fits)action.push([use,()=>{
   const applied=medicine?consume(world,s,id,key,stats(world,id,current().level)):equip(world,s,id,key);
   if(applied)sound(medicine?'solve':'touch');
   inspect(key);
  }]);
  const left=medicine?'包里还有 '+qty+' 份':on?'正在穿戴':'正用　'+(defs[h[slot]]?.name||'空');
  ui.show('kit-detail',item.name,rows.join('\n'),[...action,['放回布袋',()=>unroll(slot)],['卷起整备布',back]],from||'');
  layItemOnCloth(ui.panel,key,item,{owner:who,slot:compartments[slot],left});
 }
 chooseSlot();
}
