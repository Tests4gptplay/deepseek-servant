import {poly,line,oval,arc} from './paint.mjs';
import {plate,box} from './voyage-shapes.mjs';
import {figure} from './figures.mjs';
import {add,board,cottage,coop,dryingRack,flare,lantern,net,quayEdge,steps,stroke,surface,timber} from './household-art.mjs';

const places=new Set(['chair-eye','sheared-lintel','hinge-landing','eave-shoulder','skirt-cut','pale-sump','slant-cobbles','low-hinge','stool-mender']);
export const tiltedPlace=id=>places.has(id);
function dog(c,x,y,t,up){
 c.save();c.translate(x,y);const sway=Math.sin(t*3)*1.4;
 const hind='#ac773e',gold='#dbac5f',light='#f2cc81',edge='#624f36';
 poly(c,[[-11,-9],[-21,-14+sway],[-24,-23+sway],[-19,-20+sway],[-15,-15],[-8,-13]],gold,edge);
 poly(c,[[-12,-13],[-3,-15],[5,-14],[10,-20],[14,-17],[10,-10],[2,-5],[-10,-6],[-15,-8]],gold,edge);
 poly(c,[[6,-17],[8,-23],[12,-29],[14,-22],[19,-22],[23,-20],[26,-18],[19,-15],[11,-14]],light,edge);
 poly(c,[[8,-23],[11,-29],[12,-22]],hind);oval(c,24,-18.5,2,1.5,edge);oval(c,17,-21.6,1.35,1.25,'#292b27');
 for(const [dx,dy] of [[-10,1],[-6,-1]]){line(c,dx,-7,dx-2,dy,hind,3);line(c,dx-2,dy,dx+1,dy,light,2.4);}
 for(const [dx,dy] of [[4,0],[7,-2]]){const ex=up?dx+11:dx-1,ey=up?-16+dy:dy;line(c,dx,-10,ex,ey,gold,3.4);line(c,ex,ey,ex+3,ey+.5,light,2.5);}
 line(c,8,-16,13,-14,'#52726e',2);c.restore();
}
function foldingChair(c,x,y,fold){
 const rim='#614a3a',seat='#ca9461',step=fold*11;c.save();c.translate(x,y);
 oval(c,0,2,23,5,'#344d4c77');
 for(const dx of [-10,9]){line(c,dx-2,-1,dx+7-step*.5,-18,rim,3);line(c,dx+8,1,dx-4+step*.45,-23,rim,3);}
 poly(c,[[-16,-23],[7,-18],[17,-23-step],[0,-27-step]],seat,rim);
 line(c,-12,-22,-16+step*.7,-41,rim,3.4);line(c,12,-20,8+step*.7,-39,rim,3.4);
 poly(c,[[-17+step*.7,-45],[8+step*.7,-41],[10+step*.7,-34],[-16+step*.7,-37]],'#b98055',rim);
 for(let i=0;i<3;i++){const a=-9+i*8+step*.7,b=-40+i*1.3;oval(c,a,b,2.9,2.6,i===2?'#453f35':'#edce8a');if(i<2)oval(c,a-.6,b-.7,1.1,.8,'#fff0b1');else arc(c,a,b,2.65,0,Math.PI*1.55,'#947657',.95);}
 c.restore();
}
function resident(c,p,s,t,progress,called){
 const x=18.65+progress*6.45,y=10.18+progress*1.08,[a,b]=p(x,y,4*(1-progress));
 const pace=progress>0&&progress<1?progress*49:0;figure(c,a,b,'chendi',t,{scale:1.28,stride:pace,flip:progress>.85});
 poly(c,[[a-6,b-39],[a-1,b-44],[a+5,b-41],[a+6,b-38],[a+2,b-40],[a-5,b-37]],'#a77565','#705c52');
 poly(c,[[a-6,b-27],[a+5,b-26],[a+7,b-14],[a-2,b-11]],'#b9aa88','#766e5a');
 const reach=Math.min(1,called*1.7),leap=Math.sin(Math.PI*reach)*14;
 dog(c,a-56+reach*33,b+3-reach*15-leap,t,reach>.41);
 if(reach>.5){line(c,a-7,b-28,a+1,b-18,'#90805e',1);line(c,a+1,b-18,a+7,b-20,'#b3a079',1);}
}
function canopy(c,p,x,y,w,removed){
 const reach=1.52*(1-removed)+.12;
 for(const k of [0,w])stroke(c,p,[x+k,y],[x+k,y,43],'#76634e',3);
 for(let i=0;i<6;i++){const x0=x+i*w/6,x1=x+(i+1)*w/6;
 poly(c,[p(x0,y,45),p(x1,y,45),p(x1,y+reach,34+removed*7),p(x0,y+reach,34+removed*7)],i%2?'#9ca99c':'#688d8b','#536f6c');}
 stroke(c,p,[x,y+reach,34+removed*7],[x+w,y+reach,34+removed*7],'#dbc59a',2);
}
export function streetGround(c,p,map,s,t){
 const id=map.id;surface(c,p,1,5,map.width-2,map.height-6,false,t);
 if(id==='chair-eye'||id==='sheared-lintel'||id==='pale-sump'){
  surface(c,p,2,7,map.width-4,2.62,true,t);surface(c,p,1.1,12.9,map.width-2.2,4.9,true,t);
  for(const x of [3,10.2,18.5,26.2]){board(c,p,x,11.8,3.2,.68,.4,true);steps(c,p,x+1.2,12.44,3,.5);}
 }else{
  surface(c,p,1,15,map.width-2,4.2,true,t);board(c,p,2,10.4,map.width-4,1.3,0,true);
 }
 for(let i=0;i<5;i++){const y=13.1+i*.47;stroke(c,p,[5,y],[9.2+i*.83,y],'#82958c',1.1);}
}
function rescueRoom(c,p,s,t,q,blend){
 const away=blend('chair-free'),called=blend('chair-sent');
 add(q,16,9.4,()=>cottage(c,p,15.9,7.1,4.4,2.7,{lit:true,open:true,h:54,roof:'#5b737b',door:.19,window:.65}));
 add(q,18.4,9.9,()=>{const x=18.28,y=9.84;
  poly(c,[p(x,y,8),p(x+1.1,y,8),p(x+1.1,y,45),p(x,y,45)],'#304e53','#443f39');
  stroke(c,p,[x-.08,y,46],[x+1.18,y,46],'#d2b18c',3);stroke(c,p,[x-.09,y,8],[x+1.19,y,8],'#d7be95',4);
  poly(c,[p(x-.01,y,44),p(x-.39,y+.08,44),p(x-.39,y+.08,12),p(x-.01,y,12)],'#83988b','#665f51');
  for(let i=0;i<4;i++)stroke(c,p,[x-.36,y+.08,14+i*7],[x-.05,y,14+i*7],'#53675f',1.4);
  stroke(c,p,[16.6,9.88,4],[20.25,9.88,4],'#91aaa1',2);
 });
 add(q,18.22,10.48,()=>foldingChair(c,...p(18.22,10.48,1),called));
 add(q,18.65+away*6.45,10.18+away*1.08,()=>resident(c,p,s,t,away,called));
 add(q,20.4,10.35,()=>lantern(c,...p(20.4,10.35),41,true,t));
 add(q,23.1,9.3,()=>{steps(c,p,23.1,9.3,6,1.6);board(c,p,24.85,9.28,2.2,1.75,13);});
}
function threshold(c,p,s,t,q,blend,id){
 const opened=blend('slope-port-open'),d=s.flags['city-door-spent']?opened:0,a=s.flags['city-awning-spent']?opened:0;
 const market=id==='stool-mender',doorX=market?14.4:18.2,awningX=market?19.8:25.7;
 for(const [x,shade] of [[doorX-2,'#7a7d73'],[awningX-2,'#59777a']])add(q,x,9.4,()=>cottage(c,p,x,7.05,4.2,2.4,{h:43,roof:shade,wall:'#b7a181',open:x<doorX&&d>.45,lit:true}));
 add(q,doorX,10.4,()=>{
  const x=doorX,y=10.1,w=1.14;for(const k of [0,w])stroke(c,p,[x+k,y],[x+k,y,39],'#755b47',4);
  stroke(c,p,[x-.09,y,40],[x+w+.09,y,40],'#d7b78b',4);
  if(d<.98){const top=36*(1-d);poly(c,[p(x+.03,y,1),p(x+w-.03,y,1),p(x+w-.03,y+d*1.4,top+1),p(x+.03,y+d*1.4,top+1)],'#b68e63','#6c5947');
   for(const k of [.23,.49,.77])stroke(c,p,[x+k,y,2],[x+k,y+d*1.4,top],'#8d6c50',1.2);}
  if(d>.02){board(c,p,x,y+.15,w,1.6*d,.5);stroke(c,p,[x,y+.6],[x+w,y+.6],'#978266',2);}
  lantern(c,...p(x+1.33,y),33,true,t);
 });
 add(q,awningX,10.7,()=>{canopy(c,p,awningX-.8,9.45,2.05,a);if(a>.03){
  poly(c,[p(awningX-.65,10.3),p(awningX+.94,10.3),p(awningX+.94,10.3+2.5*a),p(awningX-.65,10.3+2.5*a)],'#87a196','#c6bc91');
  for(let i=0;i<3;i++)stroke(c,p,[awningX-.47+i*.49,10.35],[awningX-.47+i*.49,10.3+2.46*a],'#597f7d',2);
 }});
 if(!market)add(q,10.25,10.02,()=>{
 const x=8.9,y=9.85,w=.89;
 for(const k of [0,w])stroke(c,p,[x+k,y],[x+k,y,36],'#675342',3.4);
 stroke(c,p,[x-.06,y,37],[x+w+.06,y,37],'#cfad80',3);
 if(d<.9){poly(c,[p(x+.06,y,1),p(x+w-.06,y,1),p(x+w-.06,y,33*(1-d)),p(x+.06,y,33*(1-d))],'#b88b5e','#715d47');
  for(const z of [8,26])stroke(c,p,[x+.08,y,z*(1-d)],[x+.52,y,z*(1-d)],'#777668',1.6);}
 if(d>.05)board(c,p,x,y+.06,w,1.67*d,1);
 canopy(c,p,10.85,9.23,1.23,a);if(a>.1)board(c,p,10.94,10.04,1.03,1.12*a,.45,true);
});
 if(!market)add(q,9.2,9.5,()=>{cottage(c,p,8.2,7.3,3.5,2.1,{h:34,roof:'#749190',open:true});canopy(c,p,11.15,9.2,1.1,a);lantern(c,...p(11.75,10),25,true,t);});
}
function livedInQuay(c,p,m,s,t,q){
 const id=m.id;
 if(id==='chair-eye'){
  for(const [x,y,w,roof]of [[8.5,5.7,3.2,'#788d80'],[12.2,4.5,4.4,'#766c66'],[21.1,4.7,3.8,'#70888a'],[26.8,6.7,4.25,'#7b7364']])
   add(q,x,y+1.9,()=>cottage(c,p,x,y,w,1.9,{roof,h:34+x%9,lit:x<20,open:x>20}));
  add(q,15.8,10.25,()=>{coop(c,p,15.8,10.25);coop(c,p,15.55,10.42);dryingRack(c,p,14.2,9.85,1.14);});
  add(q,20.55,9.77,()=>{dryingRack(c,p,20.55,9.77,1.28,false);});
  surface(c,p,17.65,9.61,2.46,.72,true,t);
  for(let j=0;j<3;j++){const a=p(18.85+j*.33,10.14);line(c,a[0]-5,a[1]+1,a[0]+6,a[1]+1,'#c6c0a0',1.1);}
 }else if(id==='sheared-lintel'||id==='stool-mender'){
  add(q,20.2,9.8,()=>{coop(c,p,20.2,9.8);dryingRack(c,p,21.15,9.2,1.15,true);});
  add(q,24,7.15,()=>cottage(c,p,23.2,4.75,3.1,2.3,{h:38,lit:false,roof:'#72796d'}));
 }else{
  add(q,12,9.65,()=>dryingRack(c,p,12,9.65,1.5,false));add(q,24,10.1,()=>coop(c,p,24,10.1));
 }
 for(const [x,y,len]of [[4.5,12.9,6.8],[14.45,12.9,5.65],[23.8,12.9,5.0]]){
  quayEdge(c,p,x,y,len);
  for(let k=0;k<len;k+=1.15){const a=p(x+k,y+.32,-4);line(c,a[0]-3,a[1]+1,a[0]+6,a[1]+1,'#93a5a0',.85);}
 }
}

export function streetObjects(c,p,map,s,t,q,blend){
 livedInQuay(c,p,map,s,t,q);
 const id=map.id;
 if(id==='chair-eye')rescueRoom(c,p,s,t,q,blend);
 else if(id==='sheared-lintel'||id==='stool-mender')threshold(c,p,s,t,q,blend,id);
 else if(id==='hinge-landing'||id==='eave-shoulder'||id==='skirt-cut'){
  const high=id==='eave-shoulder',low=id==='skirt-cut',ready=blend(high?'eave-first':low?'skirt-first':'slant-placed');
  const x=high?15:low?17:21;add(q,x-4,8.9,()=>cottage(c,p,x-4,6.55,4.7,2.4,{roof:high?'#6b7066':'#567c81',open:true}));
  add(q,x-1,11.4,()=>{if(high){steps(c,p,x-3,9.6,10,2.35);board(c,p,x+.01,9.59,4.5,2.35,24);canopy(c,p,x+2,8.4,2,0);}
   else if(low){surface(c,p,x-3,9,7,3,true,t);board(c,p,x-2,10.8,4,.94,2,true);net(c,p,x-.8,9.5,2.55,ready);
    const [a,b]=p(x+.7,10.9);arc(c,a,b-3,12,Math.PI*.10,Math.PI*1.94,'#d2b98a',2.7);}
   else{steps(c,p,x-1,10,6,1.6);board(c,p,x+.8,10,3.7,1.6,15);surface(c,p,x-4,12,8,2.7,true,t);}
  });
  for(let i=0;i<3;i++){const xx=x+i*1.26+ready*2.1,yy=11.2+i*.32;add(q,xx,yy,()=>figure(c,...p(xx,yy,high?12:1),['refugee','sailmaker','child-eave'][i],t,{scale:.96,stride:ready>0&&ready<1?ready*31:0}));}
 }else if(id==='pale-sump'){
  for(const x of [8.5,17.4])add(q,x,9.6,()=>cottage(c,p,x-1,7.2,3.8,2.2,{open:x<10,h:43,lit:x>10,wall:x<10?'#d0bc9c':'#8c9b92'}));
  add(q,10,10.9,()=>{const [a,b]=p(10,10.9);for(let i=0;i<4;i++){oval(c,a+i*6-9,b-i*2,6,4,'#c7b995');line(c,a+i*6-10,b-i*2-4,a+i*6-6,b-i*2-4,'#776954',1.2);}});
 }else{
  for(const [x,d]of [[8,2.2],[17,2.75],[25,2.25]])add(q,x,9.2,()=>cottage(c,p,x-1,9.3-d,3.25,d,{roof:x===17?'#8a7771':'#748782',open:x!==17,lit:true}));
  if(id==='low-hinge')add(q,18,10.3,()=>foldingChair(c,...p(18,10.3),0));
  if(id==='slant-cobbles')add(q,10.4,10.9,()=>dog(c,...p(10.4,10.9),t,0));
 }
 for(const [x,y]of [[8.2,10.1],[16.1,9.4],[24.4,11.65],[29,12.8]])add(q,x,y,()=>lantern(c,...p(x,y),27,true,t));
}
const physical=new Set(['chair-unseat','chair-knees','chair-step','split-price','split-door','split-awning','eave-shoulder-mara','eave-back','skirt-ivo-loop','skirt-back','hinge-mark','hinge-board','hinge-boat','hinge-rope']);
export function streetItem(c,p,m,e,s,t){
 if(!tiltedPlace(m.id))return false;
 if(physical.has(e.id))return true;
 if(e.kind==='npc'||e.action?.type==='battle')return false;
 const a=p(e.x+.52,e.y+.42,9);oval(c,...a,2.6,1.8,'#dec490');return true;
}


