import {rod,face,beam,box,plate,lamp,ring,oval,poly,sail,hanging,oak,tar,brass} from './fixtures.mjs';
export function oilHouse(c,p,f,t){
 const {x,y,w,h}=f,n=y+h-.05;
 box(c,p,x+.08,y+.11,w-.18,h-.17,0,32,['#81918a','#758477','#586c68']);
 face(c,p,[[x,y,32],[x+w,y,32],[x+w,y+h*.44,43],[x,y+h*.44,43]],'#7f9493','#526d72');
 face(c,p,[[x,y+h*.44,43],[x+w,y+h*.44,43],[x+w,n+.09,32],[x,n+.09,32]],'#6b8488','#4e696c');
 for(let i=0;i<6;i++){const a=x+.25+i*.81;rod(c,p,[a,y+h*.44,43],[a,n,32],'#a1aaa0',1.5);}
 box(c,p,x+2.1,y+.81,.72,.66,40,13,brass);lamp(c,p,x+2.5,y+1.45,51,t,true,.84);
 beam(c,p,[x+.06,n,32],[x+w-.05,n,32],4);
 for(let j=0;j<3;j++){const a=x+.42+j*1.48;face(c,p,[[a,n+.05,2],[a+.84,n+.05,2],[a+.84,n+.05,24],[a,n+.05,24]],'#445d5d');if(j)for(let z=6;z<22;z+=4)rod(c,p,[a,n+.07,z],[a+.84,n+.07,z],'#8b9784',2.3);}
 for(let j=0;j<2;j++){const q=p(x+3.12+j*.51,n+.26);c.fillStyle='#9f8867';c.fillRect(q[0]-4,q[1]-9,8,9);oval(c,q[0],q[1]-9,4,1.65,'#beaa83');rod(c,(u,v)=>[u,v],[q[0]-4,q[1]-4],[q[0]+4,q[1]-4],'#6d7568',1.4);}
}
export function seamShop(c,p,s,t,add){
 add(9.2,()=>{const x=3.1,y=3.18;box(c,p,x,y,2.5,.76,0,10,oak);for(const k of [.33,.8,1.27,1.92]){const q=p(x+k,y+.4,11);ring(c,q,3.55,'#d6bd8c',.54);}
  beam(c,p,[x+.5,y+.13,10],[x+.5,y+.13,27],3);lamp(c,p,x+.5,y+.13,26,t,true,.62);});
 add(10.75,()=>{beam(c,p,[3.2,5.8,0],[3.2,5.8,28],2.8);hanging(c,p,[3.2,5.8,28],[5.18,5.8,27],2,'#af9872',1.6);sail(c,p,[3.36,5.8,27],[4.41,5.8,27],16,'#aeb19e',t,true);});
 for(const [x,y] of [[2.2,8.6],[6.47,9.3]])add(x+y,()=>{box(c,p,x,y,.62,.54,0,12,tar);for(let i=0;i<3;i++)rod(c,p,[x+.06,y+.56,3+i*3],[x+.44,y+.56,3+i*3],'#c5b78c',1);});
}
export function oilskin(c,p,e,s,t){
 const x=e.x+.11,y=e.y+.47;beam(c,p,[x,y,0],[x,y,24],2.6);const q=p(x,y,24);ring(c,q,2.5,'#bdab79',.87);
 if(!s.flags['collected:bobbins-gear']){const [a,b]=q;poly(c,[[a-2,b+2],[a+3,b+1],[a+8,b+5],[a+11,b+14],[a+7,b+15],[a+4,b+10],[a+6,b+24],[a-7,b+25],[a-6,b+11],[a-9,b+16],[a-12,b+14],[a-9,b+6]],'#9b805d','#6a6c56');rod(c,(u,v)=>[u,v],[a,b+5],[a+1,b+22],'#c6a579',1);}
}