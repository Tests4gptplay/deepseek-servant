const validMap=(world,id)=>typeof id==='string'&&Object.hasOwn(world.maps,id);
const sameVoyage=(world,state,id)=>validMap(world,id)&&
  (world.maps[id].campaign==='afterwatch')===(state.cycle?.id==='afterwatch');

function findExit(world,from,x,y,to){
  return world.maps[from]?.exits?.find(e=>e.x===x&&e.y===y&&e.to===to);
}
function empty(){return {places:[],legs:[],mark:null};}

// Recorded crossings are directional. A boat that dropped us off may not take us back.
export function loadChart(world,state,input){
  const chart=empty();
  const places=Array.isArray(input?.places)?input.places:[];
  const known=new Set();
  for(const id of places){
    if(sameVoyage(world,state,id)&&!known.has(id)){known.add(id);chart.places.push(id);}
  }
  const legs=Array.isArray(input?.legs)?input.legs:[];
  const distinct=new Map();
  for(const row of legs){
    if(!Array.isArray(row)||row.length!==5)continue;
    const [from,x,y,to,tides]=row;
    if(!known.has(from)||!known.has(to)||!Number.isInteger(tides)||tides<1||tides>3||!findExit(world,from,x,y,to))continue;
    const key=JSON.stringify([from,x,y,to]);
    if(distinct.has(key))distinct.get(key)[4]|=tides;
    else{const leg=[from,x,y,to,tides];distinct.set(key,leg);chart.legs.push(leg);}
  }
  if(known.has(input?.mark))chart.mark=input.mark;
  return chart;
}

export function notePassage(world,state,from,exit){
  if(!sameVoyage(world,state,from)||!sameVoyage(world,state,exit.to)||!findExit(world,from,exit.x,exit.y,exit.to))return;
  const c=state.fieldChart??=empty();
  for(const id of [from,exit.to])if(!c.places.includes(id))c.places.push(id);
  const tide=state.tide==='high'?2:1;
  const leg=c.legs.find(([a,x,y,b])=>a===from&&x===exit.x&&y===exit.y&&b===exit.to);
  if(leg)leg[4]|=tide;
  else c.legs.push([from,exit.x,exit.y,exit.to,tide]);
}

export function visitedPlaces(state){
  return [...new Set([...(state.fieldChart?.places||[]),state.map])];
}

export function knownWay(world,state,goal,allows){
  const current=state.map;
  if(current===goal)return [];
  const outgoing=new Map();
  for(const [from,x,y,to,tides] of state.fieldChart?.legs||[]){
    const exit=findExit(world,from,x,y,to);
    if(!exit)continue;
    if(!outgoing.has(from))outgoing.set(from,[]);
    outgoing.get(from).push({from,to,exit,tides});
  }
  function search(requireOpenFirst){
    const previous=new Map([[current,null]]),queue=[current];
    for(let i=0;i<queue.length;i++){
      for(const leg of outgoing.get(queue[i])||[]){
        if(previous.has(leg.to)||(requireOpenFirst&&leg.from===current&&!allows(state,leg.exit.requires)))continue;
        previous.set(leg.to,leg);
        if(leg.to===goal){
          const route=[];
          for(let at=goal;at!==current;){const edge=previous.get(at);route.unshift(edge);at=edge.from;}
          return route;
        }
        queue.push(leg.to);
      }
    }
    return null;
  }
  return search(true)??search(false);
}

export function ribbon(state,destination){
  if(!visitedPlaces(state).includes(destination))return false;
  const chart=state.fieldChart??=empty();
  if(!chart.places.includes(destination))chart.places.push(destination);
  chart.mark=destination;return true;
}
