import {poly,line,oval,arc} from '../paint.mjs';
const ink='#293e40',iron='#497071',dry='#ac9870',light='#e6d0a0';
export function rod(c,a,b,x,y,w=4,col=iron){
 line(c,a,b,x,y,ink,w+2);line(c,a,b-1,x,y-1,col,w);if(w>=5)line(c,a,b-2,x,y-2,'#b8ab87',1);
}
export function socket(c,x,y,r,k=1){
 oval(c,x+1,y+1,r+2,r*.69,ink);oval(c,x,y,r,r*.69,k?dry:'#63918b');oval(c,x,y,r*.66,r*.43,'#31474a');
}
export function gear(c,x,y,r,turn,black=false){
 c.save();c.translate(x,y);c.scale(1,.91);c.rotate(turn);const teeth=[];
 for(let n=0;n<16;n++)for(const [off,len] of [[0,.87],[.08,1],[.44,1],[.54,.87]]){
 const a=(n+off)*Math.PI/8;teeth.push([Math.cos(a)*r*len,Math.sin(a)*r*len]);}
 poly(c,teeth,black?'#444c49':'#d0c5aa',ink);oval(c,0,0,r*.74,r*.74,'#3f5d5e');
 for(let i=0;i<6;i++){const a=i*Math.PI/3;rod(c,Math.cos(a)*3,Math.sin(a)*3,Math.cos(a)*r*.72,Math.sin(a)*r*.72,3.4,black?'#ac8b64':'#9da59a');}
 oval(c,0,0,r*.19,r*.19,dry);line(c,-2,0,2,0,ink,1.3);c.restore();
}
export function engine(c,x,y,t,phase='white',kind='ram',still=false,size=1){
 const rev=phase==='reverse',dark=phase==='black',spin=still?0:t*(rev?-1.2:.77),beat=still?0:(1+Math.sin(t*3.2))*.5;
 c.save();c.translate(x,y);c.scale(size,size);
 oval(c,1,7,55,11,'#1e353a51');
 poly(c,[[-55,0],[-24,-14],[34,-10],[53,1],[44,10],[-20,16],[-55,8]],'#415c60',ink);
 poly(c,[[-55,5],[-20,13],[47,5],[45,14],[-18,22],[-55,12]],'#846e56',ink);
 for(const a of [-44,-24,20,39]){rod(c,a,4,a+3,-37,5);socket(c,a,3,4);}
 rod(c,-42,-37,44,-41,7);rod(c,-45,-3,37,-9,4);
 gear(c,-20,-17,16,-spin*1.6,dark);gear(c,6,-27,24,spin,dark);
 for(let i=0;i<3;i++)line(c,-49+i*3,8,-25+i*3,12,still?'#a69c81':'#d8b07c',1.5);
 if(dark){const q=kind==='shell'?0:10;poly(c,[[24,-55],[32,-57],[36,-46],[33,-35],[45+q,-29],[48+q,-20],[44+q,-15],[37+q,-17],[39+q,-22],[28,-26],[24,-35],[16,-39],[12,-47],[16,-54],[17,-46],[25,-43]],'#373f40','#e2b982');}
 else{const top=still?-36:-50-(kind==='ram'?beat*11:0);rod(c,4,-25,23,top,5,dry);poly(c,[[16,top-4],[30,top-7],[36,top],[24,top+6]],rev?'#6e9b9e':light,ink);}
 if(rev){arc(c,-42,-21,13,-2.7,.1,'#88daca',3);poly(c,[[-51,-27],[-56,-28],[-55,-20]],'#e3bc82');}
 if(still){rod(c,20,-38,29,-10,4,'#b7835f');line(c,31,-13,39,-8,'#debf8c',2.2);}
 c.restore();
}
export function incoming(c,x,y,t,proof=false){
 c.save();c.translate(x,y);poly(c,[[-49,-7],[6,-22],[54,-8],[-3,12]],'#3e6b71','#3a5558');
 for(let j=0;j<6;j++){const u=(j*.181+t*.24)%1,a=-37+u*66,b=4-u*16;
  c.beginPath();c.moveTo(a-5,b-1);c.quadraticCurveTo(a-1,b+2,a+6,b-1);c.strokeStyle=j%2?'#92c5ba':'#cee5cf';c.lineWidth=j%2?1.8:1.2;c.stroke();}
 rod(c,3,-1,3,-39,3,'#b28e65');
 for(let i=0;i<5;i++)line(c,3,-10-i*5,9+(i%2)*4,-10-i*5,i===3?'#ecb27c':'#dad6b5',1.3);
 oval(c,-8,-6+(proof?-3:0),6,2.7,'#dbbf65');c.restore();
}
