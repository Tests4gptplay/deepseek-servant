import {line,poly,oval,arc} from './paint.mjs';
export function clue(c,x,y,e){
 const label=e.name||'',id=e.id||'';
 if(id==='balance-arm')return false;
 if(/把|柄|横闩|百叶|闸轴|反提|滑轮|手轮/.test(label)||/chain-handle|lift-invert|organ-crossbar|blind-louvers/.test(id)){
  poly(c,[[x-8,y],[x-2,y-5],[x+7,y-2],[x+3,y+2]],'#998b6b','#726d58');
  line(c,x+4,y-2,x+8,y-14,'#75644c',2.6);oval(c,x+8,y-15,2.8,1.5,'#c3a775');return true;
 }
 if(/纸|签|票|账|簿|运单|名单|记拍|样本|墨|饭筹/.test(label)){
  poly(c,[[x-9,y-1],[x+3,y-6],[x+11,y-2],[x-1,y+3]],'#d6caac','#9b947b');
  for(let i=0;i<3;i++)line(c,x-4+i*3,y-i*.65,x+1+i*3,y-2-i*.65,'#88958a',.8);
  return true;
 }
 if(/潮尺|潮钟|量尺|双尺|潮印|水尺/.test(label)||/gauge|tide-bell/.test(id)){
  line(c,x-4,y,x-3,y-20,'#81745b',2.6);for(let j=0;j<5;j++)line(c,x-3,y-3-j*3,x+(j%2?0:2),y-3-j*3,'#cab68f',1);return true;
 }
 if(/车辕|扣|绳|索|股/.test(label)){
  arc(c,x-2,y-3,5,0,Math.PI*2,'#ac946c',1.5);line(c,x+2,y-3,x+8,y-8,'#927554',1.3);return true;
 }
 if(/灯|芯|烛/.test(label)){
  oval(c,x,y-1,4,2,'#b3976d');line(c,x,y-2,x,y-7,'#ba9f70',1.8);oval(c,x,y-7,1.2,2.1,'#edd4a0');return true;
 }
 return true;
}
