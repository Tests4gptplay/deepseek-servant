import {poly,line,oval,lantern,rope} from './materials.mjs';
function body(c,x,y,coords,fill,edge='#504132'){
 poly(c,coords.map(([u,v])=>[x+u,y+v]),fill,edge);
}
export function stove(c,q,night){
 const [x,y]=q(.73,.45,1);
 oval(c,[x+3,y+4],23,7,'#433c3555');
 body(c,x,y,[[-18,-3],[-11,-12],[2,-16],[15,-9],[19,0],[9,6],[-8,5]],'#8b7760');
 body(c,x,y,[[-16,-7],[-13,-25],[-6,-34],[6,-36],[14,-27],[17,-8],[7,-2],[-9,-2]],'#a07b57');
 body(c,x,y,[[-10,-5],[-9,-16],[-5,-22],[2,-22],[7,-18],[9,-6]],'#483a30');
 if(!night){
  body(c,x,y,[[-7,-7],[-3,-14],[-1,-10],[1,-18],[5,-12],[6,-7]],'#d8824d');
  line(c,[[x-4,y-7],[x-1,y-12],[x+1,y-8]],'#f2bc74',2);
 }
 for(const [u,v,l] of [[-12,-22,7],[4,-28,6],[-12,-13,5],[9,-14,5],[-10,-28,4]])line(c,[[x+u,y+v],[x+u+l,y+v-1]],'#d4b285',1.3);
 body(c,x,y,[[2,-35],[3,-49],[10,-50],[10,-36]],'#6a6455');
 line(c,[[x+2,y-49],[x+11,y-50]],'#c3ad84',2.5);
 const k=q(1.25,.35,16);oval(c,k,13,6,'#58493e');oval(c,[k[0],k[1]-3],10,3,night?'#7d9787':'#c8945e');
 rope(c,[[k[0]-10,k[1]-3],[k[0]-7,k[1]-12],[k[0]+4,k[1]-13],[k[0]+10,k[1]-5]],'#9d9879');
}
export function lasts(c,q,night){
 const [x,y]=q(1.40,.22,16);
 for(let i=0;i<3;i++){
  const xx=x-18+i*14,yy=y+Math.abs(i-1)*2;
  body(c,xx,yy,[[-5,0],[-5,-8],[-1,-7],[1,-2],[6,-1],[8,2],[4,4],[-3,3]],i===1?'#647b76':night?'#87674b':'#a86048');
  line(c,[[xx-4,yy+2],[xx+4,yy+3],[xx+7,yy+1]],'#dfbf87',1.35);
  line(c,[[xx-3,yy-4],[xx,yy-2]],'#d5ae7a',1.2);
 }
 const r=q(.4,.18,14);line(c,[[r[0]-5,r[1]+2],[r[0]+5,r[1]-9]],'#6a4d3b',3);
 line(c,[[r[0]+3,r[1]-8],[r[0]+9,r[1]-12]],'#b5b7a5',2);
}
export function linens(c,q,turned){
 const x=.21,dx=turned?2.35:3.0,dy=turned?.94:.10;
 const at=(u,v,z=0)=>q(x+dx*u-v*.28,.12+dy*u+v*.82,z);
 const pts=[[.17,.10],[.63,.10],[.63,.91],[.17,.91]];
 poly(c,pts.map(([a,b])=>at(a,b,10)),'#7d8c81','#66796c');
 for(const a of [.21,.25,.55,.59])line(c,[at(a,.15,10.6),at(a,.88,10.6)],a<.3?'#bd7963':'#dac89c',1.7);
 for(let i=0;i<4;i++){
  const a=.3+i*.052;
  poly(c,[at(a,.4,11),at(a+.02,.33,11),at(a+.04,.4,11),at(a+.02,.49,11)],'#cdbb90');
 }
 for(const u of [0,1]){const k=at(u,.78,4);oval(c,k,5,4,'#4a5752');oval(c,[k[0]-1,k[1]-1],2.2,1.7,'#d4b480');}
}
export function traversed(c,q,moved){
 const o=q(moved?2.60:1.65,.45,moved?27:20);body(c,...o,[[-7,-1],[-5,-7],[1,-9],[5,-6],[9,-5],[8,-2],[3,0],[-3,2]],'#b28158');
 for(const [u,v] of [[-4,-3],[0,-4],[4,-5]])oval(c,[o[0]+u,o[1]+v],1.1,1.1,'#594f44');
}
export function cornerLight(c,q,id){
 const source=q(.84,.35,48);
 if(id==='heel-quiet-return'||id==='heel-flooded-hall')lantern(c,source,true);
}
