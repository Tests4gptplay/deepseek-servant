import {yards,rescue} from './field-rescue.mjs';
import {survey} from './field-survey.mjs';
import {masterWork} from './master-tools.mjs';
import {fieldBook,paidDrill} from './seamanship.mjs';
import {encounter} from './encounter.mjs';

const names={rescue:'护送与修复',survey:'测绘与引航'};
export function workstation(s){
 const tr=s.expedition?.seamanship?.trail;
 if(s.cycle||!s.flags['grave-signed']||!tr||!names[tr.track]||tr.index>=yards.length)return null;
 const row=(tr.track==='rescue'?rescue:survey)[tr.index],[map,ax,ay,bx,by]=yards[tr.index];
 const stage=tr.observed?'work':'look',x=tr.observed?bx:ax,y=tr.observed?by:ay;
 return {tr,row,map,x,y,stage,name:(tr.observed?'当场实作 · ':'察看现场 · ')+row[0]};
}
export function fieldTarget(s){
 const k=workstation(s);if(!k||k.map!==s.map||Math.abs(s.x-k.x)+Math.abs(s.y-k.y)>1)return null;
 return {kind:'field',value:{id:'field-'+k.stage,name:k.name,x:k.x,y:k.y}};
}
function pressure(ctx,k,done,close){
 const s=ctx.state.player,medical=k.tr.track==='rescue',last=k.tr.index===18;
 const base=ctx.world.encounters[last?'keel-polar':'keel-long'];const hp=Math.round(base.hp*(medical?.90:1.04));
 const spec={...base,id:'field-'+k.tr.track+'-'+k.tr.index,name:last?(medical?'冷井 · 护住开闸人':'冷井 · 实测盲弯'):(medical?'驳舷 · 双止动带载':'驳舷 · 斜索带载'),hp,attack:base.attack+(medical?0:2),rewards:{xp:0,repeatXp:0,items:{},label:'工作台完整承压。回看实物后登记本次手艺。'},phases:base.phases.map(p=>({...p,fromHp:Math.round(p.fromHp*hp/base.hp)}))};
 encounter(ctx,spec,()=>{s.victories++;done();},close);
}
export function worksite(ctx,close){
 const {state,ui,sound}=ctx,s=state.player,k=workstation(s);
 if(!k||!fieldTarget(s))return close();
 const tr=k.tr,[title,clue,right,wrong,result]=k.row,index=tr.index;
 if(!tr.observed){ui.show('field-look',title,clue,[['记下现场再去另一端',()=>{tr.observed=true;tr.mistakes=0;sound('touch');close();} ],['稍后再察看',close]],'察看方位 '+s.x+' / '+s.y);return;}
 const action=()=>{if(index===11||index===18)pressure(ctx,k,done,close);else masterWork(ctx,k,done,close);};
 const done=()=>{
  if(tr.index!==index)return close();const gains=paidDrill(ctx.world,s,index);
  const medical=tr.track==='rescue',item=index%4===2?(medical?'tonic':'brine-dose'):null;
  if(item)s.expedition.stock[item]=(s.expedition.stock[item]||0)+1;
  const recovered=index%5===4;if(recovered){s.expedition.fieldPrep={...s.expedition.fieldPrep,[medical?'mara':'mira']:medical?'brace':'mark'};}
  tr.log.push({index,site:k.map,title,outcome:result,misses:tr.mistakes||0,gains});tr.index++;tr.observed=false;delete tr.mistakes;delete tr.rig;
  sound('solve');ui.show('field-done',title,result+'\n'+s.expedition.roster.map(id=>ctx.world.actors[id].name+' Lv'+s.expedition.heroes[id].level+'（＋'+gains[id]+'）').join('　'),[['记下并收起器具',close]],item?'值守人补上了'+(medical?'药剂。':'盐膏。'):recovered?(medical?'下一场已固定救扶索。':'下一场已标出第一处软点。'):'双方留有一份同号回执。');
 };
 const solve=(hint='')=>{
  const options=[[right,action],[wrong,()=>{tr.mistakes=(tr.mistakes||0)+1;sound('touch');solve('试放没有对齐，东西仍在托盘。回看另一端留下的实测。');}]];
  if(index%3!==1)options.reverse();ui.show('field-work',title,[clue,hint].filter(Boolean).join('\n'),[...options,['先收手',close]],index===11||index===18?'对好后还须在真实潮压下完成三段检校。':'实作处 '+k.x+' / '+k.y);
 };solve();
}
export function guildLedger(ctx,back){
 const {world,state,ui,sound}=ctx,s=state.player;if(!s.flags['grave-signed']||s.cycle)return back();
 const b=fieldBook(s),tr=b.trail,k=workstation(s),older=Object.keys(s.expedition.guild?.receipts||{}).length;
 const options=[],info=['坡上两行碑落成，行会开始把首航所得用在真正有人接手的岗位。'];
 if(!tr){for(const [id,label] of Object.entries(names))options.push(['走'+label,()=>{b.trail={track:id,index:0,observed:false,log:[]};sound('touch');guildLedger(ctx,back);}]);}
 else{info.push(names[tr.track]+' · 已交接 '+tr.log.length+' / '+yards.length);if(k)info.push(world.maps[k.map].name+'　'+k.x+' / '+k.y+'\n'+(k.stage==='look'?'先察看证物，再到另一端动手。':'带着刚看的实物去另一端选择做法。'));else info.push('两端的凭据已经齐了。'+(tr.custodyText||'旅伴保存着两端的记录。'));
  options.push(['逐项看已交接的实务',()=>ui.show('guild','岗位交接簿',tr.log.map(n=>n.title+'　'+n.outcome).join('\n')||'还未交接第一件。',[['回到岗位簿',()=>guildLedger(ctx,back)]] )]);}
 if(older)info.push('保留下来的旧版行会凭据 '+older+' 份。现有等级保留。');
 options.push(['返回航海志',back]);ui.show('guild','海路行会 · 首航实务复核',info.join('\n\n'),options,'最后六项逐次授一级。实地察看、处置和承压均可另日接续。');
}
