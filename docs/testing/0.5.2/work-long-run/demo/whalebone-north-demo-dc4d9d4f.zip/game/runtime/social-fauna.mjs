import {line,oval,poly,arc} from './paint.mjs';
import {wheel} from './voyage-shapes.mjs';

// Steam, water and feather movement all accept the scene clock (zero in reduced motion).
export function heron(c,x,y,t,pose='rest',nest=false){
 c.save();c.translate(x,y);
 if(nest){oval(c,-19,2,17,5,'#695b46');for(let i=0;i<12;i++){const a=(i*.81)%2;
  line(c,-33+i*2,2-a,-25+i*1.6,4-a,'#ae976b',1.5);}
  for(const n of [0,1]){oval(c,-23+n*8,-2,4,4,'#b7bcaa');oval(c,-22+n*8,-5,2.3,2.1,'#d9d3b6');line(c,-21+n*8,-5,-17+n*8,-5,'#ad9060',1.5);}}
 const wing=pose==='flare',down=pose==='lean',f=Math.sin(t*2.8)*1.6;
 oval(c,0,2,17,4,'#4154494d');
 for(const [i,k] of [[-4,-2],[3,4]]){line(c,i,-16,i+k,-6,'#60634f',2);line(c,i+k,-6,i+k-1,1,'#777553',1.8);line(c,i+k-1,1,i+k+6,2,'#9b8b5f',1.6);}
 poly(c,[[-20,-17],[-12,-25],[-1,-29],[10,-26],[12,-21],[5,-16],[-10,-15]],'#d3d6c7','#647a78');
 if(wing){for(let j=0;j<2;j++){c.save();c.translate(-j*6,-j*2);poly(c,[[-2,-21],[-13,-35-f],[-38,-49-f],[-34,-37],[-29,-36],[-28,-29],[-21,-27],[-17,-21],[-7,-17]],j?'#afc2bb':'#7f9996','#617d79');for(let i=0;i<4;i++)line(c,-11,-24,-32+i*4,-42+i*3-f,'#e4e3cd',1.2);c.restore();}}
 else{poly(c,[[8,-25],[-1,-25],[-12,-23],[-23,-16],[-15,-17],[-19,-14],[-6,-16],[4,-20]],'#a5b9b6','#718a88');for(let j=0;j<3;j++)line(c,-12-j*3,-19+j,-1,-23+j,'#e2e3cf',1);}
 const hx=down?27:17,hy=down?-28:-43;
 c.beginPath();c.moveTo(8,-23);c.bezierCurveTo(23,-28,1,hy+3,hx,hy);c.strokeStyle='#577573';c.lineWidth=5.8;c.stroke();c.lineWidth=3.5;c.strokeStyle='#f4e9cd';c.stroke();c.lineWidth=1;
 oval(c,hx,hy,4.9,3.1,'#ebe5c9');poly(c,[[hx+3,hy-1],[hx+17,hy+1],[hx+3,hy+2]],'#c8a468','#7a795e');oval(c,hx+1,hy-.7,.9,.9,'#394c4d');
 line(c,hx-3,hy-2,hx-13,hy-4+f,'#718a84',1.35);c.restore();
}
export function courseRig(c,x,y,t,water,guard){
 c.save();c.translate(x,y);oval(c,0,2,29,6,'#4154495c');
 if(water){for(let i=0;i<3;i++){const j=-14+i*14;line(c,j,1,j,-32+i*3,'#655c4a',3);poly(c,[[j,-31+i*3],[j+12,-28+i*3],[j,-24+i*3]],i===1?'#cf9871':'#a5ccc1');}
  for(let i=0;i<3;i++){c.beginPath();c.moveTo(-28,-2-i*3);c.quadraticCurveTo(-15,-11-i*3+Math.sin(t+i)*2,0,-4-i*3);c.quadraticCurveTo(14,1-i*3,25,-7-i*3);c.strokeStyle=i%2?'#d2d9bb':'#668f8e';c.lineWidth=2.3;c.stroke();}c.lineWidth=1;
 }else{line(c,-17,0,-12,-26,'#81735b',5);line(c,15,0,11,-24,'#81735b',5);line(c,-16,-20,16,-22,'#594e40',4);wheel(c,0,-19,14,t*(guard?.2:.9),8);line(c,0,-19,17,-30,'#ddc497',2.8);}
 c.restore();
}
export function cauldron(c,x,y,t,cold=false){
 c.save();c.translate(x,y);oval(c,0,3,21,6,'#504d42');poly(c,[[-18,2],[-16,-9],[13,-12],[20,-2],[9,4]],'#8c7161','#625649');
 oval(c,0,-7,11,8,'#4a5350');oval(c,0,-12,12,4.5,'#a69372');oval(c,0,-12,9.6,3.3,cold?'#8b9c8c':'#c79c6b');
 arc(c,0,-13,9,-3.1,0,'#685d49',1.8);
 if(!cold){for(let i=0;i<3;i++){const h=7+((t*4+i*4)%10),dx=Math.sin(t+i)*2;c.beginPath();c.moveTo(-4+i*4,-14);c.quadraticCurveTo(-5+i*4+dx,-17,-4+i*4+dx,-14-h);c.strokeStyle='#e1d7bbab';c.lineWidth=1.3;c.stroke();}oval(c,0,-1,5,1.7,'#d19458');}
 c.restore();
}
