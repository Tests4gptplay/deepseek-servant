import {line,oval,poly} from './paint.mjs';
import {cord,ironEye,tideStep,liftBasket} from './whale-rigging.mjs';

export const breathingMaps=new Set(['cup-eaves','blow-stoop','lung-baths','bucket-gable','tin-quay']);
export function shoulderHeight(flags){return flags['flank-raised']?36:flags['flank-deep']?-16:3;}
export function easedHeight(s,action,t){
 const target=shoulderHeight(s.flags);
 if(!action||action.map!==s.map||!['watch-sink','watch-rise'].includes(action.id))return target;
 const k=Math.min(1,Math.max(0,(t-action.at)/1.8));
 return action.fromHeight+(target-action.fromHeight)*k*k*(3-2*k);
}
function continuousBank(c,p,from,to,rise,t,wide){
 const A=p(...from),B=p(...to),len=Math.hypot(B[0]-A[0],B[1]-A[1]);if(!len)return;
 const depth=wide?48:32,h=(wide?24:17)+rise*.47;
 c.save();c.translate(...A);c.rotate(Math.atan2(B[1]-A[1],B[0]-A[0]));
 const wet=c.createLinearGradient(0,-depth,0,depth*.8);wet.addColorStop(0,'#85aaa0');wet.addColorStop(.34,'#587e7b');wet.addColorStop(.67,'#668c85');wet.addColorStop(1,'#91b4a4');
 c.beginPath();c.moveTo(-37,5);c.bezierCurveTo(-16,-depth*.5,len*.10,-depth,len*.29,-depth*.9);c.bezierCurveTo(len*.58,-depth*1.12,len*.84,-depth*.77,len+47,-depth*.26);c.quadraticCurveTo(len+86,depth*.32,len+16,depth*.65);c.bezierCurveTo(len*.72,depth*1.02,len*.32,depth*.67,len*.09,depth*.8);c.quadraticCurveTo(-53,depth*.61,-37,5);c.fillStyle=wet;c.fill();
 for(let j=0;j<37;j++){const x=j*len/37+7*Math.cos(j),y=depth*(j%2?.48:-.61)+3*Math.sin(j+t*.81);line(c,x,y,x+8+j%4*4,y-1.5,'#b1cbb994',1.45);}
 const skin=c.createLinearGradient(0,-h,0,14);skin.addColorStop(0,'#a1b1a1');skin.addColorStop(.22,'#708c80');skin.addColorStop(.62,'#496f6a');skin.addColorStop(1,'#345a5b');
 c.beginPath();c.moveTo(-12,9);c.bezierCurveTo(len*.045,-h*.37,len*.10,-h*.85,len*.25,-h*.80);c.bezierCurveTo(len*.36,-h*.78,len*.43,-h*1.23,len*.57,-h*1.08);c.bezierCurveTo(len*.72,-h*.94,len*.83,-h*.65,len*.91,-h*.51);c.quadraticCurveTo(len*.994,-h*.22,len+9,5);c.bezierCurveTo(len*.96,16,len*.79,17,len*.67,12);c.bezierCurveTo(len*.43,18,len*.29,12,len*.16,14);c.quadraticCurveTo(len*.03,16,-12,9);c.fillStyle=skin;c.fill();
 c.save();c.clip();for(let j=0;j<37;j++){
  const x=len*(j+.45)/37,z=4-h*(.24+.33*Math.sin(j*2.2)**2),pale=j%5===0;
  c.strokeStyle=pale?'#cbcab090':'#9bb49c76';c.lineWidth=pale?2.1:1.2;c.beginPath();c.moveTo(x-5,z);c.quadraticCurveTo(x,z-3,x+6+(j%4)*2,z-1);c.stroke();
  if(j%4===1){oval(c,x+3,z+4,2.1,1.4,'#d0c6a44d');oval(c,x+6,z+2,1.8,1.1,'#d1c7a255');}
 }
 for(let j=0;j<8;j++){const x=len*.75+j*9,y=-h*.32+j*.7;c.strokeStyle='#b4b89b9d';c.lineWidth=1.6;c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+4,y+7,x+14,y+10);c.stroke();}
 const ex=len*.872,ey=-h*.36;oval(c,ex,ey,7,3.5,'#2b4848');oval(c,ex+1,ey-.7,1.6,1,'#e4d3aa');c.restore();
 const vent=len*.54,vY=-h*1.09;oval(c,vent,vY,8.5,2.4,'#49675e');line(c,vent-6,vY-2,vent+3,vY-2.9,'#c5c5a7',1.4);
 if(rise>8){for(let k=0;k<10;k++){const q=(t*.63+k*.099)%1;oval(c,vent+(k-4)*q*5,vY-q*(26+rise*.8),2.5+q*5,2+q*4,'rgba(218,234,216,'+(.57*(1-q))+')');}}
 c.restore();
}
function drawBridge(c,p,x,y,z,endZ){
 const A=p(x,y,z),B=p(x+1.82,y-.65,endZ),D=p(x,y+.60,z),E=p(x+1.82,y-.05,endZ);
 poly(c,[A,B,E,D],'#baa27b','#73664e');for(let i=0;i<6;i++){const f=i/6;line(c,A[0]+(B[0]-A[0])*f,A[1]+(B[1]-A[1])*f,D[0]+(E[0]-D[0])*f,D[1]+(E[1]-D[1])*f,'#8a795e',1.4);}
 for(const side of [[A,B],[D,E]])cord(c,[side[0][0],side[0][1]-12],[side[1][0],side[1][1]-15],3,'#8b795e',1.7);
}
export function shoulderScene(c,p,m,s,rise,t,ordered){
 if(!breathingMaps.has(m.id))return;
 const banks={'cup-eaves':[[1.7,3.6],[44.1,3]],'blow-stoop':[[5.7,12.5],[30.4,8.55]],'lung-baths':[[1.9,5.7],[27.0,6.2]],'bucket-gable':[[2.1,15.4],[14.2,14.25]],'tin-quay':[[1.5,4.3],[31.1,4.4]]};
 const [from,to]=banks[m.id];continuousBank(c,p,from,to,rise,t,m.id==='blow-stoop');
 if(m.id==='blow-stoop')for(const [x,y] of [[10.2,11.75],[16.4,10.8],[25,9.3]]){
  ordered.push([x+y+.02,()=>{const hold=p(x+.42,y-.4,13+rise*.52);cord(c,p(x-1.25,y+1.1,12),hold,rise>9?3:14,'#bca87c',2.6);oval(c,...hold,4,2.3,'#bda574');}]);
 }
 if(m.id==='blow-stoop'){
   for(const [x,y] of [[9.4,12.2],[16,10.1],[26.1,10.4]])ordered.push([x+y+.6,()=>{const z=Math.max(-5,6+rise*.50);drawBridge(c,p,x,y,z,10);tideStep(c,p,x+2.1,y-.22);ironEye(c,p,x+1.76,y+.9); }]);
   ordered.push([28.9+9,()=>liftBasket(c,p,28,9.2,Math.max(2,10+rise*.38),s.flags['flank-raised'])]);
 }
}
