import {lineCover} from './battle-pairs/two-ends.mjs';
import {protect,incomingElement} from './elements.mjs';
const legacy = {
 '横冲':{kind:'rush',power:1.35,counter:'dodge'},'卷网自护':{kind:'shell',power:.8,counter:'skill'},
 '顶门':{kind:'ram',power:1.6,counter:'guard'},'旋索':{kind:'whirl',power:1.25,counter:'dodge'}
};
const hints={rush:'让出直线路径，侧移后露出的甲缘可以追击。',ram:'将重心压近护桩，稳住后再还击。',shell:'外壳合拢，普通斩击只会擦过。协作技可以撬开缝隙。',whirl:'留在内圈会被缠住，侧移到外缘。'};
export function intent(spec,hp,round){
 const phases=[...(spec.phases||[])].sort((a,b)=>a.fromHp-b.fromHp);
 const p=phases.find(x=>hp<=x.fromHp)||phases.at(-1)||{};
 const list=p.moves||spec.moves;const m=list?.length?list[(round-1)%list.length]:p.move||spec.move||'横冲';
 const raw=typeof m==='string'?{name:m}:m;
 const base=legacy[raw.name]||{kind:raw.kind||'rush',power:1.1,counter:'dodge'};
 const step={...base,...raw};return {...step,phaseThreshold:p.fromHp,tell:p.tell||spec.tell||step.tell||'对手正在调整位置。',hint:step.hint||hints[step.kind]||'留意站位。'};
}
export function retaliation(b){
 const intent=b.intent,attack=Math.max(1,Number(b.spec.attack)||4),eligible=b.party.filter(h=>h.hp>0);
 const target=eligible[(b.round-1)%eligible.length],affected=intent.kind==='whirl'?eligible:[target];
 for(const member of b.party)member.hurt=0;
 const logs=[];
 for(const h of affected){
  const safe=h.action===intent.counter||(intent.kind==='rush'&&h.lane==='edge');
  const guarding=h.action==='guard';const raw=safe?0:Math.max(1,Math.round(attack*intent.power)+1-h.defense-(guarding?3:0));
  const shock=incomingElement(b.spec,intent),guarded=raw?protect(h,shock,raw,b.teamGuard):{loss:0,saved:0,element:''};
  const {saved,element}=guarded,shared=lineCover(b,h,shock,guarded.loss),loss=guarded.loss-shared;
  h.hp=Math.max(0,h.hp-loss);logs.push(h.name+(loss?'受击 '+loss:'避开冲击')+(saved?'（'+element+'防护抵去 '+saved+'）':'')+(shared?'（双桩短索卸去 '+shared+'）':''));
  if(safe)b.opening=Math.max(b.opening,3);
  h.hurt=loss;
 }
 for(const h of b.party){if(h.action==='guard')h.mp=Math.min(h.maxMp,h.mp+1);h.action=null;}
 delete b.lineBrace;b.teamGuard=false;b.log+='　'+intent.name+'：'+logs.join('，')+'。';
}
