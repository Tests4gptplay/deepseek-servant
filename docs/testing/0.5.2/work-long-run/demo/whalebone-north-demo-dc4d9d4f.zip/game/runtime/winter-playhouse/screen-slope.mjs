import {patch,timber,face,poly,line,oval} from './joinery.mjs';
const pole='#6d4536',gilt='#dab677',wine='#8f424b',aqua='#628d86',black='#2d3d42';
function deer(c,x,y,scale){
 c.save();c.translate(x,y);c.scale(scale,scale);
 poly(c,[[-26,-8],[-17,-17],[-3,-13],[8,-17],[17,-29],[24,-31],[30,-22],[24,-19],[19,-17],[13,-4],[5,-1],[-3,-2],[-10,2],[-19,1]],'#833f3b');
 for(const [a,b,dx] of [[-15,0,-5],[-9,1,4],[5,-1,-2],[12,-5,8]]){
  line(c,a,b,a+dx,b+13,'#75433d',2.4);line(c,a+dx,b+13,a+dx+4,b+12,'#704139',1.7);oval(c,a,b,1.8,1.8,gilt);
 }
 for(const [bx,dx] of [[18,-4],[21,4]]){
  line(c,bx,-27,bx+dx,-45,'#7b483e',1.8);line(c,bx+dx,-39,bx+dx-5,-43,'#7b483e',1.3);line(c,bx+dx,-36,bx+dx+5,-43,'#7b483e',1.3);
 }
 oval(c,24,-26,1.5,1.5,'#ecc789');line(c,-8,-11,16,-21,'#cc8a65',1);c.restore();
}
function boards(c,p,x,y,w,d,z){
 patch(c,p,[[x,y,z],[x+w,y,z],[x+w,y+d,z],[x,y+d,z]],'#9e7755',pole);
 for(let i=.38;i<d;i+=.44)timber(c,p,[x,y+i,z+.4],[x+w,y+i,z+.4],'#c4a07a',1);
}
function theatre(c,p,f,s,t){
 const x=f.x+.35,y=f.y+.35,w=f.w-.65,d=f.h-.55,front=y+d;
 boards(c,p,x,y,w,d,13);
 for(const dx of [.12,w*.5,w-.1])timber(c,p,[x+dx,front,0],[x+dx,front,15],pole,6.5);
 const curtainY=y+d*.53,span=w*31;
 face(c,p,x,curtainY,()=>{
  const light=c.createLinearGradient(0,-126,span,-18);light.addColorStop(0,'#7f9991');light.addColorStop(.24,'#e6c897');light.addColorStop(.60,'#f0d4a7');light.addColorStop(1,'#bd986f');
  poly(c,[[0,-118],[span,-118],[span,-22],[0,-22]],light,pole);
  for(let i=0;i<22;i++)line(c,4+i*(span-8)/22,-116,4+i*(span-8)/22,-23,'#f8e2bb31',.8);
  poly(c,[[2,-32],[25,-43],[53,-42],[76,-52],[94,-48],[128,-53],[166,-42],[192,-46],[span,-35],[span,-22],[2,-22]],'#a8a388');
  if(!s.flags['ramp-passed']){oval(c,span*.77,-89,17,17,'#e6c878');oval(c,span*.77+6,-95,15.2,15.2,'#dcc39a');line(c,span*.77,-118,span*.77,-105,gilt,.9);}
  oval(c,span*.18,-85,9,9,'#cd7750');
  for(let i=0;i<7;i++){const angle=i*Math.PI*2/7;line(c,span*.18+11*Math.cos(angle),-85+11*Math.sin(angle),span*.18+14*Math.cos(angle),-85+14*Math.sin(angle),'#b56b4a',1.1);}
  deer(c,span*.45,-46+Math.sin(t*.72)*.6,1.08);
  for(const edge of [0,span]){
   const dir=edge? -1:1;
   poly(c,[[edge,-120],[edge+dir*41,-120],[edge+dir*32,-107],[edge+dir*13,-76],[edge+dir*23,-26],[edge,-24]],wine,pole);
   for(let i=4;i<24;i+=5)line(c,edge+dir*i,-117,edge+dir*(i*.34),-76,'#bd6e60',1.6);
   line(c,edge+dir*4,-75,edge+dir*13,-76,'#e3b578',3);
  }
  for(let dx=6;dx<span;dx+=17)poly(c,[[dx,-115],[dx+8,-104],[dx+16,-115]],dx%2?'#af6655':aqua,pole);
 });
 for(const end of [x-.07,x+w+.07]){
  timber(c,p,[end,curtainY,13],[end,curtainY,131],pole,7.5);timber(c,p,[end,curtainY,20],[end,curtainY,118],gilt,1.4);
  timber(c,p,[end,front,15],[end,curtainY,83],aqua,4);
 }
 timber(c,p,[x-.2,curtainY,128],[x+w+.2,curtainY,128],black,7);timber(c,p,[x-.2,curtainY,130],[x+w+.2,curtainY,130],gilt,2);
 face(c,p,x+.5,front+.08,()=>{
  const width=(w-.9)*31;poly(c,[[0,-14],[width,-14],[width,0],[0,0]],'#627d73',pole);
  for(let i=5;i<width-5;i+=10)poly(c,[[i,-6],[i+4,-10],[i+8,-6],[i+4,-2]],'#dbbd84');
 });
}
function moonHoist(c,p,f,s){
 const x=f.x+.55,y=f.y+f.h-.55,w=f.w-1;
 for(const a of [x,x+w]){timber(c,p,[a,y,0],[a,y,105],pole,6);timber(c,p,[a,y,60],[a+(a===x?1:-1),y,99],aqua,4);}
 timber(c,p,[x-.3,y,104],[x+w+.3,y,104],gilt,4.4);
 face(c,p,x,y,()=>{const width=w*31,shift=s.flags['ramp-passed']?66:0;
  line(c,width*.32,-102,width*.32,-72+shift,pole,1.3);oval(c,width*.32,-53+shift,17,17,'#ddbe7d');oval(c,width*.32+5,-58+shift,14,14,'#66847b');
  line(c,width*.73,-102,width*.73,-78,pole,1.2);poly(c,[[width*.73,-78],[width*.73+15,-52],[width*.73,-58],[width*.73-15,-52]],'#bc7154',pole);
 });
}
export function theatreFeature(c,p,map,f,s,t){
 if(map.id!=='screen-slope')return false;
 if(f.kind==='building'&&f.x===3){theatre(c,p,f,s,t);return true;}
 if(f.kind==='crane'&&f.x===16){moonHoist(c,p,f,s);return true;}
 return false;
}
export function theatreFloor(c,p,map){
 if(map.id!=='screen-slope')return;
 for(let i=0;i<28;i++){const x=3+i,y=10.65+.65*Math.cos(i*.22);for(const j of [-1,1]){timber(c,p,[x,y+j*.36,1.2],[x+.9,10.65+.65*Math.cos((i+.9)*.22)+j*.36,1.2],'#8c735c',2.2);}}
 for(let i=0;i<9;i++){const x=4+i*3.2;patch(c,p,[[x,9.8,1],[x+.5,9.8,1],[x+.6,10,1],[x,10,1]],i%2?wine:aqua);}
}
