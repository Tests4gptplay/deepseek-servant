import {setFlags} from './state.mjs';
import {dialogue} from './dialogue.mjs';
export const stairId='lullaby-double-stair';
const lower={accompany:[20,14],apart:[10,15]};
const label={mara:'玛拉',ivo:'伊沃'},opposite=a=>a==='mara'?'ivo':'mara';
function story(s){return s.progress.lullaby??=( {guides:{}} );}
export function guideOn(map,s){
 const guide=map.lullabyGuide;if(!guide||!s.flags[guide.requires])return null;
 const index=s.progress.lullaby?.guides?.[map.id]||0;
 return {guide,index,point:guide.path[Math.min(index,guide.path.length-1)],done:index>=guide.path.length};
}
export function visitBayDoor(s,from){
 if(s.map!==stairId)return;
 const st=story(s);st.guides??={};const entry=[s.x,s.y];
 // The new return to the stair always begins at the actual new door with Mara.
 st.pair={active:'mara',mara:entry,ivo:st.pair?.ivo||[5,14],from};
}
export function hearthStep(map,s){
 const reading=guideOn(map,s);
 if(reading&&!reading.done){const {point,guide,index}=reading;
  if(Math.abs(s.x-point[0])+Math.abs(s.y-point[1])<=2){const st=story(s);st.guides??={};st.guides[map.id]=index+1;
   if(index+1===guide.path.length)s.flags[guide.flag]=true;}
 }
 if(map.id!==stairId)return;
 const pair=story(s).pair;if(pair)pair[pair.active]=[s.x,s.y];
}
export function residentPresent(s,e){
 switch(e.id){
 case 'lullaby-carter':return !s.flags['coffin-aboard'];
 case 'lullaby-awning':return !s.flags['lullaby-child-led'];
 case 'lullaby-aunt-holds':return !!s.flags['lullaby-port-choice']&&!s.flags['coffin-aboard'];
 case 'lullaby-old-stove-returns':return !!(s.flags['clutch-still']&&s.flags['lullaby-galley']);
 case 'lullaby-downstairs':return !!s.flags['lullaby-galley'];
 default:return true;
 }
}
export function currentPair(s){if(s.map!==stairId)return null;
 return s.progress.lullaby?.pair||null;}
export function switchHand(s){
 if(s.map!==stairId||!s.expedition?.roster.includes('ivo'))return false;
 if(!currentPair(s))visitBayDoor(s,s.map);
 const pair=currentPair(s);pair[pair.active]=[s.x,s.y];pair.active=opposite(pair.active);
 [s.x,s.y]=pair[pair.active];s.facing=[0,1];return true;
}
export const actorName=s=>label[currentPair(s)?.active||'mara'];
export function pathWords(map,s){
 const read=guideOn(map,s);
 if(read){if(read.done)return read.guide.who+'在换气的窄处停下，给你让出进门的位置。';
  const [x,y]=read.point;const dir=(a,lo,hi)=>a===0?'':a<0?lo:hi;
  return read.guide.who+'在'+(dir(y-s.y,'北','南')+dir(x-s.x,'西','东')||'身边')+'招手。走近后再一同往前。';}
 const pair=currentPair(s);if(!pair)return '';
 return pair.active==='ivo'?'伊沃走低廊：近柱守在油窗下，远台能将围看的人引开。':'玛拉在扶车：东窗能陪栗芽问，西边能独自经过；伊沃会留在你换手时的位置。';
}
export function crossKitchen(ctx,e,close){
 const s=ctx.state.player,pair=currentPair(s),mode=e.action.mode,who=actorName(s);
 if(s.flags['lullaby-choice']){ctx.ui.show('dialogue','两端都还记得',s.flags['lullaby-accompany']?'栗芽已在东窗问完。近柱还有两个人等一张热饼。':'栗芽按自己想要的时间开过门。远台的人没有来打听。',[['收好手',close]]);return;}
 const [a,b]=lower[mode],spot=pair?.ivo,distance=spot?Math.abs(spot[0]-a)+Math.abs(spot[1]-b):99;
 if(!pair||who!=='玛拉'||distance>1){ctx.ui.show('gate',who,who==='伊沃'?'栗芽想看着玛拉说。你能守住自己的位置，再换到玛拉那一端。':mode==='accompany'?'东窗挤着过饭队。换到伊沃，实走到楼下油窗的近柱边，再把操控交回玛拉。':'西侧的来人仍在看。换到伊沃，实走到远台请他们看潮，再交回玛拉。',[['先退一步',close]]);return;}
 const lines=mode==='accompany'?[{who:'栗芽',text:'你站在这儿就好。别牵我的手，我得自己伸过去。'},{who:'玛拉',text:'嗯。我等。',lullabyClip:'mara-wait'},{who:'伊沃',text:'下面的饭队得绕我一下。谁错了那顿，我去道歉。'}]:[{who:'玛拉',text:'我推到木框以外。你说什么我听不到。',lullabyClip:'mara-leave'},{who:'栗芽',text:'那我听得到自己了。你走过去，等灶下再见。'}];
 dialogue(ctx.ui,ctx.state,lines,()=>{setFlags(s,e.action.set);s.flags['event:'+s.map+':'+e.id]=true;ctx.sync();close();});
}
