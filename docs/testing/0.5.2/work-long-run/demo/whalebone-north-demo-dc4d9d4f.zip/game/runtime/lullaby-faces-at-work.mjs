import {poly,line,oval} from './paint.mjs';
import {figure} from './figures.mjs';
export function kitchenWorker(c,a,b,t,e){
 const child=e.id==='lullaby-awning'||e.id==='lullaby-daughter',cook=e.id==='lullaby-mother'||e.id==='lullaby-old-stove-returns',wait=e.id==='lullaby-aunt-holds',porter=e.id==='lullaby-carter';
 if(!child&&!cook&&!wait&&!porter)return false;
 if(wait){figure(c,a,b,e.id,t,{scale:1.1});line(c,a-9,b-11,a-17,b-12,'#b18c64',3);poly(c,[[a-19,b-17],[a-12,b-13],[a-15,b-8],[a-22,b-11]],'#c4bba7');return true;}
 figure(c,a,b,child?'lullaby-child':cook?'lullaby-mother':e.id,t,{scale:child?1.24:1.13});
 if(child){oval(c,a,b-22,6.8,2.6,'#8f5a49');poly(c,[[a-5,b-23],[a,b-28],[a+5,b-23]],'#925b48');line(c,a+2,b-21,a+8,b-21,'#c29c66',1.5);if(e.id==='lullaby-daughter'){oval(c,a+10,b-10,9,3.8,'#494d41');line(c,a+3,b-9,a-3,b-6,'#84745e',1.6);}}
 else if(cook){poly(c,[[a-4,b-20],[a+4,b-20],[a+7,b-5],[a-5,b-4]],'#cfad88','#806e60');line(c,a-4,b-17,a+4,b-17,'#ad7b60');line(c,a+5,b-14,a+12,b-12,'#bd9273',2.4);oval(c,a+15,b-12,7,2.8,'#53594b');}
 else{poly(c,[[a-8,b-19],[a-4,b-15],[a-8,b-6],[a-14,b-8]],'#ae8d58','#70664e');line(c,a-5,b-18,a+5,b-13,'#bcaa7f',2);}
 return true;
}
export function companionsWatching(c,p,map,s,t,ordered){
 if(map.id!=='lullaby-double-stair'&&map.id!=='lullaby-clay-hob')return;
 const stage=map.id==='lullaby-double-stair';
 const [x,y]=stage?(s.flags['lullaby-apart']?[10.9,6.7]:s.flags['lullaby-accompany']?[24.2,7.7]:[16.6,7.6]):[7.4,8.6];
 ordered.push([x+y+1.01,()=>{const [a,b]=p(x+.5,y+.5);if(stage){kitchenWorker(c,a,b,t,{id:'lullaby-daughter'});line(c,a+11,b-14,a+12,b-19,'#c69a75',2);}
  else if(s.flags['lullaby-accompany']){oval(c,a,b-4,11,4,'#b7a78d');oval(c,a,b-5,8,2.5,'#ca9661');}
  else{line(c,a-10,b-5,a+7,b-9,'#6b5949',3);oval(c,a+8,b-9,7,3,'#c48d57');}}]);
}
