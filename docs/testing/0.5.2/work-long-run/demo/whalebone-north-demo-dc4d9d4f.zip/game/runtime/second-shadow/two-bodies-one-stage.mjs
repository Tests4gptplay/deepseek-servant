import {walkable} from '../state.mjs';
import {stageBook,exchangeStagePlaces,holdAt,pushFoot} from './where-the-ropeman-stands.mjs';
const names={mara:'玛拉',ivo:'伊沃',heron:'木鹤',seal:'皮海豹'};
export function stageAtWork(ctx,e,close){
 const s=ctx.state.player,b=stageBook(s),op=e.action.op;
 const hand=()=>exchangeStagePlaces(ctx.world,s,walkable);
 const body='现在脚下是'+names[b.active]+'。幕里安着'+names[b.figure]+'。踏长 '+b.weight+' 口。'+(b.hold?'伊沃持着'+(b.hold==='heron'?'长颈麻索。':'裂铃短背索。'):'上巷两根麻索都松着。');
 let commands=[];
 if(op==='pose')commands=['heron','seal'].map(k=>['安进'+names[k],()=>{if(b.active!=='mara')return '拆箱要玛拉来。蓝套挂在匣边。';b.figure=k;return names[k]+'已固定在影匣，布脚垂在台下，等长短合适的索与踏木。';}]);
 if(op.endsWith('-line')){const k=op.split('-')[0];commands=[['亲手守住这根索',()=>holdAt(s,k)],['松开手上的麻索',()=>{if(b.active!=='ivo')return '让真正在索边的人自己松手。';if(b.hold)b.handsOff++;b.hold=null;return '伊沃摊开手，以前那条索已经没有人守。';}]];}
 if(op==='weight')commands=[0,1,2].map(v=>[['撤回木跟','推到一口刻度','推到两口刻度'][v],()=>{if(b.active!=='mara')return '先叫玛拉站回踏木这边。';b.weight=v;return ['木跟平躺，脚下没有压劲。','第一根铜销卡住，踏长一口。','第二根铜销卡住，踏长两口。'][v];}]);
 if(op==='press')commands=[['真的压下踏木，看对面哪双手还在',()=>pushFoot(s)]];
 commands.push(['用脚边的蓝套换另一个人接手',hand]);
 ctx.ui.show('dialogue',e.name,body,[...commands.map(([title,act])=>[title,()=>{const msg=act();ctx.state.scenicFocus=null;ctx.sync();ctx.ui.show('dialogue',names[stageBook(s).active],msg,[['继续',close]]);}]),['松开蓝套回现场',close]]);
}
