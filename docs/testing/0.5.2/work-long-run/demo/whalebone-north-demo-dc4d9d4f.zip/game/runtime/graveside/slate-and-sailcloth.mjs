// Stone, the folded mortuary cloth, and the oil lamp are drawn in the same local plane.
const slate=[[96,49],[139,28],[556,22],[608,49],[626,225],[593,263],[127,270],[93,244]];
function path(c,points){c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();}
export function shape(c,points,fill,edge){path(c,points);c.fillStyle=fill;c.fill();if(edge){c.lineWidth=1.4;c.strokeStyle=edge;c.stroke();}}
export function trace(c,pts,color,w=1){c.beginPath();pts.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.lineWidth=w;c.lineCap='round';c.strokeStyle=color;c.stroke();}
function grain(i,k){const n=Math.sin(i*78.233+k*14.753)*47387.5453;return n-Math.floor(n);}
export function stone(c,lamp){
 const bg=c.createLinearGradient(0,0,0,310);bg.addColorStop(0,'#668481');bg.addColorStop(.32,'#8f9a84');bg.addColorStop(.5,'#7a7965');bg.addColorStop(1,'#3c4c46');c.fillStyle=bg;c.fillRect(0,0,720,310);
 for(let i=0;i<240;i++){const x=grain(i,1)*720,y=15+grain(i,2)*290;if(y<46){trace(c,[[x,y],[x+3+grain(i,4)*26,y-.8]],'#dee6c54d',1);}else{trace(c,[[x,y],[x+2+grain(i,3)*9,y-2]],'#c2ba8a61',1.4);}}
 c.save();c.shadowColor='#172d25bd';c.shadowBlur=16;c.shadowOffsetY=8;shape(c,slate,'#475049');c.restore();
 shape(c,[[96,49],[139,28],[556,22],[608,49],[615,60],[555,34],[140,38]],'#bdbea1');
 const grey=c.createLinearGradient(100,55,630,268);grey.addColorStop(0,'#929d8e');grey.addColorStop(.38,'#adb19b');grey.addColorStop(1,'#778479');
 shape(c,[[99,54],[141,38],[555,33],[602,56],[617,222],[589,252],[130,261],[101,237]],grey);
 c.save();path(c,slate);c.clip();
 for(let i=0;i<760;i++){const x=90+grain(i,12)*546,y=22+grain(i,18)*248,n=grain(i,17);c.fillStyle=n>.56?'#dde0c64c':'#52645c3d';c.fillRect(x,y,n*3.5+.6,grain(i,14)*1.25+.5);}
 for(const [x,y,w] of [[122,74,91],[528,65,60],[232,220,148],[105,237,70],[487,242,77]]){trace(c,[[x,y],[x+w*.21,y-6],[x+w*.48,y-7],[x+w*.8,y-14],[x+w,y-15]],'#65776980',1);trace(c,[[x+w*.43,y-7],[x+w*.42,y-13],[x+w*.37,y-16]],'#65776960',.8);}
 const glow=c.createRadialGradient(lamp,162,25,lamp,162,430);glow.addColorStop(0,'#ffe1a85c');glow.addColorStop(.65,'#ffe8b424');glow.addColorStop(1,'#162f2a3c');c.fillStyle=glow;c.fillRect(0,0,720,310);c.restore();
}
export function cloth(c,points,side){
 c.save();c.shadowColor='#27352fa8';c.shadowOffsetY=4;c.shadowBlur=4;shape(c,points,'#bcb094','#756f60');c.restore();c.save();path(c,points);c.clip();
 const x=side==='left'?91:488;
 for(let i=0;i<40;i++){const px=x-66+i*7;trace(c,[[px,22],[px+29,96],[px+13,177],[px+49,278]],i%4?'#ddcfb32e':'#786e5761',i%4?.8:2.6);}
 for(let j=0;j<28;j++)trace(c,[[x-90,25+j*10],[x+35,29+j*10],[x+141,24+j*10]],'#81766132',.9);
 c.restore();
}
export function handLamp(c,x){
 const y=258;c.save();c.translate(x,y);c.shadowColor='#29362eaa';c.shadowBlur=8;c.shadowOffsetY=4;
 shape(c,[[-26,5],[-16,-2],[14,-2],[24,4],[17,11],[-16,13]],'#675f49','#514e42');c.shadowBlur=0;
 shape(c,[[-15,1],[-12,-22],[-7,-31],[4,-32],[12,-23],[15,0]],'#bd9670','#706953');
 shape(c,[[-8,-3],[-8,-21],[-4,-28],[3,-28],[8,-20],[9,-4]],'#f1d6a1');c.fillStyle='#c67b3d';c.beginPath();c.ellipse(0,-11,3.4,8,.15,0,Math.PI*2);c.fill();trace(c,[[-3,-2],[-1,-12],[1,-16]],'#fff0b8',2);
 trace(c,[[-14,-17],[-20,-26],[-15,-38],[-7,-43],[2,-43],[10,-36]],'#5d5946',2);trace(c,[[-14,-19],[-10,-27],[-5,-32],[6,-32],[11,-26]],'#73644a',2);c.restore();
}
