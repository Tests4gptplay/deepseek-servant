import {phrase,patterns,criticism} from './how-a-song-makes-room.mjs';
import {scoreBoard} from './a-score-cut-in-wood.mjs';
import {codaAtTheHem,atTheTiltedInn} from './the-verse-after-the-room.mjs';
const menu='salt-song';
export function musicBench(ctx,station,leave){
 const {ui,state,sound,sync}=ctx,s=state.player;
 const close=()=>{sound.stopSaltPhrase?.();leave();};
 const work=station.action.work;
 if(work==='hem')return codaAtTheHem(ctx,close);
 if(work==='return')return atTheTiltedInn(ctx,close);
 if(work==='heel'||work==='reed'){
  const heel=work==='heel',flag='salt-song-'+work,rows={heel:[],reed:[],child:[]};rows[work]=patterns[work];
  const target=heel?'第一、第四、第七拍':'第二、第五、第八拍';
  function lesson(note='',play=false,slow=false){
   ui.show(menu,heel?'巧棠的三只凳脚':'方莳的木簧换气',
    (note|| (heel?'绿线的脚每踏一次，隔着裙摆也看得见木钉抬一下。由左往右数满八格，后面那只脚刚好伸进下一小节。':'木窗没有封牢，一粒干谷随着簧片跳三次。最后那一跳紧贴窗框最右，下一口气从空格前跨过。'))+
    (s.flags[flag]?'　这条已收入你们的凳谱。':'　你摸到的三声落在哪些拍？'),
    [['看与听这八拍',()=>lesson('',true)],['把它放慢',()=>lesson('',true,true)],
     ...(!s.flags[flag]?['第一、第四、第七拍','第二、第五、第八拍','第三、第五、第七拍'].map(answer=>[answer,()=>{
      if(answer!==target)return lesson(heel?'巧棠把鞋尖抬起来：第一声跟船头齐，再隔两片木。你可以把它放慢。':'方莳把稻谷放回窗边。开头是留白，第五拍颤一次，第八拍贴着末尾。');
      s.flags[flag]=true;sync();lesson(heel?'巧棠解下鞋尖的绿线，量出三只脚的间距。她终于肯跟你们上船，但要由阿梢自己开口。':'方莳把同一段用右手打在你的指节上。她说等了好多年，倒不差今晚这一口气。');
     }]):[]),['放下木板',close]]);
   scoreBoard(ui,rows,{play,slow});if(play)sound.saltPhrase(rows,[],slow);
  }
  return lesson();
 }
 if(work!=='mix')throw Error('未知船凳工位 '+work);
 const saved=s.progress.saltSong??={heel:0,reed:0,place:null};
 if(!Number.isInteger(saved.heel)||saved.heel<0||saved.heel>7)saved.heel=0;
 if(!Number.isInteger(saved.reed)||saved.reed<0||saved.reed>7)saved.reed=0;
 function finish(){
  const porch=s.flags['salt-song-porch'];
  ui.show(menu,porch?'井边来了半条街':'一张桌上正好放下六只手',porch?
   '阿梢在檐口喊“井底下没有帆”；街对面卖瓜的接了一声，也没有抢她末尾的“帆”。巧棠等她自己鞠躬，才把凳抬进人堆。方莳把给小桌的那段空拍带回窗边。':
   '头一拍，方莳把邻桌两只手都拉上木面。阿梢唱到井底没有帆，最慢会意的老船工笑得最响。他让孩子再来，明早他自己教隔壁那桌。巧棠没有催工。',[['让阿梢把这一段再唱一次',()=>replay()],['等人从两边下船',close]]);
 }
 function replay(){const rows=phrase(saved.heel,saved.reed);finish();scoreBoard(ui,rows,{play:true});sound.saltPhrase(rows);}
 if(s.flags['salt-song-played'])return finish();
 function choose(){
  ui.show(menu,'同一条巷有两群听众','外檐等着隔街的孩子，方莳跟暂时走不了夜路的人坐在矮桌。唱词只这一份；先演给谁，脚和簧就得换一种搭法。',
   [['隔着外檐给街童唱',()=>{saved.place='porch';sync();mix();}],['在矮桌边把木音递到手上',()=>{saved.place='table';sync();mix();}],['先把凳子靠岸',close]]);
 }
 function mix(note='',play=false,slow=false){
  const rows=phrase(saved.heel,saved.reed),porch=saved.place==='porch';
  function shift(track,by){saved[track]=(saved[track]+by+8)%8;sync();mix();}
  const goal=porch?'外檐要靠脚的一、四、七拍认清开头；簧把第三、第六拍的字送过巷，末拍交给阿梢。':'矮桌头一拍要安静；第二拍脚与簧同到，第四拍独听簧，第七拍有脚，末拍独听阿梢。';
  ui.show(menu,porch?'给外檐排一个开阔的八拍':'给坐着的人排一个摸得见的八拍',(note?note+'　':'')+goal,
   [['脚音向前一拍',()=>shift('heel',-1)],['脚音向后一拍',()=>shift('heel',1)],['簧音向前一拍',()=>shift('reed',-1)],['簧音向后一拍',()=>shift('reed',1)],['听合奏',()=>mix('',true)],['慢听合奏',()=>mix('',true,true)],['请听众在场合一遍',()=>{const why=criticism(saved.place,rows);if(why)return mix(why);s.flags['salt-song-played']=true;s.flags['salt-song-'+saved.place]=true;sync();finish();sound.saltPhrase(rows);}],['回去听另一桌',choose],['系住凳谱先走',close]]);
  scoreBoard(ui,rows,{play,slow});if(play)sound.saltPhrase(rows,[],slow);
 }
 return ['table','porch'].includes(saved.place)?mix():choose();
}
