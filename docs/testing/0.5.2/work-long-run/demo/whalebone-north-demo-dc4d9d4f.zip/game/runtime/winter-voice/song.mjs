const cues={
 'whalefall-cup':'voice-table','whalefall-ice-near':'voice-double-ice','whalefall-ice-gap':'voice-dry-ice',
 'whalefall-wood-chest':'voice-bridge','whalefall-wood-tail':'voice-child',
 'whalefall-read-wood':'voice-child','whalefall-read-glass':'voice-double-ice','whalefall-bell-test':'voice-wool',
 'whalefall-ring-on-land':'voice-wool','whalefall-lamp-test':'voice-light','whalefall-send-the-light':'voice-light','whalefall-hollow-name':'voice-shelter'};
export const voiceCue=id=>cues[id];
const voices={
 'voice-table':[[0,284,260,.22,.04,0],[.36,284,220,.5,.045,0]],
 'voice-double-ice':[[0,720,658,.26,.055,-.32],[.03,1082,998,.18,.022,-.32],[.35,720,658,.26,.026,-.32],[.38,1082,998,.18,.011,-.32]],
 'voice-dry-ice':[[0,720,658,.26,.055,-.32],[.03,1082,998,.18,.022,-.32]],
 'voice-bridge':[[0,102,68,.69,.066,.52],[.10,204,119,.56,.02,.40],[.84,109,81,.34,.06,-.1],[1.32,238,157,.22,.04,-.66]],
 'voice-child':[[0,101,70,.6,.059,.53],[.67,108,81,.31,.049,-.11],[1.07,245,162,.23,.052,-.69],[1.13,355,245,.14,.019,-.7]],
 'voice-wool':[[0,180,123,.19,.058,-.4],[.28,110,70,.38,.043,.07]],
 'voice-light':[[0,214,229,.32,.035,-.42],[.36,313,335,.44,.036,.44]],
 'voice-shelter':[[0,264,263,.31,.042,-.3],[.36,222,221,.4,.04,.1],[.8,176,175,.6,.04,.32],[1.46,224,224,.78,.025,0]]};
export function playBone(ctx,bus,id){
 const voice=voices[id];if(!voice)return false;
 for(const [wait,from,to,seconds,weight,side] of voice){
  const tone=ctx.createOscillator(),gain=ctx.createGain(),at=ctx.currentTime+wait;
  tone.type=from>600?'triangle':'sine';tone.frequency.setValueAtTime(from,at);tone.frequency.exponentialRampToValueAtTime(to,at+seconds);
  gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(weight,at+Math.min(.04,seconds*.14));gain.gain.exponentialRampToValueAtTime(.0001,at+seconds);
  tone.connect(gain);const pan=ctx.createStereoPanner?.();
  if(pan){pan.pan.value=side;gain.connect(pan);pan.connect(bus);}else{gain.connect(bus);}
  tone.onended=()=>{tone.disconnect();gain.disconnect();pan?.disconnect();};tone.start(at);tone.stop(at+seconds+.025);
 }
 return true;
}
