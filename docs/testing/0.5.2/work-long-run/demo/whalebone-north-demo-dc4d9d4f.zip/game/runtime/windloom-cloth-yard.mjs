import {poly,line,oval} from './heelturn-cabins.mjs';
import {rigHazard} from './windloom-fight-art.mjs';
const scenes={'windloom-drying-bluff':'north','windloom-rime-field':'winter','windloom-slant-court':'harbor'};
const palettes={north:['#a9614e','#d9b78a','#a9896e'],winter:['#d0d7c7','#80a39e','#b9c4ac'],harbor:['#b77d59','#caa477','#8c7969']};
const wood='#6f5b48',thread='#d4c09b';
function workshop(c,q,w,h,sc){
 const co=palettes[sc];
 poly(c,[q(0,0),q(w,0),q(w,h),q(0,h)],co[2],wood);
 poly(c,[q(0,0),q(w,0),q(w,0,47),q(0,0,43)],co[1],wood);
 poly(c,[q(0,0),q(0,h),q(0,h,35),q(0,0,43)],co[2],wood);
 for(let a=.7;a<w;a+=.7)line(c,[q(a,.1),q(a,.1,44)],'#80765e',1);
 for(let a=.7;a<h;a+=.7)line(c,[q(.1,a),q(w-.1,a)],'#ab9877',1);
 for(let i=0;i<6;i++){
  const a=.2+w*.13*i;poly(c,[q(a,.2,45),q(a+w*.13,.2,45),q(a+w*.13,h*.42,35),q(a,h*.42,35)],i%2?co[0]:co[1],wood);
 }
 const [px,py]=q(w*.55,h*.32,21);oval(c,[px,py],8,3,'#a7af94');
 for(let j=0;j<4;j++){
  const u=.7+w*.12*j,v=h*.65;
  poly(c,[q(u,v,8),q(u+.55,v,8),q(u+.65,v+.36,7),q(u+.12,v+.37,7)],j%2?co[0]:co[1],wood);
 }
}
function frame(c,q,f,sc,s,t){
 const w=f.w-.35,h=f.h-.3,hi=sc==='harbor'?60:49,co=palettes[sc],b=s.flags['windloom-'+sc+'-done'],torn=s.flags['windloom-'+sc+'-scar'];
 for(const [x,y,z] of [[.25,.4,hi],[w-.5,.25,hi-6],[w-.48,h-.15,hi*.64],[.28,h-.12,hi*.67]]){line(c,[q(x,y),q(x,y,z)],wood,4.3);line(c,[q(x,y,z),q(x+.3,y+.65)],thread,1.1);}
 for(let i=0;i<7;i++){
  const u=(w-.8)*i/7+.3,v=(w-.8)*(i+1)/7+.3,sw=(b?1.4:4.2)*Math.sin(t*1.6+i*.4);
  const back=y=>hi-y*1.2,low=y=>hi*.54+y*.56+sw;
  const tip=torn&&i===5?low(u)+10:low(u)-3;
  poly(c,[q(u,.3,back(u)),q(v,.3,back(v)),q(v,h*.64,low(v)+5),q((u+v)/2,h-.12,tip),q(u,h*.63,low(u)+4)],i%2?co[0]:co[1],wood);
  line(c,[q(u,.31,back(u)),q((u+v)/2,h*.58,low(u)+7),q((u+v)/2,h-.12,tip)],thread,1);
 }
 for(let i=0;i<4;i++){const v=w*(.18+.18*i);line(c,[q(v,h*.7,hi*.58),q(v+.25,h+.23,2)],'#9d8a62',1.25);}
}
export function windCloth(c,p,map,f,s,t){
 const sc=scenes[map.id];if(!sc)return false;const q=(u,v,z=0)=>p(f.x+u,f.y+v,z);
 if(f.kind==='building')workshop(c,q,f.w-.16,f.h-.2,sc);
 else if(f.kind==='wl-frame')frame(c,q,f,sc,s,t);
 else if(f.kind==='wl-shadow'){
  for(let i=0;i<3;i++){const a=.2+i*1.25;poly(c,[q(a,.3),q(a+1.40,.48),q(a+.8,1.3),q(a+.13,1.06)],sc==='winter'?'#929d89':'#8b806b');}
 }else if(f.kind==='wl-gear'){
  for(let i=0;i<3;i++){const a=.25+i*1.14;poly(c,[q(a,.4,3),q(a+.75,.41,3),q(a+.76,1.05,3),q(a,1.05,3)],i===0?'#b4956b':'#8a987e',wood);line(c,[q(a,.7),q(a,.7,10+i*4)],wood,2);}
 }else if(f.kind==='path'||f.kind==='water'){
  for(let j=0;j<4;j++){const y=f.h*(j+.45)/4;line(c,[q(.12,y),q(f.w*.35,y+.035),q(f.w-.12,y)],f.kind==='water'?'#a8beb3':'#bda789',1);}
 }else return false;
 return true;
}
export function windSceneObject(c,x,y,t,e,s){
 const found=/^windloom-(north|winter|harbor)-fight$/.exec(e.id||'');if(!found)return false;
 if(s.flags['windloom-'+found[1]+'-done']){line(c,[[x-5,y],[x,y-2],[x+5,y]],'#d2b98e',1.1);return true;}
 c.save();c.translate(x,y);c.scale(.80,.80);rigHazard(c,0,0,t,found[1],0,'idle',false);c.restore();return true;
}
