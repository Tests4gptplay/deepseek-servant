// Original music for salt-market footsteps and the northern pilot's answering call.
// Offsets are in eighth notes. All pitches are semitones above each scene's tonic.
const saltMelody = [
 [[0,0,1.4],[2,3,.8],[3,7,1.8]], [[.5,5,1.3],[2.5,3,.7],[4,2,1.3]],
 [[0,-2,1.9],[3,0,.8],[4,3,1.4]], [[0,2,2.1],[3.5,-2,1.4]],
 [[0,5,1.6],[2,7,.7],[3,10,2.1]], [[1,8,.7],[2,7,.7],[4,5,1.5]],
 [[0,3,1.9],[3,2,1.1],[5,-2,.7]], [[0,0,3.6]]
];
const northMelody = [
 [[0,0,2.1],[3,7,1.5],[6,9,2.7]], [[1,7,1.8],[5,4,2.2]],
 [[0,2,2.5],[4,7,1.5],[7,11,1.5]], [],
 [[0,9,1.8],[3,12,1.5],[6,11,2.7]], [[1,7,2.6],[6,4,1.9]],
 [[0,2,2],[3,4,1.5],[7,0,2]], []
];
const saltBass = [0,-5,-2,-7,-5,-2,-5,0];
const northBass = [0,-5,2,-5,-3,-5,-7,0];
const pulses = {'salt-steps-low':.285,'salt-steps-high':.305,'north-no-answer':.355,'north-answer':.355};
export function regionalCue(map,state){
  if(map.act===3)return state.tide==='high'?'salt-steps-high':'salt-steps-low';
  if(map.act===4)return state.flags['remote-lit']?'north-answer':'north-no-answer';
}
export function regionalSeconds(name){
  if(!Object.hasOwn(pulses,name))return;
  return pulses[name]*(name.startsWith('salt')?6:10)*8*2;
}
export function regionalArrangement(ctx,bus,name){
  const pulse=pulses[name];
  if(!pulse)return;
  const salt=name.startsWith('salt'),wet=name==='salt-steps-high',answered=name==='north-answer';
  const length=salt?6:10,tonic=salt?174.614:146.832;
  const conductor=ctx.createGain(),live=new Set();
  conductor.gain.value=.81;conductor.connect(bus);
  let when=ctx.currentTime+.045,bar=0,timer,closed=false;
  function voice(t,pitch,duration,level,wave,pan=0,soft=false){
    const oscillator=ctx.createOscillator(),env=ctx.createGain();
    const stereo=typeof ctx.createStereoPanner==='function'?ctx.createStereoPanner():null;
    const attack=Math.min(duration*.24,soft?.11:.016);
    oscillator.type=wave;oscillator.frequency.setValueAtTime(tonic*2**(pitch/12),t);
    env.gain.setValueAtTime(.0001,t);env.gain.exponentialRampToValueAtTime(level,t+attack);
    env.gain.exponentialRampToValueAtTime(level*.48,t+duration*.62);env.gain.exponentialRampToValueAtTime(.0001,t+duration);
    oscillator.connect(env);
    if(stereo){stereo.pan.value=pan;env.connect(stereo);stereo.connect(conductor);}else env.connect(conductor);
    live.add(oscillator);
    oscillator.onended=()=>{live.delete(oscillator);oscillator.disconnect();env.disconnect();stereo?.disconnect();};
    oscillator.start(t);oscillator.stop(t+duration+.01);
  }
  function playBar(index,t){
    const k=index%8,second=index>=8;
    const melody=salt?saltMelody[k]:northMelody[k];
    const bass=(salt?saltBass:northBass)[k]-12;
    if(salt){
      voice(t,bass,pulse*(wet?3.4:1.8),.056,'sine',-.18,true);
      if(k!==7){voice(t+3*pulse,bass+7,pulse*1.35,.026,'triangle',.13,true);}
      for(const beat of (wet?[0,3.5]:[0,2,3,5])){
        if(k===7&&beat>0)break;
        voice(t+beat*pulse,beat%3===0?-5:2,.075,.023,'triangle',beat%3===0?-.42:.4);
      }
      for(const [offset,pitch,span] of melody){
        const step=t+offset*pulse;
        voice(step,pitch+(second&&k===4?2:0),span*pulse,.047,'triangle',-.11);
        if(!wet)voice(step+.008,pitch+12.01,.095,.012,'sine',-.16);
      }
      if((wet||second)&&[1,3,5,7].includes(k))voice(t+3.2*pulse,saltBass[k]+7,1.7*pulse,.029,'sine',.42,true);
    }else{
      if(k%4!==3)voice(t,bass,pulse*5.4,.055,'sine',-.08,true);
      for(const [offset,pitch,span] of melody){
        const step=t+offset*pulse;
        voice(step,pitch+5,span*pulse,.045,'sine',-.32,true);
        voice(step+.016,pitch+17.05,span*pulse*.73,.011,'triangle',-.32,true);
      }
      if(k===3||k===7){
        // Before the red mark is repaired the silent tacking space stays audible.
        if(answered)for(const [at,p] of [[.7,7],[3.25,4],[6.6,k===7?0:2]]){
          voice(t+at*pulse,p+5,pulse*(at>6?2.7:1.65),.039,'triangle',.46,true);
        }else voice(t+6*pulse,-12,pulse*1.5,.013,'sine',.32,true);
      }else if(second&&k===5){voice(t+7*pulse,7,2*pulse,.026,'sine',.36,true);}
    }
  }
  function advance(){
    if(closed)return;
    if(ctx.state==='running'){
      if(when<ctx.currentTime-.12)when=ctx.currentTime+.045;
      while(when<ctx.currentTime+.52){playBar(bar,when);bar=(bar+1)%16;when+=length*pulse;}
    }
    timer=setTimeout(advance,120);
  }
  advance();
  return ()=>{closed=true;clearTimeout(timer);const t=ctx.currentTime;conductor.gain.setTargetAtTime(.0001,t,.024);
    for(const osc of live){try{osc.stop(t+.15);}catch{}}setTimeout(()=>conductor.disconnect(),200);};
}
