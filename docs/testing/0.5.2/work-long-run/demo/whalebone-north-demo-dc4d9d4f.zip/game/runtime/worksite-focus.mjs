import {line,oval,poly} from './paint.mjs';
import {waterEye,sluice,ironEye,liftBasket} from './whale-rigging.mjs';
import {redArm,transitMark,backWindow} from './winter-pilot-rig.mjs';
import {skiff,handcart} from './harbor-crafts.mjs';
import {bed} from './voyage-shapes.mjs';
const titles={'split-cistern':'两口井的剖面','shiver-bars':'领航人的三点视线','red-beacon':'远近两盏红灯','blow-stoop':'鲸肩和固定栈桥','lung-baths':'热锅与活索','bucket-gable':'灰斗与垂线','dry-share':'病铺和盐水罐','stove-lip':'落脚板和解结眼','soup-transom':'挡汤闸的背面','low-sill':'窄口车辙','ladle-cut':'撤离舟的舷口'};
export const focalTitle=id=>titles[id]||'';
export function surveyFrame(c,w,h,m,s,focus,rise,t,blend){
 if(!focus||focus.map!==m.id||!titles[m.id])return;
 const W=Math.min(404,w-16),H=Math.min(134,h*.22),cx=w<710?w*.50:w*.74,cy=w<710?Math.min(121,h*.18):Math.min(119,h*.18);
 c.save();c.translate(cx-W*.5,cy-H*.32);
 const grad=c.createLinearGradient(0,0,W,H);grad.addColorStop(0,'#203e41f2');grad.addColorStop(1,'#28474be8');c.fillStyle=grad;c.fillRect(0,0,W,H);c.strokeStyle='#c0aa7d';c.strokeRect(.5,.5,W-1,H-1);
 c.fillStyle='#f3dfab';c.font='bold 14px serif';c.fillText(titles[m.id],12,18);
 const f=s.flags,scale=Math.min(1.12,W/306),cy2=H*.65;
 function pos(x,y,z=0){return [W*.50+(x-y)*17*scale,cy2+(x+y)*5*scale-z*.8*scale];}
 const label=(xx,txt)=>{c.font='bold 13px sans-serif';c.textAlign='center';c.fillStyle='#e5dbbf';c.fillText(txt,W*xx,H-7);c.textAlign='left';};
 if(m.id==='split-cistern'){waterEye(c,pos,-3.9,0,false,!!f['rinse-out']);waterEye(c,pos,3.1,0,true,!!f['rinse-out']);sluice(c,pos,.1,.9,blend('rinse-out'));label(.27,'低盐井 · 暗沿');label(.7,'高淡井 · 白沿');}
 else if(m.id==='shiver-bars'){transitMark(c,pos,-4.7,-.1,true,s.tide);backWindow(c,pos,.1,-.6);skiff(c,pos,4.5,0,s.tide,t);label(.25,'黑礁圆孔');label(.53,'固定窗槛');label(.79,'船上双钉');}
 else if(m.id==='red-beacon'){redArm(c,pos,-2.8,1,blend('outer-arm'),false);redArm(c,pos,3.6,0,blend('remote-lit'),true);label(.29,'海侧远臂');label(.72,'油廊近臂');}
 else if(m.id==='blow-stoop'){const Y=cy2-8-rise*.50,A=W*.17,B=W*.59;
  c.fillStyle='#6e9184';c.beginPath();c.moveTo(W*.08,cy2+10);c.quadraticCurveTo(W*.20,Y-27,W*.49,Y);c.lineTo(W*.54,cy2+15);c.fill();
  for(let j=0;j<4;j++)line(c,A+j*8,Y-5,A+5+j*8,Y-8,'#adc0a7',1.7);
  line(c,A+18,Y,B,cy2-8,'#e5c58d',5);for(let i=0;i<4;i++)line(c,B+i*13,cy2-8,B+i*13,cy2+10,'#a89168',3);
  const yy=cy2+(s.tide==='high'?0:9);line(c,W*.08,yy,W*.93,yy,'#91bfbb',1.4);label(.29,'鲸肩');label(.69,s.tide==='high'?'固定岸 · 涨潮':'固定岸 · 低潮');}
 else if(m.id==='dry-share'||m.id==='ladle-cut'){bed(c,pos,-3.7,-.4,true);skiff(c,pos,3.8,0,s.tide,t,true);label(.27,'卧铺');label(.72,'船舷');}
 else if(m.id==='low-sill'){handcart(c,pos,-2.3,.1,false);ironEye(c,pos,3.1,.2,false,true);label(.32,'挡车轮');label(.72,'回拖眼');}
 else if(m.id==='soup-transom'){liftBasket(c,pos,-3,0,f['transom-grit']?17:4,true);sluice(c,pos,2.8,-.2,!!f['transom-open']);label(.29,'红砂收斗');label(.70,'两向分闸');}
 else{ironEye(c,pos,-3.7,0,true,false);liftBasket(c,pos,3.0,0,f['bucket-rigged']||f['bath-slack']?17:4,!!(f['bucket-rigged']||f['bath-slack']));label(.27,'留在岸上的眼');label(.72,'能移动的吊索');}
 c.restore();
}
