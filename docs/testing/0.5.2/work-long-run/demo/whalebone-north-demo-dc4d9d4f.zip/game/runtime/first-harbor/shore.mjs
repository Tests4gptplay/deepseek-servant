import {arc,rand} from '../paint.mjs';
import {poly,line,oval,box,plate,stroke,face,sag,stone,timber} from './form.mjs';
import {vapor} from './trades.mjs';
function crown(c,x,y,rx,ry,k,t){
 const wind=Math.sin(t*.46+k*.37)*1.3;const px=x+wind,leaf=(dx,dy,r,a,col)=>{
  c.beginPath();c.moveTo(px+dx-r, y+dy);c.bezierCurveTo(px+dx-r*.85,y+dy-a*.85,px+dx-r*.34,y+dy-a,px+dx,y+dy-a*.77);
  c.bezierCurveTo(px+dx+r*.40,y+dy-a*1.17,px+dx+r*.85,y+dy-a*.58,px+dx+r,y+dy-a*.24);
  c.bezierCurveTo(px+dx+r*.62,y+dy+a*.34,px+dx-r*.55,y+dy+a*.43,px+dx-r,y+dy);c.fillStyle=col;c.fill();
 };
 leaf(0,0,rx,ry,'#49665b');leaf(-rx*.27,-ry*.11,rx*.72,ry*.87,'#68836b');leaf(rx*.24,-ry*.30,rx*.68,ry*.76,'#788d70');
 for(let n=0;n<8;n++){const xx=(rand(k,n)-.5)*rx*1.4,yy=(rand(n,k)-.5)*ry*.55;line(c,px+xx,y+yy,px+xx+2+rand(n,k+1)*3,y+yy-1,'#bac09474',.9);}
}
export function shadeTree(c,p,x,y,t){
 box(c,p,x-.5,y-.33,1.15,.66,-3,5,stone);plate(c,p,x-.38,y-.23,.91,.46,2.25,'#726e52');
 const [a,b]=p(x,y,2);c.save();c.translate(a,b);c.scale(1.46,1.36);
 oval(c,6,2,29,6,'#40564932');c.beginPath();c.moveTo(-4,0);c.bezierCurveTo(-3,-11,2,-21,-3,-34);
 c.lineTo(1,-37);c.bezierCurveTo(5,-28,7,-24,5,-18);c.bezierCurveTo(2,-10,4,-5,5,-1);c.closePath();c.fillStyle='#6b6350';c.fill();
 for(const [u,v,X,Y] of [[0,-21,-12,-34],[0,-29,10,-43],[-6,-30,-24,-34],[7,-35,19,-39]]){line(c,u,v,X,Y,'#655e49',3.7);line(c,u,v-1,X,Y-1,'#a49469',1.15);}
 for(const [u,v,U,V] of [[-10,-33,-32,-38],[-3,-37,-17,-51],[13,-40,27,-48]])line(c,u,v,U,V,'#897d59',1.8);
 crown(c,-29,-40,12,8,82,t);crown(c,26,-48,13,9,74,t);crown(c,-13,-50,13,9,79,t);
 crown(c,-19,-35,16,12,34,t);crown(c,14,-42,19,13,28,t);crown(c,-2,-46,21,15,44,t);crown(c,-12,-39,17,9,71,t);c.restore();
}
export function harborBoat(c,p,x,y,w,h,s,t,funeral=false){
 const z=(s.tide==='high'?3:-4)+Math.sin(t*.88+x)*.65;
 const A=(u,v,l=0)=>p(x+u*w,y+v*h,z+l),plan=(pts,fill,edge)=>poly(c,pts.map(q=>A(...q)),fill,edge);
 const shape=[[0,.53,3],[.14,.12,3],[.78,.04,4],[1,.37,7],[.93,.69,5],[.70,1,3],[.20,.96,2]];
 plan(shape.map(([u,v,z])=>[u+.02,v+.10,z-6]),'#436b6b80');
 plan([[0,.53,3],[.20,.96,2],[.70,1,3],[.93,.69,5],[1,.37,7],[.93,.74,-2],[.70,.97,-6],[.20,.92,-5],[.065,.63,-2]],funeral?'#705844':'#695345','#4f5a51');
 plan(shape,'#b99465','#60523f');plan([[.08,.48,4],[.20,.20,4],[.75,.12,5],[.91,.40,6],[.81,.69,4],[.65,.86,4],[.22,.82,3]],funeral?'#947650':'#8f7957','#7a654e');
 for(let i=0;i<7;i++){const u=.19+i*.085;line(c,...A(u,.18,4.5),...A(u+.01,.83,3.8),'#c1a174',1.4);}
 for(const u of [.25,.68]){line(c,...A(u,.12,5),...A(u,.90,4.5),'#645743',3.0);line(c,...A(u,.12,6.1),...A(u,.90,5.6),'#ccae7c',1.4);}
 if(funeral){
  const full=s.flags['coffin-aboard'];if(full){box(c,p,x+w*.35,y+h*.37,w*.38,h*.35,z+5,6,['#ddc59d','#967a59','#725d4c']);plan([[.35,.37,12],[.73,.37,12],[.71,.72,12],[.38,.72,12]],'#ddcfb0','#8d7c60');for(const u of [.41,.66])line(c,...A(u,.37,13),...A(u,.72,13),'#a89772',1.5);}
  else{plan([[.35,.38,5],[.70,.38,5],[.69,.70,5],[.37,.69,5]],'#d6c7a6','#a69270');}
  for(const u of [.16,.81]){line(c,...A(u,.23,5),...A(u,.23,18),'#887454',1.8);const q=A(u,.23,19);oval(c,...q,2.6,3.2,'#ddbc78');}
 }else{
  box(c,p,x+w*.36,y+h*.29,w*.23,h*.44,z+4,5,timber);const q=A(.5,.48,11);oval(c,...q,7,3.8,'#796c55');vapor(c,q[0],q[1]-2,t,'#f3e7cad6',1.12);const a=A(.24,.37,12),b=A(.71,.37,12),d=A(.69,.91,12),e=A(.25,.91,12);poly(c,[a,b,d,e],'#b3956b','#78664d');for(const u of [.27,.63]){line(c,...A(u,.87,12),...A(u,.87,4),'#73634e',1.8);const z=A(u+.025,.73,13);oval(c,...z,3.8,1.6,'#e2c9a3');}
  const pot=A(.45,.43,17);oval(c,pot[0],pot[1],8.5,4.8,'#515d56');oval(c,pot[0],pot[1]-2.8,8.4,3.7,'#a18d69');oval(c,pot[0],pot[1]-3.3,6.9,2.4,'#c4a668');vapor(c,pot[0],pot[1]-4,t,'#efe9cfb0',.94);
  for(const [u,z] of [[.18,25],[.71,28]])line(c,...A(u,.20,4),...A(u,.20,z),'#806d50',1.8);line(c,...A(.18,.20,25),...A(.71,.20,28),'#ad9370',1.3);for(let j=0;j<3;j++){const q=A(.24+j*.085,.21,22);oval(c,...q,1.35,3.5,'#c6b48a');}
  for(const u of [.25,.69]){const q=A(u,.54,6);oval(c,...q,4.8,2.3,'#d5b98d');}
 }
 for(let i=0;i<4;i++){const q=A(.18+i*.20,1.0+Math.sin(t*.6+i)*.025,-3);line(c,q[0]-3,q[1],q[0]+6,q[1],'#c3d3bcaa',1);}
}
export function steps(c,p,x,y,axis,up,s,t){
 const horizontal=axis==='x',at=(a,b,z)=>horizontal?p(x+a,y+b,z):p(x+b,y+a,z);
 const w=.88,run=1.85,start=-run*.5;for(let n=0;n<7;n++){
  const a=start+n*run/7,A=at(a,-w*.5,up*(n-3)*1.8+.8),B=at(a,w*.5,up*(n-3)*1.8+.8);
  const C=at(a+run/7,w*.5,up*(n-3)*1.8+.8),D=at(a+run/7,-w*.5,up*(n-3)*1.8+.8);
  poly(c,[A,B,C,D],n%2?'#a89170':'#b8a282','#7a7562');line(c,...A,...B,'#dac7a0',1.4);
 }
 const posts=[start+.03,start+run-.03];for(const a of posts)for(const b of [-w*.57,w*.57])line(c,...at(a,b,up*a*7),...at(a,b,up*a*7+15),'#746953',2.8);
 for(const b of [-w*.57,w*.57])line(c,...at(posts[0],b,up*posts[0]*7+15),...at(posts[1],b,up*posts[1]*7+15),'#b29e76',2.05);
}
