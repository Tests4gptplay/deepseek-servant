import {poly,line,oval} from '../heelturn-cabins.mjs';
const lost='#394c4c',gold='#c7a473',skin='#b98d70',cold='#83aaa0';
const people={
 'whalefall-listener':'caller','whalefall-wet-sister':'sister','whalefall-baker':'baker','whalefall-shed-clue':'maker',
 'whalefall-tin-mender':'tinner','whalefall-stationer':'keeper','whalefall-knot-wool':'keeper','whalefall-share-oil':'baker','whalefall-sand-kid':'child',
 'whalefall-waiting-oars':'keeper','whalefall-pass-the-chest':'oars','whalefall-find-the-baskets':'baker','whalefall-bring-the-fish':'maker'
};
const colors={caller:['#405e66','#7e8582'],baker:['#8b6049','#cb9f69'],maker:['#5b6864','#a48a67'],keeper:['#65736a','#ccb494'],tinner:['#596873','#a4a4a0'],oars:['#6e826c','#b39b70'],child:['#857c59','#c7b17b']};
function basin(c,t){
 const move=Math.sin(t*.9)*.7;
 oval(c,[0,1],14,4,'#284c51');oval(c,[1,-.4],12,2.4,'#4d8483');
 poly(c,[[-9,-3],[-7,-12],[-3,-17],[2,-18],[8,-14],[9,-3],[5,-1],[-5,-1]],'#678c86',lost);
 oval(c,[1,-18],4.7,5.3,'#9ebaae');poly(c,[[-4,-18],[-5,-23],[-2,-26],[3,-24],[5,-20],[1,-22]],'#455957',lost);
 poly(c,[[-3,-19],[-9,-23],[-8,-19],[-7,-15],[-4,-14]],'#7e9e8f','#4b6962');
 for(let i=0;i<3;i++)line(c,[[-5,-19+i],[-8,-21+i*2]],'#b5bf9f',.8);
 line(c,[[-6,-11],[-11,-6],[-16,-8+move]],'#8fae9b',2.7);
 for(let i=0;i<3;i++)line(c,[[-16,-8+move],[-19-i,-9-i*1.5+move]],'#a2b66f',1.3);
 line(c,[[4,-9],[9,-5],[12,-7]],'#8fae9b',2.3);line(c,[[-11,0],[-5,1],[2,1],[9,-.5]],'#c3d6bd',1.45);
 oval(c,[2.6,-18.7],.65,.65,lost);
}
function clothes(c,type,t){
 const [coat,trim]=colors[type],kid=type==='child';if(kid)c.scale(.78,.78);
 oval(c,[0,1],7.8,2.6,'#45504a55');
 for(const x of [-3.5,3.5]){line(c,[[x,-12],[x*1.08,-1],[x+2,.1]],'#414943',3.2);}
 poly(c,[[-6,-23],[-1,-26],[5,-24],[7,-19],[7,-12],[8,-7],[2,-5],[-7,-8],[-5,-17]],coat,lost);
 poly(c,[[-5,-21],[-1,-24],[5,-22],[3,-19],[-.5,-11],[-4,-9],[-6,-13]],trim);
 oval(c,[.6,-28],4.5,5.3,type==='caller'?'#a5b7a3':skin);
 if(type==='caller'){
  poly(c,[[-6,-29],[-4,-34],[1,-34],[5,-31],[2,-29],[-3,-30],[-7,-23]],'#5a706c',lost);
  poly(c,[[-3,-27],[-8,-31],[-7,-26],[-5,-24]],'#a7b293','#5d796e');
  for(let i=0;i<3;i++)line(c,[[-5,-25+i],[-8,-28+i*1.2]],'#c9c3a7',1);
  line(c,[[-6,-16],[-10,-11],[-13,-13]],'#a2ad97',2.5);oval(c,[-13,-14],4.0,1.8,'#cdb78b');line(c,[[-16,-13],[-14,-11],[-10,-12]],'#8c7959',1.2);
 }else{
  poly(c,[[-5,-28],[-5,-32],[-1,-34],[3,-33],[5,-29],[1,-30],[-3,-28]],'#584b40');
  if(type==='baker'){poly(c,[[-7,-30],[-5,-34],[0,-36],[4,-34],[6,-30],[1,-32]],'#bb9a76');oval(c,[9,-14],5.3,3.1,'#ad774c');for(let i=0;i<3;i++)line(c,[[6+i*2,-16],[7+i*2,-13]],'#d9b486');}
  if(type==='keeper'||type==='oars'){line(c,[[6,-5],[10,-33]],'#8a7759',2.2);poly(c,[[9,-31],[10,-39],[13,-41],[12,-32]],'#b69b70',lost);}
  if(type==='tinner'){line(c,[[-6,-18],[-10,-10]],'#c2b79b',2);poly(c,[[4,-16],[9,-22],[12,-19],[8,-14]],'#96b0ac',lost);}
  if(type==='maker'){line(c,[[-7,-16],[-11,-6]],'#a5906c',2.3);poly(c,[[-12,-8],[-7,-5],[-10,-2],[-14,-6]],'#7d918b',lost);}
 }
 oval(c,[2.5,-28.4],.66,.64,lost);line(c,[[1,-25.8],[3,-25.5]],'#906e57',.74);
}
export function shoreFamily(c,a,b,t,e){
 if(!e.id.startsWith('whalefall-'))return false;
 const who=people[e.id];if(!who)return false;c.save();c.translate(a,b);c.scale(1.08,1.08);
 if(who==='sister')basin(c,t);else clothes(c,who,t);c.restore();return true;
}
