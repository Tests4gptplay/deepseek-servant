import {poly,line,oval,arc} from './paint.mjs';
import {box,wood,parchment,plate,mast} from './voyage-shapes.mjs';

function rack(c,p,x,y,night,loaded){
 const [a,b]=p(x,y);box(c,p,x-1.1,y-.22,2.25,.46,0,5,wood);
 line(c,a-32,b+1,a-32,b-42,'#685545',5);line(c,a+32,b+1,a+32,b-42,'#685545',5);line(c,a-33,b-41,a+34,b-41,'#c1a075',5);
 for(let i=0;i<7;i++){const xx=a-25+i*8,yy=b-32+i%2*2;line(c,xx,b-40,xx,yy,'#bba68a',1.9);arc(c,xx+2.5,yy,2.7,0,Math.PI,'#554a40',1.7);
  if(i===6&&loaded){poly(c,[[xx-4,yy+3],[xx+4,yy+3],[xx+3,yy+12],[xx-2,yy+13]],'#c38456','#5d5146');line(c,xx-1,yy+6,xx+2,yy+6,'#dfc88d',1.1);}}
 poly(c,[[a-33,b-41],[a-21,b-41],[a-22,b-26],[a-26,b-29],[a-31,b-25]],night?'#566575':'#e6dac0','#726755');
}
function press(c,p,x,y,hot,stamped){
 const [a,b]=p(x,y);box(c,p,x-.7,y-.47,1.3,.92,3,8,wood);
 poly(c,[[a-18,b-10],[a-12,b-19],[a+15,b-16],[a+11,b-8]],'#ddd3b2','#6e6654');
 line(c,a-12,b-12,a-12,b-44,'#514f49',5);line(c,a-12,b-43,a+14,b-42,'#9d8b69',5);line(c,a+10,b-43,a+10,b-21,'#79664d',3);
 const drop=stamped?7:0;poly(c,[[a+3,b-26+drop],[a+17,b-26+drop],[a+19,b-19+drop],[a+1,b-19+drop]],hot?'#b47653':'#7f9d9c','#565a50');
 line(c,a-13,b-39,a+22,b-(stamped?30:50),'#604f43',3);oval(c,a+23,b-(stamped?30:50),3,2,'#bc9c70');
 if(stamped)arc(c,a-1,b-14,4,0,Math.PI*1.7,'#9e5d48',1.6);
}
function tactile(c,p,x,y,read){
 const [a,b]=p(x,y);box(c,p,x-.91,y-.48,1.8,.82,2,8,wood);
 poly(c,[[a-27,b-13],[a-24,b-32],[a+22,b-34],[a+24,b-14]],'#c8a576','#5d5041');
 for(let row=0;row<2;row++){const widths=row?[4,4,9]:[4,9,4];let xx=a-17;
  for(const w of widths){line(c,xx,b-26+row*8,xx+w,b-26+row*8,read?'#eadbb2':'#e0bc88',3);line(c,xx,b-24+row*8,xx+w,b-24+row*8,'#78644e',1.6);xx+=w+5;}}
 line(c,a+16,b-30,a+16,b-16,'#75644e',1.2);
}
function stake(c,a,b,outside,marked,t,high){
 const k=outside?1:-1;oval(c,a,b+3,29,5,'#64909385');c.save();c.translate(a,b);
 poly(c,[[-7,2],[-5,-43],[1,-49],[6,-45],[6,3]],'#886748','#4d5248');line(c,-3,-40,-1,-4,'#c3a377',2);
 for(let i=0;i<(outside?3:6);i++)line(c,-6,-9-i*5,1,-11-i*5,'#e3c99b',1.6);
 oval(c,2,-36,4,3,'#413f38');arc(c,2,-36,6,0,6.3,marked?'#f3d28c':'#b9a07b',2);
 c.beginPath();c.moveTo(2,-36);c.quadraticCurveTo(k*24,-(high?35:11)+Math.sin(t*1.4)*2,k*45,-(high?30:3));c.strokeStyle='#ac936e';c.lineWidth=3;c.stroke();c.lineWidth=1;
 if(marked){for(let j=0;j<3;j++)line(c,k*(12+j*4),-30+j,k*(13+j*4),-35+j,'#dcbd86',1.5);}c.restore();
}
function swirl(c,a,b,t,turned){
 for(let j=0;j<4;j++){const x=a+(j-1.5)*15,y=b+Math.sin(t*.8+j)*3;c.save();c.translate(x,y);c.scale(1,.42);arc(c,0,0,8+j*.7,turned?.7:-2.4,turned?4.7:1.5,'#b7d1bd',1.7);c.restore();}
}
export function fanFish(c,x,y,t,outward=false,scale=1){
 c.save();c.translate(x,y);c.scale(scale,scale);
 for(const [i,dx,dy] of [[0,-15,-4],[1,12,-11],[2,2,2]]){
  c.save();c.translate(dx+Math.sin(t*1.4+i)*2,dy);if(i===1)c.scale(-1,1);
  const spread=outward?13:6,fin='#79a29b';
  poly(c,[[1,-4],[5,-8],[14,-8],[12,-4],[19,-2],[9,1],[2,1],[-7,-1],[-12,1],[-14,-3],[-9,-4]],'#536f71','#374e51');
  poly(c,[[-5,-3],[-12,-spread-4],[-17,-spread+1],[-18,1],[-14,spread-2],[-4,0]],fin,'#47666c');
  for(const y2 of [-spread,-spread/2,1,spread-4])line(c,-5,-2,-15,y2,'#c7c2a2',.9);oval(c,10,-5,1.5,1.5,'#ead19a');c.restore();
 }c.restore();
}
function shelter(c,p,f,night,loaded){
 const x=f.x,y=f.y,w=f.w||3,h=f.h||2;
 // The front stays open to show the two shifts' different hooks.
 const v=(i,j,z)=>p(x+.2+i*(w-.4),y+.2+j*(h-.4),z);
 for(const i of [0,1])for(const j of [0,.72])line(c,...v(i,j,1),...v(i,j,47),'#77674f',3.8);
 poly(c,[v(0,-.02,46),v(1,-.02,46),v(1,.23,57),v(0,.23,57)],night?'#73858a':'#b1a18a','#756e5d');
 poly(c,[v(0,.23,57),v(1,.23,57),v(1,.62,46),v(0,.62,46)],night?'#8c9a96':'#c8b18b','#7f7663');
 for(let i=0;i<7;i++)line(c,...v(i/7,.23,57.2),...v(i/7,.62,46.2),night?'#b1b7ac':'#dfc9a0',1.1);
 shelfRail(c,p,x+.45,y+h*.62,w-.9);rack(c,p,x+w*.5,y+h*.71,night,loaded);
 for(let j=0;j<3;j++)box(c,p,x+.5+j*.74,y+h*.28,.6,.65,0,9+j%2*3,wood);
}
function shelfRail(c,p,x,y,w){
 for(const j of [0,.34])line(c,...p(x,y+j),...p(x+w,y+j),'#706a59',2);
 for(let i=0;i<=w;i+=.48)line(c,...p(x+i,y-.05),...p(x+i,y+.39),'#9b896b',1.1);
}
export function shoalWater(c,p,map,s,t){
 if(map.id!=='mat-inlet')return;
 const edge=[[11.7,9.55],[12.7,8.96],[15.3,9.1],[16.85,10.02],[17,11.2],[15.5,12.06],[12.74,11.8],[11.63,10.8]];
 const ring=(sx,sy)=>edge.map(([x,y])=>p(14+(x-14)*sx,10.5+(y-10.5)*sy,.7));
 poly(c,ring(1.05,1.07),'#b3ac89');poly(c,ring(1,1),'#688f91');poly(c,ring(.85,.8),'#597c82');
 for(let i=0;i<16;i++){const x=12.8+i%5*.57,y=9.8+Math.floor(i/5)*.36,[a,b]=p(x,y,.9);
  line(c,a-4+Math.sin(t+i)*1.7,b,a+4,b-.6,i%3?'#8eaaa2':'#bac2ac',1.25);}
 const [a,b]=p(15.2,10.72);for(let i=0;i<10;i++)oval(c,a+(i%4)*3.5,b+Math.floor(i/4)*2,2.3,1.3,'#d6c7a6');
}
export function exchangeFeature(c,p,map,f,s,t){
 const {id}=map,x=f.x+(f.w||1)*.5,y=f.y+(f.h||1)*.55;
 if(id==='transit-shed'&&f.kind==='crate'){shelter(c,p,f,f.x>10,!!s.flags['seventh-hook']);return true;}
 if(id==='ticket-works'&&f.kind==='crate'){press(c,p,x,y,f.x<15,!!s.flags['wax-withdrawn']);return true;}
 if(id==='blind-window'&&f.kind==='crate'){tactile(c,p,x,y,!!s.flags['board-proved']);return true;}
 if((id==='outer-spar'||id==='inner-stake')&&f.kind==='wall'){stake(c,...p(x,y),id==='outer-spar',!!s.flags[id==='outer-spar'?'relay-outside':'relay-inside'],t,s.tide==='high');return true;}
 return false;
}
export function exchangeItem(c,p,map,e,s,t){
 const x=e.x+.5,y=e.y+.5,[a,b]=p(x,y),f=s.flags;
 switch(e.id){
 case 'lay-warm':case 'lay-cold':case 'release-wax':press(c,p,x,y,e.id==='lay-warm',!!f[e.action.id]);return true;
 case 'board-test':case 'board-letter':tactile(c,p,x,y,!!f['board-proved']);return true;
 case 'seventh-hook':rack(c,p,x,y,false,!!f['seventh-hook']);return true;
 case 'call-day-shift':case 'call-night-shift':mast(c,p,x,y,31,e.id==='call-day-shift'?'#eee0ba':'#647181',t,Number(!!f[e.id==='call-day-shift'?'salt-day':'salt-night']));return true;
 case 'transfer-slot':case 'new-goods-slot':box(c,p,x-.5,y-.38,1.0,.7,1,9,wood);parchment(c,a,b-9,+(e.id==='transfer-slot'),!!f[e.id==='transfer-slot'?'coded-transfer':'coded-new']);return true;
 case 'outer-observe':case 'inner-observe':case 'inner-answer':case 'outer-answer':stake(c,a,b,e.id.startsWith('outer'),!!f[e.action.id],t,s.tide==='high');return true;
 case 'reverse-line':swirl(c,a,b+8,t,!!f['eddy-return']);stake(c,a-10,b-2,false,!!f['eddy-return'],t,false);return true;
 case 'old-mat':case 'float-slat':{const on=!!f['fan-slat'];plate(c,p,x-.65,y-.42,1.5,.88,on?8:1,'#a7956d','#6d7061');for(let i=0;i<8;i++)line(c,...p(x-.62+i*.18,y-.38,on?10:2),...p(x-.62+i*.18,y+.46,2),'#665d47',1.25);return true;}
 case 'fan-standoff':for(let j=0;j<6;j++)oval(c,a-15+(j%3)*5,b+4+Math.floor(j/3)*2,2.5,1.5,'#d9c9a0');fanFish(c,a+(f['shoal-clear']?15:0),b-5,t,s.tide==='high',.9);return true;
 default:return false;
 }
}
