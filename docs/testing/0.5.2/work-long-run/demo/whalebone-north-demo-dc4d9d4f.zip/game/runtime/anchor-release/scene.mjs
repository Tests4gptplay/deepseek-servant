import {poly,line,oval} from '../paint.mjs';
import {incoming,engine} from './forged.mjs';
import {station,pin} from './hands.mjs';
import {evacuation} from './evacuate.mjs';
export {deck,architecture} from './deck.mjs';
const sites=new Set(['anchor-yard','ratchet-loft','weir-sleeve','flood-stair','safe-keel','lee-cutter','dry-court','salt-lane']);
const stations=new Set(['mara-shoe','ivo-bridle','selene-vent','mira-chalk','mara-floodgate']);
export const anchorCue=id=>stations.has(id)||['bran-unpin','cut-ramp','press-workers','sling-wards','set-stretcher','count-first','salt-workers-berth'].includes(id);
export function anchorItem(c,p,m,e,s,t,focus,blend,battle){
 if(!sites.has(m.id))return false;const [a,b]=p(e.x+.5,e.y+.5),f=s.flags;
 if((m.id==='anchor-yard'||m.id==='ratchet-loft')&&stations.has(e.id)){
  station(c,a,b,e.id,f,t,!battle);return true;
 }
 if(m.id==='ratchet-loft'){
  if(e.id==='clutch-fight'){engine(c,a+31,b-12,t,'white','ram',!!f['clutch-still'],1.03);return true;}
  if(e.id==='bran-unpin'){pin(c,a,b,f,focus?.id,blend('bran-unpinned'));return true;}
 }
 if(m.id==='weir-sleeve'&&e.id==='weir-cup'&&f['clutch-still']){incoming(c,a+31,b-4,t,f['weir-proof']);return false;}
 if(f['harbor-tilted']&&((m.id==='lee-cutter'&&e.id==='set-stretcher')||(m.id==='safe-keel'&&e.id==='salt-workers-berth')))return true;
 return evacuation(c,a,b,e.id,f,t);
}
export function anchorPlaces(c,p,m,s,t,ordered){
 if(!s.flags['harbor-tilted'])return;
 const id=m.id==='lee-cutter'?'set-stretcher':m.id==='safe-keel'?'salt-workers-berth':null;
 if(!id)return;const e=m.entities.find(q=>q.id===id);if(!e)return;
 const [a,b]=p(e.x+.5,e.y+.5);ordered.push([e.x+e.y+4.7,()=>evacuation(c,a,b,id,s.flags,t)]);
}
export function chamberLight(c,w,h,m){
 if(m.id!=='ratchet-loft'&&m.id!=='weir-sleeve')return;
 const shade=c.createLinearGradient(0,0,w,h*.28);
 shade.addColorStop(0,'#243d421e');shade.addColorStop(.46,'#fee8ae08');shade.addColorStop(1,'#233e4b2f');c.fillStyle=shade;c.fillRect(0,0,w,h);
}
