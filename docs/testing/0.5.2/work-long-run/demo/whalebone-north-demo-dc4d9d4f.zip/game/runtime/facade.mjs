import {line,poly,oval,rand,seed} from './paint.mjs';
export function facade(c,f,pos,top,rise=19){
 const w=f.w||2,h=f.h||2,k=seed(f.label||f.kind);
 const n=Math.max(4,Math.min(14,Math.round(w*2)));
 for(let r=1;r<=5;r++){
   const t=r/6,v=h*(.50+.53*t),z=top+rise-(rise+1)*t;
   for(let i=0;i<n;i++){
     let u=w*(i+(r%2)*.4)/n;if(u>w)continue;
     const end=Math.min(w+.07,u+w*.92/n);
     line(c,...pos(u,v,z),...pos(end,v,z),'#d2b48c55',.8);
     if(rand(i+k,r)>.55)line(c,...pos(u,v,z),...pos(u,v-h*.055,z+2),'#483f403f',.7);
   }
 }
 const windows=Math.max(1,Math.floor(h)-1);
 for(let j=0;j<windows;j++){
   const y=h*(j+.5)/windows,d=Math.min(.42,h/windows*.48),height=top*.21;
   const side=(a,b,dy,dz,fill)=>poly(c,[pos(w,a,b),pos(w,a+dy,b),pos(w,a+dy,b+dz),pos(w,a,b+dz)],fill);
   side(y,top*.37,d,height,'#586d68');
   side(y+.035,top*.40,d*.26,height*.63,'#a1aaa0');
   line(c,...pos(w,y-.05,top*.34),...pos(w,y+d+.07,top*.34),'#767a66',2);
   line(c,...pos(w,y+d*.55,top*.37),...pos(w,y+d*.55,top*.58),'#c5ba97',.9);
 }
 // Canvas cloth is stretched between two points on the waterfront wall.
 const begin=pos(w*.09,h,top*.72),end=pos(w*.47,h,top*.72);
 const cloth=/殓|葬|守台/.test(f.label||'')?'#eae0c3':(/秤|粮|税/.test(f.label||'')?'#a7614e':'#77918a');
 poly(c,[begin,end,[end[0]-7,end[1]+8],[begin[0]-7,begin[1]+8]],cloth,'#747c6d');
 for(let i=0;i<6;i++){const a=i/6,b=(i+1)/6;
  const x=begin[0]+(end[0]-begin[0])*a-7,y=begin[1]+(end[1]-begin[1])*a+8;
  const xx=begin[0]+(end[0]-begin[0])*b-7,yy=begin[1]+(end[1]-begin[1])*b+8;
  poly(c,[[x,y],[xx,yy],[xx,yy+3],[(x+xx)/2,(y+yy)/2+4],[x,y+3]],i%2?cloth:'#dbcea7');
 }
 const sign=pos(w*.66,h,top*.57);
 line(c,sign[0],sign[1],sign[0]-11,sign[1]+1,'#5b665a',1.4);
 line(c,sign[0]-8,sign[1]+1,sign[0]-8,sign[1]+5,'#6d705a');
 poly(c,[[sign[0]-13,sign[1]+5],[sign[0]-3,sign[1]+4],[sign[0]-3,sign[1]+12],[sign[0]-12,sign[1]+13]],'#74674f','#4f5e52');
 oval(c,sign[0]-8,sign[1]+8,2.4,1.1,'#d8bf83');
}
