import {begin,settle} from './battle.mjs';
import {setCombFight,combMove,listeningCue} from '../rules/comb-turn.mjs';
export function combDuel(ctx,e,id,close){
  const {world,state,ui,sound}=ctx,s=state.player;
  const canvas=ui.canvas,done=()=>{state.battle=null;delete canvas.dataset.combPhase;delete canvas.dataset.combSide;delete canvas.dataset.combActor;delete canvas.dataset.combLane;close();};
  function start(){state.battle=setCombFight(begin(world,s,{...world.encounters[id],entityId:e.id}));ctx.sync();sound('battle');show();}
  function collect(){
    const b=state.battle;settle(world,s,b,true);s.victories++;
    if(id==='comb-skein')s.flags['comb-basket-clear']=true;
    else{
      if(!s.flags['comb-driven']){const bag=s.expedition.stock;bag['comb-sheath']=(bag['comb-sheath']||0)+1;}
      s.flags['comb-driven']=true;
      if(b.comb.brood>=2)s.flags['comb-brood-safe']=true;
    }
    done();
  }
  function show(){
    const b=state.battle,h=b.party[b.actor],t=b.intent;
    canvas.dataset.combPhase=String(t.stage);canvas.dataset.combSide=t.side;
    if(h){canvas.dataset.combActor=h.id;canvas.dataset.combLane=h.combLane;}
    if(b.phase==='win'){
      const text=id==='comb-skein'?'帘骨松开，虾笼浮起。没有人割断透明幼串。':
        '母冠退到水深处。玛拉从里桩解下一片旧卸力垫，制成可穿戴的卸力垫肩。'+(b.comb.brood>=2?'两拨幼串从护索下游过，回水里留下了活珠。':'回水静下来，幼串随整冠转向外湾。');
      ui.show('comb-win','收起护索',text,[['收队回到桩边',collect]],b.log);return;
    }
    if(b.phase==='lose'){ui.show('comb-lose','四个人被拉回上沿','伊沃把扶索套在原桩上，容大家从入水前重新整理。',[
      ['从入水前重试',start],['沿上沿撤回',done]]);return;}
    const action=kind=>()=>{if(combMove(b,kind,performance.now()))sound(kind==='inner'||kind==='outer'?'tide':kind==='cover'?'touch':'battle');show();};
    const details='第'+b.round+'轮　冠 '+b.hp+'/'+b.max+'　'+h.name+' '+h.hp+'/'+h.maxHp+' 气'+h.mp+'/'+h.maxMp+'　'+(h.combLane==='inner'?'短桩':'深水')+'　已护幼串 '+b.comb.brood+listeningCue(b);
    ui.show('comb-duel',h.name+' · '+t.name,t.sign+' '+t.hint+'\n'+b.log,[
      ['试探帘缘',action('attack')],[h.skill.name+' · '+(h.skill.cost??2)+'气',action('skill')],
      ['挪到短桩',action('inner')],['移向深水',action('outer')],['护住桩缝',action('cover')],
      ['盐橘药剂 ×'+(b.stock.tonic||0),action('tonic')],
      ...(b.stock['brine-dose']>0?[['回暖盐膏 ×'+b.stock['brine-dose'],action('salve')]]:[]),
      ['攀索退出',()=>{settle(world,s,b,false);done();}]],details);
  }
  start();
}
