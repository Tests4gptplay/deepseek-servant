const gold='#d7b573',white='#dbe8da',sea='#315c63';
export function plate(ui,label,painter){
 const bound=document.createElement('figure');bound.dataset.fieldSketch='stars';bound.className='star-instrument';const cv=document.createElement('canvas');
 cv.setAttribute('role','img');cv.setAttribute('aria-label',label);cv.width=840;cv.height=320;const c=cv.getContext('2d');c.scale(2,2);
 const b=c.createLinearGradient(0,0,0,160);b.addColorStop(0,'#101f30');b.addColorStop(.72,'#30434c');b.addColorStop(1,'#162d32');c.fillStyle=b;c.fillRect(0,0,420,160);
 painter(c);bound.append(cv);ui.panel.querySelector('p').before(bound);
}
function line(c,x,y,x2,y2,color,width=1){c.beginPath();c.moveTo(x,y);c.lineTo(x2,y2);c.strokeStyle=color;c.lineWidth=width;c.stroke();}
function round(c,x,y,r,k,edge){c.beginPath();c.arc(x,y,r,0,7);c.fillStyle=k;c.fill();if(edge){c.strokeStyle=edge;c.lineWidth=1.2;c.stroke();}}
function star(c,x,y,r,color){c.fillStyle=color;c.beginPath();c.moveTo(x-r,y);c.lineTo(x-r*.2,y-r*.23);c.lineTo(x,y-r*1.6);c.lineTo(x+r*.22,y-r*.27);c.lineTo(x+r,y);c.lineTo(x+r*.19,y+r*.32);c.lineTo(x,y+r*1.5);c.lineTo(x-r*.23,y+r*.24);c.closePath();c.fill();}
function type(c,t,x,y,size=12,ink=white){c.font=size+'px Georgia,serif';c.fillStyle=ink;c.fillText(t,x,y);}
export function telescope(c,setting,goal){
 for(let i=0;i<57;i++){const x=14+(i*47+i*i*3)%390,y=9+(i*19+i*i*7)%105;round(c,x,y,i%5?.65:1.15,'#cadcca');}
 c.strokeStyle='#9aa69b59';c.lineWidth=.8;c.beginPath();c.ellipse(204,350,490,302,.03,3.5,5.96);c.stroke();
 const x=71+goal*45,q=71+setting*45;
 line(c,x-30,45,x,63,'#8f9f9c');line(c,x,63,x+23,34,'#8f9f9c');star(c,x-30,45,4,white);star(c,x+23,34,3.7,white);star(c,x,63,5.4,'#f3ae81');
 for(const d of [-1,1]){line(c,q+d*5,9,q+d*5,99,'#e1be79',1.3);line(c,q+d*9,91,q+d*5,83,gold,1);}
 line(c,43,109,377,109,gold,2.2);for(let i=0;i<37;i++)line(c,45+i*9.1,109,45+i*9.1,109+(i%5?4:9),'#d0af73',.8);
 round(c,26,112,10,'#77785f',gold);round(c,26,112,3,'#3b4a48');
 type(c,'西',23,142);type(c,'东',381,142);type(c,'两粒白星之间，短芒指着那颗赤星。',109,145,12,'#e0d0a7');
}
function clock(c,x,title,v,base){
 round(c,x,76,49,'#59635b','#9ba08a');round(c,x,76,44,'#d2c6a4','#a58a59');
 for(let n=0;n<16;n++){const a=(n/16-.25)*2*Math.PI;line(c,x+Math.cos(a)*35,76+Math.sin(a)*35,x+Math.cos(a)*41,76+Math.sin(a)*41,'#494c43',n%4?.8:2);}
 const needle=(val,color,th,length)=>{const a=(val/16-.25)*2*Math.PI;line(c,x,76,x+length*Math.cos(a),76+length*Math.sin(a),color,th);};
 needle(base,'#876a55',1.8,31);needle(v,'#263d40',3,37);round(c,x,76,3.4,'#c49856','#445249');
 type(c,title,x-22,17,13);type(c,'岸 '+base+' ／ 船 '+v,x-32,146,13,'#e8d5a7');
}
export function chronometer(c,values){clock(c,77,'第一更',values[0],4);clock(c,210,'第四更',values[1],7);clock(c,343,'第七更',values[2],10);}
export function lagoon(c,map,pos){
 const w=41,h=24,left=87,top=16;
 for(let y=0;y<5;y++)for(let x=0;x<6;x++){
  const X=left+x*w,Y=top+y*h,k=[x,y].join(','),reef=map.land.has(k),flow=map.flow[k];
  c.fillStyle=reef?'#6a7161':(x+y)%2?'#335c65':'#3e6970';c.fillRect(X,Y,w-1,h-1);
  if(reef){line(c,X+6,Y+17,X+15,Y+7,'#b7af8c',1.1);line(c,X+15,Y+7,X+22,Y+13,'#b7af8c');line(c,X+23,Y+17,X+30,Y+10,'#b7af8c');}
  if(flow)type(c,flow[0]===1?'→':flow[1]===-1?'↑':'↓',X+13,Y+16,17,'#dae5c9');
  if(map.end[0]===x&&map.end[1]===y){line(c,X+8,Y+17,X+31,Y+17,gold,2.1);line(c,X+12,Y+17,X+12,Y+5,gold,2);star(c,X+12,Y+3,2.6,'#f1cb87');}
 }
 const [x,y]=pos,X=left+(x+.5)*w,Y=top+(y+.5)*h;c.fillStyle='#ead7ad';c.beginPath();c.moveTo(X,Y-9);c.quadraticCurveTo(X+9,Y-1,X+5,Y+8);c.lineTo(X-5,Y+8);c.quadraticCurveTo(X-9,Y-1,X,Y-9);c.fill();line(c,X-6,Y+4,X+6,Y-2,'#795b41',2);
 type(c,'北',42,38,15,gold);line(c,47,67,47,45,gold);type(c,'白礁',26,112,12);type(c,'水脉 →',345,102,12);type(c,'灯桩',345,124,12,gold);
}
