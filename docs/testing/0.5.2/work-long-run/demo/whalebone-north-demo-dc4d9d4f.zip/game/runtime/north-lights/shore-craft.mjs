import {face,rod,plate,box,line,oval,poly,beam,ring,hanging} from '../lamplit-whale/fixtures.mjs';
export const slate=['#84918a','#526d6e','#3d575d'],timber=['#bb9872','#86694f','#584d46'],bone=['#ddcd9d','#b5a27b','#887c65'];
export function cliff(c,p,x,y,w,h,H,seed=1){
 const A=(i,j,z)=>p(x+i*w,y+j*h,z),corners=[[.01,.40,.48],[.24,.04,.84],[.66,.02,.95],[.96,.32,.62],[.86,.79,.53],[.50,.97,.69],[.15,.86,.66]];
 const crest=corners.map(([i,j,z])=>A(i,j,z*H));
 for(let n=2;n<7;n++){const k=(n+1)%7,a=corners[n],b=corners[k];poly(c,[crest[n],crest[k],A(b[0],b[1],0),A(a[0],a[1],0)],n%2?'#526969':'#677771','#5c6c68');}
 poly(c,crest,'#94a194','#607773');poly(c,[crest[0],crest[1],crest[2],A(.43,.49,H*.79)],'#afad92');
 const mix=(a,b,k)=>a.map((v,i)=>v+(b[i]-v)*k),centre=A(.49,.49,H*.91);
 const fissures=[[.09,.48,.32,.43],[.32,.43,.41,.59],[.41,.59,.36,.72],[.57,.69,.67,.57],[.67,.57,.77,.58],[.29,.21,.38,.31],[.38,.31,.45,.33]];
 for(let j=0;j<corners.length;j++){
  const a=corners[j],b=corners[(j+1)%corners.length],u=mix(a,b,.30),v=mix(a,b,.69);
  const edge1=A(u[0],u[1],u[2]*H),edge2=A(v[0],v[1],v[2]*H),spur=mix(centre,edge1,.48+(j%3)*.08);
  poly(c,[crest[j],edge1,spur],j%2?'#9a9a7f':'#b2ac8d');
  poly(c,[edge1,edge2,spur],j%3?'#83968a86':'#b1a68b');
  if(j>=2){for(const level of [.33,.66]){const one=A(u[0],u[1],u[2]*H*level),mid=A(v[0],v[1],v[2]*H*level+2);line(c,...one,...mid,'#3e585b',1.2);line(c,one[0],one[1]-1,...mid,'#8c9788',.7);}}
 }
 for(const [u,v,a,b] of fissures){const from=A(u,v,H*.73),to=A(a,b,H*.72);line(c,...from,...to,'#5d716c',1.35);line(c,from[0]+1,from[1]-1,to[0]+1,to[1]-1,'#c0b696',.8);}
 for(let i=0;i<9;i++){const u=.24+((i*19+seed*13)%51)/100,v=.25+((i*13+seed)%48)/100;rod(c,p,[x+u*w,y+v*h,H*.71],[x+(u+.067)*w,y+(v-.025)*h,H*.7],i%3?'#788679':'#c0bb95',1.1);}
}
export function rib(c,p,x,y,span,height,broken=false){
 const [a,b]=p(x,y);c.save();c.translate(a,b);const k=span/75;c.scale(k,height/103);
 c.beginPath();c.moveTo(-13,1);c.bezierCurveTo(-22,-40,-30,-86,broken?-6:45,broken?-66:-103);
 if(broken){c.lineTo(1,-62);c.lineTo(-2,-57);}else{c.bezierCurveTo(22,-93,-2,-72,-4,-55);}
 c.bezierCurveTo(-12,-35,-3,-11,8,-1);c.closePath();c.fillStyle='#c3ad82';c.strokeStyle='#776e60';c.lineWidth=1.4;c.fill();c.stroke();
 c.beginPath();c.moveTo(-10,-1);c.bezierCurveTo(-23,-43,-23,-76,broken?-3:39,broken?-62:-99);c.strokeStyle='#ede0b0';c.lineWidth=3;c.stroke();
 for(let j=0;j<5;j++){const yy=-8-j*8;line(c,-11-j*.55,yy,-4-j*1.45,yy-3,'#8e826a',1.1);}
 oval(c,0,2,14,3,'#786f5d78');c.restore();
}
export function rack(c,p,x,y,h=42){
 beam(c,p,[x,y,0],[x,y,h],4);beam(c,p,[x+.76,y+.22,0],[x+.76,y+.22,h+1],4);
 for(let z=7;z<h;z+=7)rod(c,p,[x,y,z],[x+.76,y+.22,z+1],'#c5b489',1.7);
}
export function gauge(c,p,x,y,high){
 box(c,p,x,y,.22,.21,0,32,slate);const a=p(x+.2,y+.21,0);
 for(let j=1;j<=5;j++)line(c,a[0]-5,a[1]-j*5,a[0]+(j%2?2:5),a[1]-j*5,j%2?'#eee0ac':'#a96c54',1.8);
 const v=high?22:9;oval(c,a[0]+2,a[1]-v,6.2,2.2,'#c0dacc');line(c,a[0]-4,a[1]-v,a[0]+6,a[1]-v,'#49787d',1.4);
}
export function lit(c,a,b,r,ink='#ffcc80'){
 const g=c.createRadialGradient(a,b,0,a,b,r);g.addColorStop(0,ink+'cb');g.addColorStop(.36,ink+'62');g.addColorStop(1,ink+'00');c.fillStyle=g;c.fillRect(a-r,b-r,2*r,2*r);
}
export function spool(c,p,x,y,z,ink='#927857'){
 const [a,b]=p(x,y,z);for(let i=2;i>=0;i--)ring(c,[a+i*.8,b-i*2],8-i,ink,.39);
}
export function capstan(c,p,x,y){
 box(c,p,x-.28,y-.32,.58,.65,0,8,timber);const [a,b]=p(x,y,9);oval(c,a,b-4,8,3.2,'#5a655e');oval(c,a,b-9,9,3.4,'#bb9d71');line(c,a-13,b-5,a+15,b-12,'#897352',2);spool(c,p,x+.57,y+.23,2);
}
