import {showPortrait} from './dialogue-portraits/panel.mjs';
export function frame(root){
 root.innerHTML=`<div class="shell"><header class="mast"><div class="wordmark"><span class="crest" aria-hidden="true">✥</span><div><strong>鲸骨以北</strong><small>NORTH OF WHALEBONE</small></div></div><div class="mast-right"><span class="tide"></span><button data-key="sound" aria-pressed="false">声音</button><button data-key="log">航海志</button></div></header>
 <section class="stage"><canvas tabindex="0" aria-label="港口。用方向键移动，E 互动"></canvas><div class="place"><small data-key="act"></small><h1></h1></div><div class="toast" role="status" hidden></div><div class="prompt" hidden></div><div class="touch"><div class="dpad"><button data-dir="0,-1" aria-label="向北">北</button><button data-dir="-1,0" aria-label="向西">西</button><button data-dir="0,1" aria-label="向南">南</button><button data-dir="1,0" aria-label="向东">东</button></div><button data-key="use" class="act">互动</button></div><article class="panel" role="dialog" aria-modal="true" aria-labelledby="panel-title" hidden><h2 id="panel-title"></h2><p></p><small></small><div class="options"></div></article></section>
 <footer class="keel"><span class="chapter"></span><span class="guide">方向键 / WASD 移动　 E 互动　 J 航海志</span><button data-key="save">存档</button></footer></div>`;
 const q=sel=>root.querySelector(sel),panel=q('.panel'),canvas=q('canvas');let timer;
 function hide(){panel.hidden=true;showPortrait(panel,'','','');panel.removeAttribute('data-mode');canvas.focus({preventScroll:true});}
 function show(mode,title,body,options,detail=''){
  panel.querySelector('[data-field-sketch]')?.remove();
  panel.hidden=false;panel.dataset.mode=mode;panel.querySelector('h2').textContent=title;panel.querySelector('p').textContent=body;showPortrait(panel,mode,title,body);
  const sm=panel.querySelector('small');sm.textContent=detail;sm.hidden=!detail;
  const buttons=options.map(([label,callback])=>{const b=document.createElement('button');b.textContent=label;b.addEventListener('click',callback);return b;});
  panel.querySelector('.options').replaceChildren(...buttons);buttons[0]?.focus({preventScroll:true});
 }
 function toast(msg){const n=q('.toast');clearTimeout(timer);n.textContent=msg;n.hidden=false;timer=setTimeout(()=>{n.hidden=true},2800);}
 return {q,panel,canvas,show,hide,toast};
}
