import {panel,cord,oval,lantern} from '../folded-house-art/materials.mjs';
const pine='#574d42',snow='#c2c9b9',amber='#e9bb70';
function wall(c,q,left,right,y,hue,roof,warm){
 const h=roof,oak=warm?'#8a6c50':'#68685c',edge='#564f45';
 panel(c,q,[[left,.10,2],[right,.10,2],[right,y,2],[left,y,2]],'#776f59',edge);
 panel(c,q,[[left,y,1],[right,y,1],[right,y,h],[left,y,h+3]],hue,edge);
 panel(c,q,[[right,.1,2],[right,y,1],[right,y,h],[right,.1,h+5]],oak,edge);
 for(let i=0;i<7;i++){
  const z=5+i*(h-5)/7;
  cord(c,q,[[left+.01,y,z],[left+(right-left)*.4,y,z+1.2],[right,y,z-1]],i%3?'#7d775e':'#c1a77f',1);
  cord(c,q,[[right,.1,z+3],[right,.51,z+1],[right,y,z]],'#514d4199',1);
 }
 for(const k of [left+.022,left+.49*(right-left),right-.018])
  cord(c,q,[[k,y+.01,2],[k-.01,y+.015,h+3]],pine,3.8);
 const span=right-left;
 for(const r of [.20,.66]){
  const l=left+span*r,v=l+.14*span;
  panel(c,q,[[l,y+.012,16],[v,y+.012,17],[v,y+.012,h-6],[l,y+.012,h-4]],warm?'#876746':'#648182',pine);
  panel(c,q,[[l+.012,y+.013,18],[v-.009,y+.013,18],[v-.009,y+.013,h-9],[l+.012,y+.013,h-8]],warm?amber:'#a1bab0');
  cord(c,q,[[(l+v)/2,y+.018,16],[(l+v)/2,y+.018,h-6]],pine,2);
  cord(c,q,[[l-.01,y+.025,16],[v+.02,y+.025,16]],'#ddc499',2.4);
 }
 const crest=h+18,mid=(.1+y)*.5;
 panel(c,q,[[left-.025,.07,h+6],[right+.018,.07,h+6],[right+.018,mid,crest],[left-.025,mid,crest+2]],'#718281',edge);
 panel(c,q,[[left-.025,mid,crest+2],[right+.018,mid,crest],[right+.032,y+.025,h+1],[left-.035,y+.025,h+4]],warm?'#6b7b70':'#566b70',edge);
 for(let i=1;i<13;i++){
  const x=left+(right-left)*i/13;
  cord(c,q,[[x,mid,crest+1],[x-.003,y+.021,h+4]],i%3===0?'#b4b9a3':'#87968a',i%3===0?1.7:1);
 }
 cord(c,q,[[left-.02,mid,crest+3],[right+.02,mid,crest+2]],snow,2.6);
}
function stove(c,q,u,v,t){
 panel(c,q,[[u,v,37],[u+.052,v,37],[u+.052,v,74],[u,v,76]],'#685d4d',pine);
 panel(c,q,[[u+.052,v,37],[u+.052,v+.055,38],[u+.052,v+.055,73],[u+.052,v,74]],'#465554',pine);
 cord(c,q,[[u-.01,v,74],[u+.065,v,74]],'#9e9c83',3);
 const [x,y]=q(u+.02,v,76);c.save();for(let i=0;i<4;i++){
  const r=i*6,j=Math.sin(t*.5+i*.6)*2;oval(c,[x+2*r+j,y-3-r],5+i*2.2,2.5+i*.8,'#cad3c277');
 }c.restore();
}
function rack(c,q,u0,u1,y){
 for(const u of [u0,u1])cord(c,q,[[u,y,0],[u,y,26]],pine,3);
 cord(c,q,[[u0-.02,y,25],[u1+.02,y,23]],'#a8885b',3);
 for(let i=0;i<6;i++){
  const u=u0+(i+.35)*(u1-u0)/6;
  cord(c,q,[[u,y,24],[u,y,18]],'#b5a88c');
  const [x,z]=q(u,y,16);c.save();c.translate(x,z);c.rotate(-.24);oval(c,[0,1],2.9,6.6,i%2?'#af9577':'#776656');
  c.fillStyle='#776855';c.beginPath();c.moveTo(-2,5);c.lineTo(3,9);c.lineTo(1,4);c.fill();c.restore();
 }
}
function iceFace(c,q,n){
 for(let i=0;i<4;i++){
  const l=i*.23,r=Math.min(.99,l+.31),top=18+((i+2*n)*13%41);
  panel(c,q,[[l,.73,2],[r,.71,2],[r,.54,top-4],[l+.10,.38,top+8],[l+.025,.42,top]],i%2?'#88aeb1':'#a0bfbc','#718b90');
  panel(c,q,[[r,.71,2],[r,.54,top-4],[l+.10,.38,top+8],[l+.07,.58,top*.56]],'#bad2c7');
  cord(c,q,[[l+.12,.53,top*.77],[l+.17,.64,top*.50],[l+.13,.64,top*.39],[r-.02,.68,top*.20]],'#d5e3d6',1.25);
 }
}
function oldBone(c,q){
 for(let i=0;i<5;i++){
  const u=.06+i*.19,h=23+(i%3)*7;
  cord(c,q,[[u,.75],[u-.03,.54,h*.6],[u+.04,.30,h],[u+.13,.22,h+4],[u+.17,.31,h-3]],'#676d5e',7);
  cord(c,q,[[u,.75,1],[u-.025,.54,h*.6+2],[u+.04,.30,h+1],[u+.14,.235,h+5]],i%2?'#c8bea0':'#a99f85',4.2);
  oval(c,q(u+.06,.29,h-2),2.7,1.6,'#6d7566');
 }
}
export function familyBuildings(c,p,map,f,s,t){
 if(!map.id.startsWith('whalefall-'))return false;
 const q=(u,v,z=0)=>p(f.x+u*f.w,f.y+v*f.h,z);
 if(f.kind==='water')return true;
 if(f.kind==='wall'){
  if(map.id==='whalefall-glass')iceFace(c,q,f.x);
  else oldBone(c,q);
  return true;
 }
 if(f.kind!=='building')return false;
 if(map.id==='whalefall-porch'){
  if(f.x<20){wall(c,q,.025,.93,.88,'#9b856a',35,true);stove(c,q,.26,.41,t);rack(c,q,.12,.43,.96);lantern(c,q(.77,.89,21),true);}
  else{wall(c,q,.025,.48,.73,'#908d75',32,false);wall(c,q,.51,.97,.9,'#aa8767',40,true);stove(c,q,.79,.38,t);}
 }else if(map.id==='whalefall-mouth'){
  wall(c,q,.06,.72,.70,'#967953',29,true);stove(c,q,.37,.4,t);rack(c,q,.15,.85,.88);rack(c,q,.74,.94,.53);
 }else if(map.id==='whalefall-glass'){
  wall(c,q,.08,.87,.8,'#827b6f',28,false);for(let i=0;i<5;i++)lantern(c,q(.2+i*.13,.88,18+i%2*3),false);
 }else{wall(c,q,.04,.94,.83,'#7a8174',34,false);rack(c,q,.16,.78,.95);}
 return true;
}
