import {syllables,voiceNames} from './how-a-song-makes-room.mjs';
const paints={heel:'#f3b579',reed:'#9ad5bd',child:'#e5d899'};
const outline=(c,ink,w=1)=>{c.strokeStyle=ink;c.lineWidth=w;c.stroke();};
function shape(c,voice,x,y,tone){
 c.fillStyle=tone;c.beginPath();
 if(voice==='heel'){c.moveTo(x-7,y-6);c.lineTo(x+4,y-6);c.lineTo(x+8,y+4);c.quadraticCurveTo(x,y+8,x-7,y+4);c.closePath();}
 if(voice==='reed'){c.moveTo(x-8,y+5);c.quadraticCurveTo(x-5,y-7,x+8,y-5);c.quadraticCurveTo(x+5,y+6,x-8,y+5);}
 if(voice==='child'){c.moveTo(x-7,y+2);c.quadraticCurveTo(x,y-12,x+7,y+2);c.quadraticCurveTo(x,y+9,x-7,y+2);}
 c.fill();outline(c,'#423f32',1);
}
function carve(c,rows,pulse){
 const w=458,h=149,g=c.createLinearGradient(0,0,w,h);g.addColorStop(0,'#553625');g.addColorStop(.43,'#966d43');g.addColorStop(1,'#463b35');c.fillStyle=g;c.fillRect(0,0,w,h);
 for(let j=0;j<22;j++){c.beginPath();const y=3+j*7;c.moveTo(0,y);c.bezierCurveTo(124,y+5*Math.sin(j),261,y+6*Math.cos(j),w,y+1);outline(c,j%3?'#dec18c24':'#28201e58',1.2);}
 c.fillStyle='#2c3c3b';c.fillRect(12,11,434,122);const left=83,span=43.5,top=37;
 for(let i=0;i<8;i++){
  const x=left+i*span;c.fillStyle=i===pulse?'#b68e50':i%2?'#384a45':'#30403e';c.fillRect(x-17,15,35,109);
  c.font='12px serif';c.textAlign='center';c.fillStyle='#ede1b6';c.fillText(syllables[i],x,29);
 }
 for(const [j,voice] of Object.keys(voiceNames).entries()){
  const y=top+j*28+12;c.font='14px serif';c.fillStyle=paints[voice];c.textAlign='left';c.fillText(voiceNames[voice],22,y+4);
  for(let i=0;i<8;i++){
   const x=left+i*span;
   if(rows[voice].includes(i))shape(c,voice,x,y,paints[voice]);
   else{c.beginPath();c.moveTo(x-4,y);c.lineTo(x+4,y);outline(c,'#b6b79d',1.15);}
  }
 }
 for(const x of [7,w-7])for(const y of [7,h-8]){c.beginPath();c.arc(x,y,2.9,0,7);c.fillStyle='#b4a77e';c.fill();}
}
export function scoreBoard(ui,rows,{play=false,slow=false}={}){
 const figure=document.createElement('figure');figure.className='salt-song-score';figure.dataset.fieldSketch='salt-song';
 const canvas=document.createElement('canvas');canvas.width=916;canvas.height=298;
 const alt=Object.keys(voiceNames).map(k=>voiceNames[k]+'在'+(rows[k].map(i=>syllables[i]).join('、')||'无')+'拍').join('。');
 canvas.setAttribute('role','img');canvas.setAttribute('aria-label','八拍船凳谱。'+alt);
 const context=canvas.getContext('2d');context.scale(2,2);carve(context,rows,-1);figure.append(canvas);
 const text=document.createElement('figcaption');text.textContent=alt+'。';figure.append(text);ui.panel.querySelector('p').before(figure);
 if(!play)return;
 const started=performance.now(),step=slow?470:320;
 function next(now){
  if(!figure.isConnected)return;
  const beat=Math.floor((now-started-65)/step);carve(context,rows,beat<8?beat:-1);
  if(beat<8)requestAnimationFrame(next);
 }
 requestAnimationFrame(next);
}
