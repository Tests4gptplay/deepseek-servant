import {attachHearthVoice} from './lullaby-voice.mjs';
import {stairId,currentPair,switchHand,actorName,pathWords} from './lullaby-partners.mjs';
import {bayReading} from './driftbay-footfall.mjs';
import {readTheWorkingStage} from './second-shadow/which-end-of-the-rope.mjs';
import {roleAtWork} from './second-shadow/where-the-ropeman-stands.mjs';
import {trainingMode} from './seamanship.mjs';
import {guildLedger,fieldTarget,worksite} from './guild-ledger.mjs';
import { fresh, step, targets, marked } from './state.mjs';
import { frame } from './frame.mjs';
import { makeScene } from './scene.mjs';
import { paintBattle } from './fight-art.mjs';
import { audioControl } from './audio.mjs';
import { bindInput } from './input.mjs';
import { interactions } from './events.mjs';
import { storage } from './storage.mjs';
import { syncParty } from './party.mjs';
import { crewMenu } from './crew.mjs';
import {fieldAtlas} from './field-atlas/menu.mjs';
import {entries} from './logbook.mjs';

import {waterStep,waterReadout} from './tidal-route/travel.mjs';
export function mount(root, world) {
 const ui = frame(root), state = {player:fresh(world),battle:null,paintBattle};
 const soundButton=ui.q('[data-key=sound]'),sound=audioControl(soundButton);attachHearthVoice(ui,soundButton);
 const switchButton=document.createElement('button');switchButton.type='button';switchButton.dataset.key='lullaby-switch';switchButton.hidden=true;
 ui.q('.mast-right').insertBefore(switchButton,soundButton);switchButton.addEventListener('click',()=>{if(ui.panel.hidden&&switchHand(state.player)){sync();ui.canvas.focus({preventScroll:true});}});
 function sync(){
  const s=state.player,map=world.maps[s.map],name=map.name.split(/\s*[·｜]\s*/);
  syncParty(world,s);sound.scene(map,s,!!state.battle);
  root.dataset.map=s.map;root.dataset.x=String(s.x);root.dataset.y=String(s.y);root.dataset.tide=s.tide;
  ui.q('.place h1').textContent=name.at(-1);ui.q('[data-key=act]').textContent='第 '+map.act+' 幕'+(name.length>1?'　'+name[0]:'');
  ui.q('.tide').textContent=s.tide==='high'?'涨潮':'低潮';
  root.dataset.voyage=s.cycle?.id==='afterwatch'?'afterwatch':'first';
  ui.q('.chapter').textContent=(s.cycle?.id==='afterwatch'?'第二航次 · 沅籽':roleAtWork(s)==='ivo'?'伊沃 · 守索':actorName(s))+'　◇　'+map.name+'　'+s.x+' / '+s.y;
  waterReadout(root,state,map);readTheWorkingStage(root,s);
  const canSwitch=s.map===stairId&&s.expedition?.roster.includes('ivo');switchButton.hidden=!canSwitch;switchButton.disabled=!ui.panel.hidden;
  if(canSwitch){switchButton.textContent=currentPair(s)?.active==='ivo'?'换到玛拉':'换到伊沃';root.dataset.hand=actorName(s);}else delete root.dataset.hand;
  const target=fieldTarget(s)||targets(world,s)[0],p=ui.q('.prompt');p.hidden=!target||!ui.panel.hidden;
  if(!target&&map.driftbay&&ui.panel.hidden){p.hidden=false;p.textContent=bayReading(map,s);}
  const words=pathWords(map,s);if(words&&!target&&ui.panel.hidden){p.hidden=false;p.textContent=words;}
  if(target)p.textContent='互动　'+(target.value.name||target.value.label||world.maps[target.value.to]?.name||'通路');
 }
 const ctx={ui,state,world,sound,sync}, {use,close}=interactions(ctx), saves=storage(ctx,close);
 ctx.openVoyage=saves.offer;
 function move(dx,dy){if(ui.panel.hidden){const s=state.player,map=world.maps[s.map],before=[s.x,s.y];step(world,s,dx,dy);if(s.x!==before[0]||s.y!==before[1]){const note=waterStep(state,map,before,s);if(note)ui.toast(note);}sync();}}
 function interact(){
   const field=fieldTarget(state.player),options=targets(world,state.player);if(field)options.unshift(field);
    const act=t=>t?.kind==='field'?worksite(ctx,close):use(t);
   if(options.length<2){act(options[0]);return;}
   ui.show('targets','伸手可及',world.maps[state.player.map].name,[
    ...options.map(t=>[t.value.name||t.value.label||'通道',()=>act(t)]),['返回',close]]);
 }
 function journal(){
  const s=state.player,all=Object.values(world.maps).flatMap(m=>(m.entities||[]).map(e=>[m,e]));
  const text=entries(world,s).map(q=>{
   const stages=q.stages||[],done=stages.filter(k=>marked(s,k)).length;
   if(marked(s,q.endFlag))return '✓ '+q.name+'　已记入航簿';
   const k=stages.find(k=>!marked(s,k)),target=all.find(([,e])=>e.action?.id===k||e.action?.set===k);
   return q.name+'　'+done+' / '+stages.length+(target?'\n　'+target[0].name+' · '+target[1].name:'');
  }).join('\n\n');
  const items=Object.entries(s.inventory).map(([k,v])=>k+' ×'+v).join('，');
  const options=s.cycle?.id==='afterwatch'?[['翻开航次存档',saves.open]]:[['队伍与整备',()=>crewMenu(ctx,close)]];
  if(!s.cycle&&!s.flags['grave-signed'])options.push(['同行授业与见习',()=>trainingMode(ctx,journal)]);
   if(s.flags['grave-signed']&&!s.cycle)options.push(['海路行会实务复核',()=>guildLedger(ctx,journal)]);
  options.push(['走过的航图',()=>fieldAtlas(ctx,journal)]);
  ui.show('journal',s.cycle?.id==='afterwatch'?'沅籽的值灯航记':'航海志',text||'尚未记下委托。',[...options,['合上航簿',close]],items?'随身物件　'+items:'港记随沿途见闻更新。');
 }
 function dismiss(){if(state.battle)return;close();}
 bindInput(root,ui,{move,interact,journal,save:saves.open,dismiss});
 saves.resume();sync();ui.canvas.focus({preventScroll:true});return makeScene(ui.canvas,world,()=>state);
}
