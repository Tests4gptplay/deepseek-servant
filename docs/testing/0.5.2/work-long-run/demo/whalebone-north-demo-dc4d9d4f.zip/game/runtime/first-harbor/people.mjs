import {figure} from '../figures.mjs';
import {poly,line,oval,arc} from '../paint.mjs';
import {vapor} from './trades.mjs';
const jobs={
 'pall-bearer':['bearer','#716477','#cea48a'],'carter':['wheel','#856a53','#c29c77'],
 'weigh-clerk':['weigh','#6c8077','#c6a382'],'pot-keeper':['pot','#726e58','#c8a181'],
 'rope-mender':['splice','#6c747b','#cba487'],'fish-seller':['sort','#9a7561','#d0a27e'],
 'gauge-tender':['tide','#68807d','#c6a584'],'ivo-watch':['brake','#79574c','#b78665'],
 'lamp-neighbor':['wick','#7c6c76','#c69b80'],'seamstress':['sew','#9b7069','#d0a492'],
 'yard-apprentice':['carry','#83765d','#c5a183']};
function bowl(c,x,y,w,h,t,color){
 oval(c,x,y+1,w,h,'#564c3f');oval(c,x,y-2,w,h,color);oval(c,x,y-2.5,w-1.7,h*.50,'#d4b77d');
 vapor(c,x,y-4,t,'#eee2bedb',.78);
}
function rope(c,x,y,r,color){c.beginPath();c.ellipse(x,y,r,r*.42,-.14,0,Math.PI*2);c.strokeStyle=color;c.lineWidth=1.35;c.stroke();c.lineWidth=1;}
export function portPerson(c,p,map,e,s,t){
 if(e.kind!=='npc'||!jobs[e.id])return false;const [job,coat,skin]=jobs[e.id],foot=p(e.x+.5,e.y+.5);
 const a=Math.sin(t*(job==='pot'?.90:.68)+e.x*.65),swing=Math.sin(t*1.8+e.y);
 const stroll=job==='carry'||job==='wheel',fx=foot[0]+(stroll?4.3*a:0),fy=foot[1]+(stroll?1.7*a:0);
 if(job==='pot'){
  poly(c,[[fx-28,fy-4],[fx-13,fy-7],[fx-4,fy-2],[fx-18,fy+2]],'#ac8d65','#755d48');
  line(c,fx-26,fy-4,fx-26,fy+2,'#6b5d4e',2.3);line(c,fx-11,fy-3,fx-11,fy+3,'#6b5d4e',2.3);
  bowl(c,fx-18,fy-7,7,3.4,t,'#80816a');
 }else if(job==='splice'||job==='brake'){
  for(let i=0;i<3;i++)rope(c,fx-13,fy-2+i*.9,7-i*.8,'#b69b70');line(c,fx-16,fy-5,fx-7,fy-11,'#9a805b',1.3);
 }else if(job==='weigh'||job==='sort'||job==='sew'){
  poly(c,[[fx-25,fy-7],[fx-10,fy-11],[fx-3,fy-8],[fx-18,fy-4]],'#b08f68','#72624c');
  for(const i of [0,12])line(c,fx-22+i,fy-4-i*.17,fx-22+i,fy+2-i*.17,'#70604c',1.9);
  for(let i=0;i<3;i++){const x=fx-18+i*3.8,y=fy-7.5-i*.55;if(job==='sort'){oval(c,x,y,3,1.35,'#8aa39a');poly(c,[[x+2,y],[x+4,y-1.2],[x+4,y+.8]],'#788e85');}
   else if(job==='weigh'){oval(c,x,y,2.4,1.4,'#5a6862');oval(c,x,y-1.4,1.75,.85,'#a7a987');}
   else line(c,x-2,y+1,x+3,y-2,'#cbb399',2);}
 }else if(job==='tide'){
  line(c,fx-15,fy+3,fx-15,fy-31,'#786c51',2.6);for(let n=0;n<7;n++)line(c,fx-16,fy-n*4,fx-13,fy-n*4,'#d7c694',1);
 }else if(job==='wheel'){
  for(const [x,y] of [[fx-27,fy-6],[fx-14,fy-2]]){oval(c,x,y,5,4.7,'#73654e');oval(c,x,y,3.1,2.9,'#b2966e');}
  poly(c,[[fx-34,fy-10],[fx-21,fy-14],[fx-8,fy-10],[fx-21,fy-6]],'#b79268','#78654b');poly(c,[[fx-34,fy-10],[fx-21,fy-6],[fx-9,fy-10],[fx-10,fy-6],[fx-21,fy-3],[fx-34,fy-7]],'#957455','#776347');
  poly(c,[[fx-30,fy-12],[fx-24,fy-15],[fx-18,fy-13],[fx-20,fy-8],[fx-28,fy-8]],'#ccb68c','#8b7657');line(c,fx-13,fy-7,fx-7,fy-13,'#846f50',1.9);c.save();c.translate(fx-14,fy-2);c.scale(1,.82);c.rotate(a*.22);arc(c,0,0,6,0,Math.PI*2,'#876e53',2);for(let j=0;j<4;j++){c.rotate(Math.PI/4);line(c,-5,0,5,0,'#b09a70',1);}c.restore();
 }else if(job==='wick'){oval(c,fx-13,fy-4,6,2.4,'#9e8969');for(let i=0;i<3;i++)line(c,fx-16+i*3,fy-5,fx-16+i*3,fy-12-i%2,'#dfc891',1.6);}
 figure(c,fx,fy,e.id==='ivo-watch'?'ivo':e.id,t,{scale:1.08,stride:stroll?t*2.4:0});
 let hx=fx-12,hy=fy-12;
 if(job==='pot'){hx=fx-13+a*1.6;hy=fy-15+swing*1.4;line(c,hx,hy,fx-18+a*2,fy-7,'#7e5f44',1.65);}
 if(job==='splice'||job==='sew'){hx=fx-10+a*2.4;hy=fy-13+a;line(c,hx,hy,fx-15,fy-7,'#c3af82',.93);}
 if(job==='tide'){hx=fx-14;hy=fy-16+swing*2;}
 if(job==='wick'){hx=fx-12;hy=fy-12+a;line(c,hx,hy,fx-14,fy-7,'#9e977e',1);}
 if(job==='bearer'||job==='carry'){
  hx=fx-7;hy=fy-13;poly(c,[[fx-10,fy-15],[fx-2,fy-17],[fx+4,fy-13],[fx-5,fy-10]],job==='bearer'?'#c4bc9d':'#ac8664','#8a7960');
 }
 line(c,fx-3.6,fy-20,fx-7,fy-14.5,coat,3.1);line(c,fx-7,fy-14.5,hx,hy,skin,2.0);oval(c,hx,hy,1.4,1.1,skin);
 return true;
}
