// Offset is applied to the map, scenery, combatants and water in the scene camera together.
export function combCamera(b,clock,reduced){
  if(!b?.comb||reduced)return {x:0,y:0,focus:reduced?'still':'shore'};
  const last=b.last,age=last?clock-last.start:10000;
  const next=b.party[b.actor],base=b.intent.stage===2?-4:b.intent.stage===1?2:0;
  if(!last||age<0||age>760)return {x:base,y:0,focus:next?.id||'crown'};
  const a=b.party[last.a],pref={mara:[8,1],ivo:[12,-3],selene:[16,4],mira:[10,3]};
  const target=pref[a.id]||[6,0],r=Math.min(1,age/760);
  const draw=Math.sin(Math.min(1,r/.43)*Math.PI*.5)*(1-Math.min(1,Math.max(0,(r-.29)/.32)));
  const meet=Math.sin(Math.min(1,Math.max(0,(r-.34)/.66))*Math.PI);
  return {x:base+target[0]*draw-(last.hit?13:5)*meet,y:target[1]*draw+(last.response?3:1)*meet,
    focus:r<.42?a.id:last.response?'return-water':last.hit?'open-bell':next?.id||'crown'};
}
