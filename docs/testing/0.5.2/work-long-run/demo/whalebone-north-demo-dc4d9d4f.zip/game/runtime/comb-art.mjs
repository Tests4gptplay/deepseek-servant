import {poly,line,oval,arc} from './paint.mjs';
const ink='#254e59',ivory='#f8efcc',amber='#ffc36c';
export function larvalTrain(c,x,y,t,n=6){
  for(let i=0;i<n;i++){const px=x+i*4.1,py=y+Math.sin(i*.76+t)*2.3;
    if(i)line(c,px-4,py+1,px,py,'#e6e5c4',.85);
    oval(c,px,py,2.1,1.65,i%2?ivory:amber);oval(c,px-.4,py-.45,.55,.45,ink);}
}
export function crown(c,x,y,t,stage=0,side='inner',scale=1){
  c.save();c.translate(x,y);c.scale(scale,scale);
  oval(c,1,3,25,6,'#184b5c66');
  for(let i=0;i<5;i++){
    const sweep=Math.sin(t*1.15+i*.63),base=-17+i*7.5,bent=stage===1?(side==='inner'?7:-7):3;
    const height=[18,28,34,26,16][i],tip=base-6+bent+sweep*2.2;
    const skin=c.createLinearGradient(base,-height,base+3,2);skin.addColorStop(0,'#e7edce');skin.addColorStop(.33,'#8ac8bd');skin.addColorStop(.78,'#6098a7');skin.addColorStop(1,'#e2c27c');
    c.beginPath();c.moveTo(base-5,0);c.bezierCurveTo(base-9,-6,tip-6,-height+4,tip,-height);
    c.bezierCurveTo(tip+3,-height+6,base+9,-12,base+3,0);c.fillStyle=skin;c.fill();c.strokeStyle=ink;c.lineWidth=1.1;c.stroke();
    for(let j=1;j<4;j++){const k=j/4;line(c,base-4+(tip-base)*k,-height*k+3,base+2+(tip-base)*k,-height*k-1,'#e8eece',.95);}
    const edge=stage===1&&((side==='inner'&&i>=3)||(side==='outer'&&i<=1));
    oval(c,base,-3,edge?4.4:2.6,edge?5.4:3.3,edge?'#ffce68':'#be996c');oval(c,base-.8,-4.1,1,1,'#fff2b9');
    for(let j=0;j<2;j++){c.beginPath();c.moveTo(base+j*2,0);c.quadraticCurveTo(base+4+j*2,8+sweep*2,base-1+sweep*3+j*4,10+j);c.strokeStyle=j?'#dedda6':'#668d89';c.lineWidth=.85;c.stroke();}
  }
  if(stage===2)larvalTrain(c,-26,9,t,8);c.restore();
}
export function paintCombItem(c,p,map,e,s,t){
  if(e.action?.type!=='comb-coast')return false;
  const part=e.action.part,[x,y]=p(e.x+.5,e.y+.5),safe=s.flags['comb-safe'],driven=s.flags['comb-driven'];
  c.save();c.translate(x,y);
  oval(c,0,1,18,4,'#31575258');
  if(part==='crown'||part==='foam'||part==='shadow'){
    c.translate(part==='foam'?17:part==='shadow'?14:12,-2);
    if(part==='crown'&&(safe||driven)){
      if(safe||s.flags['comb-brood-safe'])larvalTrain(c,-8,0,t,5);
      else {line(c,-12,0,7,2,'#376b72',2);line(c,-6,-2,13,0,ivory,1);}
    }else{
      for(let j=0;j<3;j++){const v=Math.sin(t*.9+j)*1.5;line(c,-15+j*11,2+v,-10+j*11,-1+v,ivory,1.6);}
      crown(c,2,-2,t,part==='shadow'?1:0,'inner',part==='crown'?1.02:part==='foam'?.44:.64);
      if(part==='shadow')larvalTrain(c,-18,5,t,5);
    }
  }else if(part==='dry'){
    poly(c,[[-16,2],[-5,-7],[14,-5],[17,-1],[3,6]],'#9f9a81',ink);
    poly(c,[[-15,0],[-5,-7],[11,-5],[3,0]],'#657a4e');line(c,-6,-5,4,-5,ivory,1.2);
  }else if(part==='ring'||part==='quiet'||part==='return'){
    line(c,-3,0,-4,-13,'#785d48',4);arc(c,-4,-14,3.6,0,Math.PI*2,amber,1.6);
    c.beginPath();c.moveTo(-4,-12);c.quadraticCurveTo(1,7+(part==='return'&&safe?-8:0),16,-1);c.strokeStyle='#ddc190';c.lineWidth=1.7;c.stroke();
    if(part==='quiet'||part==='return')larvalTrain(c,-13,4,t,part==='return'&&safe?7:3);
  }else if(part==='basket'){
    poly(c,[[-10,-7],[7,-9],[13,-5],[9,0],[-7,2]],'#ab926c',ink);
    for(let j=-7;j<8;j+=3)line(c,j,-6,j+1,0,'#514e42',1);
    if(!s.flags['comb-basket-clear'])crown(c,9,-4,t,0,'inner',.38);
  }else{
    poly(c,[[-13,1],[-11,-5],[11,-6],[14,-1]],'#866d53',ink);
    arc(c,-4,-7,4,0,6.3,'#ddd6b3',1.7);arc(c,5,-5,3.3,0,6.3,'#d39763',1.8);
  }
  c.restore();return true;
}
