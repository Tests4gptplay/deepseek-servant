export const posts={ridge:'迎风挑杆',heel:'中轴踏板',lee:'背风接网'};
export const trades={
 mara:{post:'heel',name:'压住会回弹的轴脚',moves:['guard','skill'],plain:'架势或协作技'},
 ivo:{post:'lee',name:'接回滑过下缘的游索',moves:['dodge','skill'],plain:'侧移或协作技'},
 selene:{post:'heel',name:'用手背和潮术辨湿布的真重',moves:['guard','skill','salve'],plain:'架势、协作技或盐膏'},
 mira:{post:'ridge',name:'标出布背的第二重影',moves:['dodge','attack','skill'],plain:'侧移、攻击或协作技'}
};
const initial={mara:'heel',ivo:'ridge',selene:'lee',mira:'lee'};
export function startPosts(spec,party,player){
 if(!spec.windloom)return null;
 const roster=party.map(h=>h.id),here=Object.fromEntries(roster.map(id=>[id,initial[id]||'heel']));
 return {here,planned:null,work:{},log:[],rounds:[],strain:0,covers:0,scuffs:0,broken:!!player.progress?.windloomVoyages?.[spec.windloom.scene]?.tornOnRetreat,crossings:0,roster,stageSeen:[],guarded:new Set()};
}
export function stage(b){const d=b.spec.windloom,t=b.intent.phaseThreshold;return t<=d.end?2:t<=d.mid?1:0;}
export function swept(b){const sequence=b.spec.windloom.scene==='winter'?['heel','lee','ridge']:b.spec.windloom.scene==='harbor'?['lee','heel','ridge']:['ridge','heel','lee'];return sequence[stage(b)];}
export function choosePost(b,post){if(!b.windloom||!Object.hasOwn(posts,post))return false;b.windloom.planned=post;return true;}
export function dutyText(b){
 const w=b.windloom,h=b.party[b.actor],job=trades[h.id],pos=w.planned||w.here[h.id],done=Object.keys(w.work).length;
 return '面风 '+['正面','反面','倒兜'][stage(b)]+'，风压正扫'+posts[swept(b)]+'。'+h.name+'在'+posts[pos]+'。本职去'+posts[job.post]+'，用'+job.plain+'来'+job.name+'。\n已接岗位 '+done+'/4。旁人脚下的松缝 '+w.strain+'/3；'+(w.broken?'第一道布已经裂过。':'腾出一手护人可缝回未裂的余量。');
}
export function takePost(b,h,kind,hit){
 const w=b.windloom,d=b.spec.windloom,stageAt=stage(b),previous=w.here[h.id],post=w.planned||previous;
 w.planned=null;w.here[h.id]=post;if(post!==previous)w.crossings++;
 if(!w.stageSeen.includes(stageAt))w.stageSeen.push(stageAt);
 const duty=trades[h.id],protectedAction=['guard','dodge','cover'].includes(kind)||kind==='skill'&&['brace','heal'].includes(h.skill.kind);
 if(kind==='cover'){
  w.covers++;w.strain=Math.max(0,w.strain-2);w.guarded.add(h.id);
 }else if(post===swept(b)&&!protectedAction){
  w.strain++;
  if(w.strain>=3){w.scuffs++;w.strain=0;w.broken=true;}
 }
 const credit=post===duty.post&&(duty.moves.includes(kind)||(kind==='cover'&&['mara','ivo'].includes(h.id)));
 if(credit&&!w.work[h.id]){w.work[h.id]={round:b.round,phase:stageAt,post,kind};hit+=5;}
 // Each change of wind must be encountered in a fresh round. Strong crews cannot skip past the turn.
 const hands=Object.keys(w.work).length;
 const floor=stageAt===0?d.mid+(hands<1?1:0):stageAt===1?d.end+(hands<3?1:0):(hands<4?1:0);
 const effective=Math.max(0,Math.min(hit,Math.max(0,b.hp-floor)));
 w.log.push({round:b.round,hero:h.id,phase:stageAt,from:previous,post,kind,credit,cover:w.covers,strain:w.strain,scuffs:w.scuffs,hp:b.hp,hit:effective});
 return effective;
}
export function registerGust(b){
 const w=b.windloom,wind=swept(b),p=b.spec.windloom.scene==='harbor'?8:b.spec.windloom.scene==='winter'?6:4,losses={};
 for(const h of b.party){
  if(h.hp<=0||w.here[h.id]!==wind||w.guarded.has(h.id))continue;
  const last=w.log.findLast(e=>e.hero===h.id&&e.round===b.round);
  if(!last||['dodge','guard','cover'].includes(last.kind))continue;
  const relief=Math.round(p*(h.resists?.wind||0))+(h.armor==='oilskin'?2:0);
  const harm=Math.max(0,p-relief);h.hp=Math.max(0,h.hp-harm);h.hurt=(h.hurt||0)+harm;losses[h.id]={harm,relief};
 }
 w.rounds.push({round:b.round,stage:stage(b),wind,losses});w.guarded.clear();
}
export function keepWindVoyage(s,b,won){
 if(!b.windloom)return;const w=b.windloom,scene=b.spec.windloom.scene;
 const all=s.progress.windloomVoyages??={},history=all[scene]??={retreats:0};
 const sample={won,round:b.round,roster:w.roster,roles:w.work,phases:w.stageSeen,covers:w.covers,scuffs:w.scuffs,fabricTorn:w.broken,moves:w.log,rounds:w.rounds,
   outfit:Object.fromEntries(b.party.map(h=>[h.id,{skill:h.skill.name,armor:h.armor,ward:h.resists||{}}]))};
 if(!won){history.retreats++;history.lastRetreat=sample;if(w.broken)history.tornOnRetreat=true;return;}
 history.finish=sample;s.flags['windloom-'+scene+'-kept']=!w.broken&&w.covers>0;
 s.flags['windloom-'+scene+'-scar']=w.broken||w.covers===0;
}
