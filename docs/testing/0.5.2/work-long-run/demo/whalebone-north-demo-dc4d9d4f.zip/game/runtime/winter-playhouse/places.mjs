import {cart,cottage,coop,dryingRack,lantern,steps} from '../household-art.mjs';
import {heelFeature,heelFloor} from './heel-house.mjs';
import {theatreFeature,theatreFloor} from './screen-slope.mjs';
import {currentWorks,currentFloor} from './return-mark-and-sluice.mjs';
import {bearingFeature,bearingFloor} from './bearing-and-net.mjs';
export function landmarkFeature(c,p,map,f,s,t){
 switch(map.id){
 case 'heel-house':return heelFeature(c,p,map,f,s);
 case 'screen-slope':return theatreFeature(c,p,map,f,s,t);
 case 'edge-bleach':case 'weir-sleeve':return currentWorks(c,p,map,f,s,t);
 case 'bow-parallax':case 'brine-spine':return bearingFeature(c,p,map,f,s,t);
 default:return false;
 }
}
export function landmarkFloor(c,p,map,s,t){
 switch(map.id){
 case 'heel-house':return heelFloor(c,p,map);
 case 'screen-slope':return theatreFloor(c,p,map);
 case 'edge-bleach':case 'weir-sleeve':return currentFloor(c,p,map,s,t);
 case 'bow-parallax':return bearingFloor(c,p,map);
 }
}

export function landmarkCourt(c,p,map,s,t,ordered){
 if(map.id!=='heel-house'&&map.id!=='screen-slope')return false;
 const house=map.id==='heel-house';
 const enqueue=(x,y,paint)=>ordered.push([x+y,paint]);
 for(const f of map.features){
  const relevant=house?f.kind==='building'&&f.x===2||f.kind==='crate'&&f.x===16:f.kind==='building'&&f.x===3||f.kind==='crane'&&f.x===16;
  if(relevant)enqueue(f.x+f.w*.52,f.y+f.h-.2,()=>{if(house)heelFeature(c,p,map,f,s);else theatreFeature(c,p,map,f,s,t);});
 }
 enqueue(27,8.85,()=>{cottage(c,p,25.6,5.6,6.3,3.1,{h:house?65:73,roof:house?'#788e80':'#636d78',wall:house?'#b6a082':'#baa28d',door:.2,window:.63,lit:true,open:false});});
 enqueue(27,9.9,()=>{lantern(c,...p(27,9.8),31,false,t);});
 if(house){
  enqueue(5.3,9.5,()=>{coop(c,p,5.3,9.5);coop(c,p,5.0,9.65);});
  enqueue(15,9.3,()=>{dryingRack(c,p,13.2,9.3,2.75,false);});
  enqueue(23.5,14.9,()=>{dryingRack(c,p,21.7,14.9,2.95,true);});
 }else{
  const wheel=Number(!!s.flags['ramp-passed']);enqueue(16.6,10.4,()=>cart(c,p,16.3+wheel*1.5,10.35-wheel*.4,wheel*.13));
  enqueue(23.7,10.1,()=>{steps(c,p,22.6,9.4,6,1.5);lantern(c,...p(24.1,10.6),30,false,t);});
 }
 return true;
}
