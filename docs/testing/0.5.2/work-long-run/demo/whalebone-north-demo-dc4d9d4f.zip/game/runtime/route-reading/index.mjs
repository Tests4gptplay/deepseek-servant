import {port} from './port.mjs';
import {hold} from './hold.mjs';
import {salt} from './salt.mjs';
import {coast} from './north.mjs';
import {winter} from './winter.mjs';
import {harborNight} from './evacuation.mjs';
import {returnPort} from './other-port-and-hold.mjs';
import {otherSalt} from './other-salt.mjs';
import {otherCoast} from './other-north.mjs';
import {otherReturn} from './other-winter-and-harbor.mjs';

import {nearCrossings} from './near-crossings.mjs';
import {northernCrossings} from './northern-crossings.mjs';
import {basinReadings,basinCrossings} from './basin-crossings.mjs';

export const crossingReadings=Object.freeze({...nearCrossings,...northernCrossings,...basinCrossings});

export const routeReadings = Object.freeze({...port,...hold,...salt,...coast,...winter,...harborNight,...returnPort,...otherSalt,...otherCoast,...otherReturn,...basinReadings});

export function routeClue(player, entity){
  const entry=entity.to ? crossingReadings[player.map+'>'+entity.to+'@'+entity.x+','+entity.y] : routeReadings[player.map+'/'+entity.id];
  return typeof entry==='function' ? entry(player.flags) : entry;
}
