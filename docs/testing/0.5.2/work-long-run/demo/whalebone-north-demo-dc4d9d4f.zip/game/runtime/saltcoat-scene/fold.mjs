import {line,poly,oval} from '../paint.mjs';
// An empty drying trestle beside the seller's loaded trays. Long upper edge, heavy wet return.
export function foldStand(c,{settled=false,held=false,release=1,learner=false}={}){
 const h=settled?Math.min(1,Math.max(0,release)):0,pull=held&&!settled?2:0;
 oval(c,2,1,34,4.8,'#434b3f48');
 for(const [x,y] of [[-25,1],[19,2]]){line(c,x,y,x+4,y-27,'#5c4a3c',3.4);line(c,x+4,y-27,x+10,y-4,'#94744f',2.4);}
 line(c,-25,-12,29,-6,'#896c4d',2.8);line(c,-23,-28,24,-23,'#62503f',3.4);
 line(c,-22,-29,23,-24,'#c2a476',1.3);
 poly(c,[[-17,-28],[-9,-30],[7,-28],[18,-25],[11,-22],[-4,-23]],'#9daea0','#586c66');
 poly(c,[[-17,-28],[-6,-25],[3,-25],[12,-23],[14,-18],[9,-17],[3,-17],[-5,-20],[-12,-19],[-17,-21]],'#839c96','#526b68');
 line(c,-13,-26,-5,-23,'#c9cbbc',1.3);line(c,-2,-23,6,-21,'#c5cbb7',1);
 const tipX=15+5*h+pull,tipY=-10-8*h-pull;
 c.beginPath();c.moveTo(-17,-22);c.bezierCurveTo(-13,-18,-12,-16,-6,-17);c.bezierCurveTo(0,-18,4,-13,9,-14);
 c.quadraticCurveTo(13,-14,tipX-2,tipY-2);c.lineTo(tipX,tipY);c.quadraticCurveTo(12,-5-h*4,7,-9-h*2);
 c.bezierCurveTo(1,-8,-2,-12,-8,-12);c.bezierCurveTo(-14,-10,-16,-14,-18,-15);c.closePath();c.fillStyle='#3c6165';c.fill();c.strokeStyle='#344e50';c.lineWidth=1;c.stroke();
 c.beginPath();c.moveTo(-16,-16);c.bezierCurveTo(-11,-11,-9,-16,-3,-13);c.bezierCurveTo(3,-12,6,-8,10,-11-h*2);c.lineTo(tipX-1,tipY-1);c.strokeStyle='#d3d0ab';c.lineWidth=1.45;c.stroke();
 line(c,-13,-24,-10,-19,'#a5b3a8',.95);line(c,2,-24,6,-17,'#6d8a86',.95);
 if(!settled){oval(c,-10,-10,1.1,1.7,'#bad3cd');oval(c,10,-6,1,1.5,'#bad3cd');}
 else {oval(c,tipX+1,-5,1.2,2,'#bad3cd');oval(c,tipX+2,0,3.1,.8,'#8fa99e');}
 if(held||learner){poly(c,[[27,-14],[32,-15],[33,-10],[29,-8],[25,-9],[23,-11],[20,-12],[19,-14],[23,-14]],'#deb092','#725547');
  line(c,24,-13,27,-12,'#ae826b',.9);line(c,25,-12,28,-11,'#ae826b',.8);poly(c,[[31,-16],[36,-18],[39,-12],[33,-9]],learner?'#74856d':'#5e7776','#465a55');}
}
