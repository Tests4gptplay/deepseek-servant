import {arc,line,oval} from '../paint.mjs';
const point=(b,x,y,id)=>{
 const n=b.party.findIndex(h=>h.id===id&&h.hp>0);if(n<0)return null;
 const edge=b.party[n].lane==='edge'?9:0;
 return [x+[-27,-52,-82,-101][n]-edge,y+[-10,20,-8,23][n]-edge-13];
};
function knot(c,x,y){arc(c,x,y,3.2,-2.7,2.7,'#e2c585',1.8);line(c,x-3,y+2,x+4,y-2,'#e2c585',1.3);}
export function pairSigns(c,x,y,b,t){
 const rope=b.pairTurns?.rope,a=point(b,x,y,'mara'),i=point(b,x,y,'ivo');
 if(a&&i&&(rope||b.lineBrace?.length)){
  const slack=b.lineBrace?.length?3:8+Math.sin(t*3);
  c.save();c.lineWidth=2.2;c.strokeStyle='#d9b779';c.beginPath();c.moveTo(...a);c.quadraticCurveTo((a[0]+i[0])/2-7,(a[1]+i[1])/2+slack,...i);c.stroke();knot(c,...a);knot(c,...i);c.restore();
 }
 if(b.sightMarks>0||b.pairTurns?.sight){
  for(const id of ['selene','mira']){
   const at=point(b,x,y,id);if(!at)continue;
   const [vx,vy]=at,tx=x+38,ty=y-18;
   c.save();c.setLineDash([3,7]);line(c,vx+4,vy,tx,ty,b.sightMarks?'#8ad5c6':'#88b8a9',1);c.restore();
  }
  if(b.sightMarks>0){for(let n=0;n<b.sightMarks;n++)arc(c,x+38,y-18,8+n*4,-2.65,-.3,'#dfcc90',1.8);oval(c,x+38,y-18,2,2,'#efdb9f');}
 }
}
