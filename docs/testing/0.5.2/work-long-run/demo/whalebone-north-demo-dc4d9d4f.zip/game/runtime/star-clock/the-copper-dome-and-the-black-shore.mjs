import {copperDome,quayFixtures} from './the-rivets-and-the-tidewall.mjs';
import {poly,line,oval,rand} from '../paint.mjs';
const locations=new Set(['star-clock-quay','meridian-shutter','pendulum-cellar','night-oar-road','mothglass-landing']);
const brass='#b49a67',stone='#6c817a',shade='#40544f',glass='#70a9a1';
export function starSky(c,w,h,m,t){
 if(!locations.has(m.id))return false;
 const shop=m.id==='pendulum-cellar',sun=m.id==='star-clock-quay';
 const g=c.createLinearGradient(0,0,0,h);g.addColorStop(0,shop?'#152a2d':sun?'#426071':'#16273f');g.addColorStop(.32,shop?'#4e655c':sun?'#d1a982':'#475970');g.addColorStop(.51,shop?'#374a41':sun?'#79948a':'#465e66');g.addColorStop(1,'#243e44');c.fillStyle=g;c.fillRect(0,0,w,h);
 if(shop){for(let i=0;i<8;i++){const x=w*i/7;line(c,x,0,x-30,h*.75,'#34473e',9);line(c,x+4,0,x-25,h*.75,'#626e59',2);}return true;}
 for(let i=0;i<110;i++){const x=w*rand(i,111),y=h*rand(i,192)*.31;oval(c,x,y,i%6?.62:1.4,i%6?.62:1.4,sun?'#efe0c975':'#d5ded9bd');}
 const a=w*.73,b=h*.115;for(const [dx,dy,col] of [[-24,-9,'#e1e0ca'],[0,3,'#e9a982'],[17,-15,'#d1dacf']]){oval(c,a+dx,b+dy,1.6,1.6,col);line(c,a+dx,b+dy-4,a+dx,b+dy+4,col,.7);}
 const horizon=h*.29;for(let k=0;k<2;k++){const pts=[[0,horizon+25]];for(let j=0;j<=26;j++)pts.push([j*w/26,horizon+11*Math.sin(j*.68+k)-rand(j,52+k)*10+k*8]);pts.push([w,horizon+29],[0,horizon+29]);poly(c,pts,k?'#4a6263':'#687879');}
 for(let i=0;i<70;i++){const x=w*rand(i,141),y=horizon+27+rand(i,20)*(h-horizon-24);line(c,x+Math.sin(t*.23+i)*2,y,x+5+11*rand(i,244),y,'#d5d9bf42',.8);}return true;
}
function dome(c,p,f){
 if(copperDome(c,p,f))return;
 const u=f.x+f.w*.5,v=f.y+f.h*.56,[a,b]=p(u,v),rx=(f.w+f.h)*10,ry=rx*.32;
 oval(c,a,b+1,rx,ry,'#445b54');c.fillStyle='#6f8981';c.beginPath();c.moveTo(a-rx,b);c.bezierCurveTo(a-rx*.98,b-69,a-rx*.22,b-106,a+1,b-106);c.bezierCurveTo(a+rx*.37,b-101,a+rx,b-58,a+rx,b);c.bezierCurveTo(a+rx*.57,b+ry,a-rx*.57,b+ry,a-rx,b);c.fill();
 for(const bend of [-.70,-.32,.1,.44,.76]){c.beginPath();c.moveTo(a+2,b-104);c.quadraticCurveTo(a+rx*bend*1.28,b-66,a+rx*bend,b+ry*Math.sqrt(1-bend*bend)*.74);c.strokeStyle='#b3a985';c.lineWidth=1.5;c.stroke();}
 c.beginPath();c.moveTo(a-4,b-105);c.quadraticCurveTo(a+rx*.14,b-49,a+rx*.11,b+ry*.72);c.strokeStyle='#233c41';c.lineWidth=9;c.stroke();c.lineWidth=1;
 for(const sign of [-1,1])line(c,a+sign*4,b-106,a+sign*4,b-121,brass,1.7);oval(c,a,b-121,8,2.4,brass);
}
function house(c,p,f,kind){
 const x=f.x,y=f.y,w=f.w,h=f.h,z=kind==='gate'?51:35;
 const L=(u,v,k=0)=>p(x+u,y+v,k);const a=L(0,h),b=L(w,h),e=L(w,0);
 poly(c,[a,b,L(w,h,z),L(0,h,z)],kind==='glass'?'#809a87':'#acac8e',shade);
 poly(c,[b,e,L(w,0,z),L(w,h,z)],'#65786b',shade);
 poly(c,[L(-.2,-.2,z),L(w+.2,-.2,z),L(w+.2,h+.2,z),L(-.2,h+.2,z)],kind==='glass'?glass:'#596f64',shade);
 for(let i=.6;i<w-.15;i+=1.14){const n=L(i,h,z*.4);c.fillStyle='#3a514b';c.fillRect(n[0]-3,n[1]-6,6,10);line(c,n[0],n[1]-5,n[0],n[1]+2,kind==='glass'?'#a8e5ce':'#d8c79a',1.1);}
 const [cx,cy]=L(w*.44,h,z+3);
 if(kind==='gate'||kind==='shop'){oval(c,cx,cy-14,14,15,'#344b47');oval(c,cx,cy-14,12,13,'#d1c59b');for(let i=0;i<12;i++){const a=i*Math.PI/6;line(c,cx+9*Math.sin(a),cy-14-10*Math.cos(a),cx+11*Math.sin(a),cy-14-12*Math.cos(a),'#59645b',1);}
  line(c,cx,cy-14,cx-6,cy-18,shade,1.8);line(c,cx,cy-14,cx+5,cy-22,shade,1.2);oval(c,cx,cy-14,1.3,1.3,brass);}
}
export function starFeature(c,p,m,f){
 if(quayFixtures(c,p,m,f))return true;
 if(!locations.has(m.id)||f.kind!=='building')return false;
 if(m.id==='meridian-shutter')dome(c,p,f);else house(c,p,f,m.id==='mothglass-landing'?'glass':m.id==='star-clock-quay'&&f.x>20?'gate':m.id==='star-clock-quay'&&f.x<10?'shop':'room');
 return true;
}
