import {stations} from '../rules/trials.mjs';
import {encounter} from './encounter.mjs';
import {syncParty} from './party.mjs';

function matchedCourse(spec,s){
 const previous=spec.id==='keel-long'?'practice:keel-black':spec.id==='keel-polar'?'practice:keel-long-scaled':null;
 if(!previous||!s.flags[previous]&&!(spec.id==='keel-polar'&&s.flags['practice:keel-long']))return null;
 const levels=Object.values(s.expedition.heroes).map(h=>h.level),level=Math.max(1,Math.floor(levels.reduce((a,b)=>a+b,0)/levels.length));
 if(level>=spec.level)return null;
 const deep=spec.id==='keel-polar',hp=Math.min(spec.hp,(deep?290:224)+(deep?10:8)*level),attack=Math.min(spec.attack,(deep?9:7)+Math.round(level*(deep?.79:.68)));
 return {...spec,id:spec.id+'-scaled',name:spec.name+' · 本队水压',level,hp,attack,phases:spec.phases.map(p=>({...p,fromHp:Math.max(1,Math.round(p.fromHp*hp/spec.hp))})),
  rewards:{xp:deep?131:89,repeatXp:1,items:{'brine-dose':1},label:'同水序、同岗位的检校留了一枚靛蓝签。原压记录另记。'}};
}
export function practice(ctx,entity,close){
 const {state,ui,world}=ctx,station=stations[state.player.map];if(!station)return close();
 syncParty(world,state.player);
 function menu(){
  const options=station.list.map(id=>{const s=world.encounters[id];return [s.name+' · Lv'+s.level,()=>offer(s)];});
  ui.show('practice',entity.name,'各地值守人用闲下来的卷盘和水槽复演航险。黑潮上检后，旧领航员还可以按同行者的实有身手压浅水槽，依次走完深线水序。两种压力各记各的签。',[...options,['离开试台',close]]);
 }
 function start(spec){
  encounter(ctx,{...spec,entityId:entity.id},()=>{state.player.flags['practice:'+spec.id]=true;state.player.victories++;ctx.sync();close();},close);
 }
 function offer(spec){
  const first=!state.player.flags['reward:'+spec.id],award=spec.rewards||{},calibrated=matchedCourse(spec,state.player);
  const opts=[['开始检校',()=>start(spec)]];
  if(calibrated)opts.push(['按本队水压校试',()=>ui.show('practice',calibrated.name,
   '值守人改调压舱水。伙伴照用眼下的等级、配装和药品，三段水序与读招完整保留。\n承载 '+calibrated.hp+'　压力 '+calibrated.attack+'　全压检校另记。',
   [['按此水压开闸',()=>start(calibrated)],['回原压说明',()=>offer(spec)]] )]);
  opts.push(['回试台',menu]);
  ui.show('practice',spec.name,spec.objective+'\n建议成长 Lv'+spec.level+'　承载 '+spec.hp+'　压力 '+spec.attack+'\n'+(first?'首检经验 '+award.xp:'复检经验 '+award.repeatXp),opts);
 }
 menu();
}
