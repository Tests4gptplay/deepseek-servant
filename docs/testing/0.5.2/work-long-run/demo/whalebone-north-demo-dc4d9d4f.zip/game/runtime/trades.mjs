import {line,poly,oval,arc} from './paint.mjs';
export function balance(c,x,y,level=false,t=0){
 const tilt=level?0:-.095+Math.sin(t*1.15)*.016;
 c.save();c.translate(x,y);oval(c,5,3,40,8,'#47574a55');
 poly(c,[[-30,2],[-18,-3],[23,-1],[37,4],[25,8],[-23,8]],'#a68560','#776a51');
 poly(c,[[-4,0],[0,-52],[5,-53],[7,0]],'#755c45','#554f40');
 c.save();c.translate(3,-46);c.rotate(tilt+.078);c.translate(-3,46);
 line(c,-33,-43,39,-49,'#665844',4);line(c,-33,-45,39,-51,'#dfbd77',1.6);
 for(const [k,off] of [[-29,2],[34,-3]]){
  line(c,k,-44+off,k-8,-23+off,'#71796a');line(c,k,-44+off,k+9,-23+off,'#71796a');
  poly(c,[[k-10,-23+off],[k+10,-23+off],[k+5,-18+off],[k-4,-18+off]],'#c59864','#735e45');
 }
 c.restore();
 if(level){oval(c,-28,-20,4,1.6,'#766955');oval(c,-22,-20,3.4,1.5,'#87785f');}
 arc(c,3,-31,10,-Math.PI,0,'#c7b090',4);line(c,3,-31,-2,-40,'#ad5543',2);line(c,3,-31,7,-39,'#f0e1bc',1.6);
 for(let i=0;i<4;i++)line(c,12+i*5,-52,12+i*5,-48,'#795f48',.8);
 c.restore();
}
export function business(c,f,p,h){
 const w=f.w||2,d=f.h||2,label=f.label||'',loc=p(w*.52,d,h*.49);
 c.save();c.translate(...loc);
 if(/殓|葬/.test(label)){
  line(c,-14,-13,-14,21,'#8a7458',2);line(c,21,-3,21,31,'#8a7458',2);
  poly(c,[[-17,-18],[2,-23],[26,-10],[21,-2],[-14,-12]],'#e8dfc7','#9f9e85');
  for(const x of [-12,-5,4,12]){line(c,x,-11+(x+12)*.35,x,-1+(x+12)*.35,'#d8c8a1',3);}
  oval(c,2,19,9,3,'#798373');for(let j=0;j<5;j++){line(c,j*2-3,17,j*3-6,9-j%2,'#78896d');oval(c,j*3-6,8-j%2,2.7,1.7,'#e6d4a2');}
 }else if(/秤/.test(label)){
  poly(c,[[-12,13],[6,7],[18,12],[0,18]],'#9a7754','#675d4a');
  for(let i=0;i<3;i++){const x=-4+i*6,y=10+i*.6;poly(c,[[x-3,y],[x-2,y-4],[x+2,y-4],[x+3,y]],'#6f7061','#575e54');}
  line(c,-15,-8,-15,16,'#806b4e',2);line(c,-15,-8,-2,-12,'#9a815d',2);
 }else if(/粮|仓/.test(label)){
  for(let j=0;j<6;j++){const x=(j%3)*8-10+(j>2?2:0),y=j>2?13:18;oval(c,x,y,6.5,4.7,'#b1976c');line(c,x-4,y,x+3,y+2,'#8b785b',.8);}
  line(c,1,-13,24,-19,'#625740',3);line(c,21,-17,21,0,'#777659');poly(c,[[18,-2],[24,-2],[26,3],[16,3]],'#8e7855');
 }else if(/索|缆/.test(label)){
  for(const a of [-4,8]){for(let j=0;j<4;j++)arc(c,a,11,8-j,0,Math.PI*2,'#a58a62',1);}
  line(c,-17,-7,16,-14,'#73674e',2);line(c,14,-14,14,9,'#a78c62',2);line(c,-15,-7,-15,12,'#a78c62',2);
 }
 c.restore();
}
