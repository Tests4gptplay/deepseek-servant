import {material} from '../tiles.mjs';
import {walkable} from '../state.mjs';
export const bays=new Set(['hulls-not-in-line','keel-in-shadow']);
// Coordinates are in map space; each dock and turning basin follows the authored entrances.
export const edges={
 'hulls-not-in-line':[
  ['bank',[[41.4,17.5],[43.3,16.25],[44.5,7.5],[46.9,6.8],[47,24.5],[38.4,21.7],[38.5,19.5]]],
  ['quay',[[2.4,9.1],[34.9,9.1],[35.3,11.9],[2.2,12.0]]],
  ['gangway',[[31.1,11.2],[32.6,10.8],[36.7,13.2],[37.1,14.25],[35.8,14.47],[33.1,12.9]]],
  ['stairs',[[27.3,15.9],[42.7,15.8],[43.6,18.4],[40.5,19.25],[38.8,18.10],[27.5,17.9]]],
  ['float',[[26.4,14.6],[29.2,14.2],[31.0,15.9],[30.0,17.3],[28.1,16.7]]]
 ],
 'keel-in-shadow':[
  ['bank',[[34.1,17],[38.9,14],[43.7,14],[44,21.1],[38,22.1],[35.3,19.5]]],
  ['quay',[[2.3,9.94],[35.1,9.95],[35.2,11.98],[2.10,12.02]]],
  ['mud',[[3.3,12.0],[6.8,11.6],[12.7,12.0],[14.1,13.4],[11.5,15.3],[6.0,15.65],[3.2,14.18]]],
  ['reef',[[24.8,11.55],[29.5,11.43],[31.8,12.51],[30.3,13.65],[27.0,14.18],[24.5,13.0]]],
  ['stairs',[[25.0,15.05],[37.9,14.5],[40.0,15.6],[38.1,17.53],[26.2,17.76],[24.6,16.5]]],
  ['gangway',[[32.9,11.1],[34.4,10.9],[35.45,14.7],[36.55,15.58],[35.35,16.0],[34.30,15.15]]]
 ]
};
export const localWorks={
 'fender-kin':[3,10,32,2,'fender','护筐双面木栈'],
 'crib-hold':[0,14,10,3,'slats','舱底探水格栅'],
 'outside-navel':[8,14,16,1,'reef','可立脚的螺衣砾脊'],
 'germ-cellar':[9,12,13,1,'mud','留有草绳拖痕的潮泥阶'],
 'wren-deck':[24,12,5,2,'tender','鹪鹩号的探浅艇甲板'],
 'upper-spar':[18,10,4,2,'ward','南檐护送驳的靠板'],
 'lower-tide':[17,14,2,3,'slats','进潮槽踏铁与观水缝'],
 'flour-skiff':[21,4,6,1,'galley','食舫的碗架通板'],
 'hush-bay':[20,5,5,1,'tender','背风艇两条舷板'],
 'ladle-cut':[12,10,3,1,'stairs','灶檐水街的搁脚阶'],
 'keel-cradle':[17,12,3,1,'cradle','砾鞍上的干舟床'],
 'breathing-scree':[18,12,3,1,'reef','绕开螺卵床的砾肩']
};
function inside(x,y,ring){
 let hit=false;for(let i=0,j=ring.length-1;i<ring.length;j=i++){
  const [ax,ay]=ring[i],[bx,by]=ring[j];
  if((ay>y)!==(by>y)&&x<(bx-ax)*(y-ay)/(by-ay)+ax)hit=!hit;
 }return hit;
}
export const labels={bank:'海岸石肩',quay:'岸栈',gangway:'连岸踏板',stairs:'潮阶',float:'浮排',mud:'潮泥浅滩',reef:'露水暗礁',rowing:'划艇过水'};
export function footing(m,x,y){
 if(!m||!walkable(m,x,y))return null;
 const regions=edges[m.id];if(regions){
  for(let i=regions.length-1;i>=0;i--)if(inside(x+.5,y+.5,regions[i][1]))return regions[i][0];
  return 'rowing';
 }
 const q=localWorks[m.id];return q&&x>=q[0]&&x<q[0]+q[2]&&y>=q[1]&&y<q[1]+q[3]&&material(m,x,y)==='water'?q[4]:null;
}
export function footingName(m,k){return localWorks[m.id]?.[5]||labels[k]||'';}
