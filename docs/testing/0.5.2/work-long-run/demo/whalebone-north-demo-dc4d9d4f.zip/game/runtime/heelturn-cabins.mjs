const homeIds=new Set(['heel-hall','heel-high-sill','heel-low-turn','heel-folded-room','heel-flooded-hall','heel-broad-ramp','heel-quiet-return']);
export function poly(c,points,ink,border){
 c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();
 c.fillStyle=ink;c.fill();if(border){c.strokeStyle=border;c.lineWidth=1.2;c.stroke();}
}
export function line(c,points,color,w=1){c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.strokeStyle=color;c.lineWidth=w;c.stroke();}
export function oval(c,[x,y],rx,ry,fill){c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);c.fillStyle=fill;c.fill();}
function cabin(c,p,f,night){
 const x=f.x+.12,y=f.y+.15,w=f.w-.25,h=f.h-.3,height=Math.min(66,32+2.8*h);
 const q=(a,b,z=0)=>p(x+a,y+b,z),shadow='#504638',warm=night?'#a8875a':'#c6a679',deep=night?'#544b40':'#74634d';
 poly(c,[q(0,0),q(w,0),q(w,h),q(0,h)],'#998060',shadow);
 poly(c,[q(0,0),q(w,0),q(w,0,height-5),q(0,0,height)],warm,shadow);
 poly(c,[q(0,0),q(0,h),q(0,h,height-4),q(0,0,height)],deep,shadow);
 for(let i=1;i<h*1.6;i++){const k=i/1.6;line(c,[q(0,k),q(0,k,height-4)],'#594e40');}
 for(let i=1;i<w*1.6;i++){const k=i/1.6;line(c,[q(k,0),q(k,0,height-4)],'#9a7e58');}
 for(const a of [0,w*.42,w])line(c,[q(a,0),q(a+.04,0,height-4)],'#554a3b',3);
 const lx=w*.26,rx=w*.66;
 poly(c,[q(lx,0,19),q(rx,0,19),q(rx,0,height-9),q(lx,0,height-8)],'#385154','#574b3a');
 for(let i=0;i<3;i++)line(c,[q(lx,0,23+i*6),q(rx,0,23+i*6)],i===1?'#cfbd8d':'#8cae9b',2);
 poly(c,[q(.12,h*.35,24),q(.12,h*.7,25),q(.12,h*.7,14),q(.12,h*.52,16),q(.12,h*.35,13)],night?'#95736a':'#9a665b');
 line(c,[q(0,.12,height+2),q(w,.12,height-2)],'#d4b07e',3);
 line(c,[q(.09,0,height+3),q(.09,h,height-1)],'#594a39',4);
 // Open front lets the player see the floor, living spaces and bent footing.
 for(const u of [w*.16,w*.68]){
  line(c,[q(u,.18,height-5),q(u+.35,1.1,height+2)],'#6e5b44',3);
  line(c,[q(u+.35,1.1,height+2),q(u+.45,1.35,height+1)],'#d4ac72',2);
 }
 poly(c,[q(.45,h*.25,13),q(.45,h*.7,13),q(1.12,h*.7,13),q(1.12,h*.25,13)],'#bc9867','#64513a');
 const pot=q(.7,h*.4,16);oval(c,pot,5,4,'#496866');oval(c,[pot[0],pot[1]-3],3.7,1.4,'#acb5a3');
 const bed=[q(w*.34,h*.46,6),q(w*.78,h*.46,6),q(w*.78,h*.66,6),q(w*.34,h*.66,6)];
 poly(c,bed,'#baaa89','#74664e');line(c,[bed[2],bed[3]],'#617b72',3);
 if(night)line(c,[q(0,h*.8,8),q(w*.45,h*.77,8),q(w,h*.64,12)],'#a5c7bc',1.8);
}
function rib(c,p,f){
 const x=f.x+.1,y=f.y+.1,w=f.w-.2,h=f.h-.2;
 const q=(a,b,z=0)=>p(x+a,y+b,z);
 poly(c,[q(0,0),q(w,0),q(w,h),q(0,h)],'#736951','#594c3d');
 const n=Math.max(2,Math.min(7,Math.round(Math.max(w,h)/1.7)));
 for(let j=0;j<n;j++){
  const u=(j+.35)/n,ax=w*u,b=h*.38,z=18+11*Math.sin(u*Math.PI);
  const left=q(ax,b-.13),right=q(ax+.30,b+.23),top=q(ax+.10,b-.05,z);
  poly(c,[left,right,top,q(ax-.14,b-.12,z-1)],'#8e795b','#504e42');
  line(c,[q(ax+.01,b,z),q(ax+.2,b+.24,0)],'#bd9d73',1.4);
 }
 line(c,[q(0,h*.30,17),q(w*.4,h*.28,23),q(w,h*.45,15)],'#554a3b',3);
}
function cabinFloor(c,p,f){
 const a=f.x,b=f.y,w=f.w,h=f.h||1;
 if(f.kind==='water'){
  for(let i=0;i<5;i++){const y=b+h*(i+.4)/5;line(c,[p(a+w*.12,y),p(a+w*.29,y+.06),p(a+w*.35,y)],'#a8c0b569',1);}
  return;
 }
 for(const side of [.10,.86])line(c,[p(a+.15,b+h*side),p(a+w*.36,b+h*side+.04),p(a+w-.15,b+h*side)],'#baa988',1.25);
 if(f.kind==='pier'){
  for(let k=.65;k<w;k+=1.25)line(c,[p(a+k,b+h*.12),p(a+k+.04,b+h*.82)],'#816e53',1);
 }
}
function cupboard(c,p,f){
 const x=f.x+.3,y=f.y+.32,w=Math.min(3.4,f.w-.4),h=Math.min(1.05,f.h-.4);
 const q=(u,v,z=0)=>p(x+u,y+v,z),a=q(0,0,15),b=q(w,0,15),d=q(0,h,15),e=q(w,h,15);
 poly(c,[a,b,e,d],'#b49566','#675442');poly(c,[d,e,q(w,h),q(0,h)],'#826c4f','#5e523e');
 for(let u=.25;u<w;u+=.65){line(c,[q(u,0,15),q(u,h,15)],'#8e7956');oval(c,q(u,h,8),2,1.3,'#d5bd82');}
}
export function openHeelCabin(c,p,map,f){
 if(!homeIds.has(map.id))return false;
 if(f.kind==='building')cabin(c,p,f,map.act===6);
 else if(f.kind==='wall')rib(c,p,f);
 else if(f.kind==='crate')cupboard(c,p,f);
 else if(['path','pier','water'].includes(f.kind))cabinFloor(c,p,f);
 else return false;
 return true;
}
