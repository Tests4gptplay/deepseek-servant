import {arc,line,oval,poly} from './paint.mjs';
import {box,plate,wood,wheel,tub} from './voyage-shapes.mjs';
import {seedBed,skiff,coalRack} from './harbor-crafts.mjs';
import {screen,table} from './social-furniture.mjs';
import {cauldron} from './social-fauna.mjs';

const sites={
 'rye-yard':[[8,8.2,'mill'],[12,8.6,'sacks'],[16,10.1,'hearth'],[20.2,9,'bed']],
 'germ-cellar':[[10.2,8.4,'marks'],[13,10.2,'tray'],[17.8,9.5,'hoist'],[21.8,10.1,'split']],
 'flour-skiff':[[9,8.8,'oars'],[13.6,8.6,'skiff'],[17.4,10.2,'bowls'],[22,10,'kettle']],
 'split-table':[[9,8.7,'grain'],[13.1,8.7,'millstone'],[16,9.9,'bench'],[19,10,'bowls']],
 'moth-hatch':[[8.9,8.4,'marks'],[12.8,9.7,'silk'],[17.3,9.1,'hatch']],
 'husk-room':[[9.2,8.7,'fungus'],[13.4,8.6,'curtain'],[17.4,9.4,'moths'],[20.8,10.7,'bed']]
};
function sack(c,p,x,y){for(let j=0;j<7;j++){const a=p(x+(j%3)*.34,y+Math.floor(j/3)*.21,5+(j>4?4:0));oval(c,...a,8,5,'#b49c73');line(c,a[0]+2,a[1]-3,a[0]+5,a[1]-6,'#7a7057',1.6);}}
function stone(c,p,x,y){const a=p(x,y,8);oval(c,a[0],a[1]+2,27,13,'#737e75');oval(c,...a,27,10,'#aaa99a');for(let i=0;i<8;i++){const r=i*Math.PI/4;line(c,a[0]+4*Math.cos(r),a[1]+2*Math.sin(r),a[0]+24*Math.cos(r),a[1]+8*Math.sin(r),'#8a9183',1.2);}oval(c,...a,4,2.2,'#5c6962');}
function draw(c,p,x,y,k,s,t){
 const f=s.flags,high=s.tide==='high',[a,b]=p(x,y);
 switch(k){
 case 'mill':stone(c,p,x,y);wheel(c,a-13,b-22,20,t*.35,12);box(c,p,x-.97,y-.06,1.94,.23,26,5,wood);break;
 case 'millstone':stone(c,p,x,y);for(const dx of [-1.05,.68])box(c,p,x+dx,y+.4,.67,.42,0,8,wood);break;
 case 'sacks':sack(c,p,x-.3,y-.2);break;
 case 'grain':table(c,p,x-1,y-.4,'paper');sack(c,(x,y,z=0)=>p(x,y,z+12),x-.25,y);break;
 case 'hearth':case 'kettle':cauldron(c,a,b,t,k==='hearth'||!f['moth-heat-owed']||f['moth-cold-account']);break;
 case 'oars':for(let i=0;i<2;i++){const q=p(x,y+i*.24);line(c,q[0]-16,q[1]+2,q[0]+21,q[1]-13,'#a88861',2);oval(c,q[0]+21,q[1]-13,6,2.5,'#c9a97c');}break;
 case 'skiff':skiff(c,p,x,y,s.tide,t,true);break;
 case 'bowls':table(c,p,x-.84,y-.39,'bowl');if(f['rye-received'])tub(c,a+16,b-13,7,'#c8b386');break;
 case 'bench':box(c,p,x-.65,y-.24,1.35,.48,0,8,wood);break;
 case 'bed':seedBed(c,p,x-.9,y-.5,!!(f['rye-root']||f['moth-root']||f['rye-received']));break;
 case 'marks':for(let i=0;i<4;i++){const z=3+i*5;line(c,...p(x-1,y,z),...p(x+.82,y,z),'#909982',2);}line(c,...p(x-.7,y+.04,high?18:7),...p(x+.93,y+.04,high?18:7),'#b2cebc',2);break;
 case 'tray':case 'hoist':{const up=k==='hoist'&&f['rye-air'],z=up?23:high?7:3;
  if(k==='hoist'){for(const dx of [-.78,.86])line(c,...p(x+dx,y),...p(x+dx,y,37),'#79654f',2.8);line(c,...p(x-.8,y,36),...p(x+.9,y,36),'#b59e72',3);}
  tub(c,a,b+1,14,high?'#729994':'#918a73');seedBed(c,(a,b,u=0)=>p(a,b,u+z),x-.74,y-.45,!!(f['rye-root']&&up));
  if(k==='hoist')for(const dx of [-.64,.72])line(c,...p(x+dx,y,35),...p(x+dx,y,z+6),'#a89873',1.4);break;}
 case 'split':{coalRack(c,p,x-.75,y-.35,true);if(f['rye-root']){const q=p(x,y,12);line(c,...q,q[0]-2,q[1]-10,'#a8bf70',2);}}break;
 case 'silk':screen(c,p,x-.72,y,1.5,'#87a69a',!!f['moth-ready']);break;
 case 'hatch':case 'curtain':screen(c,p,x-.88,y,1.83,k==='hatch'?'#869080':'#b48066',!!f['moth-flue']);break;
 case 'fungus':for(let i=0;i<8;i++){const q=p(x+(i%4)*.28-.5,y+Math.floor(i/4)*.29);line(c,...q,q[0],q[1]-(high?3:7),'#b7b98c',2);oval(c,q[0],q[1]-(high?3:7),4.3,2.1,'#c5b795');}break;
 case 'moths':for(let i=0;i<7;i++){const dx=f['moth-flue']?16:3,z=i*2+t;let u=a+Math.cos(z*.55)*dx+i*2,v=b-15+Math.sin(z*.91)*5;
  oval(c,u-2,v,3.3,1.6,'#d5d1a3');oval(c,u+2,v-2,2.8,1.7,'#c6c4a0');}break;
 }
}
export function saltPlaces(c,p,m,s,t,ordered){for(const [x,y,k] of sites[m.id]||[])ordered.push([x+y+.52,()=>draw(c,p,x,y,k,s,t)]);}
export function saltWorkshop(c,p,m,f,s,t){
 if(!sites[m.id])return false;const x=f.x+(f.w||1)*.5,y=f.y+(f.h||1)*.68;
 if(f.kind==='hearth'){draw(c,p,x,y,'hearth',s,t);return true;}if(f.kind==='boat'){draw(c,p,x,y,'skiff',s,t);return true;}
 if(f.kind==='crate'){draw(c,p,x,y,m.id==='germ-cellar'?'tray':m.id==='husk-room'?'moths':m.id==='moth-hatch'?'silk':'sacks',s,t);return true;}
 return false;
}
