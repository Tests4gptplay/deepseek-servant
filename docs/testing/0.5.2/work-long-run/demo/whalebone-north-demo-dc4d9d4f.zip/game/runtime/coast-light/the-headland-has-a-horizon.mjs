import {outdoorWatch} from '../star-clock/surfaces-under-starlight.mjs';
const shore=new Set(['edge-bleach','rib-survey','red-beacon','burial-cape']);
// The navigable cells keep their square coordinates. Only distant rows of the
// same coast are projected towards the painted sea horizon.
export function makeShoreProjection(map,viewX,viewY,anchorY,height,zoom,ordinary){
 if(!shore.has(map.id)&&!outdoorWatch(map))return ordinary;
 const horizon=outdoorWatch(map)?.318:map.id==='burial-cape'?.335:.298;
 const vanishingDepth=Math.min(-76,(horizon-anchorY)*height/zoom);
 const shoulder=-42,room=shoulder-vanishingDepth;
 return (x,y,z=0)=>{
  const depth=(x+y-viewX-viewY-1)*14,lateral=(x-y-viewX+viewY)*31;
  if(depth>=shoulder)return [lateral,depth-z];
  const fall=1-Math.exp((depth-shoulder)/room);
  const f=1-.15*fall*fall;
  return [lateral*f,shoulder-room*fall-z*(1-.18*fall)];
 };
}
