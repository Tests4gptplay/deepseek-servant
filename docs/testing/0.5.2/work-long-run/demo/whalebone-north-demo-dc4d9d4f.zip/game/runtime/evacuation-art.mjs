import {poly,line,oval,arc} from './paint.mjs';
import {box,wood,bed,parchment} from './voyage-shapes.mjs';
import {figure} from './figures.mjs';
function cup(c,x,y,large=false){
 const k=large?1:.72;c.save();c.translate(x,y);c.scale(k,k);
 poly(c,[[-6,-9],[6,-9],[5,-2],[2,0],[-4,-1]],'#d5b24d','#645944');arc(c,7,-6,3,-1.6,1.7,'#c9ab61',1.6);oval(c,0,-9,6,1.6,'#e5ce82');oval(c,0,-9,4.5,.7,'#8b7148');c.restore();
}
function slopingRoom(c,a,b,open){
 c.save();c.translate(a,b);c.rotate(-.105);
 poly(c,[[-65,7],[-66,-65],[18,-79],[62,-52],[59,1]],'#a08d73','#625c51');
 poly(c,[[-66,-65],[16,-82],[66,-55],[56,-49],[12,-68],[-68,-55]],'#6e7167','#565b52');
 for(const x of [-53,-14,31,55])line(c,x,-53,x,3,'#765f4c',3);
 line(c,-58,-22,48,-27,'#8d7961',4);line(c,-15,0,-18,-44,'#584d42',20);
 poly(c,[[-29,-39],[-11,-42],[-11,-2],[-29,1]],'#474c46');
 if(open)poly(c,[[-30,0],[-11,-2],[15,11],[2,18]],'#b38e65','#705d48');
 else poly(c,[[-28,-37],[-14,-40],[-14,-3],[-28,-1]],'#8b6c4e','#594d41');
 for(const x of [10,29]){poly(c,[[x,-32],[x+12,-33],[x+12,-19],[x,-18]],'#8eaaaa','#655f50');line(c,x+5,-33,x+5,-18,'#c7b795',1.4);}
 c.restore();
}
function shutters(c,a,b,open){
 c.save();c.translate(a,b);poly(c,[[-34,-9],[-34,-53],[34,-56],[34,-12]],'#766a57','#5d5144');
 poly(c,[[-28,-17],[-28,-48],[28,-50],[28,-19]],'#526967','#cbb994');
 for(const side of [-1,1]){const inn=open?22:1,outer=30;
  poly(c,[[side*outer,-50],[side*inn,-47],[side*inn,-17],[side*outer,-19]],'#a78860','#605747');
  for(const h of [-42,-36,-30,-24])line(c,side*(inn+1),h+1,side*(outer-1),h-1,'#c4ab83',1.3);}
 line(c,-34,-13,35,-15,'#baa27e',3);c.restore();
}
function plank(c,p,x,y,loose,t){
 const h=loose?5+Math.sin(t*1.1)*1.8:13;
 const a=p(x-1,y-.4,4),b=p(x+1.25,y-.4,h),d=p(x-1,y+.38,4),e=p(x+1.25,y+.38,h);
 poly(c,[a,b,e,d],'#aa8564','#675e50');for(let i=0;i<6;i++){const q=i/6;line(c,a[0]+(b[0]-a[0])*q,a[1]+(b[1]-a[1])*q,d[0]+(e[0]-d[0])*q,d[1]+(e[1]-d[1])*q,'#7d6b56',1.4);}
 for(const sx of [-.92,.85]){const [xx,yy]=p(x+sx,y+.36,sx<0?5:h);arc(c,xx,yy,4.7,0,6.2,'#cdb377',1.7);}
}
function lampGlass(c,a,b,inside,lit,t){
 c.save();c.translate(a,b);poly(c,[[-24,-2],[-24,-43],[22,-46],[22,-6]],'#796d59','#544f45');
 for(const [k,col] of [[-1,inside?'#83a8ad':'#bd7862'],[1,inside?'#b07562':'#7e9596']]){
  const x=k*10;poly(c,[[x-7,-10],[x-7,-34],[x,-40],[x+7,-35],[x+7,-12]],lit&&k===1?'#e4c783':col,'#534f47');
  line(c,x-5,-17,x+5,-31,'#c6c4a6',1.1);
 }
 if(inside){line(c,-18,-38,-11,-42,'#94ced2',3);line(c,-12,-40,-8,-40,'#d89c83',2);}
 line(c,-22,-4,23,-8,'#d0b58b',2);c.restore();
}
function bell(c,a,b,paired,t){
 line(c,a-27,b,a-27,b-46,'#75654f',3.5);line(c,a+27,b-3,a+27,b-49,'#75654f',3.5);line(c,a-28,b-46,a+28,b-49,'#a58b64',4);
 for(const [x,L] of [[-13,13],[12,23]]){
  const xx=a+x+(paired?Math.sin(t*2.1+x)*1.8:0),yy=b-47+L;line(c,a+x,b-46,xx,yy,'#92816b',1.7);
  poly(c,[[xx-4,yy+1],[xx-3,yy-5],[xx,yy-8],[xx+3,yy-5],[xx+4,yy+1],[xx+7,yy+4],[xx-7,yy+4]],'#b8975d','#705f48');oval(c,xx,yy+5,1.8,2,'#67574c');
 }
}
export function relayFeature(c,p,map,f,s,t){
 const x=f.x+(f.w||1)*.5,y=f.y+(f.h||1)*.55,[a,b]=p(x,y);
 if(map.id==='tilting-inn'&&['building','wall'].includes(f.kind)){slopingRoom(c,a,b,!!s.flags['inn-offered']);return true;}
 if(map.id==='shutter-walk'&&(f.kind==='building'||f.kind==='wall'&&f.x>0)){shutters(c,a,b,!!s.flags['shutter-open']);return true;}
 if(map.id==='copper-gutter'&&f.kind==='pier'){for(let i=1;i<7;i++)plank(c,p,f.x+i*2.45,f.y+1,!!s.flags['gutter-loose'],t);return true;}
 if(map.id==='lamp-back'&&f.kind==='wall'&&f.x>0){lampGlass(c,a,b,!!s.flags['watch-inside'],false,t);return true;}
 if(map.id==='ferrule-shed'&&f.kind==='building'){bell(c,a,b,!!s.flags['watch-bells'],t);return true;}
 return false;
}
export function relayItem(c,p,map,e,s,t){
 const x=e.x+.5,y=e.y+.5,[a,b]=p(x,y),f=s.flags;
 switch(e.id){
 case 'mara-footrail':bed(c,p,x+.18,y-.72,!f['inn-clear']);if(f['inn-clear'])figure(c,a+26,b-3,'yellow-guest',t,{scale:1.09});cup(c,a+13,b-12,true);return true;
 case 'deck-wrong':case 'deck-float':case 'mara-tray':plank(c,p,x,y,!!f['gutter-loose'],t);if(e.id==='mara-tray')cup(c,a+3,b-8,true);return true;
 case 'shutter-carpenter':shutters(c,a+24,b-6,!!f['shutter-open']);return false;
 case 'stairs-cup':cup(c,a,b-(f['cup-travel']?19:7),true);return true;
 case 'steady-cup':{
  figure(c,a+18,b-5,'yellow-host',t,{scale:1.02});
  if(f['evac-float']&&!f['cup-travel']){figure(c,a-17,b,'yellow-guest',t,{scale:1.12});cup(c,a-9,b-18,true);}
  else{line(c,a-16,b-4,a+1,b-22,'#bba27e',3.0);arc(c,a-13,b-4,6,0,Math.PI*1.7,'#a78d69',2);}
  return true;}
 case 'cup-received':{
  bed(c,p,x+.63,y-.8,false,true);figure(c,a+34,b-4,'yellow-host',t,{scale:1.04});
  if(f['cup-travel']){figure(c,a-24,b,'yellow-guest',t,{scale:1.12});cup(c,f['inn-arrived']?a+24:a-17,f['inn-arrived']?b-10:b-18,true);}
  return true;}
 case 'paper-back':box(c,p,x-.5,y-.44,1.1,.7,2,7,wood);parchment(c,a,b-9,1,true);return true;
 case 'peel-face':case 'peel-back':case 'label-lamp':lampGlass(c,a,b,!!f['watch-inside']||e.id==='peel-back',!!f['watch-paint-order'],t);return true;
 case 'two-strikers':bell(c,a,b,!!f['watch-bells'],t);return true;
 case 'new-hand':lampGlass(c,a+22,b-4,true,!!f['watch-second-end'],t);return false;
 default:return false;
 }
}
