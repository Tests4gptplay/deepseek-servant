import {arc,line,oval,poly} from './paint.mjs';
import {box,wood,plate,bed,wheel,tub} from './voyage-shapes.mjs';
import {bakehouse,servingWindow,washRun,coalRack,handcart,skiff,seedBed} from './harbor-crafts.mjs';
import {cauldron} from './social-fauna.mjs';
import {screen,table} from './social-furniture.mjs';

export function stones(c,p,x,y,back=false){
 const stone=['#bca58a','#9c846e','#786b5d'];
 for(let j=0;j<3;j++)for(let k=0;k<3;k++){
  const dx=back?.23+.09*j:k*.44,dy=back?k*.44:.14*j;
  box(c,p,x+dx+(back?0:(j%2)*.18),y+dy,back?.32:.45,back?.48:.30,j*5,5,stone);
 }
}
function tube(c,p,x,y,far,s,t){
 const [a,b]=p(x,y),d=far?-1:1;box(c,p,x-.4,y-.17,.87,.38,0,7,wood);
 c.save();c.translate(a,b);c.lineCap='round';
 for(const [stroke,w] of [['#635a4f',8],['#b7845f',5],['#edbf85',1.5]]){
  c.strokeStyle=stroke;c.lineWidth=w;c.beginPath();c.moveTo(-17*d,-29);c.bezierCurveTo(-3*d,-33,-16*d,-8,0,-8);c.bezierCurveTo(15*d,-8,5*d,-23,18*d,-23);c.stroke();
 }
 oval(c,18*d,-23,6,8,'#785d4f');oval(c,18*d,-23,3.1,5.7,'#403f3a');c.restore();
}
export function deckObject(c,p,x,y,type,s,t){
 const q=s.flags,a=p(x,y),X=a[0],Y=a[1],wet=s.tide==='high';
 switch(type){
  case 'earpipe':tube(c,p,x,y,false,s,t);break;
  case 'earshelf':box(c,p,x-.65,y-.25,1.4,.55,0,13,wood);for(let j=0;j<3;j++)tube(c,(a,b,z=0)=>p(a,b,z+12),x+j*.37-.3,y,true,s,t);break;
  case 'bend':case 'bendOther':for(let i=0;i<3;i++){stones(c,p,x+i*.46,y);stones(c,p,x+(type==='bend'?0:1),y+i*.45,true);}break;
  case 'felt':screen(c,p,x-.85,y,2,'#846c69',!q['ear-damped']);tube(c,p,x+1,y+.14,true,s,t);break;
  case 'skiff':skiff(c,p,x,y,s.tide,t);break;
  case 'wetRing':{let z=wet?14:7;line(c,...p(x-.65,y,z+1),...p(x+.65,y,z-2),'#9a9172',2.2);let b=p(x,y,z-3);arc(c,...b,5,0,Math.PI*2,'#d6ad79',3);break;}
  case 'oars':for(let i=0;i<2;i++){const b=p(x+i*.22,y);line(c,b[0]-18,b[1]-7,b[0]+13,b[1]+2,'#a98862',2);oval(c,b[0]+14,b[1]+2,7,3,'#aa865a');}break;
  case 'gate':wheel(c,X,Y-16,14,q['ear-keys-done']?.72:.12,8);for(let i=0;i<5;i++)line(c,...p(x+.6,y+i*.3,3),...p(x+.6,y+i*.3,q['ear-keys-done']?10:24),'#8e7c60',3.2);break;
  case 'rail':for(let i=0;i<=3;i++){const a=p(x-.8+i*.57,y);line(c,...a,a[0],a[1]-(q['ear-rail-done']?13:23),'#817057',3);}
   line(c,...p(x-.9,y,q['ear-rail-done']?12:21),...p(x+1,y,q['ear-rail-done']?12:21),'#c2b18a',2.6);break;
  case 'lasts':{
    for(const xx of [-.85,.8])for(const yy of [-.23,.35])line(c,...p(x+xx,y+yy),...p(x+xx,y+yy,12),'#665742',3.1);
    box(c,p,x-.93,y-.32,1.92,.79,12,3.4,wood);
    for(let i=0;i<3;i++){
      const [u,v]=p(x-.53+i*.56,y+.08,17);
      poly(c,[[u-10,v+2],[u-7,v-2],[u-2,v-3],[u+1,v-9],[u+5,v-10],[u+7,v-7],[u+7,v],[u+3,v+3]],i===1?'#b58c62':'#ca9e71','#745841');
      line(c,u-9,v+2,u+4,v+3,'#e3c39c',1.7);line(c,u+1,v-3,u+5,v-4,'#805e42',1.2);
    }
    break;}
  case 'green':seedBed(c,p,x-1,y-.4,!!(q['sun-scatter']||q['leaves-fed']));break;
  case 'glass':case 'glassLow':{const z=type==='glass'?36:18,other=q['sun-scatter'],points=[p(x-.75,y,z),p(x+.65,y,other?z+2:z-8),p(x+.72,y+.45,other?z-14:z-25),p(x-.7,y+.5,z-10)];
   for(const d of [-.58,.55])line(c,...p(x+d,y+.2),...p(x+d,y+.2,z),'#796a55',2.7);
   poly(c,points,other?'#94b3a8':'#c5d7c4','#6e8277');line(c,...points[0],...points[2],'#f1e6b2',2);break;}
 }
}
