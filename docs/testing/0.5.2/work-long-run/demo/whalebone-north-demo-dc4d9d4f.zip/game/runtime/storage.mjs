import {decode,SAVE_KEY} from './state.mjs';
import {afterwatchKey} from '../content/cycle-journal.mjs';
import {voyages,shelfKey,nextBackup} from './voyages.mjs';

export function storage(ctx,close){
 const {ui,world,state,sound,sync}=ctx,backup=SAVE_KEY+'.bak';
 const disk={getItem:k=>localStorage.getItem(k),setItem:(k,v)=>localStorage.setItem(k,v),removeItem:k=>localStorage.removeItem(k)};
 const books=voyages(disk,world),read=k=>disk.getItem(k),second=()=>state.player.cycle?.id==='afterwatch';
 function guard(fn){try{fn();}catch(e){ui.toast(e.message||'存档区不可用。');}}
 function arrive(player,notice){if(!player)throw Error('没有可读的记录。');state.player=player;close();ui.toast(notice);}
 function primary(raw){if(!raw)throw Error('没有可读的首航。');const p=decode(world,raw);if(p.cycle)throw Error('此文件缺少封存首航，请导入完整次航册。');return p;}
 function putFirst(raw){
  const old=read(SAVE_KEY),book=read(shelfKey);
  if(old!==null)disk.setItem(backup,old);
  if(book!==null&&book!=='first')books.activate('first');
  try{disk.setItem(SAVE_KEY,raw);}catch(e){if(book!==null&&book!=='first')books.activate(book);throw e;}
 }
 function save(force=false){
  if(second()){books.save(state.player);sound('save');close();ui.toast('沅籽的次航已记下。');return;}
  const old=read(SAVE_KEY);
  if(old!==null&&!force){
   try{primary(old);}catch(e){ui.show('save','保留原始存档',e.message+'。可以先导出原档。确认覆盖时，原文将移进备份。',[['返回',menu],['确认备份并替换',()=>guard(()=>save(true))]]);return;}
  }
  putFirst(JSON.stringify(state.player));sound('save');close();ui.toast('航记已写入此浏览器。');
 }
 function download(raw,name='whalebone-north-save.json'){
  if(!raw)throw Error('没有可导出的记录。');
  const link=document.createElement('a'),url=URL.createObjectURL(new Blob([raw],{type:'application/json'}));
  link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),1200);
 }
 function importFile(){
  const picker=document.createElement('input');picker.type='file';picker.accept='.json,application/json';
  picker.addEventListener('change',async()=>{
   const file=picker.files?.[0];if(!file)return;
   let raw;
   try{
    if(file.size>2_000_000)throw Error('存档过大。');
    raw=await file.text();const body=JSON.parse(raw);
    if(body&&('primary' in body||'next' in body)){arrive(books.bring(raw),'导入成功。已打开沅籽的次航。');return;}
    const next=primary(raw);putFirst(raw);arrive(next,'导入成功。');
   }catch(e){
    if(e.code==='DAMAGED_SECOND'){
     ui.show('repair','保留损坏的次航原件','这份导入可读。本机次册受损，可先下载原件。确认恢复会把损坏原文保存在次航备份。',[
      ['返回',menu],['导出损坏原件',()=>guard(()=>download(books.raw(),'whalebone-afterwatch-damaged.json'))],
      ['备份损坏次册并导入',()=>guard(()=>arrive(books.bring(raw,true),'次航已恢复，旧原件可从存档面板导出。'))]]);
    }else ui.toast('导入未生效。'+e.message);
   }
  });picker.click();
 }
 function offer(){
  ui.show('voyage','另开值灯次航','首航封存于墓坡，随时可回来。次航由沅籽值灯，从旧窗背面追查那一夜。两册分别记载。',[
   ['先留在墓坡',close],['翻开沅籽的次航',()=>guard(()=>arrive(books.start(state.player),'第二航次 · 沅籽接过钥匙。'))]]);
 }
 function menu(){
  const isNext=second(),nextRaw=books.raw(),firstRaw=books.primary();
  const actions=[['记下当前位置',()=>save()],['读取航记',()=>arrive(isNext?books.second():read(shelfKey)==='archive'?books.first():primary(firstRaw),'已回到记录地点。')],
   ['导出当前',()=>isNext?download(books.portable(state.player),'whalebone-afterwatch.json'):download(JSON.stringify(state.player))],['导入文件',importFile]];
  if(nextRaw!==null){
   if(isNext)actions.push(['记下次航并回到首航',()=>{books.save(state.player);arrive(books.first(),'玛拉的首航已打开。');}]);
   else actions.push(['续读已存的次航',()=>arrive(books.second(),'续读沅籽的次航。')]);
   actions.push(['导出次航原件',()=>download(nextRaw,'whalebone-afterwatch-original.json')],['导出封存首航',()=>download(books.validate(nextRaw).primary)]);
  }
  if(firstRaw!==null)actions.push(['导出原档',()=>download(firstRaw)]);
  if(read(backup)!==null)actions.push(['读取备份',()=>{const old=primary(read(backup));books.activate('first');arrive(old,'首航备份已读入。');}]);
  if(read(nextBackup)!==null)actions.push(['导出次航备份',()=>download(read(nextBackup),'whalebone-afterwatch-backup.json')]);
  actions.push(['返回',close]);
  ui.show('save',isNext?'存档 · 沅籽的第二航次':'船舱存档',isNext?'本册随时可导出，附有封存的首航。回首航前会先保存值灯进度。':'航记保存在此浏览器。导出文件可以带走进度。',actions.map(([name,fn])=>[name,()=>guard(fn)]));
 }
 function resume(){
  try{const next=books.resume();if(next){state.player=next;return;}}catch{ui.toast('次航档未能读取。存档面板可导出次航原件；本机首航仍可打开。');}
  guard(()=>{const raw=books.primary();if(raw)state.player=primary(raw);});
 }
 return {open:()=>guard(menu),resume,offer};
}
