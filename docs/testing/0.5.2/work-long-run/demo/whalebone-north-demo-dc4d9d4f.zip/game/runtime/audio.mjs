import {playPhrase} from './salt-song/how-a-song-makes-room.mjs';
import {soundWorkshop} from './workshop-sounds.mjs';
import {scoreFor,arrange} from './music.mjs';
export function audioControl(button){
 let stopSalt;
 let ctx,bus,enabled=false,scene='vigil',stopScore;
 const sounds={touch:[220,330],gate:[196,392],solve:[262,330,392],battle:[110,155],tide:[147,196],save:[247,311]};
 function play(id='touch'){
  if(!enabled||!ctx)return;if(soundWorkshop(ctx,bus,id))return;const notes=sounds[id]||sounds.touch,now=ctx.currentTime;
  notes.forEach((f,i)=>{const osc=ctx.createOscillator(),gain=ctx.createGain(),start=now+i*.07;
    osc.type=id==='battle'?'triangle':'sine';osc.frequency.setValueAtTime(f,start);
    gain.gain.setValueAtTime(.0001,start);gain.gain.exponentialRampToValueAtTime(.047,start+.018);gain.gain.exponentialRampToValueAtTime(.0001,start+.48);
    osc.connect(gain);gain.connect(bus);osc.onended=()=>{osc.disconnect();gain.disconnect()};osc.start(start);osc.stop(start+.5);});
 }
 play.stopSaltPhrase=()=>{if(!stopSalt)return;stopSalt();stopSalt=undefined;if(enabled)stopScore=arrange(ctx,bus,scene);};
 play.saltPhrase=(rows,coda=[],slow=false)=>{
  if(!enabled||!ctx)return false;
  stopSalt?.();stopScore?.();stopScore=undefined;
  stopSalt=playPhrase(ctx,bus,rows,coda,slow,()=>{stopSalt=undefined;if(enabled)stopScore=arrange(ctx,bus,scene);});return true;
 };
 play.scene=(map,state,battle=false)=>{const next=scoreFor(map,state,battle);button.dataset.cue=next;if(next===scene)return;stopSalt?.();stopSalt=undefined;scene=next;if(enabled){stopScore?.();stopScore=arrange(ctx,bus,scene);}};
 button.addEventListener('click',async()=>{
  try{
   if(!ctx){ctx=new AudioContext();bus=ctx.createGain();bus.gain.value=.64;bus.connect(ctx.destination);}
   enabled=!enabled;
   if(enabled){await ctx.resume();bus.gain.cancelScheduledValues(ctx.currentTime);bus.gain.setValueAtTime(.64,ctx.currentTime);stopScore=arrange(ctx,bus,scene);}
   else{stopSalt?.();stopSalt=undefined;stopScore?.();stopScore=undefined;bus.gain.cancelScheduledValues(ctx.currentTime);bus.gain.setTargetAtTime(.0001,ctx.currentTime,.018);}
   button.setAttribute('aria-pressed',String(enabled));button.textContent=enabled?'静音':'声音';if(enabled)play();
  }catch{enabled=false;button.setAttribute('aria-pressed','false');button.textContent='声音不可用';}
 });
 return play;
}
