import {arc,line,oval,poly} from './paint.mjs';
export function mudClapper(c,x,y,t,action){
 const folded=action==='shell',curl=action==='whirl',jab=action==='ram',reach=folded?6:jab?19:13;
 c.save();c.translate(x,y);
 oval(c,0,2,25,5,'#59695175');
 const sway=Math.sin(t*4.6)*1.6;
 for(let i=0;i<6;i++){
  const xx=9-i*3.1,yy=-5+i*.85;
  oval(c,xx,yy,6.1-i*.35,4.3-i*.32,i%2?'#ab9771':'#ad8364');
  line(c,xx-1,yy-2,xx-3,yy+1,'#6d795f',1.5);
  line(c,xx-1,yy+2,xx-4+sway,yy+5,'#786e56',1);
 }
 poly(c,[[-9,-2],[-20,-5],[-18,1],[-12,4],[-17,7],[-8,6]],'#9c8a65','#70694f');
 const eye=folded?1:3;
 for(const n of [0,1]){line(c,8+n*3,-8,10+n*4,-11-eye,'#737559',1.4);oval(c,10+n*4,-11-eye,1.9,1.8,'#273b3c');}
 const yy=folded?-11:jab?-13:-8;
 line(c,8,-5,reach,yy,'#846d53',3);
 poly(c,[[reach-1,yy],[reach+1,yy-5],[reach+10,yy-7],[reach+8,yy-2],[reach+15,yy+1],[reach+9,yy+4],[reach+2,yy+3]],'#ad7454','#615d48');
 oval(c,reach+3,yy-2,1.8,1.2,'#dfd7a7');oval(c,reach+6,yy-3,1.6,1,'#d7d8ad');
 line(c,12,-5,folded?15:25,-2+sway,'#d6c699',.9);
 if(curl)for(let j=0;j<3;j++)arc(c,2,1,14+j*5,.3+j*.4,2.7+j*.25,'#c4aa81',1.3);
 else if(action==='rush')line(c,-13,2,-23,4,'#c1d2b7',1.5);
 else if(jab)line(c,18,3,30,3,'#c6c5a8',1.6);
 c.restore();
}
