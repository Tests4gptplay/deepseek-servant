import {arc,line,oval,poly} from './paint.mjs';
import {box,plate,wood,parchment,mast,wheel} from './voyage-shapes.mjs';
import {skiff} from './harbor-crafts.mjs';

const sites={
 'wren-deck':[[8.7,8.5,'helm'],[13.3,9.1,'charts'],[18.3,9.9,'skiff']],
 'bow-parallax':[[9,8.1,'fork'],[14.5,8.6,'white'],[19.2,10.4,'sight'],[22,9,'hook']],
 'pearl-return':[[8.2,9.1,'cage'],[13,10,'loom'],[18.7,10.8,'door']],
 'hook-cliff':[[9.5,8.0,'hook'],[12.4,9,'rope'],[16.4,9.2,'sight'],[20,10.4,'white']],
 'pearl-moot':[[8,8.8,'charts'],[13.5,8.2,'loom'],[19,10,'cage']],
 'lantern-trawl':[[9,8.8,'keel'],[13.3,8.6,'loom'],[18.6,10.2,'door']],
 'brine-spine':[[10,9.8,'skiff'],[13.8,8.9,'sail'],[17,9.1,'cage'],[20,10.8,'wave']]
};
function grid(c,p,x,y,low=false){
 const z=low?8:24;
 for(let i=0;i<=6;i++){const u=i*.25;line(c,...p(x+u,y,z),...p(x+u,y+.75,low?0:10),'#9f987b',1);}
 for(let i=0;i<5;i++){const v=i*.19;line(c,...p(x,y+v,z-i*2.7),...p(x+1.5,y+v,z-i*2.7),'#9ea591',1);}
 for(const u of [0,1.5])line(c,...p(x+u,y+.7,0),...p(x+u,y,z+2),'#735e4d',2.2);
}
function draw(c,p,x,y,k,s,t){
 const f=s.flags,[a,b]=p(x,y),high=s.tide==='high';
 switch(k){
 case 'helm':wheel(c,a,b-19,16,Math.sin(t*.4)*.1,8);box(c,p,x-.38,y,.8,.5,0,9,wood);break;
 case 'charts':box(c,p,x-.99,y-.42,2.04,.9,0,14,wood);parchment(c,a-14,b-15,false);parchment(c,a+14,b-13,true,!!f['wren-survey']);break;
 case 'skiff':skiff(c,p,x,y,s.tide,t,!!f['wren-drift']);break;
 case 'fork':for(const dx of [-.42,.45])line(c,...p(x,y,2),...p(x+dx,y,35),'#816b56',3);break;
 case 'white':{const dx=Math.max(-11,Math.min(11,(s.x-x)*1.12))+Math.sin(t*.62)*2;
  poly(c,[[a+dx-13,b-3],[a+dx-4,b-15],[a+dx+1,b-25],[a+dx+6,b-7],[a+dx+12,b-5]],'#d4d9c7','#8faaa1');line(c,a+dx-12,b-1,a+dx+12,b-3,'#c5d7c8',2);break;}
 case 'hook':poly(c,[[a-26,b],[a-19,b-20],[a-10,b-41],[a-4,b-38],[a-8,b-28],[a+3,b-30],[a+13,b-50],[a+20,b-35],[a+15,b-4]],'#536c6c','#344e52');
  line(c,a-7,b-27,a+4,b-30,'#aeab90',2);break;
 case 'sight':{const flip=f['wren-black']||f['wren-survey'];for(const dx of [-.55,.56]){const q=p(x+dx,y,8);line(c,...q,q[0]+(flip?6:0),q[1]-25,'#9b805e',4);line(c,q[0]-4+(flip?6:0),q[1]-25,q[0]+4+(flip?6:0),q[1]-24,'#dbbd80',2);}
  line(c,...p(x-.75,y,11),...p(x+.74,y,11),'#8d7960',3);break;}
 case 'loom':grid(c,p,x-.75,y-.4);for(let n=0;n<6;n++){const b=p(x-.55+n*.21,y+.2,15);line(c,b[0]-2,b[1]+2,b[0]+2,b[1]-3,'#d29c77',1.6);}break;
 case 'cage':box(c,p,x-.8,y-.38,1.6,.75,0,6,wood);grid(c,p,x-.75,y-.37,true);for(let i=0;i<7;i++){const q=p(x-.59+(i%4)*.32,y-.2+Math.floor(i/4)*.3,6);oval(c,...q,4,2.5,f['wren-crossed']?'#c4d8ae':'#a8bfba');}break;
 case 'door':grid(c,p,x-.8-(f['pearl-door']?.8:0),y,!!f['pearl-door']);break;
 case 'rope':{for(let j=0;j<3;j++)arc(c,a+j*2,b,9-j*1.5,0,Math.PI*2,'#b6a175',1.7);
  if(f['wren-return-line'])line(c,...p(x,y,6),...p(x+2.1,y-.8,4),'#d8bd87',2);break;}
 case 'keel':for(let i=0;i<5;i++){let q=p(x-.9+i*.4,y,2);c.beginPath();c.moveTo(q[0]-14,q[1]);c.quadraticCurveTo(q[0]-12,q[1]-25,q[0]+4,q[1]-33);c.lineTo(q[0]+9,q[1]-31);c.quadraticCurveTo(q[0]-5,q[1]-16,q[0]-9,q[1]);c.closePath();c.fillStyle=i%2?'#a59174':'#8d816b';c.fill();}break;
 case 'sail':{const out=f['trawl-clear']||f['trawl-sail-up'];mast(c,p,x,y,29,'#ab806b',t,false);
  poly(c,[p(x,y,28),p(x+(out?1.5:.30),y+.08,out?20:23),p(x+(out?1.45:.3),y+.1,8),p(x,y,12)],out?'#cfa280':'#8a8270','#776c58');break;}
 case 'wave':for(let i=0;i<5;i++){const q=p(x-.65+i*.28,y,high?8:4);arc(c,q[0],q[1]+Math.sin(t*1.7+i)*3,7+i*.7,3.7,6.1,'#b0cbc0',1.5);}break;
 }
}
export function wrenPlaces(c,p,m,s,t,ordered){for(const [x,y,k]of sites[m.id]||[])ordered.push([x+y+.56,()=>draw(c,p,x,y,k,s,t)]);}
export function wrenFeature(c,p,m,f,s,t){
 if(!sites[m.id])return false;const x=f.x+(f.w||1)*.5,y=f.y+(f.h||1)*.62;
 if(f.kind==='boat'){skiff(c,p,x,y,s.tide,t);return true;}
 if(f.kind==='crate'){draw(c,p,x,y,m.id==='wren-deck'?'charts':m.id==='bow-parallax'?'sight':'cage',s,t);return true;}
 return false;
}
