import {line,oval,poly} from './paint.mjs';
import {box,plate,wood} from './voyage-shapes.mjs';

// Work rooms use a short cutaway behind the workers. Supports end before the walk lane.
const bays={
 'bread-turn':[[10.4,6.75,'flue'],[18.15,6.4,'clinic']],
 'willow-tea':[[6.2,6.85,'service'],[12.8,6.4,'dry']],
 'sill-walk':[[14.6,7.2,'kiln']],
 'rain-parlor':[[12.6,6.7,'clinic'],[18.4,9.05,'door']],
 'boiler-stair':[[12.2,6.45,'water'],[17.0,8.7,'water']],
 'laundry-pit':[[7.2,8.45,'water'],[16.85,7.65,'spring']],
 'voice-deck':[[12.2,7.45,'ear']], 'tile-bend':[[10.8,6.9,'kiln'],[15.6,6.75,'ear']],
 'hush-bay':[[15.7,7.45,'landing']], 'outside-row':[[16.45,9,'landing']],
 'sun-ladle':[[8.5,8,'leather'],[11.55,9.05,'plants']], 'sailglass':[[17.45,8.85,'glass']],
 'germ-cellar':[[17.2,8.05,'lift']], 'rye-yard':[[8.5,6.9,'drive']],
 'ferrule-shed':[[13.9,6.85,'bell']], 'lamp-back':[[16.8,6.75,'glass']],
 'watch-calendar':[[9.15,6.55,'service']], 'bell-quarter':[[7.6,6.65,'flue']]
};
function base(c,p,x,y,w,h,tone,top){
 const q=(u,v,z=0)=>p(x+u,y+v,z);
 plate(c,p,x-.08,y-.1,w+.2,.8,1,'#3c424248');
 poly(c,[q(0,0),q(w,0),q(w,0,h),q(0,0,h)],tone,'#5a584e');
 box(c,p,x-.13,y-.1,w+.26,.29,h,5,top||wood);
 for(const dn of [0,w]){line(c,...q(dn,.05),...q(dn,.05,h+3),'#6d6254',5);line(c,...q(dn+.035,.07,5),...q(dn+.035,.07,h-3),'#b9a17a',1.4);}
 return q;
}
function bay(c,p,x,y,kind,s,t){
 const q=(u,v,z=0)=>p(x+u,y+v,z),wet=s.tide==='high';
 if(['flue','kiln','water','spring'].includes(kind)){
  const water=kind==='water'||kind==='spring',w=water?2.75:2.35,h=kind==='flue'?54:water?32:37;
  base(c,p,x-1,y,w,h,water?'#869890':'#aa8470');const b=(u,z)=>q(u-1,.035,z);
  for(let z=6;z<h-1;z+=7){line(c,...b(0,z),...b(w,z),'#d0bfa1',1.1);for(let u=(z%2)*.34+.1;u<w;u+=.69)line(c,...b(u,z),...b(u,z+6),water?'#768980':'#98705c',1);}
  if(water){const stripe=kind==='spring'?'#b1c39e':'#648b90';for(let j=0;j<3;j++)line(c,...b(.05,5+j*3+(wet?5:0)),...b(w-.08,5+j*3+(wet?5:0)),stripe,1.6);
   const a=b(w*.6,17);oval(c,...a,9,7.5,'#5b6b65');oval(c,...a,6.3,4.7,'#334e4f');for(let k=0;k<4;k++)line(c,a[0]+k*1.7-2,a[1]+3,a[0]+k*1.9-2,a[1]+Math.sin(t+k)*2+(wet?16:8),'#94bdac',1.5);}
  if(kind==='flue'){box(c,p,x+.35,y+.04,.67,.57,h,22,['#b7997b','#91715f','#706055']);box(c,p,x+.27,y-.04,.83,.73,h+20,5,wood);
   for(let j=0;j<3;j++){const z=51+j*9,a=q(.62,-.03,z+30);oval(c,a[0]+Math.sin(t*.6+j)*3,a[1],4+j*1.8,2.4+j,'#9a978343');}}
  return;
 }
 if(['clinic','service','door','ear','glass','bell'].includes(kind)){
  const w=kind==='bell'?3.25:2.4,h=kind==='door'?38:kind==='bell'?47:32;
  base(c,p,x-1.05,y,w,h,kind==='glass'?'#738e8b':kind==='door'?'#927968':'#a79d81');
  const b=(u,z)=>q(u-1.05,.09,z);
  if(kind==='ear'||kind==='bell'){for(let j=0;j<5;j++){const a=b(.25+j*(w-.52)/4,h-7),sz=kind==='bell'?4+j%3:3;
    line(c,...a,a[0],a[1]+9+j%2*5,'#866d4e',2);oval(c,a[0],a[1]+10+j%2*5,sz,sz*.76,kind==='bell'?'#be9e67':'#b28566');}line(c,...b(.08,13),...b(w-.07,13),'#675d4d',3);}
  else if(kind==='door'){const swing=s.flags['want-alley']||s.flags['alley-booked'];
   poly(c,[b(.36,1),b(w-.44,1),b(w-.44,h-4),b(.36,h-4)],'#4b605b','#d0b58a');
   const end=swing?.65:w-.48;poly(c,[b(.38,1),q(end-1.05,swing?.77:.1,1),q(end-1.05,swing?.77:.1,h-5),b(.38,h-5)],'#a48a72','#735f50');}
  else{const lo=kind==='clinic'?10:14;poly(c,[b(.24,lo),b(w-.22,lo),b(w-.22,h-5),b(.24,h-5)],kind==='glass'?'#8ba9a4':'#526b64','#d9c395');
   for(let j=.35;j<w-.1;j+=.5)line(c,...b(j,lo),...b(j,h-5),kind==='glass'?'#b4d2be':'#a18b69',1.5);line(c,...b(.05,lo),...b(w,lo),'#dec49b',3.5);}
  return;
 }
 const tall=['lift','drive'].includes(kind),w=tall?2.9:2.45,h=tall?47:kind==='landing'?21:29;
 for(const u of [-1,w-1]){line(c,...q(u,0,0),...q(u,0,h),'#705d49',5);line(c,...q(u+.04,.01,0),...q(u+.04,.01,h),'#b99c6e',1.6);}
 line(c,...q(-1,0,h),...q(w-1,0,h),'#846f51',5);
 if(tall){let a=q(w*.5-1,0,h-3);oval(c,...a,7,7,'#695f4e');oval(c,...a,4,4,'#b49b6e');for(const u of [-.52,.72])line(c,...q(u,0,h-1),...q(u,0,kind==='lift'&&s.flags['rye-air']?24:6),'#82745b',2);}
 else if(kind==='landing'){for(let i=0;i<4;i++)line(c,...q(-1+i*.69,.08,h-3),...q(-.58+i*.69,.08,h-9),'#a8926c',2);}
 else{for(let j=0;j<5;j++){const a=q(-.7+j*.49,0,h-4);line(c,...a,a[0],a[1]+7,'#8e7b5c',1.4);oval(c,a[0]+2,a[1]+8,kind==='leather'?7:4,kind==='plants'?5:2.8,kind==='plants'?'#809462':'#b5946d');}}
}
export function workshopBays(c,p,m,s,t,ordered){
 for(const [x,y,k] of bays[m.id]||[])ordered.push([x+y+.07,()=>bay(c,p,x,y,k,s,t)]);
}
