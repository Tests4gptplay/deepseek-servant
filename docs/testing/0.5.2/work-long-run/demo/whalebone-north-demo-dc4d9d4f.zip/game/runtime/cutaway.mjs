import {line,poly,oval,rand} from './paint.mjs';
export function shell(c,p,map,mode,s,t){
 const w=map.width,h=map.height,hold=mode==='hold',wake=mode==='vigil',top=hold?70:65;
 const face=(points,color,edge)=>poly(c,points.map(([x,y,z])=>p(x,y,z||0)),color,edge);
 const row=hold?'#5f6c61':'#918971',far=hold?'#4d5d52':wake?'#c1a888':'#ab9b82';
 face([[0,0],[w,0],[w,0,top],[0,0,top]],far,'#514d41');
 face([[0,0],[0,h],[0,h,top],[0,0,top]],hold?'#465752':'#ae9479','#594f45');
 for(let z=7;z<top;z+=hold?12:10){
   line(c,...p(0,0,z),...p(w,0,z),row,.95);line(c,...p(0,0,z),...p(0,h,z),row,.85);
   if(!hold)for(let x=(z%3)*.4;x<w;x+=1.6)line(c,...p(x,0,z),...p(x,0,z+9),'#9b9078',.8);
 }
 const plank=(x,y,xx,yy,height,col)=>{line(c,...p(x,y),...p(x,y,height),col,4);line(c,...p(x,y,height),...p(xx,yy,height),col,4);};
 for(let x=.35;x<w;x+=3.6){
   plank(x,0,Math.min(w,x+3.6),0,top-2,'#6a5947');
   line(c,...p(x,0,top-17),...p(Math.min(w,x+.7),0,top-3),'#746247',2.3);
   const pos=p(x,0,9);oval(c,...pos,1.5,1.2,'#c2ad81');
   if(hold){line(c,...p(x,0,top-5),...p(x+.25,1.08,top+8),'#a08056',5);line(c,...p(x+.25,1.08,top+8),...p(x+.62,1.62,top+5),'#8e7555',3);}
 }
 for(let y=.25;y<h;y+=3.45){plank(0,y,0,Math.min(h,y+3.45),top-3,'#6b5845');line(c,...p(0,y,top-13),...p(0,Math.min(h,y+.55),top-4),'#755e46',2);}
 for(const x of [w*.23,w*.67]){
   const width=wake?1.7:1.1;
   face([[x,0,24],[x+width,0,24],[x+width,0,52],[x,0,52]],hold?'#243d41':'#739091','#6b5e4a');
   for(const j of [.14,.55,.94])line(c,...p(x+j*width,-.01,24),...p(x+j*width,-.01,52),hold?'#8b7757':'#cfb68c',2);
   line(c,...p(x-.15,0,21),...p(x+width+.13,0,21),'#665646',3);
   if(!hold)face([[x,.05],[x+width,.05],[x+width+1.2,3.25],[x+1.2,3.25]],'#ffe5b640');
 }
 if(wake){
   face([[2.15,5.08],[6.2,5.08],[6.2,7.6],[2.15,7.6]],'#87796a','#afa18a');
   for(let d=0;d<3;d++)line(c,...p(2.27,5.25+d*.10),...p(6.07,5.25+d*.10),d===1?'#728f91':'#c3ac8b',1);
   // A threshold with pegged boards and blue household thread.
   face([[6.45,h-1.27],[8.45,h-1.27],[8.45,h-.43],[6.45,h-.43]],'#89715c','#665344');
   line(c,...p(6.55,h-.69),...p(8.37,h-.69),'#b4a288',1.3);
 }
 for(let x=1;x<w;x+=4.2)face([[x,.1],[x+.21,.1],[x+2.1,Math.min(h-1,8)],[x+1.8,Math.min(h-1,8)]],hold?'#243c3d25':'#5b534019');
 const edge=(v1,v2,depth)=>{const a=p(...v1),b=p(...v2);poly(c,[a,b,[b[0],b[1]+depth],[a[0],a[1]+depth]],hold?'#344747':'#615749');line(c,...a,...b,'#b8a184',2);};
 edge([0,h],[w,h],hold?19:12);edge([w,0],[w,h],hold?19:12);
}
