import {notes,phrase,validCoda} from './how-a-song-makes-room.mjs';
import {scoreBoard} from './a-score-cut-in-wood.mjs';
export function codaAtTheHem(ctx,close){
 const {ui,state,sound,sync}=ctx,s=state.player;
 const history=s.progress.saltSong;
 if(!history)return close();
 s.flags['salt-song-hem-heard']=true;sync();
 let picked=Array.isArray(history.draft)?history.draft.filter(n=>Number.isInteger(n)&&n>=0&&n<5).slice(0,4):[];
 function show(note='',play=false){
  const written=validCoda(history.coda),line=written?history.coda:picked,rows=phrase(history.heel,history.reed);
  const actions=written?[['重听留下的四音',()=>show('',true)],['从晒绳底下钻出去',close]]:
   [...(picked.length<4?notes.map((n,i)=>['缝入'+n,()=>{picked.push(i);history.draft=[...picked];sync();show();}]):[]),
    ...(picked.length?[['拆最后一针',()=>{picked.pop();history.draft=[...picked];sync();show();}]]:[]),
    ...(picked.length===4?[['试听自己这四音',()=>show('',true)],['让全娘收下这段散场曲',()=>{
      history.coda=[...picked];delete history.draft;s.flags['salt-song-wrote']=true;sync();show('全娘把第四枚布扣缝进檐影。晒阁不是指挥台，散场之后，这一小节会跟着衣裳走。',true);
    }]]:[]),['留一截线，下次再来',close]];
  const words=(note?note+'　':'')+(written?'全娘抖开晒布，四枚旧扣自己连成了一句。':'全娘说，散场以后给没进门的人留一个小结尾。五枚音扣可任取四回，重用也好；那句由你来接。')+
   '　布扣上的声音：'+(line.length?line.map(n=>notes[n]).join(' · '):'还空着')+'。';
  ui.show('salt-song','顶风的散场小节',words,actions);scoreBoard(ui,rows,{play});if(play)sound.saltPhrase(rows,line);
 }
 show();
}
export function atTheTiltedInn(ctx,close){
 const {ui,state,sound,sync}=ctx,s=state.player,record=s.progress.saltSong;
 if(!record)return close();
 const rows=phrase(record.heel,record.reed),coda=validCoda(record.coda)?record.coda:[];
 const porch=!!s.flags['salt-song-porch'];
 function visit(play=false){
  s.flags['salt-song-homecoming']=true;sync();
  const tail=coda.length?'　屋里人接起晒衣阁保下的四个音：'+coda.map(n=>notes[n]).join('、')+'。全娘说：“这几个是你当初缝的。”':'　散场的一段留了白。有人拿碗底在门框上替它收声。';
  ui.show('salt-song',porch?'檐后有人认出了那句“没有帆”':'六只手把凳子的回声传完',
   (porch?'客栈倾过半尺，前檐的孩子牵着当时卖瓜的老船工。他只会唱你们送过街的两字。“井底——”阿梢自己把“帆”补上。玛拉等老人笑完，才替他扶住门。':
     '客栈的桌子已经斜了，方莳把右手放在横倒的凳面上。船墙挡住她的脸，外头的人摸到第二拍双响，知道她还坐得稳。末拍一空，她自己说了“走”。')+tail,
   [['在这家门里重听旧曲',()=>visit(true)],['扶好门上的木闩',close]]);
  scoreBoard(ui,rows,{play});if(play)sound.saltPhrase(rows,coda);
 }
 visit();
}
