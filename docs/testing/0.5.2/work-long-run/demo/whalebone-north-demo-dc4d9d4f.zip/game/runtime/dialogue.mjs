import { allows, setFlags } from './state.mjs';

export function dialogue(ui, state, lines, done) {
  let index = 0;
  const pending = { flags: {} };
  const preview = () => ({ ...state.player, flags: { ...state.player.flags, ...pending.flags } });
  function advance() {
    while (index < lines.length) {
      const line = lines[index++];
      if (!allows(preview(), line.if)) continue;
      const options = line.choices?.length
        ? line.choices.map(choice => [choice.text, () => {
            setFlags(pending, choice.set);
            advance();
          }])
        : [['继续', advance]];
      ui.show('dialogue', line.who || '港记', line.text, options);
      if(line.lullabyClip)ui.hearthVoice?.(line.lullabyClip);
      return;
    }
    Object.assign(state.player.flags, pending.flags);
    done();
  }
  advance();
}
