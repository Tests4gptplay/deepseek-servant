import {poly,line,oval,arc} from '../paint.mjs';
import {bed,box,plate,wood} from '../voyage-shapes.mjs';

function signal(c,p,x,y,t,answered){
  const base=p(x+.46,y+.8),top=p(x+.46,y+.8,62);
  line(c,...base,...top,'#4f625c',4);line(c,base[0]-1,base[1]-2,top[0]-1,top[1]+1,'#bfaa79',1);
  line(c,top[0]-6,top[1]+4,top[0]+12,top[1]+2,'#6b6150',2.6);
  const swing=Math.sin(t*1.3)*1.3,lx=top[0]+8+swing,ly=top[1]+13;
  line(c,top[0]+9,top[1]+2,lx,ly-3,'#4d5853');
  poly(c,[[lx-4,ly-3],[lx+4,ly-3],[lx+3,ly+5],[lx-3,ly+5]],answered?'#efbf72':'#d3bb84','#695f4c');
  line(c,lx-5,ly-4,lx+5,ly-4,'#4b5954',1.8);line(c,lx-4,ly+5,lx+4,ly+5,'#4b5954',1.7);
  const eye=p(x+.14,y+.86,12);arc(c,...eye,4.5,0,Math.PI*2,'#bec6a5',1.8);
  line(c,eye[0]+4,eye[1],base[0]+12,base[1]-10,'#a8a67c',1.4);
}
function lowWindow(c,p,x,y,held){
  const a=p(x+.06,y+.65),b=p(x+1.86,y+.65);
  for(const pt of [a,b]){line(c,...pt,pt[0],pt[1]-22,'#665443',4.3);line(c,pt[0]-1,pt[1]-20,pt[0]-1,pt[1]-5,'#c19a72');}
  poly(c,[p(x+.08,y+.65,4),p(x+1.83,y+.65,4),p(x+1.83,y+.65,8),p(x+.08,y+.65,8)],'#a47d57','#6a5b48');
  line(c,a[0],a[1]-22,b[0],b[1]-22,'#6f6753',3);
  const ring=p(x+1.22,y+.68,11);arc(c,...ring,4.5,0,2*Math.PI,held?'#e1b567':'#b6a777',2);
  const grip=p(x+1.78,y+1.12,3);line(c,ring[0]+3,ring[1]+2,...grip,'#b6a070',2);
  for(let i=0;i<3;i++)arc(c,grip[0]-i*2,grip[1],4.4-i*.7,0,Math.PI*1.9,'#8c7858',1.2);
}
function wetRack(c,p,x,y,short,wet){
  const run=short?.76:2.14,reach=short?1.16:.60;
  for(const dx of [0,run])for(const dy of [0,reach]){
    line(c,...p(x+dx,y+dy,1),...p(x+dx,y+dy,20),'#665444',2.7);
  }
  for(let i=0;i<=5;i++){
    const a=x+run*i/5;
    line(c,...p(a,y,19),...p(a,y+reach,15),'#b39569',1.7);
    if(i<5){
      const z=wet?7+i%3:11+i%2;
      poly(c,[p(a+.025,y+.09,18.8),p(a+run/5-.014,y+.09,18.8),p(a+run/5-.02,y+reach+.04,z),p(a+.02,y+reach+.04,z-2)],
        (wet?['#afbdac','#c5c8ad','#9db2a8']:['#e3d3a8','#d8c597','#e7d7b5'])[i%3],'#ab9b79');
    }
  }
  if(wet){
    for(let n=0;n<4;n++){const d=p(x+.23+n*.19,y+reach+.16,2);oval(c,...d,3.6,.85,'#899f978c');}
  }
}
function nightBed(c,p,x,y,water,flags){
  const bx=x+.12,by=y+.05;
  bed(c,p,bx,by,false,false);
  plate(c,p,bx+.49,by+.06,.95,.74,13.3,water?'#597d83':'#98745d','#6c6d59');
  for(let i=0;i<4;i++){
    const n=bx+.58+i*.16;line(c,...p(n,by+.08,13.8),...p(n,by+.79,13.8),water?'#c3c5a3':'#d6bb8e',1);
  }
  if(water){
    const heel=p(bx+1.68,by+.77,8),tow=p(bx+2.62,by+1.15,2);
    line(c,...heel,...tow,flags['nap-heel-set']?'#b78252':'#879482',2);
    for(let i=0;i<4;i++)arc(c,tow[0]+i*1.3,tow[1],4.3-i*.65,0,Math.PI*1.88,'#b6a77e',1.1);
  }else{
    box(c,p,bx+.20,by-.15,.16,.15,0,24,wood);
    const peg=p(bx+.23,by-.13,19);line(c,peg[0]-4,peg[1]+4,peg[0]+3,peg[1]-3,'#b59b73',2.5);
    oval(c,peg[0]+3,peg[1]-3,2.3,1.7,flags['nap-knock-set']?'#e4c188':'#b5a789');
  }
}
export function waterObject(c,p,f,flags,t){
  switch(f.id){
    case 'cross-signal-pole':signal(c,p,f.x,f.y,t,!!flags['cross-boundary-kept']);break;
    case 'cross-low-window':lowWindow(c,p,f.x,f.y,!!flags['cross-wrist-run']);break;
    case 'cross-first-paper':wetRack(c,p,f.x,f.y,!!flags['cross-short-rack'],!!flags['cross-low-water']);break;
    case 'nap-aft-bed':nightBed(c,p,f.x,f.y,true,flags);break;
    case 'nap-wall-bed':nightBed(c,p,f.x,f.y,false,flags);break;
    default:return false;
  }
  return true;
}
