import {line,oval,poly,arc} from './paint.mjs';
import {box,plate,wood,iron,bed,tub,parchment} from './voyage-shapes.mjs';
import {galley,tideStep,liftBasket,ironEye,cord,sluice} from './whale-rigging.mjs';
import {handcart,skiff,servingWindow,bakehouse} from './harbor-crafts.mjs';
import {figure} from './figures.mjs';
import {shoreSections} from './harbor-landings.mjs';

const spots={
 'cup-eaves':[[8,10,'bowls'],[15,10.5,'kite'],[26,11.2,'stall'],[35,12.2,'bowls']],
 'lung-baths':[[7.8,8.8,'hot-knot'],[12,10.5,'tray'],[15,9.7,'ring'],[18,10.6,'slack'],[22,9.7,'tray'],[24,10.6,'cook']],
 'bucket-gable':[[8.8,8.7,'ash'],[16.8,9.7,'plumb'],[22.2,9.5,'basket'],[25,10.6,'cook']],
 'tin-quay':[[6,9.5,'steps'],[16.8,9.4,'receiver'],[24.4,8.5,'basket']],
 'pot-round':[[7.3,8.3,'stove'],[10,11.7,'mortar'],[14,9.5,'shard'],[19,10.4,'chimes'],[21.5,11.2,'meal']],
 'stove-lip':[[8.1,8.6,'ember'],[8.1,11.8,'ring'],[15.1,9.7,'blocks'],[18,9.8,'slack'],[24,10.1,'landing']],
 'dropped-vane':[[8,9.5,'tilt-lamp'],[11.5,11.3,'bowl'],[18,9.7,'shoe'],[25.1,10.5,'brush']],
 'soup-transom':[[8.8,8.8,'basket-red'],[13.9,10.6,'fork'],[19.8,9.8,'sluice'],[15.4,12.3,'board']],
 'low-sill':[[9,9.7,'wheel'],[17.8,9.8,'track'],[12,10.8,'tow'],[25.4,11.5,'cart']],
 'ash-sound':[[8,8.8,'stove'],[13,9.6,'saltsteps'],[20.7,9.6,'rail'],[25,10.6,'meal']],
 'spoon-skiff':[[8,9.6,'galley-boat'],[12,8.6,'currents'],[16,11.6,'net'],[21.6,9.6,'ring'],[25.2,10.5,'oar']],
 'ladle-cut':[[8.8,9.6,'bed'],[12,11.4,'floodlamp'],[15.8,10.8,'carry'],[19,8.8,'pole'],[24.1,10.7,'lifeboat']]
};
export const shoreMaps=new Set([...Object.keys(spots),'blow-stoop']);
function tripod(c,p,x,y,z=30){for(const [dx,dy] of [[-.65,.3],[.6,.2],[0,-.4]])line(c,...p(x+dx,y+dy),...p(x,y,z),'#8b7357',3);}
function pan(c,p,x,y,z=10){const [a,b]=p(x,y,z);oval(c,a,b,13,5,'#b9b9a1');oval(c,a,b-1,10,3.4,'#cb9868');line(c,a+10,b-1,a+22,b-5,'#87735b',2.5);}
function draw(c,p,x,y,k,s,t){
 const f=s.flags,[a,b]=p(x,y),wet=s.tide==='high';
 switch(k){
 case 'bowls':case 'chimes':case 'kite':{const z=k==='kite'?42:33;tripod(c,p,x,y,z);for(let i=0;i<4;i++){const q=p(x-.65+i*.42,y,z-i*2);cord(c,p(x,y,z),q,2,'#aa9575');line(c,...q,q[0]+Math.sin(t+i)*2,q[1]+8+i*1.5,'#9c8462',1.3);if(k==='kite')poly(c,[[q[0],q[1]+5],[q[0]+5,q[1]+10],[q[0],q[1]+17],[q[0]-5,q[1]+9]],'#ab8970');else oval(c,q[0],q[1]+10+i*1.5,5,2.6,i%2?'#689697':'#ddc496');}break;}
 case 'stall':case 'meal':box(c,p,x-.9,y-.4,1.8,.8,0,12,wood);for(const dx of [-.51,.45])pan(c,p,x+dx,y,15);break;
 case 'hot-knot':case 'slack':case 'ring':ironEye(c,p,x,y,k==='hot-knot',k==='slack'&&!!(f['bath-slack']||f['stove-released']));break;
 case 'tray':{const z=f['bath-plate']?13:f['bath-slack']?7:15;for(const dx of [-1,.85])line(c,...p(x+dx,y),...p(x+dx,y,24),'#796550',3);cord(c,p(x-.98,y,22),p(x+.9,y,22),f['bath-slack']?9:1,'#c5af82',2.5);pan(c,p,x+(f['bath-plate']?.45:0),y,z);break;}
 case 'cook':case 'receiver':figure(c,a,b,'hearth-tender',t,{scale:1.04});pan(c,p,x+.3,y+.1,15);break;
 case 'ash':case 'ember':case 'stove':galley(c,p,x,y,true);if(k==='ash')for(let i=0;i<5;i++){const q=p(x+i*.18,y-.12,16+i*3);oval(c,...q,7-i*.65,3.4,'#756e606c');}break;
 case 'basket':liftBasket(c,p,x,y,f['bucket-plate']?19:f['bucket-rigged']?12:4,!!f['bucket-rigged']);break;
 case 'plumb':tripod(c,p,x,y,39);cord(c,p(x,y,39),p(x,y,15),0,'#d7c08c',1.2);pan(c,p,x,y,14);break;
 case 'steps':case 'saltsteps':tideStep(c,p,x,y,wet);break;
 case 'mortar':case 'bowl':case 'shard':tub(c,a,b,12,k==='shard'?'#79aaa3':'#bc987c');line(c,a+2,b-7,a+12,b-21,'#997d61',3.2);break;
 case 'blocks':case 'carry':box(c,p,x-.7,y-.45,1.4,.9,0,8,wood);if(f['kitchen-shore']||f['hearth-bed-arrived'])bed(c,p,x-.65,y-.4,!!f['hearth-bed-arrived']);break;
 case 'landing':case 'galley-boat':case 'lifeboat':skiff(c,p,x,y,s.tide,t,true);if(k!=='lifeboat'||f['hearth-crew-arrived'])pan(c,p,x-.15,y+.11,9);break;
 case 'tilt-lamp':{const q=p(x+.34,y,35),at=p(x+.34,y,11);line(c,...p(x-.6,y),...q,'#7e6655',3);line(c,...q,...at,'#b19f7c',1.6);oval(c,...at,4,6,'#f4c071');break;}
 case 'shoe':case 'brush':case 'track':for(let j=0;j<6;j++){const q=p(x-.8+j*.27,y+(j%2)*.17);oval(c,...q,k==='shoe'?5:3,1.8,'#a56d54');}break;
 case 'basket-red':liftBasket(c,p,x,y,f['transom-grit']?17:5,true);break;
 case 'fork':case 'sluice':sluice(c,p,x,y,!!f['transom-open']);break;
 case 'board':plate(c,p,x-.75,y-.35,1.5,.9,wet&&f['transom-open']?10:1,'#c4a981','#806c54');break;
 case 'wheel':case 'cart':handcart(c,p,x-.5,y-.3,false);break;
 case 'tow':case 'rail':case 'pole':case 'oar':for(let i=0;i<3;i++){const u=x-.7+i*.64;line(c,...p(u,y),...p(u,y,18),'#8a775c',3);}cord(c,p(x-.7,y,18),p(x+.60,y,18),k==='tow'?6:1,'#c4ad7e',2.7);break;
 case 'currents':case 'net':for(let j=0;j<7;j++){let q=p(x-.8+j*.25,y+.14*Math.sin(t+j),k==='net'?10:1);line(c,q[0]-5,q[1]+2,q[0]+8,q[1]-1,k==='net'?'#b6a77f':'#b4d4c5',1.7);}break;
 case 'bed':bed(c,p,x-.75,y-.28,!!f['hearth-bed-arrived']);break;
 case 'floodlamp':tub(c,a,b,9,'#635952');oval(c,a,b-12,3,5,'#efbf76');break;
 }
}
export function workAlongShore(c,p,m,s,t,ordered){
 shoreSections(c,p,m,s,t,ordered);
 for(const [x,y,k] of spots[m.id]||[])ordered.push([x+y+.42,()=>draw(c,p,x,y,k,s,t)]);
}
