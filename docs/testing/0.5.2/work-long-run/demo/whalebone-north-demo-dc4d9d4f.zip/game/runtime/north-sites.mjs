import {poly,line,oval,arc} from './paint.mjs';
import {plate,box,wood,iron,mast,bob,parchment} from './voyage-shapes.mjs';
function ribs(c,p,x,y,w,h){
 const [a,b]=p(x+w*.5,y+h*.57);c.save();c.translate(a,b);
 c.fillStyle='#d4c9a5';c.strokeStyle='#78847a';c.lineWidth=1.5;c.beginPath();c.moveTo(-34,12);
 c.bezierCurveTo(-37,-10,-30,-45,-13,-64);c.bezierCurveTo(-5,-74,7,-77,15,-74);c.bezierCurveTo(-10,-66,-23,-30,-21,5);c.closePath();c.fill();c.stroke();
 for(let i=0;i<5;i++)line(c,-29+i*2.2,-6-i*10,-22+i*2,-9-i*10,'#a8ad99',1.2);oval(c,-28,7,11,3,'#6a746b76');c.restore();
}
function rock(c,p,f,ice,t){
 const x=f.x,y=f.y,w=f.w||2,h=f.h||2,b=p(x+w*.52,y+h*.5),d=ice?Math.sin(t*.4)*2:0;
 const v=(i,j,z)=>{const a=p(x+i*w,y+j*h,z);return [a[0]+d,a[1]]};const top=[v(.05,.42,14),v(.29,.02,22),v(.72,.06,18),v(.96,.43,16),v(.73,.89,12),v(.27,.95,14)];
 poly(c,[top[3],top[4],top[5],v(.23,.94,2),v(.71,1,1),v(1,.5,2)],ice?'#77a3a9':'#667775');poly(c,top,ice?'#cadfdb':'#85948d','#7d9691');
 poly(c,[top[0],top[1],top[2],v(.48,.47,18)],ice?'#e9eadd':'#a5aca0');line(c,...top[2],...v(.65,.49,15),'#829d9b',1.4);
 if(!ice){line(c,b[0]-5,b[1]-17,b[0]-4,b[1]-56,'#6c5646',3);poly(c,[[b[0]-4,b[1]-56],[b[0]+8,b[1]-53],[b[0]-4,b[1]-47]],'#a76c54');}
}
function chartTable(c,p,x,y,completed){
 box(c,p,x-.66,y-.46,1.22,.72,4,8,wood);const [a,b]=p(x,y,14);parchment(c,a-12,b,0,completed);parchment(c,a+12,b+1,1,completed);
 line(c,a-20,b+3,a+11,b+7,'#8c7655',2);oval(c,a+16,b-10,2.3,2.3,'#4b6261');
}
function plumb(c,p,x,y,n,flag){
 const [a,b]=p(x,y);box(c,p,x-.46,y-.28,.8,.53,0,5,wood);
 line(c,a-9,b-3,a-9,b-40,'#665a48',3.2);line(c,a-10,b-41,a+12,b-36,'#857052',3.6);
 arc(c,a+10,b-34,4,0,7,'#b88e55',2);bob(c,a+11,b-2,n,flag);
 for(let i=0;i<(n===3?3:6);i++)line(c,a-12,b-7-i*3,a-7,b-7-i*3,'#cab58c',1);
}
function twinHook(c,a,b,done){
 for(const [i,h] of [[-10,17],[10,26]]){line(c,a+i,b-4,a+i,b-h,'#847b63',3);arc(c,a+i+4,b-h,4,Math.PI,Math.PI*2,'#a59b7d',2.5);
 if(done){line(c,a+i+5,b-h,a+i+16,b-4,i>0?'#8e6154':'#687d83',2.4);}}}
export function northFeature(c,p,map,f,s,t){
 if(map.act!==4)return false;const q=f.label||'', x=f.x,y=f.y,w=f.w||1,h=f.h||1;
 if(map.id==='rib-survey'&&f.kind==='wall'||map.id==='rib-pocket'&&f.kind==='wall'){ribs(c,p,x,y,w,h);return true;}
 if(map.id==='ice-mark'&&f.kind==='crate'){rock(c,p,f,true,t);return true;}
 if(map.id==='red-beacon'&&f.kind==='wall'){box(c,p,x+.6,y+.6,w*.7,h*.7,0,38,['#b28e73','#8b6353','#6a5751']);const[a,b]=p(x+w*.54,y+h*.48,38);line(c,a,b,a,b-39,'#665449',5);for(const i of [-1,1]){line(c,a,b-31,a+i*23,b-33+i*(s.flags['remote-lit']?5:13),'#80694d',3);oval(c,a+i*23,b-32+i*(s.flags['remote-lit']?5:13),4,5,i<0?'#d4c198':'#c87a60');}return true;}
 if(map.id==='wreck-slope'&&f.kind==='boat'){const a=p(x+w*.47,y+h*.54);c.save();c.translate(...a);c.rotate(-.12);
 poly(c,[[-84,-5],[-51,9],[49,13],[81,-8],[56,14],[28,22],[-49,17]],'#69564c','#4b4f49');poly(c,[[-84,-5],[-41,-15],[43,-17],[81,-8],[49,8],[-46,7]],'#a3825e','#6a5e4f');for(let i=0;i<7;i++)line(c,-41+i*12,-13,-38+i*12,5,'#705f4b',2);for(const j of [4,10])line(c,-43,j,45,j+3,'#baae94',1.4);twinHook(c,54,0,!!s.flags['return-twice']);c.restore();return true;}
 if(map.id==='rib-pocket'&&f.kind==='crate'){for(let j=0;j<3;j++)box(c,p,x+j*.9,y+.8,.77,.7,0,17,wood);return true;}
 if(map.id==='stamp-shop'&&(f.kind==='building'||f.kind==='crate')){for(let i=0;i<4;i++){box(c,p,x+.35+i*.71,y+.6,.66,1.1,0,20,iron);const[a,b]=p(x+.6+i*.71,y+1,21);line(c,a-4,b,a+6,b-3,'#c7a781',2);}return true;}
 return false;
}
export function northItem(c,p,map,e,s,t){
 if(map.act!==4)return false;
 const x=e.x+.5,y=e.y+.5,[a,b]=p(x,y),flag=k=>!!s.flags[k];
 switch(e.id){
 case 'mira-first':case 'ink-oath':chartTable(c,p,x+.54,y-.36,flag('north-chart'));return false;
 case 'lead-zero':case 'mud-wax':case 'mud-drop':case 'rock-drop':plumb(c,p,x,y,e.id==='rock-drop'?8:3,flag(e.action?.id));return true;
 case 'rib-heel':case 'rib-sight':case 'ice-sight':case 'ice-pin':{
  const icy=e.id.startsWith('ice');mast(c,p,x,y,icy?30:41,icy?'#b16753':'#ece0ad',t,icy?1:0);
  for(const d of [-1,1])line(c,a+d*4,b-6,a+d*4,b-22,icy?'#43545a':'#716c5d',2.6);
  if(e.id==='ice-sight')rock(c,p,{x:x+.26,y:y-.64,w:.65,h:.64},true,t);return true;}
 case 'margin-prick':case 'returned-letters':case 'strap-marks':box(c,p,x-.28,y-.20,.55,.37,0,11,wood);parchment(c,a+3,b-11,1,flag('honest-margin'));arc(c,a-5,b-6,5,0,6,'#d6ac68',2);return true;
 case 'two-drafts':case 'split-cleat':twinHook(c,a,b,flag('return-twice'));line(c,a-23,b+1,a+21,b+1,'#aa8467',2);return true;
 case 'pin-rubbing':case 'test-punch':chartTable(c,p,x,y,flag('maker-known'));for(let j=0;j<3;j++)line(c,a-9+j*4,b-12,a-8+j*4,b-(j===2?21:16),'#796553',1.8);return true;
 case 'arm-out':case 'arm-in':case 'oil-gallery':mast(c,p,x,y,e.id==='arm-in'?21:36,e.id==='arm-in'?'#bd745d':'#dedab7',t,+flag('outer-arm'));return true;
 default:return false;
 }
}
