import {line,poly,oval} from './paint.mjs';
import {box,plate,wood} from './voyage-shapes.mjs';
import {screen} from './social-furniture.mjs';
const palette={
 'willow-tea':['#a7a78a','#d4bf94','#859782'], 'rain-parlor':['#9a8580','#d3b696','#a7a899'],
 'voice-deck':['#719390','#c1a77e','#99775e'], 'tile-bend':['#ac7d68','#c8a388','#738b85'],
 'hush-bay':['#698d90','#b5aa88','#7a9b9b'], 'laundry-pit':['#82968c','#abb49b','#667f79'],
 'germ-cellar':['#8f9775','#b5af86','#759588'], 'split-table':['#b8946a','#c3b28d','#8d866c'],
 'moth-hatch':['#879382','#bdaf87','#84957c'], 'husk-room':['#9b8a74','#bc9a79','#a77c66'],
 'pearl-moot':['#82958c','#bdb6a4','#978d78'], 'lantern-trawl':['#788987','#a89574','#758e94'],
 'watch-calendar':['#80928b','#c2b89c','#928372'], 'lamp-back':['#8d8180','#c49a78','#7a9391'],
 'ferrule-shed':['#839694','#b59e80','#9a7e66']
};
export function partition(c,p,m,f,s){
 const theme=palette[m.id];if(!theme||f.kind!=='wall'&&f.kind!=='crate')return false;
 const {x,y,w=1,h=1}=f;
 if(w<3||h<2)return false;
 const nearY=y+h-.28,width=w-.56,lo=5,hi=m.id==='ferrule-shed'?22:19;
 // Preserve a visible work top and near corners; tall faces use the real blocked footprint.
 box(c,p,x+.28,y+.24,width,h-.5,0,5,[theme[1],theme[0],theme[2]]);
 if(f.kind==='crate'){for(let u=.65;u<w-.3;u+=.78)line(c,...p(x+u,y+.3,5.5),...p(x+u,nearY,5.5),'#776c5350',1.1);return false;}
 for(let u=.37;u<w-.15;u+=1.47){
  const len=Math.min(1.4,w-u-.12);if(len<.17)break;
  const z=(w>12&&Math.floor(u/1.47)%5===2)?lo:hi;
  poly(c,[p(x+u,y+.36,5),p(x+u+len,y+.36,5),p(x+u+len,y+.36,z),p(x+u,y+.36,z)],theme[0],'#5c6b60');
  line(c,...p(x+u,y+.36,z+1),...p(x+u+len,y+.36,z+1),theme[1],2.5);
  line(c,...p(x+u+.12,y+.36,5),...p(x+u+.12,y+.36,z-2),theme[2],2);
 }
 if(m.id==='tile-bend'||m.id==='germ-cellar'){
  for(let u=.4;u<w-.45;u+=.65)for(let k=0;k<2;k++)line(c,...p(x+u,y+.38,7+k*5),...p(x+u+.45,y+.38,7+k*5),'#d2b295',1.25);
 }
 return false;
}
export function floorLane(c,p,m,s){
 const theme=palette[m.id];if(!theme)return;
 for(const f of m.features.filter(x=>x.kind==='path'||x.kind==='pier')){
  const x=f.x,y=f.y,w=f.w||1,h=f.h||1;
  plate(c,p,x+.08,y+.1,w-.16,h-.2,.5,theme[2]+'4d');
  for(const yy of [y+.17,y+h-.17]){
   line(c,...p(x+.12,yy,.9),...p(x+w-.11,yy,.9),theme[0],2);
   for(let u=.34;u<w-.1;u+=1.35){const q=p(x+u,yy,1);oval(c,...q,1.6,.75,theme[1]);}
  }
 }
 if(m.id==='ferrule-shed'){
  for(let i=0;i<4;i++)plate(c,p,6.3+i*2.05,6.39,1.55,.26,.6,i%2?'#9b816b':'#b29a77');
 }
}
