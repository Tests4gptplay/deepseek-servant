import {funeralObject} from './funeral-room.mjs';
import {waterObject} from './night-water.mjs';

export function householdObject(context,project,feature,state,time){
  if(!feature.id)return false;
  return funeralObject(context,project,feature,state.flags)||waterObject(context,project,feature,state.flags,time);
}
