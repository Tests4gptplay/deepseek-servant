import {line,poly,oval,rand} from './paint.mjs';
export function hearthRise(map,x,y){
 if(map.id!=='lullaby-double-stair')return 0;
 return Math.max(0,Math.min(1,(12.65-y)/2.9))*37;
}
const names={'lullaby-pan-lane':['#af9780','#d0b99a'],'lullaby-last-stove':['#9e8064','#d7b58c'],'lullaby-roof-arcade':['#647b7d','#a5ae95'],'lullaby-double-stair':['#8f7963','#cfb491'],'lullaby-clay-hob':['#8c7563','#b59d78']};
function strip(c,p,x,y,w,h,color){poly(c,[p(x,y),p(x+w,y),p(x+w,y+h),p(x,y+h)],color);}
function mark(c,p,u,v,x,y,col,width=1){line(c,...p(u,v),...p(x,y),col,width);}
function bars(c,p,x,y,w,n){strip(c,p,x,y,w,1,'#625e50');for(let i=0;i<n;i++){const px=x+i*w/n;strip(c,p,px,y+.04,w/n*.28,.9,'#c8ac7d');}}
function bench(c,a,b){
 for(const dx of [-17,12]){line(c,a+dx,b+4,a+dx-1,b-7,'#725941',3);}
 poly(c,[[a-23,b-7],[a+7,b-16],[a+21,b-10],[a-9,b-1]],'#b38b60','#725942');
 line(c,a-22,b-6,a-9,b,'#c5af83',2);oval(c,a+4,b-13,8.5,3,'#adb09c');oval(c,a+4,b-14,5,2,'#cba16b');
}
function oven(c,a,b,t,side){
 oval(c,a+5,b+3,23,7,'#51483866');poly(c,[[a-18,b-22],[a+5,b-30],[a+22,b-20],[a+20,b],[a-2,b+7],[a-18,b-1]],'#a37757','#675a49');
 poly(c,[[a-18,b-22],[a+3,b-14],[a+20,b-20],[a+5,b-29]],'#b9906a','#7f654d');
 poly(c,[[a-10,b-1],[a-10,b-12],[a-5,b-14],[a,b-11],[a,b+2]],'#50453c');
 poly(c,[[a-8,b-2],[a-5,b-9-Math.sin(t*3)*1.7],[a-2,b]],'#eea25e');oval(c,a-3,b-23,11,3.5,'#484f49');
 line(c,a+7,b-23,a+17,b-29,'#514c42',2);if(side)line(c,a+18,b-3,a+23,b-14,'#d2ba95',2);
}
function racks(c,p,m,s,t,out){
 const placed=m.id==='lullaby-pan-lane'?[[9,14,0],[16,9,1],[21,5,0]]:m.id==='lullaby-last-stove'?[[14,8,1],[10,7,0],[19,11,0]]:m.id==='lullaby-roof-arcade'?[[7,8,0],[12,14,0],[19,10,1]]:m.id==='lullaby-clay-hob'?[[9,8,0],[14,6,1],[18,11,0]]:[];
 for(const [x,y,fire] of placed)out.push([x+y+.35,()=>{const [a,b]=p(x+.35,y+.35);if(fire)oven(c,a,b,t,true);else bench(c,a,b);}]);
}
export function hearthGround(c,p,m,s,t,out){
 const colours=names[m.id];if(!colours)return;const id=m.id;
 if(id==='lullaby-double-stair'){
  strip(c,p,1.4,5.8,29.5,3.9,'#a591738c');strip(c,p,1.4,12.35,29.5,4,'#786d5aa8');
  for(let x=1;x<=29;x++){if(x%4===0)mark(c,p,x+.1,6,x+.1,9.6,'#6c675899',1.25);mark(c,p,x+.18,12.5,x+.18,16.1,'#a69a7875');}
  for(const [x,w] of [[2.6,2.5],[17.2,2.5],[29.7,1.4]])for(let j=0;j<8;j++){const y=9.6+j*.36;strip(c,p,x,y,w,.22,j%2?'#968978':'#b9a184');mark(c,p,x,y+.22,x+w,y+.22,'#544e43',1.5);}
  for(const [x,w] of [[5.7,11.3],[20.5,8.7]]){const y=9.8;
   out.push([x+w+y+.36,()=>{const pts=[p(x,y),p(x+w,y),p(x+w,y,-26),p(x,y,-26)];poly(c,pts,'#695f51','#574f45');
   for(let i=0;i<w;i+=1.2){line(c,...p(x+i+.1,y,-5),...p(x+i+1,y,-22),'#ad9776',2);line(c,...p(x+i+.8,y,-4),...p(x+i+.8,y,-24),'#83765e',2);}}]);}
  bars(c,p,18.7,13.55,2.7,7);bars(c,p,8.2,15.75,2.6,6);
 }else{
  for(const f of m.features)if(['pier','path'].includes(f.kind)){
   strip(c,p,f.x+.08,f.y+.08,f.w-.16,f.h-.16,colours[0]+'88');
   for(let i=0;i<f.w;i++){const px=f.x+i+.11;mark(c,p,px,f.y+.14,px+.08,f.y+f.h-.15,colours[1]+'85');
    if(i%3===0){mark(c,p,px+.2,f.y+.7,px+.85,f.y+.68,'#685c4c88');mark(c,p,px+.12,f.y+1.17,px+.54,f.y+1.14,'#dbcaab88');}}
  }
  if(id==='lullaby-pan-lane'){for(const y of [10.9,12.1]){for(let x=2;x<23;x+=1.1)mark(c,p,x,y,x+.85,y+(rand(x*4,8)-.5)*.08,'#79654c',1.9);}bars(c,p,10.1,11.25,2.15,8);}
  if(id==='lullaby-roof-arcade'){for(let x=3;x<25;x+=3){mark(c,p,x,12.65,x+2.4,12.65,'#7b654f',2.8);const [a,b]=p(x+.3,12.65);oval(c,a,b,2.4,1.4,'#d1b886');}}
  if(id==='lullaby-clay-hob'){strip(c,p,6.5,7.5,11.8,2.15,'#b5a17d88');bars(c,p,6.5,9.9,3.2,8);}
 }
 racks(c,p,m,s,t,out);
}
