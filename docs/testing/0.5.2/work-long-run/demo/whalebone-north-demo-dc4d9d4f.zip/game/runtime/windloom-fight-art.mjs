import {arc,line,oval,poly} from './paint.mjs';
import {stage,swept} from './windloom-posts.mjs';
const colors={ridge:'#daa675',heel:'#d3c29a',lee:'#86aa9c'};
const platforms={ridge:[-92,-13],heel:[-54,13],lee:[-107,25]};
export function rigSlot(b,h,index){
 const w=b.windloom,pos=b.party[b.actor]?.id===h.id&&w.planned||w.here[h.id],u=platforms[pos];
 return [u[0]+(index%2)*13,u[1]-(index>>1)*9];
}
export function underRig(c,x,y,t,b){
 const w=b.windloom;if(!w)return;const active=swept(b);
 for(const [k,[u,v]] of Object.entries(platforms)){
  const dx=x+u,dy=y+v,hot=k===active;
  poly(c,[[dx-13,dy+2],[dx+5,dy-5],[dx+22,dy],[dx+3,dy+8]],hot?'#a78169':'#79817a','#5f635a');
  line(c,dx-11,dy+2,dx+3,dy+6,colors[k],2.1);
  if(hot){const r=4*Math.sin(t*2.6);line(c,dx-23+r,dy-5,dx-11+r,dy-3,'#e9b57e',1.7);}
  line(c,dx+7,dy-3,x+12,y-8,hot?'#e8bc8c55':'#b1c3a867',1.1);
 }
}
export function rigHazard(c,x,y,t,scene,phase,action,broken=false){
 c.save();c.translate(x,y);
 const sway=Math.sin(t*2.8)*2.5,wind=phase===2?-1:1;
 if(scene==='north'){
  const open=phase===1?8:26,p=phase===2?sway*1.5:sway;
  oval(c,0,2,16,3,'#66716a88');
  poly(c,[[-1,-12],[-11,-21-p],[-open,-19-p],[-open-5,-13-p],[-13,-12],[-4,-6]],'#48575b','#354449');
  poly(c,[[0,-11],[12,-22+p],[open+2,-23+p],[open+8,-20+p],[14,-11],[4,-6]],'#71817b','#425450');
  poly(c,[[-6,-10],[2,-14],[8,-14],[11,-10],[6,-9],[3,-5],[-4,-4],[-10,-2]],'#b4ad8b','#535e54');
  line(c,-5,-4,-8,2,'#d9aa72',2);line(c,-7,1,-16,5,'#d99a77',1.3);oval(c,7,-12,1.3,1.2,'#2e4141');
  for(let j=0;j<3;j++)line(c,-14-j*3,-17-p,-17-j*3,-13-p,'#c2c5a9',1);
 }else{
  const frost=scene==='winter',leaves=frost?3:4;
  const ax=0,ay=-13,angle=(phase*.35+Math.sin(t*.9)*.08)*wind;
  for(let i=0;i<leaves;i++){
   const a=angle+Math.PI*2*i/leaves,r=phase===1?20:30,tx=ax+Math.cos(a)*r,ty=ay+Math.sin(a)*r*.61;
   const sx=ax+Math.cos(a+.72)*r*.57,sy=ay+Math.sin(a+.72)*r*.45;
   poly(c,[[ax,ay],[sx,sy],[tx,ty],[ax+Math.cos(a-.21)*r*.55,ay+Math.sin(a-.21)*r*.32]],frost?(i%2?'#91aca8':'#d3dfcc'):(i%2?'#b9795a':'#ddba78'),'#5a6458');
   line(c,ax,ay,tx,ty,'#a49b78',1.5);
  }
  oval(c,ax,ay,4.4,3.5,'#797b65');line(c,ax,ay+3,-5,5,'#76634e',3.5);
  if(broken)line(c,0,-16,15,-9,'#563d39',2);
 }
 if(phase===2||action==='whirl')for(let i=0;i<2;i++)arc(c,1,2,16+i*6,.1+i*.5,2.6+i*.38,'#bfccb7',1.4);
 c.restore();
}
export function liveRig(c,x,y,t,b){rigHazard(c,x,y,t,b.spec.windloom.scene,stage(b),b.intent.kind,b.windloom.broken);}
