import {poly,line,oval,rand} from '../paint.mjs';
import {edges} from './charts.mjs';
import {waterBody,landingObject} from './estuary.mjs';
import {planking,intertidal,edge,post} from './surfaces.mjs';
import {tiedBoat} from './rowing.mjs';

function current(c,p,x,y,extent,t){
 const [a,b]=p(x,y);
 const swing=t?Math.sin(t*.56+x)*1.7:0;
 c.beginPath();c.moveTo(a-extent,b+3);c.bezierCurveTo(a-extent*.6,b-4+swing,a+extent*.15,b+1,a+extent,b-6);
 c.strokeStyle='#c5ded193';c.lineWidth=1.5;c.stroke();
}
function clothes(c,p,x,y,w,gathered){
 const [a,b]=p(x,y);line(c,a-w*.49,b-2,a-w*.49,b-22,'#655c48',2);line(c,a+w*.41,b+2,a+w*.41,b-16,'#665e48',2);
 c.beginPath();c.moveTo(a-w*.49,b-21);c.quadraticCurveTo(a,b-13,a+w*.41,b-16);c.strokeStyle='#574e41';c.lineWidth=1.15;c.stroke();
 if(gathered){for(const off of [0,6,12]){oval(c,a+w*.2+off,b-2.6,5,2.8,off===6?'#738e91':'#f4edd8');}return;}
 for(const [dx,ink] of [[-.23,'#e9eee1'],[.04,'#618d94']]){
  const u=a+dx*w,v=b-18+dx*4;
  poly(c,[[u-2,v],[u+2,v+1],[u+6,v+3],[u+5,v+6],[u+3,v+5],[u+3,v+12],[u-4,v+10],[u-3,v+4],[u-6,v+5],[u-7,v+2]],ink,'#6e8180');
 }
}
function flags(c,p,x,y,color){
 const [a,b]=p(x,y);line(c,a,b+1,a,b-26,'#554f40',2);
 poly(c,[[a+1,b-26],[a+13,b-24],[a+19,b-26],[a+16,b-18],[a+7,b-19],[a+1,b-20]],color,'#755c51');
}
function greenWindow(c,p){
 const [a,b]=p(29.95,13.28);
 poly(c,[[a-12,b-9],[a+7,b-16],[a+15,b-10],[a+13,b+1],[a-5,b+7],[a-12,b+3]],'#aa9a7c','#646c5d');
 poly(c,[[a-8,b-6],[a+4,b-11],[a+5,b-3],[a-7,b+1]],'#518276','#d4c8a0');
 line(c,a-2,b-8,a-1,b-1,'#d1c098',1.4);
}
export function paintBay(c,p,m,s,t,visible){
 const shapes=edges[m.id];if(!shapes)return;
 waterBody(c,p,m,s,t,visible);
 // Set down land first. Narrow floats and boarding planks cross it at the high-water seam.
 for(const kind of ['bank','mud','reef','stairs','quay','float','gangway'])for(const [key,ring] of shapes){
  if(key!==kind)continue;
  if(['quay','float','gangway'].includes(kind))planking(c,p,ring,kind);else intertidal(c,p,ring,kind,s.tide);
 }
 const home=m.id==='hulls-not-in-line';
 for(const [x,y] of home?[[12,12.9],[16,13.5],[19,14],[22,14.4],[25.3,14.65],[33,15.2],[38.7,14.4],[42.8,15.5]]:[[15.6,13.8],[19.1,14.1],[21.8,13.5],[24.8,14.5],[31.7,14.1],[38.5,13.6]])current(c,p,x,y,11+rand(x,y)*8,t);
 for(const [x,y] of home?[[5,11.91],[11,11.9],[17.3,11.9],[24,11.9],[30,11.85],[35.8,13.95],[27.05,15.18],[29.5,16.5],[40.9,16.02]]:[[4.2,11.93],[12,11.95],[18,11.9],[24,11.96],[30.2,11.95],[35.3,14.88],[37.5,15.05]])post(c,p,x,y,8,true);
 if(home){
  for(const x of [30,34,39])edge(c,p,[x,17.76],[x+.63,17.72],'#797a68',2);
 }else{
  flags(c,p,6.4,14.86,'#a84940');greenWindow(c,p);
  for(const x of [5.4,7.6,9.8])edge(c,p,[x,13.80],[x+1.4,13.54],s.flags['return-bogged']?'#525648':'#899482',2.7);
 }
}
export function waterFeature(c,p,m,f,s,t){
 if(!edges[m.id])return false;
 if(landingObject(c,p,m,f))return true;
 // Their silhouettes and walk surfaces are already in the floor pass.
 if(f.kind==='pier'||f.kind==='path'||f.kind==='rope'||f.kind==='water'||(m.id==='keel-in-shadow'&&f.kind==='sign'))return true;
 if(f.id==='common-sleeves-on-hull'){
  const gathered=!!s.flags['common-landed-wake'],x=gathered?40.76:40.99,y=gathered?15.62:15.27;
  tiedBoat(c,p,x,y,48,13,['#314b49','#4a7870','#c9a878']);clothes(c,p,x,y,65,gathered);
  edge(c,p,[x+.65,y+.14],[41.43,16.07],'#c9b184',1.6);return true;
 }
 if(f.id==='common-mud-stripe'){
  tiedBoat(c,p,9.65,13.53,36,10,['#554d45',s.flags['return-bogged']?'#484a42':'#9e8260','#c4a675']);
  const [a,b]=p(9.65,13.53);line(c,a-23,b-5,a+4,b+9,'#93744c',2.4);return true;
 }
 if(f.kind==='boat'){
  const x=f.x+f.w*.52,y=f.y+f.h*.51;
  tiedBoat(c,p,x,y,Math.min(122,10*f.w),Math.min(29,3.65*f.h),['#375953','#667e73','#b0a17e']);
  if(m.id==='hulls-not-in-line')clothes(c,p,x,y,Math.min(83,7*f.w),true);
  return true;
 }
 return false;
}
