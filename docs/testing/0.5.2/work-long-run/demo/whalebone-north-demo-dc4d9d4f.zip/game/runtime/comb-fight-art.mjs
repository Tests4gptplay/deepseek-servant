import {poly,line,oval,arc} from './paint.mjs';
import {figure} from './figures.mjs';
import {crown,larvalTrain} from './comb-art.mjs';
import {fightingWater} from './comb-ground.mjs';
const foam='#f3efd1',ink='#30535a',gold='#f3b864';
function channel(c,t,tell){
  const y=tell.side==='inner'?-14:17;
  for(const row of [-14,17]){
    c.beginPath();c.moveTo(-115,row+2);c.bezierCurveTo(-72,row-9,-18,row+4,73,row-3);c.strokeStyle=row===y?'#537d83bd':'#72a7a380';c.lineWidth=row===y?6.5:2;c.stroke();
    if(row===y&&tell.stage===0)for(let j=0;j<5;j++){const x=-95+j*31+Math.sin(t)*2;poly(c,[[x,row+1],[x+8,row-5],[x+6,row],[x+13,row+1]],foam,ink);}
  }
  if(tell.stage===1){const dy=tell.side==='inner'?10:-15;
    for(let j=0;j<3;j++)arc(c,45+j*6,dy,4.5,-1.4,1.45,gold,1.8);}
  if(tell.stage===2){larvalTrain(c,-33,y+3,t,12);line(c,-39,y-4,-44,y+3,foam,2);line(c,-44,y+3,-38,y+6,foam,2);}
}
function signature(c,h,x,y,tx,ty,q,kind){
  if(kind==='inner'||kind==='outer'){for(let k=0;k<3;k++)line(c,x-4-k*4,y+1,x-11-k*4,y+2,'#e9e5c2',1);return;}
  if(kind==='cover'){arc(c,x+2,y-15,15,-1.44,1.5,'#b6e3da',2.4);line(c,x-3,y-11,x+14,y-3,gold,1.5);return;}
  if(kind==='tonic'||kind==='salve'){oval(c,x+6,y-20,3.2,5,gold);line(c,x+4,y-19,x+8,y-22,foam,1);return;}
  if(!(kind==='attack'||kind==='skill'))return;
  if(h.id==='mara'){
    const a=x+9+q*12,b=y-22-q*8;line(c,x+3,y-15,a,b,'#6c5341',3);poly(c,[[a-4,b-5],[a+6,b-7],[a+8,b-2],[a-2,b]],'#dde3cf',ink);
    if(q>.45)arc(c,tx-5,ty,12*q,-1.9,1.2,gold,2.6);
  }else if(h.id==='ivo'){c.beginPath();c.moveTo(x+5,y-15);c.bezierCurveTo(x+20,y-45-q*7,tx-12,ty-22,tx,ty);c.strokeStyle='#e9c187';c.lineWidth=2;c.stroke();arc(c,tx,ty,4+q*2,0,6,gold,1.3);}
  else if(h.id==='selene'){for(let j=0;j<3;j++){const a=x+8+j*13;arc(c,a,y-19-j*2,6+j*2,-2.6+q*.2,-.2,'#c8f0df',1.9);}oval(c,tx,ty,5+q*13,2.3,'#a3dbd1');}
  else{const a=x+(tx-x)*q,b=y-19+(ty-y+19)*q;line(c,a-8,b+1,a+3,b,gold,2);if(kind==='skill'){line(c,tx-5,ty-5,tx+4,ty+4,foam,1.4);line(c,tx+4,ty-5,tx-5,ty+4,foam,1.4);}}
}
export function paintCombFight(c,x,y,t,b){
  const still=t===0,last=b.last,age=last?performance.now()-last.start:10000;
  const moving=!still&&age<600,progress=moving?Math.min(1,age/540):0;
  const thrust=moving?Math.sin(progress*Math.PI):0,backlash=!still&&last?.response&&age>270&&age<800?Math.sin((age-270)/530*Math.PI):0;
  // The camera follows the acting position with a shallow sideways shift; the static mode never pans.
  c.save();c.translate(x+(still?0:thrust*(last?.a%2===0?3:-4)),y+(still?0:-thrust*1.5));fightingWater(c);channel(c,t,b.intent);
  const ex=58,ey=-7;crown(c,ex-backlash*4,ey,t,b.intent.stage,b.intent.side,b.spec.id==='comb-crown'?1.45:1.03);
  const spots=b.party.map((h,i)=>({h,i,x:[-31,-84,-108,-54][i],y:(h.combLane==='inner'?-12:14)+[0,6,-6,15][i]})).sort((a,b)=>a.y-b.y);
  for(const spot of spots){
    const {h,i}=spot,acting=last?.a===i,active=acting?thrust:0,hit=last?.response?.hits?.includes(h.id);
    let xx=spot.x+(acting&&['attack','skill'].includes(last.kind)?9*active:0)-(hit?backlash*5:0);
    let yy=spot.y;if(acting&&last.from!==last.to&&moving)yy+=(last.from==='inner'?-24:24)*(1-progress);
    if(h.hp<=0){oval(c,xx,yy,7,2.2,'#5f6061');continue;}
    if(b.actor===i){oval(c,xx,yy+1,13,4.2,'#f5d49699');line(c,xx-10,yy+2,xx+10,yy+2,gold,1.5);}
    figure(c,xx,yy,h.id,t,{scale:1.15,mark:b.actor===i,stride:active*6});
    if(acting&&(moving||still))signature(c,h,xx,yy,ex-9,ey-12,still?.68:Math.max(.12,progress),last.kind);
    if(hit&&(backlash||still))line(c,xx-6,yy-20,xx+6,yy-13,'#edbe94',2.2);
    if(h.cover)arc(c,xx+4,yy-13,11,-1.4,1.35,'#e5ddb1',1.35);
  }
  c.restore();
}
