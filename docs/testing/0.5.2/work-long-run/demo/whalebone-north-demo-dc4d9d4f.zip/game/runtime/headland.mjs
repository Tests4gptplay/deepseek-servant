import {poly,line,oval,rand} from './paint.mjs';
export function headland(c,w,h,t){
 const horizon=h*.245,x=w*.205,y=horizon+9,s=Math.min(1.16,w/860);
 c.save();c.translate(x,y);c.scale(s,s);
 const rim=[[-132,-7],[-113,-20],[-82,-22],[-66,-43],[-44,-48],[-34,-58],[-12,-57],[1,-52],[26,-54],[43,-46],[57,-43],[71,-28],[95,-25],[117,-10]];
 poly(c,[...rim,[119,5],[74,11],[20,14],[-45,12],[-131,3]],'#c2c7b6');
 for(let i=0;i<rim.length-1;i++){const [a,b]=rim[i],[xx,yy]=rim[i+1];
  poly(c,[[a,b],[xx,yy],[xx-2,7+rand(i)*3],[a-2,7]],['#bac3b5','#d5d6bd','#aebcaf','#dedbc2'][i%4]);
  line(c,a,b+3,a-3,2,'#8fa49b',.8);
 }
 for(let i=0;i<11;i++){const xx=-72+i*13,base=-14+rand(i,17)*7;
  line(c,xx,base,xx+12,base-2,'#a8b4a6',1.2);line(c,xx+2,base+4,xx+8,base+4,'#e1dfc8',1);
 }
 poly(c,[...rim.slice(0,10),[56,-45],[24,-58],[-24,-62],[-47,-53],[-70,-47],[-85,-26],[-113,-22]],'#9ba997');
 poly(c,[[-14,-58],[-12,-77],[-7,-77],[-4,-58]],'#d9d7bd','#80988d');
 poly(c,[[-14,-78],[-10,-83],[-5,-78]],'#6b827c');line(c,-10,-78,-10,-73,'#e9c27a',2);
 for(let j=0;j<4;j++){const xx=-36+j*12;line(c,xx,10,xx+21,10+Math.sin(j+t*.2),'#dce1c8',1);}
 c.restore();
 const bx=w*.43+Math.sin(t*.055)*2,by=horizon+23;
 c.save();c.translate(bx,by);c.scale(s,s);c.fillStyle='#789994';c.beginPath();
 c.moveTo(-49,3);c.bezierCurveTo(-40,1,-33,-5,-23,-7);c.bezierCurveTo(-8,-13,15,-9,25,-5);c.bezierCurveTo(30,-4,37,-3,43,-6);c.quadraticCurveTo(40,-1,34,2);c.quadraticCurveTo(0,8,-49,3);c.fill();
 line(c,-44,5,-12,5,'#d8dfc9',1.2);line(c,19,5,41,4,'#d8dfc9',1.2);
 c.strokeStyle='#e0e4cf';c.lineWidth=1.1;c.beginPath();c.moveTo(-22,-7);c.quadraticCurveTo(-24,-17,-28,-17);c.moveTo(-22,-7);c.quadraticCurveTo(-20,-18,-15,-15);c.stroke();c.restore();
}
