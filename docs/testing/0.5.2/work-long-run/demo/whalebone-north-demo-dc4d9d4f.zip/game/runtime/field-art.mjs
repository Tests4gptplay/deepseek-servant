import {workstation} from './guild-ledger.mjs';
import {yards} from './field-rescue.mjs';
import {line,oval,poly} from './paint.mjs';
import {bed,box,tub,wood} from './voyage-shapes.mjs';
import {redArm,backWindow,transitMark} from './winter-pilot-rig.mjs';
import {waterEye,ironEye,liftBasket} from './whale-rigging.mjs';
import {handcart,servingWindow,skiff} from './harbor-crafts.mjs';
const styles=['辨样','换手','稳载','定向','隔离'];
function equipment(c,p,x,y,index,medical,done,s,t){
 const a=p(x,y),kind=index%styles.length;
 if(medical){
  if(kind===0){bed(c,p,x-.75,y-.15,true);line(c,...p(x-.7,y+.15,9),...p(x+.55,y+.15,9),done?'#d8b065':'#88b5a6',3);}
  else if(kind===1){handcart(c,p,x-.55,y-.3,false);tub(c,...p(x+.66,y-.12,8),7,'#9eb3a0');}
  else if(kind===2){liftBasket(c,p,x-.18,y,done?16:4,true);}
  else if(kind===3){servingWindow(c,p,x-.53,y-.22,1.6,done);ironEye(c,p,x+.66,y+.32,false,done);}
  else{waterEye(c,p,x,y,true,done);tub(c,a[0]+17,a[1]+2,6,'#ac9874');}
 }else{
  if(kind===0)transitMark(c,p,x,y,true,s.tide);
  else if(kind===1)backWindow(c,p,x,y);
  else if(kind===2)skiff(c,p,x,y,s.tide,t,true);
  else if(kind===3)redArm(c,p,x,y,done,false);
  else{box(c,p,x-.65,y-.34,1.3,.68,1,7,wood);for(const d of [-.6,.5]){const m=p(x+d,y,12);line(c,m[0],m[1]+1,m[0],m[1]-13,'#d7b882',2);oval(c,m[0],m[1]-13,2.5,2,'#b3d6be');}}
 }
}
export function fieldScenes(c,p,m,s,t,ordered){
 const tr=s.expedition?.seamanship?.trail;if(!tr||s.cycle)return;
 const medical=tr.track==='rescue';
 for(const item of tr.log){if(item.site!==m.id)continue;const [,a,b,x,y]=yards[item.index];ordered.push([x+y+.4,()=>equipment(c,p,x,y,item.index,medical,true,s,t)]);}
 const k=workstation(s);if(!k||k.map!==m.id)return;
 ordered.push([k.x+k.y+.43,()=>{equipment(c,p,k.x,k.y,tr.index,medical,false,s,t);const [a,b]=p(k.x,k.y,44);poly(c,[[a,b-4],[a+4,b],[a,b+4],[a-4,b]],'#ecd399','#6a694e');}]);
}
