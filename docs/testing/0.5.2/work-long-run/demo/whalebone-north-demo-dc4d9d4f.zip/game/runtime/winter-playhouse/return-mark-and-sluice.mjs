import {patch,timber,face,poly,line,oval} from './joinery.mjs';
function boulder(c,p,f){
 const x=f.x+.17,y=f.y+.35,w=f.w-.4,d=f.h-.55;
 const top=[[x+.45,y+.35,29],[x+w*.55,y,49],[x+w-.3,y+1.1,58],[x+w,y+d*.66,41],[x+w*.55,y+d,37],[x+.25,y+d*.75,33]];
 patch(c,p,[top[3],top[4],[x+w*.55,y+d],[x+w,y+d*.66]],'#717c76','#485e5b');
 patch(c,p,[top[4],top[5],[x+.25,y+d*.75],[x+w*.55,y+d]],'#89938a','#4a6864');
 patch(c,p,top,'#83938b','#526b65');
 patch(c,p,[top[1],top[2],top[3],[x+w*.55,y+d*.48,43]],'#a6ada0');
 for(let i=0;i<3;i++){
  const a=.32+i*.19;timber(c,p,[x+w*.55+a,y+d-.12,30-i*.6],[x+w-.62+a*.17,y+d*.68,30+i*.4],'#ddd6b7',2.8);
 }
 const foot=[[x+w*.55,y+d+.08,2],[x+w*.35,y+d+.18,3],[x+.1,y+d*.82,3]];for(let i=1;i<foot.length;i++)timber(c,p,foot[i-1],foot[i],'#dbe7cb',2);
 for(let i=0;i<11;i++){const [a,b]=p(x+.45+i*.33,y+d*.72+.17*Math.sin(i),3);oval(c,a,b,2.2+(i%3),.9,'#a6c2aa');}
}
function gauges(c,p,f,s,t){
 const x=f.x+.3,y=f.y+f.h-.2,w=f.w-.5,water=s.flags['weir-dry']?.36:s.flags['weir-wrong']?.87:.68;
 face(c,p,x,y,()=>{
  const n=w*31;
  poly(c,[[0,-8],[0,-68],[12,-77],[n-4,-79],[n+4,-69],[n+4,-7]],'#6b7166','#394e4b');
  for(let i=6;i<n;i+=11)line(c,i,-67,i,-8,i%3?'#8e8b73':'#aaa18a',2.2);
  for(const yy of [-61,-36,-15])line(c,0,yy,n+1,yy,'#444e45',3.5);
  const cx=n*.49,cy=-70,r=27;oval(c,cx,cy,r+2,r+2,'#654d3a');oval(c,cx,cy,r-2,r-2,'#bca26f');oval(c,cx,cy,r-6,r-6,'#59635a');
  for(let i=0;i<8;i++){const a=i*Math.PI/4;line(c,cx,cy,cx+(r-4)*Math.cos(a),cy+(r-4)*Math.sin(a),'#bf9f67',2.6);}
  oval(c,cx,cy,5,5,'#64583d');line(c,cx-10,-97,cx+11,-97,'#e1bd77',2);
  for(const side of [8,n-8]){line(c,side,-8,side,-94,'#4b5449',4);line(c,side,-90,side,-14,'#ccb17f',1.2);}
  const bx=n-15,level=-14-water*23;poly(c,[[bx-4,-7],[bx-4,-43],[bx+4,-43],[bx+4,-7]],'#385651');c.fillStyle='#9db9a2';c.fillRect(bx-3,level,6,-7-level);
  for(let i=0;i<5;i++)line(c,bx+3,-12-6*i,bx+8,-12-6*i,'#ead6a3',1);
 });
 for(let i=0;i<7;i++){const z=1+i%2;const yy=y+.32+.19*i+.045*Math.sin(t+i);timber(c,p,[x+.25,yy,z],[x+w-.3,yy,z],'#b7dac399',1.3);}
}
function flowerPot(c,p,f){
 const [x,y]=p(f.x+1.1,f.y+f.h-.1);c.save();c.translate(x,y);
 for(let i=0;i<4;i++){const a=i*9;poly(c,[[a,-3],[a+8,-3],[a+6,5],[a+2,5]],'#a86c4f','#725440');line(c,a+5,-3,a+3,-13-i%2*6,'#688567',1.5);for(let k=0;k<5;k++){const b=k*1.26;oval(c,a+3+Math.cos(b)*3,-13-i%2*6+Math.sin(b)*3,2,2,'#b794a3');}oval(c,a+3,-13-i%2*6,1.4,1.5,'#d1b881');}c.restore();
}
export function currentWorks(c,p,map,f,s,t){
 if(map.id==='edge-bleach'&&f.kind==='wall'&&f.x===3){boulder(c,p,f);return true;}
 if(map.id==='edge-bleach'&&f.kind==='crate'&&f.x===23){flowerPot(c,p,f);return true;}
 if(map.id==='weir-sleeve'&&f.kind==='wall'&&f.x===3){gauges(c,p,f,s,t);return true;}
 return false;
}
export function currentFloor(c,p,map,s,t){
 if(map.id==='edge-bleach'){
  for(let i=0;i<26;i++){const x=2.7+i*.84,y=9.1+.9*Math.sin(i*.19);timber(c,p,[x,y,1],[x+.6,y+.13,1],i%4?'#a7ad89':'#e1d5aa',1.5);}
 }else if(map.id==='weir-sleeve'){
  for(const y of [8.5,13.5]){
   patch(c,p,[[2,y],[29,y],[29,y+.38],[2,y+.38]],'#426761','#5b6d58');
   for(let x=3;x<29;x+=2.4){const n=.25*Math.sin(x*.7+t*.55);timber(c,p,[x+n,y+.16,.5],[x+.78+n,y+.21,.5],'#9fc9b0',1.6);}
  }
 }
}
