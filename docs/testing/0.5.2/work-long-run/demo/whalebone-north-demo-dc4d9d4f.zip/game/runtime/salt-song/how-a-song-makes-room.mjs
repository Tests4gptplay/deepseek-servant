export const notes=['宫','商','角','徵','羽'];
export const syllables=['一','二','三','四','五','六','七','八'];
export const patterns={heel:[0,3,6],reed:[1,4,7],child:[2,5,7]};
export const voiceNames={heel:'凳脚',reed:'木簧',child:'阿梢'};
export function phrase(heel=0,reed=0){
 const move=(track,n)=>track.map(k=>(k+n+8)%8).sort((a,b)=>a-b);
 return {heel:move(patterns.heel,heel),reed:move(patterns.reed,reed),child:[...patterns.child]};
}
export function criticism(place,score){
 const h=n=>score.heel.includes(n-1),r=n=>score.reed.includes(n-1);
 if(place==='porch'){
  if(!h(1)||!h(4)||!h(7))return '巧棠把凳朝七个人站的外檐推出去。离她最远的人看不见她的鞋；要用第一、四、七拍把路搭齐。';
  if(!r(3)||!r(6))return '阿梢往外又走了一步。第三拍的“井”和第六拍的“没”要各有一声木簧托住，屋后才听得出这不是出工号。';
 }else{
  if(h(1)||r(1))return '方莳举起一只手。共桌的人要先知道谁坐下，头一拍留给椅背自己响。';
  if(!h(2)||!r(2)||h(4)||!r(4)||!h(7))return '把手放在凳面：第二拍脚和簧要一齐到，第四拍交给簧，说“帆”字之前，第七拍还应有一脚送她。';
 }
 if(h(8)||r(8))return '“帆”字的尾巴没听见。最后一拍要真能摸到一只手离开桌边，只让孩子自己收住。';
 return '';
}
export function validCoda(x){return Array.isArray(x)&&x.length===4&&x.every(v=>Number.isInteger(v)&&v>=0&&v<5);}
const scale=[261.63,293.66,329.63,392,440];
export function playPhrase(audio,destination,rows,coda=[],slow=false,done=()=>{}){
 const at=audio.currentTime+.065,step=slow?.47:.32;
 const mix=audio.createGain();mix.gain.value=.64;mix.connect(destination);
 const sounding=[];
 function note(freq,t,length,level,type,end=freq){
  const osc=audio.createOscillator(),env=audio.createGain();osc.type=type;osc.frequency.setValueAtTime(freq,t);osc.frequency.exponentialRampToValueAtTime(end,t+length*.72);
  env.gain.setValueAtTime(.0001,t);env.gain.exponentialRampToValueAtTime(level,t+.015);env.gain.exponentialRampToValueAtTime(.0001,t+length);
  osc.connect(env);env.connect(mix);osc.onended=()=>{osc.disconnect();env.disconnect();};osc.start(t);osc.stop(t+length+.015);sounding.push(osc);
 }
 for(let i=0;i<8;i++){
  const t=at+i*step;
  if(rows.heel.includes(i)){note(111,t,.18,.25,'triangle',74);note(246,t,.10,.065,'sine',168);}
  if(rows.reed.includes(i)){const f=scale[(i+1)%5]*.75;note(f,t,.30,.13,'triangle');note(f*2,t+.024,.18,.021,'sine');}
  if(rows.child.includes(i)){const f=i===7?scale[0]:i===5?scale[2]:scale[1];note(f*1.5,t+.008,i===7?.52:.29,.12,'sine');note(f*3,t+.03,.19,.02,'sine');}
 }
 if(validCoda(coda))for(let j=0;j<4;j++){const f=scale[coda[j]];note(f,at+(8+j)*step,.33,.16,'sine');note(f*2,at+(8+j)*step+.03,.21,.03,'triangle');}
 let ended=false;const finish=setTimeout(()=>{ended=true;mix.disconnect();done();},((validCoda(coda)?12:8)*step+.65)*1000);
 return ()=>{if(ended)return;ended=true;clearTimeout(finish);mix.gain.cancelScheduledValues(audio.currentTime);mix.gain.setTargetAtTime(.0001,audio.currentTime,.016);for(const osc of sounding){try{osc.stop(audio.currentTime+.07);}catch{}}setTimeout(()=>mix.disconnect(),115);};
}
