import {box,plate,face,stroke,poly,line,oval,sag,timber,stone} from './form.mjs';
export function dapple(c,p,x,y){
 const [a,b]=p(x,y,1);c.save();c.translate(a,b);c.scale(1,.44);c.rotate(-.38);
 line(c,-1,0,38,-9,'#58675040',5);for(const [u,v,r,h] of [[31,-13,13,14],[44,-16,17,13],[55,-13,11,10],[27,-5,9,8],[43,0,12,7]])oval(c,u,v,r,h,'#52684e36');
 for(let n=0;n<11;n++){const xx=28+n*2.6,yy=-17+Math.sin(n*2.6)*6;line(c,xx,yy,xx+3.5,yy+1,'#d1c39769',1.5);}c.restore();
}
export function tidalGate(c,p,s){
 const x=22.18,y=4.59,high=s.tide==='high';
 plate(c,p,x,y,1.68,1.72,-1,high?'#5a8885':'#878772','#61766d');
 for(let n=0;n<5;n++){
  const a=x+n*.31;face(c,p,[[a,y+.08,2],[a+.28,y+.08,2],[a+.28,y+1.64,2],[a,y+1.64,2]],high?'#789a9045':n%2?'#a49b80':'#bbb095');
  stroke(c,p,[a,y+.10,2],[a,y+1.64,2],high?'#a4c3adba':'#d4c49e',1.5);
  if(!high)for(let k=0;k<3;k++)stroke(c,p,[a+.02,y+.30+k*.45,2.5],[a+.14,y+.51+k*.43,2.6],'#6b816a',1.2);
 }
 if(high){plate(c,p,x+.10,y+.13,1.49,1.47,3,'#719e9bbd');for(let j=0;j<4;j++){const a=p(x+.30+j*.3,y+.43+j%2*.45,4);line(c,a[0]-7,a[1],a[0]+4,a[1]-.5,'#c8d8bb',1.2);}}
 for(const v of [y+.1,y+1.66]){box(c,p,x+1.38,v,.16,.15,0,20,timber);for(let j=0;j<2;j++)stroke(c,p,[x+1.39,v+.15,6+j*5],[x+1.54,v+.15,6+j*5],'#c9b185',1.5);}
 if(high)sag(c,p,[x+1.48,y+.15,18],[x+1.48,y+1.68,18],5,'#b49264',2.3);
 else sag(c,p,[x+1.48,y+1.66,17],[x+.57,y+1.66,8],4,'#a78a60',1.9);
}
export function workLanding(c,p,x,y,w){
 box(c,p,x,y,w,.68,-10,13,stone);for(let n=0;n<Math.ceil(w);n++)stroke(c,p,[x+n+.12,y+.69,2],[x+n+.12,y+.69,-9],'#708377',1.3);
 for(const a of [x+.10,x+w-.14]){box(c,p,a,y+.42,.15,.17,2,22,timber);stroke(c,p,[a+.07,y+.48,23],[a+.07,y+.48,28],'#c5af83',2.1);}
 sag(c,p,[x+.18,y+.48,23],[x+w-.06,y+.48,23],4,'#b29d71',1.6);
}
export function wickBench(c,p){
 const x=2.22,y=4.56;box(c,p,x,y,2.43,.45,0,15,timber);
 for(const a of [x+.10,x+2.25])stroke(c,p,[a,y+.26,12],[a,y+.26,52],'#77674d',3.4);
 stroke(c,p,[x+.03,y+.25,52],[x+2.33,y+.25,52],'#9e805a',4.3);
 for(let k=0;k<10;k++){
  const a=x+.22+k*.20,z=48-(k%3);stroke(c,p,[a,y+.27,51],[a,y+.27,z],'#8a815f',.9);
  stroke(c,p,[a-.02,y+.28,z],[a-.04,y+.29,24+k%4*2],'#e7d3a4',2.4);
 }
 const q=p(x+.52,y+.21,16.3);oval(c,...q,9.6,3.7,'#dcca9c');oval(c,q[0],q[1]-.7,6.2,2,'#b69b70');
 for(const [xx,yy] of [[4.76,4.17],[4.56,4.40]]){const A=p(xx,yy,4);oval(c,...A,7.2,3.2,'#8e775a');for(let i=0;i<4;i++)line(c,A[0]-3+i*1.8,A[1]-1,A[0]-3+i*1.8,A[1]-7-i%3,'#ddc594',1.4);}
}
export function homeSill(c,p){
 for(const u of [6.89,8.13]){
  box(c,p,u,12.42,.15,.23,0,29,timber);box(c,p,u-.05,12.36,.26,.35,28,3,['#cfb99a','#ab9172','#867961']);
 }
 const q=p(8.23,12.56,19);line(c,q[0],q[1]-7,q[0]-4,q[1]-5,'#73644c',1.7);
 poly(c,[[q[0]-5,q[1]-4],[q[0]+1,q[1]-4],[q[0],q[1]+2],[q[0]-4,q[1]+2]],'#e4c486','#876f53');
}
