import {poly,oval,line} from '../paint.mjs';
const beam='#573b32',rim='#bf9566',brass='#dbb97b',reed='#8eac95';
function beamLine(c,a,b,color=beam,width=3){line(c,...a,...b,color,width);}
function cabin(c,p,f,sleep){
 const {x,y,w,h}=f,z=sleep?35:49;
 const far=(i,u)=>p(x+i,y+.2,u),side=(j,u)=>p(x+.2,y+j,u);
 poly(c,[far(0,0),far(w,0),far(w,z),far(0,z)],sleep?'#5d675b':'#8c7156',beam);
 poly(c,[side(0,0),side(h,0),side(h,z),side(0,z)],'#735841',beam);
 for(let i=0;i<=w;i+=1.2){beamLine(c,far(i,1),far(i,z+3),beam,2.4);beamLine(c,far(i+.04,6),far(i+.04,z),rim,.8);}
 for(let j=0;j<=h;j+=1.4)beamLine(c,side(j,2),side(j,z+1),beam,2.2);
 beamLine(c,far(0,z),far(w,z),rim,3);beamLine(c,side(0,z),side(h,z),rim,3);
 for(let i=.5;i<w-1;i+=2){
  const a=p(x+i,y+1.15,12),b=p(x+i+1.55,y+1.15,12),d=p(x+i+1.55,y+2.5,12),e=p(x+i,y+2.5,12);
  poly(c,[a,b,d,e],sleep?'#7e9690':'#b49360',beam);
  if(sleep){poly(c,[a,b,p(x+i+1.55,y+1.6,17),p(x+i,y+1.6,17)],'#e3c69a',beam);beamLine(c,e,d,'#a95e4e',2.6);}
  else{const [u,v]=p(x+i+.65,y+1.7,14);oval(c,u,v,7,4.1,'#d0ac6d');oval(c,u,v-.7,5.4,2.4,'#6e6752');}
 }
}
function hull(c,p,f){
 const {x,y,w}=f;
 const at=(i,z)=>p(x+i,y+1.65+(1-z/76)*.65,z);
 const top=73;
 poly(c,[at(0,0),at(w,0),at(w,top),at(0,top)],'#55665b','#533e36');
 for(let z=7;z<top;z+=7){beamLine(c,at(0,z),at(w,z),'#2e4442',1.4);beamLine(c,at(0,z+1.6),at(w,z+1.6),'#91a18b',.9);}
 for(let i=.4;i<w;i+=2.45){beamLine(c,at(i,0),at(i+.25,top),beam,4.6);beamLine(c,at(i+.08,1),at(i+.34,top),rim,1.1);}
 for(let i=3;i<w;i+=6){const [a,b]=at(i,42);oval(c,a,b,16,18,beam);oval(c,a,b,13,15,brass);oval(c,a,b,10.2,12.4,'#a4bcbc');oval(c,a,b+1,7.5,8.9,'#688b87');line(c,a-9,b+4,a+9,b-3,'#d7dbc0',1.1);line(c,a,b-11,a,b+11,'#5a695e',1);}
}
function mat(c,p,f){
 const {x,y,w,h}=f,cords=['#a55f48','#8a8566','#bd9a64'];
 poly(c,[p(x,y),p(x+w,y),p(x+w,y+h),p(x,y+h)],'#977752','#664e3b');
 for(const e of [.12,h-.12])beamLine(c,p(x,y+e,1),p(x+w,y+e,1),'#e1bd80',2);
 for(let i=.45;i<w-.25;i+=.78){const j=Math.round(i/.78);beamLine(c,p(x+i,y+.22,1),p(x+i+.32,y+h/2,1),cords[j%3],1.8);beamLine(c,p(x+i+.32,y+h/2,1),p(x+i,y+h-.22,1),cords[j%3],1.8);}
}
export function paintSaltCarpet(c,p,map){
 if(map.id==='salt-song-room')for(const f of map.features)if(f.kind==='lane')mat(c,p,f);
}
export function saltRoomFeature(c,p,map,f){
 if(map.id!=='salt-song-room')return false;
 if(f.kind==='building')cabin(c,p,f,f.y>10);
 else if(f.kind==='wall'&&f.w>10)hull(c,p,f);
 else if(f.kind==='lane')return true;
 else if(f.kind==='crate'){
  for(let i=.65;i<f.w-.2;i+=1.25){const [a,b]=p(f.x+i,f.y+1.25);oval(c,a,b+1.5,10,3.3,'#3c37306e');oval(c,a,b-4,8.3,7.7,f.y<5?'#a67450':'#9a8b6e');oval(c,a,b-10,6.5,2.8,'#c7a776');oval(c,a,b-10,4.8,1.8,'#514639');}
 }else if(f.kind==='lamp'){
  const [a,b]=p(f.x+.5,f.y+.5);line(c,a,b-1,a,b-30,beam,3);line(c,a-8,b-29,a+11,b-33,beam,2);oval(c,a+9,b-20,7,9,'#deb173');line(c,a+9,b-30,a+9,b-11,'#9f6f4d',1);
 }
 return true;
}
export function saltRoomInstrument(c,p,map,e){
 if(e.action?.type!=='salt-song')return false;
 const [a,b]=p(e.x+.5,e.y+.5),work=e.action.work;
 oval(c,a,b+1,13,3.5,'#413a348c');
 if(work==='mix'||work==='heel'){poly(c,[[a-12,b-8],[a+3,b-13],[a+16,b-8],[a,b-3]],'#bea06d',beam);line(c,a-9,b-7,a-9,b,beam,2);line(c,a+10,b-8,a+10,b-1,beam,2);for(let i=0;i<5;i++)line(c,a-5+i*3,b-8-i*.34,a+i*3,b-5-i*.34,i%2?reed:brass,1.2);}
 else {for(let i=0;i<4;i++)line(c,a-8+i*4,b-1,a-12+i*5,b-14-i%3*3,i%2?reed:brass,2.3);}
 return true;
}
