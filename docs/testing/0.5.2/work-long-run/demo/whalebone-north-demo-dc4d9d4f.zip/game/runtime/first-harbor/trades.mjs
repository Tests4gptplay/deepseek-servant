import {box,plate,face,stroke,sag,poly,line,oval,timber,stone} from './form.mjs';
export function vapor(c,x,y,t,ink='#f0e3bd9c',scale=1){
 for(let k=0;k<3;k++){const n=Math.sin(t*.73+k*2.1)*2.5;c.beginPath();c.moveTo(x+(k-1)*3*scale,y);
  c.bezierCurveTo(x+(k*3+n)*scale,y-7*scale,x+(-5+n)*scale,y-12*scale,x+(1-k*3+n)*scale,y-20*scale);
  c.strokeStyle=ink;c.lineWidth=(1.8-k*.24)*scale;c.stroke();}c.lineWidth=1;
}
function awning(c,p,x,y,w,z,deep,cloth,trim){
 for(let i=0;i<7;i++){const a=x+w*i/7,b=x+w*(i+1)/7;const col=i%2?cloth:trim;
  face(c,p,[[a,y,z],[b,y,z],[b,y+deep,z-5],[a,y+deep,z-5]],col);
  face(c,p,[[a,y+deep,z-5],[b,y+deep,z-5],[b-.025,y+deep,z-8],[a+.025,y+deep,z-8]],col,'#746e54');}
 for(const a of [x+.04,x+w-.04])stroke(c,p,[a,y+deep-.025,0],[a,y+deep-.025,z-5],'#7c644c',2);
 stroke(c,p,[x,y+deep,z-5],[x+w,y+deep,z-5],'#d8bf97',1.35);
}
function pots(c,p,x,y,t){const q=p(x,y,10);oval(c,q[0],q[1]+1,8,5,'#584e41');oval(c,q[0],q[1]-2,10,4,'#7b7962');oval(c,q[0],q[1]-3,7.4,2.6,'#cdaf77');vapor(c,q[0],q[1]-3,t,'#f1dfbad9',.9);}
function laundry(c,p,x,y,w,z,t,colors){
 sag(c,p,[x,y,z],[x+w,y,z+1],5,'#736e54',1.15);
 for(let i=0;i<colors.length;i++){const a=x+w*(i+.55)/(colors.length+.35),hh=i%2?8:12,wind=Math.sin(t*.8+i)*1.25;
  const A=p(a,y,z-1.7),B=p(a+.35,y,z-2);poly(c,[A,B,[B[0]+wind,B[1]+hh],[A[0]-1+wind,A[1]+hh-1]],colors[i],'#7e8371');line(c,A[0]+2,A[1]+1,A[0]+2+wind,A[1]+hh-2,'#fff0ca55',.75);}
}
export function tradeFront(c,p,k,x,y,w,h,z,door,dw,t,s){
 const right=x+w-.4,clear=x+w*.70;
 if(k==='soup'){
  awning(c,p,x+.22,y,w*.49,38,.48,'#c58b49','#e0b96e');box(c,p,x+.38,y+.03,w*.39,.31,0,10,timber);
  pots(c,p,x+w*.27,y+.19,t);for(let i=0;i<3;i++){const q=p(x+.47+i*.18,y+.2,10.6);oval(c,...q,3.9,1.6,'#e5d1a5');}
 }else if(k==='wake'||k==='wick'){
  awning(c,p,door-.30,y,dw+.66,50,.57,k==='wick'?'#9b795f':'#c2bc9e',k==='wick'?'#c6a675':'#e4d7b2');
  const q=p(door+dw+.22,y+.22,24);line(c,q[0],q[1]-4,q[0],q[1]+2,'#665d49',1);poly(c,[[q[0]-3,q[1]+2],[q[0]+3,q[1]+2],[q[0]+2,q[1]+9],[q[0]-2,q[1]+9]],'#dfbc6e','#786748');
  if(k==='wake')laundry(c,p,x+w*.56,y+.10,w*.31,23,t,['#ddd5b3','#b3b59c']);
  else{box(c,p,door+dw+.30,y+.08,.36,.22,0,9,timber);const q=p(door+dw+.45,y+.18,10);oval(c,...q,4,1.8,'#ecd5a4');}
 }else if(k==='rope'||k==='winch'){
  box(c,p,clear-.45,y+.04,1.15,.24,0,11,timber);for(let i=0;i<4;i++){const q=p(clear-.28+i*.21,y+.10,14+Math.sin(i)*2);c.beginPath();c.ellipse(q[0],q[1],3+i%2,7.4,0,0,Math.PI*2);c.strokeStyle=i%2?'#c4a36c':'#a78e5d';c.lineWidth=2;c.stroke();}c.lineWidth=1;
  const A=p(right-.1,y+.02,35);line(c,A[0]-8,A[1]-1,A[0]+9,A[1]-2,'#675742',2.5);line(c,A[0]+7,A[1]-1,A[0]+7,A[1]+13,'#b99b6d',1.25);
 }else if(k==='balcony'||k==='bunks'||k==='wash'||k==='dye'){
  laundry(c,p,x+w*.44,y+.33,w*.45,k==='wash'?27:z>=75?57:30,t,k==='dye'?['#7e8587','#b28978','#77978f']:['#c1b193','#d2cbb5','#879b94']);
 }else if(k==='pump'||k==='sluice'){
  const q=p(clear+.15,y+.16,14);for(let i=0;i<6;i++){const dx=i*2.5;line(c,q[0]+dx-8,q[1]-7+dx*.14,q[0]+dx-8,q[1]+3+dx*.14,'#435c59',1.6);}stroke(c,p,[x+.18,y+.05,7],[right,y+.05,7],'#b5ac87',2.3);
 }else if(k==='store'||k==='fish'||k==='scale'){
  awning(c,p,door-.22,y,dw+.45,50,.47,k==='scale'?'#728f83':'#a87752',k==='scale'?'#a6ad87':'#c4a178');
  if(k==='store'||k==='fish'){box(c,p,right-1.05,y+.04,.92,.36,0,8,timber);for(let i=0;i<4;i++){const q=p(right-.94+i*.18,y+.24,9);oval(c,...q,4.2,2.2,k==='fish'?'#9eada3':'#c2a67c');}}
 }
}
export function roofTrade(c,p,k,x,y,w,h,z,rise,t){
 if(['soup','wick','dye','guard'].includes(k)){
  const a=x+w*.16,b=y+h*.33;box(c,p,a,b,.37,.37,z+rise-2,14,['#b58d70','#a67e69','#876e60']);
  box(c,p,a-.04,b-.04,.46,.46,z+rise+11,3,['#d2b493','#9b7c68','#8a7766']);const q=p(a+.16,b+.15,z+rise+15);if(k==='soup'||k==='wick')vapor(c,...q,t,'#e1dfc492',1.05);
 }else if(k==='scale'){
  const a=x+w*.57,b=y+h*.37;box(c,p,a,b,.88,.62,z+rise-1,13,['#a6ae9a','#829b8b','#677e78']);const q=p(a+.46,b+.37,z+rise+24);
  face(c,p,[[a-.12,b-.1,z+rise+13],[a+1.0,b-.1,z+rise+13],[a+.45,b+.34,z+rise+24]],'#748b81');
  face(c,p,[[a+1,b-.1,z+rise+13],[a+1,b+.72,z+rise+13],[a-.12,b+.72,z+rise+13],[a+.45,b+.34,z+rise+24]],'#53766d');line(c,q[0],q[1]+1,q[0],q[1]-7,'#866f4a',1.6);
 }else if(k==='winch'||k==='rope'){stroke(c,p,[x+w*.74,y+h*.47,z+rise],[x+w*.74,y+h*.47,z+rise+9],'#655a47',2);}
}
