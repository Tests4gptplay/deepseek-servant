import {face,rod,plate,box,line,oval,poly,beam,hanging,ring,lamp} from '../lamplit-whale/fixtures.mjs';
import {cliff,lit,slate,timber,spool} from './shore-craft.mjs';
function prism(c,a,b,size){
 poly(c,[[a,b-size],[a+size*.68,b+size*.46],[a-size*.78,b+size*.30]],'#b6d3ca','#728e90');
 poly(c,[[a,b-size],[a+size*.68,b+size*.46],[a+size*.96,b+size*.12],[a+size*.28,b-size*.99]],'#d2c59b','#879894');
 line(c,a,b-size,a-size*.35,b-size*.08,'#eef0ce',1.2);
}
function grinding(c,p,x,y,ground){
 box(c,p,x-.8,y-.4,1.75,.85,0,10,timber);const [a,b]=p(x,y,17);
 for(const off of [-.55,.52])beam(c,p,[x+off,y,7],[x+off,y,26],4.4);
 oval(c,a,b-4,13,14,'#586967');oval(c,a-1,b-6,10,11,'#aaa58a');ring(c,[a-1,b-6],6.2,'#807e69',.9);
 line(c,a+8,b-4,a+19,b-8,'#b29b74',2.4);line(c,a+18,b-8,a+23,b-5,'#716351',3.2);
 if(ground)prism(c,a+19,b+5,5);else oval(c,a+20,b+4,5,2.2,'#b8ad92');
}
function optical(c,p,x,y,split,t){
 box(c,p,x-.54,y-.37,1.14,.67,0,18,slate);const [a,b]=p(x,y,20);
 for(let i=0;i<2;i++){const xx=a-11+i*18;line(c,xx,b+2,xx+1,b-17,'#746747',2.6);ring(c,[xx+1,b-16],5,'#baa56e',.84);}
 line(c,a-15,b-4,a+16,b-9,'#aa9165',3);prism(c,a+2,b-12,6);
 if(split){line(c,a+10,b-16,a+30,b-24,'#ecd1a198',2.2);line(c,a+10,b-16,a+30,b-16,'#9ccec998',2.2);
  lit(c,a+30,b-24,6,'#f6c18a');lit(c,a+30,b-16,6,'#8ed3cd');}
 else{lit(c,a+24,b-18,6,'#d9c99a');}
}
export function opticsFeature(c,p,m,f,s,t){
 if(m.id!=='silent-gimbal')return false;
 const x=f.x,y=f.y,w=f.w,h=f.h;
 if(f.kind==='wall'){
  if(x===0){for(let j=0;j<5;j++){const u=x+j*w/5;cliff(c,p,u,y+.24,w/5+.24,h-.38,19+((j*11)%20),j+3);}
   for(let j=0;j<3;j++){const xx=6+j*6;beam(c,p,[xx,3.3,8],[xx,3.3,47],6);beam(c,p,[xx,3.3,47],[xx+2,3.1,44],5);} }
  else{cliff(c,p,x+.2,y+.15,w-.4,h-.4,22,11);spool(c,p,x+.7,y+.9,16);}
  return true;
 }
 if(f.kind==='building'){const u=x+1.45,v=y+2.45;grinding(c,p,u,v,!!s.flags['prism-room']);
  box(c,p,u+1.45,v-.28,.77,.78,0,8,timber);const wash=p(u+1.87,v+.1,10);oval(c,...wash,13,6,'#8b9f92');oval(c,wash[0],wash[1]-1,10,3.8,'#b7d3c8');
  const polishX=u+3.54;box(c,p,polishX,v-.42,1.35,.77,0,15,timber);plate(c,p,polishX+.14,v-.34,1.05,.58,16,'#b2a088','#897867');
  for(let i=0;i<3;i++){const a=p(polishX+.24+i*.35,v-.14,17);prism(c,...a,4+i*.7);}
  hanging(c,p,[x+.75,y+.78,40],[x+w-1.1,y+.9,36],5,'#8d8268',2);
  for(let i=0;i<4;i++){const q=p(x+1.0+i*1.25,y+.88,29);prism(c,...q,5+i%2);}return true;}
 if(f.kind==='crate'){for(let i=0;i<2;i++){box(c,p,x+.45+i*1.55,y+1.4,1.31,.74,0,16,timber);const [a,b]=p(x+1+i*1.55,y+1.74,17);for(let j=0;j<4;j++)poly(c,[[a-13+j*6,b-2],[a-8+j*6,b-3],[a-5+j*6,b+1],[a-11+j*6,b+2]],['#c38468','#c1b782','#7fa5aa','#9f998d'][j]);}return true;}
 if(f.kind==='lamp'){optical(c,p,x+.5,y+.45,!!s.flags['prism-room'],t);return true;}
 return false;
}
export function opticsEntity(c,p,m,e,s,t){
 if(m.id!=='silent-gimbal')return false;
 if(e.id==='gimbal-hand'){optical(c,p,e.x+.64,e.y-.15,!!s.flags['prism-room'],t);return true;}
 if(e.id==='gimbal-prism'){grinding(c,p,e.x+.73,e.y-.08,!s.flags['prism-found']);return true;}
 return false;
}
