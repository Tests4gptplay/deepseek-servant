import {voiceCue,playBone} from './winter-voice/song.mjs';
const cues={
 'chair-unseat':'chairDog', 'chair-step':'houseSteps', 'split-door':'thresholdWood', 'split-awning':'netCloth',
 'ramp-splay':'cartTurn','curtain-block':'netCloth','curtain-gather':'netCloth','curtain-walk':'houseSteps',
 'moon-unhook':'thresholdWood','moon-open':'houseSteps','netdorm-night':'netCloth','netdorm-open':'houseSteps',
 'swell-pass':'calfWater','calf-turn':'calfWater','eave-back':'cartTurn','skirt-back':'netCloth',
 'watch-sink':'deepBreath','watch-rise':'crestBreath','bath-spare':'ropePay','bucket-rig':'lift','well-flush':'brine','well-cask-test':'well','arm-out':'lift','arm-in':'latch','bar-low':'submerged','bar-high':'glass','pilot-night-order':'pilot','transom-dry':'well','lip-releasable':'ropePay','sill-tow':'lift','sill-cart':'frame','bend-carry':'frame','bend-first':'ropePay',
 'bread-prow':'oven', 'bread-width':'coal', 'turn-head':'frame', 'turn-feet':'frame',
 'offer-sill':'sash', 'offer-alley':'latch', 'wash-west':'brine', 'wash-east':'well',
 'ear-cover-tile':'felt','ear-raise-tile':'pipe','ear-rebound':'pipe','ear-wet-tone':'submerged',
 'glass-face':'glass','glass-grain':'frostGlass','rye-hang':'sash','rye-submerge':'brine',
 'moth-air-out':'felt','moth-unwind':'sash','wren-black-bearing':'frame','wren-white-bearing':'glass',
 'set-trawl-sail':'felt','drop-trawl-sail':'submerged','peel-back':'frostGlass','two-strikers':'bells'
};
export const workshopCue=id=>voiceCue(id)||cues[id];
const voices={
 chairDog:[[179,.08,0,.048,'triangle'],[324,.12,.11,.054,'triangle'],[249,.16,.26,.043,'sine'],[594,.15,.52,.025,'sine']],
 houseSteps:[[106,.12,0,.050,'triangle'],[152,.1,.16,.034,'sine'],[101,.15,.37,.045,'triangle']],
 thresholdWood:[[175,.19,0,.052,'triangle'],[230,.12,.08,.041,'sine'],[106,.24,.29,.052,'triangle']],
 netCloth:[[349,.16,0,.030,'triangle'],[291,.2,.11,.034,'sine'],[243,.25,.26,.038,'triangle']],
 cartTurn:[[152,.11,0,.056,'triangle'],[199,.14,.10,.032,'sine'],[147,.2,.29,.053,'triangle']],
 calfWater:[[288,.19,0,.033,'sine'],[214,.22,.15,.040,'sine'],[158,.29,.33,.034,'triangle']],
 deepBreath:[[126,.64,0,.06,'sine'],[92,.78,.24,.055,'sine'],[61,.7,.6,.038,'triangle']],
 crestBreath:[[70,.68,0,.06,'sine'],[109,.81,.21,.055,'sine'],[180,.68,.57,.035,'triangle']],
 ropePay:[[198,.23,0,.05,'triangle'],[176,.46,.16,.043,'triangle'],[122,.34,.47,.035,'sine']],
 lift:[[241,.09,0,.075,'triangle'],[319,.12,.14,.055,'triangle'],[403,.3,.28,.042,'sine']],
 pilot:[[447,.23,0,.065,'sine'],[603,.35,.22,.045,'sine'],[452,.38,.49,.04,'sine']],
 oven:[[111,.25,0,.065,'triangle'],[167,.36,.07,.024,'sine']],
 coal:[[92,.08,0,.11,'triangle'],[134,.07,.08,.055,'triangle'],[106,.13,.16,.05,'sine']],
 frame:[[164,.13,0,.075,'triangle'],[246,.20,.12,.054,'triangle']],
 sash:[[244,.105,0,.068,'triangle'],[311,.16,.085,.048,'sine']],
 latch:[[487,.055,0,.075,'triangle'],[307,.14,.053,.047,'triangle']],
 brine:[[220,.17,0,.045,'sine'],[167,.21,.085,.05,'sine'],[129,.23,.17,.048,'sine']],
 well:[[413,.25,0,.06,'sine'],[525,.32,.085,.044,'sine'],[621,.27,.16,.034,'sine']],
 felt:[[278,.084,0,.07,'sine'],[174,.12,.06,.036,'triangle']],
 pipe:[[463,.43,0,.065,'sine'],[697,.45,.11,.04,'sine'],[463,.45,.23,.029,'sine']],
 submerged:[[194,.33,0,.065,'sine'],[240,.30,.14,.034,'sine']],
 glass:[[844,.37,0,.068,'sine'],[1266,.3,.045,.028,'sine']],
 frostGlass:[[591,.3,0,.055,'triangle'],[739,.36,.09,.032,'sine']],
 bells:[[538,.65,0,.074,'sine'],[1091,.36,0,.024,'sine'],[403,.73,.29,.065,'sine'],[810,.4,.29,.021,'sine']]
};
export function soundWorkshop(ctx,bus,id){
 if(playBone(ctx,bus,id))return true;
 const notes=voices[id];if(!notes)return false;
 for(const [pitch,span,delay,volume,type]of notes){
  const at=ctx.currentTime+delay,src=ctx.createOscillator(),gain=ctx.createGain();src.type=type;
  src.frequency.setValueAtTime(pitch,at);src.frequency.exponentialRampToValueAtTime(pitch*.982,at+span);
  gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(volume,at+.012);gain.gain.exponentialRampToValueAtTime(.0001,at+span);
  src.connect(gain);gain.connect(bus);src.onended=()=>{src.disconnect();gain.disconnect();};src.start(at);src.stop(at+span+.02);
 }
 return true;
}
