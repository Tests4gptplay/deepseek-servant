import {poly,line,oval,rand} from './paint.mjs';
const coast=new Set(['edge-bleach','burial-cape','false-shoal','lee-mouth','lee-ridge','rib-survey','ice-mark','red-beacon','inner-stake','outer-spar','mat-inlet']);
export const wildCoast=id=>coast.has(id);
function band(c,p,coords,offset,color){
 const a=coords.map(([x,y])=>p(x,y+offset));c.beginPath();c.moveTo(...a[0]);
 for(let i=1;i<a.length;i++)c.lineTo(...a[i]);c.strokeStyle=color;c.lineWidth=1.8;c.stroke();c.lineWidth=1;
}
export function coastWater(c,p,m,t){
 const top=m.features.find(f=>f.kind==='water'&&f.y===0&&f.w>=m.width*.84);
 if(!coast.has(m.id)||!top)return;
 const n=top.h,bank=[],w=m.width;
 for(let i=0;i<=w*3;i++){const x=i/3,depth=.30+.18*Math.sin(x*.66)+.19*Math.sin(x*1.8)+rand(i,34)*.10;bank.push([x,n-depth]);}
 const toes=bank.map(([x,y],i)=>[x,y-.20-.13*Math.sin(x*1.09)-.065*rand(i,72)]);
 const strip=(near,far,tone)=>poly(c,[...near.map(q=>p(...q)),...far.slice().reverse().map(q=>p(...q))],tone);
 strip(bank,bank.map(([x])=>[x,n+.018]),'#8f9986');strip(toes,bank,'#667f7b');
 band(c,p,toes,-.035-Math.sin(t*.6)*.015,'#bed1bf');band(c,p,toes,-.15,'#90b4a8');
 for(let j=1;j<w;j+=1.9){const x=j+rand(j*10,12)*.77,y=n-.7-rand(j*8,8)*1.12,[a,b]=p(x,y);
  const h=3+rand(j*4,22)*6;poly(c,[[a-5-h*.5,b+1],[a-1-rand(j*8,12)*3,b-h],[a+2+h*.3,b-h*.68],[a+3+h*.46,b],[a+1,b+2]],'#788b81','#7f9b90');
  line(c,a-7,b+2,a+6,b+3,'#c6d2b8',1.05);}
}
function trail(c,p,a,b,d,e,width,color){
 c.beginPath();c.moveTo(...p(...a));c.bezierCurveTo(...p(...b),...p(...d),...p(...e));c.strokeStyle=color;c.lineWidth=width;c.lineCap='round';c.stroke();c.lineWidth=1;
}
export function capeLand(c,p,m){
 if(m.id!=='burial-cape')return;c.save();const paths=[[[1,10.4],[5.5,11.1],[9.3,10.0],[12,10.48]],[[12,10.48],[14,10.85],[17.7,10.47],[21.2,9.47]],[[12.9,10.65],[14,11.6],[16,12.2],[17.5,12.75]]];
 for(const q of paths){trail(c,p,...q,22,'#aaa38a');trail(c,p,...q,15,'#b5ac91');trail(c,p,...q,6,'#b9b195');}
 for(let j=0;j<54;j++){const x=2.1+rand(j,10)*19.3,y=10.25+.54*Math.sin((x-5)*.30)+(rand(j,15)-.5)*.54,[a,b]=p(x,y);oval(c,a,b,1.4+rand(j,11)*4,.7+rand(j,14)*.9,j%3?'#aba289':'#a69f85');}
 for(const [cx,cy,rx,ry] of [[4.4,5.8,2.5,1.9],[21.4,14.8,3,1.2],[4.0,13.8,2.2,1.3],[18.4,5.3,1.5,1]]){
  for(let j=0;j<28;j++){const ang=j*2.4,x=cx+Math.cos(ang)*rx*rand(j,21),y=cy+Math.sin(ang)*ry*rand(j,24),[a,b]=p(x,y),h=5+rand(j,5)*6;
   oval(c,a,b,7+rand(j,82)*5,2.3,'#808c7780');for(let i=0;i<5;i++){line(c,a+i*1.4-3,b,a-7+i*2,b-h+(i%2)*3,['#7b866a','#8b9479','#939578'][i%3],1.6);}
   if(j%5===0){oval(c,a-4,b-h,1.7,1.4,'#caa58a');oval(c,a-3,b-h-1,1.2,1.2,'#dfceb0');}}
 }
 for(let i=0;i<30;i++){const [a,b]=p(6+rand(i,2)*14,9+rand(i,50)*3.1);line(c,a-1.8,b,a+1.5,b-.5,'#9a957b',.75);}c.restore();
}
