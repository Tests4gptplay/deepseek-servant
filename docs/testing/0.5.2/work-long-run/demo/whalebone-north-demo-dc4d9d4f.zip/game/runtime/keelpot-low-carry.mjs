const title={blue:'青布鱼瓮',rust:'赭布鱼瓮',near:'靠岸半盘',sea:'朝海半盘'};
const tallies=s=>s.flags['keelpot-fish-first']?['near','sea']:['blue','rust'];
function liftOne(s,f,key){
 if(!s.flags['keelpot-landed'])return '高水舟还没在对岸卸下。先上舟，把第一家的东西交到接货人手里。';
 if(s.tide!=='low')return '低脚路还在水底。等第二枚系耳露出，多等也不会多出第三道肋。';
 if(f.shoulder)return '石鼻只有一人宽，一副肩不能同时架两件。现在仍担着'+title[f.shoulder]+'。';
 if(f.ashore.includes(key))return title[key]+'已经被照妹接走。垫木空了，不能再拿第二次。';
 f.shoulder=key;s.flags['keelpot-on-shoulder']=true;s.flags['keelpot-crossed']=false;
 return '你只担起'+title[key]+'。从斜坡下低脚路，先让托篓石另一面的人接一下肩，再去远岸。';
}
export function fieldLoads(op,s,f){
 const items=tallies(s),holdsFish=items[0]==='blue';
 if((op==='fish')!==holdsFish)return [['看一眼空座',()=>holdsFish?'整副苗已经随高水过埠，剩下两只改腌的实瓮在鱼铺。':'鱼都随高水送去了，剩下两半苗盘须在浸过的遮索上分肩。']];
 return [...items.map(k=>['担起'+title[k],()=>liftOne(s,f,k)]),['把低脚路担货放回原座',()=>{
  if(!f.shoulder)return '空担没有可放回的东西。';
  const item=f.shoulder;f.shoulder=null;s.flags['keelpot-crossed']=false;s.flags['keelpot-on-shoulder']=false;
  return title[item]+'放回湿垫，原来接过的件数不变。';
 }]];
}
export function landGoods(op,s,f){
 if(op==='land')return [['请照妹把舟肋里的实物接上岸',()=>{
  if(s.flags['keelpot-landed'])return '照妹已经接过这舟。木踵上只余两条湿印，没有第二份货。';
  if(!s.flags['keelpot-launched']||!f.boat.length)return '她面前还没有本班的舟。';
  const fish=s.flags['keelpot-fish-first'];f.boat.length=0;s.flags['keelpot-landed']=true;
  return fish?'两只瓮都上岸。照妹把青布送日灶，赭布留夜灶。上工绳桥只走空手人，你们可回去等低潮，替禾盏分盘。':'整架落在外床，蚝苗仍裹着外海水。蒲岸换好围裙去了粮船。回绳桥等低水，商枣的两瓮只好各担一趟。';
 }]];
 if(op==='cross')return [['把肩担挪过两处错开的石缺',()=>{
  if(!f.shoulder)return '你空手走得过，照妹却不会给一趟空担记一件。';
  if(s.flags['keelpot-crossed'])return '同一肩担已经过了石缺，不能在岸上变成两件。';
  s.flags['keelpot-crossed']=true;return '你先把靠水一端搁住，再侧肩绕过窄缺。'+title[f.shoulder]+'仍在肩上，去接货坡亲自放稳。';
 }]];
 return [['让照妹逐件接下肩货',()=>{
  const key=f.shoulder;
  if(!key)return '接货台前没有肩货。地上原有的湿印不能当作已经送来。';
  if(!s.flags['keelpot-crossed'])return '担绳还挂在近岸那道直扣。去托篓石把实物挪过错缺，再交给我。';
  if(!tallies(s).includes(key)||f.ashore.includes(key))return '这件的布头和接过的实物对不上，先把它放回原座。';
  f.ashore.push(key);f.shoulder=null;s.flags['keelpot-on-shoulder']=false;s.flags['keelpot-crossed']=false;
  if(f.ashore.length<2)return title[key]+'落在木架。尚有另一只；沿上工绳桥空手回去接，别让同一件数两回。';
  s.flags['keelpot-done']=true;
  return s.flags['keelpot-fish-first']?'两半苗都落在内沟湿床。禾盏拿一把软泥轻轻覆住绳脚。今晚鲜汤照开，她家的苗要多等一茬。':'两瓮都进凉窖，赭布仍整着。灶嫂把今夜的鲜鱼勺换成豆勺，明早上工的人分第一层带皮的鱼。';
 }]];
}
