import {face,rod,beam,box,plate,lamp,ring,oval,poly,ash,tar,oak,brass,sail,hanging} from './fixtures.mjs';
import {bed,tub} from '../voyage-shapes.mjs';
const cloth=['#bf987f','#d4c9ac','#849a99','#b2aa8b'];
function screen(c,p,x,y,w,z,color){
 face(c,p,[[x,y,0],[x+w,y,0],[x+w,y,z],[x,y,z]],'#4d625e');
 for(let i=0;i<5;i++)face(c,p,[[x+.04,y+.02,4+i*4.1],[x+w-.04,y+.02,4+i*4.1],[x+w-.04,y+.08,6.2+i*4.1],[x+.04,y+.08,6.2+i*4.1]],color,'#607369');
}
function kettle(c,p,x,y,z){
 const a=p(x,y,z);oval(c,a[0],a[1],5.3,2,'#666b56');oval(c,a[0],a[1]-4.5,5.2,4.2,'#858976');oval(c,a[0],a[1]-7.7,4.8,1.42,'#b5a57a');ring(c,[a[0],a[1]-6.5],3.3,'#666e5c',1.25);
}
function roofPane(c,p,x,y,z,wide){
 box(c,p,x,y,wide,.76,z,6,['#b4b3a1','#89998f','#73847b']);
 for(let k=.10;k<wide-.08;k+=.33){plate(c,p,x+k,y+.07,.25,.55,z+6.7,'#94afa6','#6d817a');}
}
export function fronts(c,p,f,m,s,t,ht){
 const {x,y,w,h}=f,n=y+h-.075,d=x+.47,hold=m.id==='crib-hold';const long=hold?x===20:x===17;
 const shade=hold?'#778b7b':x===3?'#a3897c':x===17?'#8e9d90':x===8?'#a39376':'#8a9b8e';
 // Hull-side doors use a continuous raised sill; stretcher bay has two sliding leaves.
 const opening=hold&&x===18||!hold&&x===3?1.25:.82;
 face(c,p,[[d,n+.02,1],[d+opening,n+.02,1],[d+opening,n+.02,ht*.81],[d,n+.02,ht*.81]],'#354e4d');
 for(const dx of [-.05,opening+.02])beam(c,p,[d+dx,n+.07,0],[d+dx,n+.07,ht*.84],2.8);
 beam(c,p,[d-.1,n+.07,ht*.84],[d+opening+.12,n+.07,ht*.84],3.35);
 rod(c,p,[d+.04,n+.08,2],[d+opening-.06,n+.08,2],'#b6a780',2.2);
 if(!hold&&x===8){for(const a of [2.2,3.4])screen(c,p,x+a,n+.08,.91,26,'#a39776');roofPane(c,p,x+1.2,y+h*.46,ht+4,2.5);}
 if(!hold&&x===1){roofPane(c,p,x+1.15,y+h*.48,ht+4,1.12);box(c,p,x+3,y+h*.43,.55,.63,ht+5,13,tar);box(c,p,x+2.94,y+h*.4,.68,.73,ht+17,2,brass);kettle(c,p,x+1.6,n+.41,7);}
 if(!hold&&x===3){sail(c,p,[d+.02,n+.13,ht*.82],[d+.54,n+.13,ht*.82],15,'#c8bfae',t);box(c,p,x+2.2,n+.17,1.57,.49,0,7,oak);kettle(c,p,x+2.55,n+.42,8);const q=p(x+3.4,n+.39,7);tub(c,...q,4.6,'#76938f');}
 if(long){beam(c,p,[x+1.8,n+.08,ht*.63],[x+w-.32,n+.08,ht*.63],3.5);
  if(!hold){for(const [j,tone] of cloth.entries()){const xx=x+2.30+j*1.28;sail(c,p,[xx,n+.19,ht*.63],[xx+.64,n+.19,ht*.63],12+j%2*7,tone,t,true);}}
  else for(let k=0;k<4;k++)box(c,p,x+2+k*1.1,n+.08,.71,.28,7,3,['#a29d78','#7b8166','#657562']);
 }
 if(!hold&&x===19){for(let j=0;j<3;j++)screen(c,p,x+2.05+j*.95,n+.06,.69,26,'#849790');}
 if(hold&&x===18){
  const xx=x+1.9;face(c,p,[[xx,n,3],[xx+3.20,n,3],[xx+3.20,n,ht-3],[xx,n,ht-3]],'#4f6861');
  bed(c,p,xx+.3,n-.16,false);bed(c,p,xx+1.75,n-.20,true);
  hanging(c,p,[xx+.13,n+.10,ht-3],[xx+3,n+.10,ht-3],2,'#b6a780');
  sail(c,p,[xx+.17,n+.13,ht-5],[xx+.42,n+.13,ht-5],15,'#ab9787',t);sail(c,p,[xx+2.63,n+.13,ht-5],[xx+2.95,n+.13,ht-5],15,'#a89280',t);
 }
 if(hold&&x===4){screen(c,p,x+2.2,n+.08,1.80,23,'#9a9c7d');roofPane(c,p,x+.91,y+h*.48,ht+5,1.27);}
}