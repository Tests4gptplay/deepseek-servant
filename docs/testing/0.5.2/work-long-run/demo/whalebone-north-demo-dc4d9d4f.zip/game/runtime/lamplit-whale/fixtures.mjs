import {poly,line,oval,rand} from '../paint.mjs';
import {box,plate} from '../voyage-shapes.mjs';
export {poly,line,oval,rand,box,plate};
export const tar=['#75918d','#4b6b6c','#354f57'],ash=['#c3b699','#a28e70','#756e5c'],oak=['#ae8965','#795d4d','#584f45'],brass=['#d7bc84','#aa8a5c','#776947'];
export const face=(c,p,q,ink,edge)=>poly(c,q.map(a=>p(...a)),ink,edge);
export const rod=(c,p,a,b,ink,width=1)=>line(c,...p(...a),...p(...b),ink,width);
export function hanging(c,p,a,b,drop,ink,width=1.5){
 const A=p(...a),B=p(...b);c.beginPath();c.moveTo(...A);c.quadraticCurveTo((A[0]+B[0])/2,(A[1]+B[1])/2+drop,...B);c.lineWidth=width;c.strokeStyle=ink;c.stroke();c.lineWidth=1;
}
export function lamp(c,p,x,y,z,t,lit=true,size=1){
 const q=p(x,y,z);c.save();c.translate(...q);c.scale(size,size);
 if(lit){const rr=18+Math.sin(t*1.19+x)*1.4,g=c.createRadialGradient(0,-3,1,0,-3,rr);g.addColorStop(0,'#ffe697ae');g.addColorStop(.33,'#f5c06d59');g.addColorStop(1,'#f6bd6b00');c.fillStyle=g;c.fillRect(-rr,-rr-3,rr*2,rr*2);}
 line(c,-7,-9,4,-9,'#755f45',1.6);line(c,2,-9,2,-6,'#8c7555',1.3);
 poly(c,[[-4,-6],[5,-6],[6,-3],[4,3],[-2,3],[-5,-2]],lit?'#e2c894':'#8d9584','#786c56');
 if(lit){oval(c,1,-1,2.1,3.2,'#fff1c8');line(c,1,-4,1,2,'#fff5d8',.9);}
 line(c,-5,-5,5,-5,'#a48b63',1.4);line(c,-3,3,4,3,'#7c6a4f',1.3);c.restore();
}
export function beam(c,p,a,b,width=5){rod(c,p,a,b,'#4d514b',width+1.5);rod(c,p,[a[0],a[1],a[2]+1],[b[0],b[1],b[2]+1],'#9e8966',width*.58);}
export function ring(c,q,r,ink,tilt=.60){
 c.beginPath();c.ellipse(q[0],q[1],r,r*tilt,-.15,0,Math.PI*2);c.lineWidth=1.65;c.strokeStyle=ink;c.stroke();c.lineWidth=1;
}
export function sail(c,p,a,b,fall,ink,t,patch=false){
 const A=p(...a),B=p(...b),w=Math.sin(t*.64+a[0])*.85;
 const dx=B[0]-A[0],dy=B[1]-A[1],R=[B[0]+w+.9,B[1]+fall-2],L=[A[0]+w-2,A[1]+fall];
 c.beginPath();c.moveTo(...A);c.lineTo(...B);c.quadraticCurveTo(B[0]-3,B[1]+fall*.48,...R);c.quadraticCurveTo((R[0]+L[0])/2,(R[1]+L[1])/2+3,...L);c.quadraticCurveTo(A[0]+2,A[1]+fall*.52,...A);
 c.fillStyle=ink;c.fill();c.strokeStyle='#777c6d';c.lineWidth=.85;c.stroke();
 for(const k of [.17,.60,.81])line(c,A[0]+dx*k,A[1]+dy*k+1,A[0]+dx*k+w-1,A[1]+dy*k+fall-2,'#eee5c54e',1.05);
 if(patch)poly(c,[[A[0]+dx*.52,A[1]+dy*.52+7],[A[0]+dx*.72,A[1]+dy*.72+6],[A[0]+dx*.70+1,A[1]+dy*.70+14],[A[0]+dx*.51,A[1]+dy*.51+15]],'#a49278','#8d876f');
}
