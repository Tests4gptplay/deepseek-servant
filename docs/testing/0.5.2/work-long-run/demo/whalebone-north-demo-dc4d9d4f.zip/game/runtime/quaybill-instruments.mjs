import {poly,line,oval} from './heelturn-cabins.mjs';

export function quaybillInstrument(c,x,y,t,e,s){
 const key=e.action?.key;if(e.action?.type!=='quaybill'||!['basket','hull','sheet','desk','bed','flour','cast','freight'].includes(key))return false;
 const q=(u,v)=>[x+u,y+v],ink='#44535a',brown='#77593d',buff='#e7cb9a',blue='#466e83';
 const rec=s.progress?.quaybill;
 if(key==='hull'||key==='basket'){
  const hull=key==='hull',setting=rec?.[key],inside=setting?.inside;
  const px=inside?'#d3b582':'#8ba0a4';
  poly(c,[q(-14,-5),q(-3,-12),q(16,-6),q(7,0)],px,ink);
  for(let i=0;i<6;i++){const u=-10+i*3.5;line(c,[q(u,-5.5),q(u+(i<4&&inside?2.4:0),i<4&&inside?-8:-7)],hull?brown:(i<4?blue:'#bb8545'),1.4);}
  const z=setting?.level==='low'?-2:-8;line(c,[q(-12,z),q(6,z-4)],'#f5d184',2.1);
  if(hull&&s.tide==='high')line(c,[q(-15,-2),q(-4,0),q(14,-3)],'#a0bfc1',1.6);
 }else if(key==='sheet'||key==='desk'){
  poly(c,[q(-11,-1),q(1,-5),q(12,0),q(0,5)],brown,ink);
  poly(c,[q(-7,-4),q(0,-9),q(9,-6),q(3,-1),q(-1,-4)],buff,ink);
  for(let i=0;i<3;i++)line(c,[q(-2+i,-6+i),q(4+i,-7+i)],blue,.8);
 }else if(key==='flour'){for(let i=0;i<3;i++)oval(c,q(i*5-5,-2-Math.round(i/2)*3),5,4,'#bb915f',brown);}
 else if(key==='bed'){poly(c,[q(-11,-1),q(2,-8),q(12,-4),q(0,4)],'#a8aaa0',ink);line(c,[q(-9,0),q(-9,5)],brown,2);line(c,[q(9,-2),q(9,3)],brown,2);}
 else{line(c,[q(-4,2),q(-4,-10)],brown,3);oval(c,q(-4,-7),6,2,'#baae87',ink);}
 return true;
}
