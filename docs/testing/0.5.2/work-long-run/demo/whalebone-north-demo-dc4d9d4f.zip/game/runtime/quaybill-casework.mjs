import {hearBothSides,workAtObject} from './quaybill-samples.mjs';
import {billDesk,sellerVoice} from './quaybill-hearing.mjs';

function useLastBoat(api,key){
 const {c,show,note,mark}=api,posted=c.verdict==='posted';
 const offered=posted?'署名单可领两袋。若腾给病后的替班人，一袋要原地转给下船的脚夫，只剩另一袋能带。':'盲号留下两个人不用叫名的暖铺。若改装粮，晏家只能从私账赊出一袋，再多便要取消别家订粮。';
 if(c.cargo){note('已离坡的末驳','这趟带走'+c.cargo.bags+'袋白麦，暖铺上有'+c.cargo.people+'个人。到安全甲板上问他们下了船往哪去。');return;}
 if(key==='freight'){note('舱口只有一架平车',offered+' 沿左右车辙去推实物。解缆之前还能推回去。');return;}
 if(key==='bed'||key==='flour'){
  const bed=key==='bed',count=bed?(posted?1:0):(posted?2:1);
  show(bed?'接暖铺的左辙':'有粮袋的右辙',offered,[
   [bed?'推暖铺到舱前，给两人留位置':'把能领出的'+count+'袋推到舱前',()=>{
    c.load={kind:bed?'bed':'grain',bags:count,people:bed?2:0};
    note('平车已实推到舱口','当前正要带走'+count+'袋白麦、'+(bed?2:0)+'个暖铺人位。去系驳人眼下清点，或沿另一条辙改装。');
   }]]);return;
 }
 if(!c.load){note('系驳人庹英','车还是空的。先去看手上哪种票，再把暖铺或粮袋实推到这里。');return;}
 show('开驳之前的最后清点',c.load.bags+'袋白麦、'+c.load.people+'个暖铺人位。仓上的人会按这趟实载说话。',[
  ['核实实载，推离泊口',()=>{c.cargo={...c.load};mark('sailed');mark('load-'+(posted?'public':'quiet')+'-'+c.cargo.kind);note('末驳开出','庹英重复了一遍舱数，岑藕在岸上等到木轮离开为止。');}],
  ['松开推车，把这次实装撤回',()=>{c.load=null;note('空车回坡','麦袋和暖铺又各在自己的车辙旁。两条路都还来得及。');}]
 ]);
}

export function quaybillUse(ctx,e,close){
 const {ui,state,sync}=ctx,s=state.player,key=e.action.key;
 const show=(title,line,options=[],kind='quaybill',detail='')=>{
  sync();ui.show(kind,title,line,[...options,['收好手里的东西，离开',close]],detail);
 };
 const note=(title,line)=>show(title,line);
 if(key==='street'){
  const words=s.flags['quaybill-corrected']?'钉过晏家名字的孔还在，旁边另写了四袋随船、两袋转作夜班饭。':s.flags['quaybill-rumor']?'小孩把“晏甫截粮”念出声。真有亲见的人一直在隔两间的浴房。':'《栖鸥领麦六袋》照过真印，落地的车却只留下四对车印。湿纸廊就在市口的西绳头，原折页仍夹在里面。';
  note('短绳上的副单',words);return;
 }
 s.progress??={};const c=s.progress.quaybill??={round:1,material:{}};
 const mark=code=>{const flag='quaybill-'+code;if(!e.action.set.includes(flag))throw Error('未登记的取证结果 '+flag);s.flags[flag]=true;};
 const record=sample=>{c.material[sample]=c.round;mark('material');};
 const api={s,c,show,note,mark,record};
 if(key==='sheet'){mark('open');note('栖鸥，整六袋。两行同一道真印。','折纸上层说“栖鸥领麦六袋”。翻开湿角，下层只余个泊字和两根向岸的短划。晏甫担六袋的账，舟脚只认真正过舷的数。去比较能跟船走的磨口，或者追到浴房看袋里的热汽。');return;}
 if(!s.flags['quaybill-open']){note('东西还没有来历','回到五号栈湿纸廊，先翻看那张还粘在一块的原单。');return;}
 if(key==='hull'||key==='basket')workAtObject(api,key);
 else if(key==='runner'||key==='nurse')hearBothSides(api,key);
 else if(key==='desk')billDesk(api);
 else if(key==='seller')sellerVoice(api);
 else useLastBoat(api,key);
}
