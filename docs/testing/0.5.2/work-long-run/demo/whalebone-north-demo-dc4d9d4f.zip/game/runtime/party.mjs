import {nextXP,paths,relics,milestones} from '../rules/vocations.mjs';
// Story recruitment and persistent expedition stats. Actor definitions remain in world.actors.
const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
const num=(n,fallback)=>Number.isFinite(n)?n:fallback;
export function actorIds(world){return Object.keys(world.actors||{});}
export function stats(world,id,level=1){
 const def=world.actors[id],l=clamp(level,1,100),growth=def.growth||{};
 return {hp:Math.max(1,Math.floor(num(def.hp,25)+(l-1)*num(growth.hp,4))),mp:Math.max(0,Math.floor(num(def.mp,8)+(l-1)*num(growth.mp,1))),
  attack:Math.max(1,Math.floor(num(def.attack,5)+(l-1)*num(growth.attack,1))),defense:Math.max(0,Math.floor(num(def.defense,1)+(l-1)*num(growth.defense,.45)))};
}
export function syncParty(world,s){
 const ids=actorIds(world);const initial=world.party?.initial || [ids.includes('mara')?'mara':ids[0]].filter(Boolean);
 const old=s.expedition&&typeof s.expedition==='object'?s.expedition:{};
 const roster=Array.isArray(old.roster)?old.roster.filter(id=>ids.includes(id)):[];
 const heroes=old.heroes&&typeof old.heroes==='object'?old.heroes:{};
 for(const id of ids){
   const def=world.actors[id],gate=def.joinFlag||('party:'+id);
   const joined=initial.includes(id)||s.flags[gate]||(id==='ivo'&&(s.flags['event:coffin-hoist:ivo-watch']||s.flags['coffin-aboard']));
   if(joined&&!roster.includes(id))roster.push(id);
 }
 for(const id of roster){
  const d=world.actors[id],prev=heroes[id]||{},level=clamp(Math.trunc(num(prev.level,1)),1,100),max=stats(world,id,level);
  heroes[id]={level,xp:Math.max(0,Math.trunc(num(prev.xp,0))),hp:clamp(num(prev.hp,max.hp),0,max.hp),mp:clamp(num(prev.mp,max.mp),0,max.mp),
   weapon:typeof prev.weapon==='string'?prev.weapon:(d.weapon||'work-iron'),armor:typeof prev.armor==='string'?prev.armor:(d.armor||'canvas')};
  if(paths[id]?.choices.some(path=>path.id===prev.career))heroes[id].career=prev.career;
  if(typeof prev.charm==='string'&&(relics[prev.charm]||prev.charm==='deep-lens'||world.equipment?.[prev.charm]?.slot==='charm'))heroes[id].charm=prev.charm;
  if(prev.studies&&typeof prev.studies==='object'){
   const seen=Object.fromEntries(milestones.filter(([key])=>prev.studies[key]===true).map(([key])=>[key,true]));
   if(Object.keys(seen).length)heroes[id].studies=seen;
  }
 }
 s.expedition={...old,roster,heroes,stock:old.stock&&typeof old.stock==='object'?old.stock:{...{tonic:2,'work-iron':1,'rope-knife':1,canvas:1,'oilskin':1},...world.party?.stock}};
 return s.expedition;
}
export function addXP(world,id,hero,amount){
 hero.xp+=Math.max(0,Math.floor(amount));
 while(hero.level<100){
  const cost=world.actors[id]?.growth?.xpBase||16,needed=nextXP(cost,hero.level);
  if(hero.xp<needed)break;
  const from=stats(world,id,hero.level);hero.xp-=needed;hero.level++;
  const to=stats(world,id,hero.level);hero.hp+=to.hp-from.hp;hero.mp+=to.mp-from.mp;
 }
 if(hero.level===100)hero.xp=0;
}
