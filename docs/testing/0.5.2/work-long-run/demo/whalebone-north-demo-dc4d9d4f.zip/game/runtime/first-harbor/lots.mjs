// The names and footprints below are the original six neighborhoods' real lots.
export const plans={
 'wharf-scale':[
  ['殓棚','wake',54,19,'slate','lime'],['公秤房','scale',92,17,'copper','ochre'],['缉粮栈','store',86,20,'slate','stone']],
 'rope-market':[
  ['索铺','rope',83,19,'slate','earth'],['饭铺','soup',53,16,'clay','honey'],['合住长屋','balcony',91,18,'clay','lime'],
  ['晒布房','wash',54,13,'plank','lime'],['鱼税棚','fish',50,10,'copper','stone'],['机工宿舍','bunks',91,16,'slate','earth']],
 'lower-tide':[['排水站','pump',54,12,'copper','stone'],['旧闸房','sluice',83,14,'slate','lime']],
 'coffin-hoist':[['守台人的宿舍','guard',87,16,'clay','honey'],['拔索工棚','winch',55,13,'plank','earth']],
 'wake-court':[['染坊','dye',55,15,'slate','earth'],['摆灯人家','wick',87,15,'clay','honey'],['邻舍连檐','balcony',85,16,'slate','lime'],['港工宿舍','bunks',88,14,'clay','stone'],['老面铺','soup',52,14,'clay','honey'],['伙房','soup',53,13,'plank','lime'],['西槽水房','pump',51,10,'copper','stone']]
};
export const walls={lime:['#d3ceaf','#bebc9f','#9baf9d'],ochre:['#d8c298','#c8ae82','#a29576'],stone:['#b0b3a5','#969f96','#73857d'],honey:['#d5bb92','#cab28b','#a78d72'],earth:['#c9af94','#b29681','#897f73']};
export const roofs={slate:['#7b9692','#466c70','#4c6464','#9d9b80'],clay:['#b89b76','#aa7058','#825d4b','#c8a47a'],copper:['#98a695','#698d81','#516d64','#aeac85'],plank:['#a69170','#8c735b','#665f50','#ad987c']};
