import {poly,line,oval,arc,rand,seed} from './paint.mjs';
import {facade} from './facade.mjs';
import {business} from './trades.mjs';
import {tradeRoof} from './roofworks.mjs';
export function house(c,p,f){
  const w=f.w||2,h=f.h||2,x=f.x,y=f.y,key=seed(f.id||f.label||f.kind),high=(/殓|葬/.test(f.label||'')?22:/粮|仓/.test(f.label||'')?45:34)+Math.min(16,6*w)+rand(key)*7;
  const pos=(a,b,z=0)=>p(x+a,y+b,z);
  const a=pos(0,0),b=pos(w,0),d=pos(0,h),e=pos(w,h);
  const A=pos(0,0,high),B=pos(w,0,high),D=pos(0,h,high),E=pos(w,h,high);
  poly(c,[d,e,[e[0]+10,e[1]+2],[d[0]+13,d[1]+3]],'#54635f69');
  poly(c,[D,E,e,d],'#e4cd9f','#69766a');poly(c,[E,B,b,e],'#9b9f86','#67746d');
  for(let row=1;row<4;row++){const z=high*row/5;line(c,...pos(0,h,z),...pos(w,h,z),'#bfba96',.8);}
  const uprights=Math.max(2,Math.min(7,Math.round(w*1.5)));
  for(let i=0;i<=uprights;i++){const u=w*i/uprights;line(c,...pos(u,h),...pos(u,h,high),'#677a70',2.2);}
  const front=(u,v,ww,hh,color)=>poly(c,[pos(u,h,v),pos(u+ww,h,v),pos(u+ww,h,v+hh),pos(u,h,v+hh)],color);
  front(.12*w,0,Math.min(.56,w*.28),high*.59,'#586661');front(.15*w,1,Math.min(.39,w*.2),high*.54,'#384f51');
  for(let i=1;i<uprights;i++){const u=w*(i+.13)/uprights;front(u,high*.44,w*.48/uprights,high*.27,'#4b6262');front(u+.03,high*.47,w*.15/uprights,high*.2,'#e6bd7e');}
  const label=f.label||'',rise=/殓|葬/.test(label)?10:/粮|仓/.test(label)?27:/索|缆/.test(label)?14:19;
  const crest=[pos(-.15,h*.5,high+rise),pos(w+.15,h*.5,high+rise)];
  const roof=['#89574e','#926f57','#526d6d','#93735d'][Math.abs(key)%4];
  poly(c,[pos(-.14,-.1,high),pos(w+.14,-.1,high),crest[1],crest[0]],'#687c75','#54666a');
  poly(c,[crest[0],crest[1],pos(w+.14,h+.16,high-1),pos(-.14,h+.16,high-1)],roof,'#596864');
  for(let i=0;i<Math.min(16,3+w*2);i++){let u=w*i/(3+w*2);line(c,...pos(u,h*.52,high+rise-1),...pos(u,h+.13,high),'#d2b48c65',.8);}
  line(c,...crest[0],...crest[1],'#ded0a5',2);line(c,...D,...E,'#776a53',2);
  facade(c,f,pos,high,rise);business(c,f,pos,high);tradeRoof(c,f,pos,high,rise);
  if(w>1.5&&!/殓|葬|粮|仓|索|缆/.test(label)){const C=pos(w*.27,h*.72,high+rise*.65);c.fillStyle='#b7aa8b';c.fillRect(C[0]-3,C[1]-10,6,11);line(c,C[0]-5,C[1]-10,C[0]+5,C[1]-10,'#746d61',3);}
}
export function gate(c,x,y,scale=1){
  c.save();c.translate(x,y);c.scale(scale,scale);
  line(c,-26,4,-23,-55,'#5c5948',6);line(c,20,4,18,-68,'#505949',7);line(c,-25,-49,30,-65,'#5f5848',6);line(c,-22,-50,18,-33,'#9b7750',3);
  line(c,-25,-51,28,-67,'#d1ad78',2);arc(c,22,-64,5,0,Math.PI*2,'#d6bb83',2);
  line(c,25,-62,25,-28,'#454e4c',1.2);line(c,22,-62,-9,-32,'#53605b',1);
  poly(c,[[21,-29],[28,-29],[33,-15],[17,-15]],'#645d4e','#423f38');poly(c,[[18,-15],[32,-15],[32,-11],[18,-11]],'#b09360');
  arc(c,-18,-30,9,0,Math.PI*2,'#b38e59',3);for(let i=0;i<4;i++)line(c,-18,-30,-18+8*Math.cos(i*1.57),-30+8*Math.sin(i*1.57),'#735e43',2);
  c.restore();
}
