import {poly,line,oval,arc,seed} from './paint.mjs';
const palette=[['#995b48','#c8a27b'],['#557e7a','#d3bea0'],['#93805c','#e1c089'],['#695e70','#c59d83'],['#567483','#d5b49c']];
export function figure(c,x,y,id,t,opts={}){
  const key=Math.abs(seed(id)),hero=id==='mara',size=opts.scale||1;
  const team={'yellow-guest':['#8d7778','#bd9a7f'],'yellow-host':['#647f78','#b3896c'],yuanzi:['#99664f','#cda78a'],mara:['#314f55','#d6ad90'],ivo:['#714f45','#b78665'],selene:['#41777e','#bb896b'],mira:['#9e7447','#a47a61']};
  const [coat,skin]=team[id]||palette[key%palette.length];
  const child=/child|孩子|童/.test(id),s=size*(child?.77:1),step=opts.stride||0,dir=opts.flip?-1:1;
  c.save();c.translate(x,y);c.scale(s*dir,s);oval(c,1,1,9,3,'#38483952');
  const foot=Math.sin(step)*2.4,bob=step?Math.abs(Math.sin(step))*.9:0;c.translate(0,-bob);
  line(c,-3,-10,-3+foot,0,'#45504d',3);line(c,3,-10,4-foot,0,'#424540',3);line(c,-4+foot,0,-.4+foot,0,'#373b36',2);line(c,3-foot,0,6-foot,0,'#373b36',2);
  poly(c,[[-5,-22],[2,-24],[6,-20],[6,-12],[8,-7],[2,-5],[-7,-7],[-4,-15]],coat,'#344a48');
  if(hero){poly(c,[[-6,-23],[0,-25],[4,-21],[2,-16],[-3,-10],[-9,-7],[-7,-17]],'#283d45');poly(c,[[-6,-22],[-1,-24],[4,-21],[1,-19],[-6,-19]],'#aab8a9');line(c,3,-18,-3,-8,'#c1a573',1.4);}
  else if(id==='selene'||!team[id]&&key%3===0)poly(c,[[-5,-21],[2,-24],[5,-19],[1,-17],[-7,-15]],'#c9c4a3');
  else if(id==='ivo'||!team[id]&&key%3===1)arc(c,-4,-15,4,0,Math.PI*1.9,'#c0a477',1.5);
  line(c,4,-19,7,-13,coat,3);line(c,7,-13,6,-11,skin,2);
  oval(c,.5,-26,4.3,5,skin);poly(c,[[-5,-26],[-4,-31],[0,-32],[4,-31],[5,-28],[0,-29],[-3,-25]],hero?'#533f37':'#625246');
  if(hero){poly(c,[[-5,-28],[-3,-23],[-5,-17],[-7,-21]],'#503b36');line(c,-3,-24,1,-23,'#e4d9bc',1.3);}
  else if(id==='mira'||!team[id]&&key%4===0){poly(c,[[-7,-28],[-4,-31],[-2,-35],[3,-34],[5,-30],[8,-29]],'#8d7857');}
  if(id==='yellow-guest'){
    poly(c,[[-6,-31],[-3,-34],[3,-33],[6,-29],[2,-28],[-2,-29],[-6,-24]],'#c9c1a9');
    poly(c,[[-6,-22],[4,-22],[6,-20],[-2,-16],[-7,-18]],'#e3cc9c');
    line(c,8,-13,9,0,'#705e4a',1.8);
  }
  if(id==='yellow-host')poly(c,[[-6,-21],[4,-22],[3,-17],[-5,-10],[-7,-13]],'#c9ad82');
  if(id==='yuanzi'){
    poly(c,[[-6,-26],[-5,-31],[-1,-33],[4,-32],[6,-29],[3,-28],[-2,-30]],'#72898c');
    poly(c,[[-6,-22],[3,-23],[6,-20],[1,-18],[-6,-19]],'#d9ca9b');
    line(c,-5,-18,-3,-10,'#d3bd80',1.8);arc(c,8,-13,3.8,Math.PI,Math.PI*2,'#3d504c',1.6);
    poly(c,[[4,-12],[11,-12],[10,-5],[5,-5]],'#edc77c','#4c5248');line(c,7,-11,7,-6,'#fff1b5',1.8);
  }
  if(id==='selene'){line(c,7,-4,10,-36,'#716957',2);oval(c,10,-36,2.8,3.3,'#b0ddd2');}
  if(id==='mira'){line(c,6,-10,10,-22,'#5b4d3f',2);arc(c,8,-17,5,-1.2,1.5,'#d1b881',1.5);}
  oval(c,2.8,-26.7,.72,.72,'#443d36');line(c,3.9,-25.3,5.1,-25,'#a17b62',.8);line(c,1.2,-24,3.0,-23.7,'#b18a6e',.65);
  if(hero){line(c,-8,-9,-10,-27,'#72654f',2.4);poly(c,[[-13,-29],[-7,-32],[-5,-28],[-11,-26]],'#87928b','#424e4b');line(c,-4,-12,3,-14,'#ceb48c',1.6);}
  else if(id==='ivo'){poly(c,[[-7,-20],[-9,-24],[-4,-25],[1,-21],[-1,-18]],'#536771','#48534e');arc(c,-6,-12,5,0,5.9,'#d4b27a',1.75);arc(c,-6,-12,3,0,5.8,'#ae8c61',1.2);line(c,6,-15,11,-27,'#827059',2);arc(c,11,-29,3,.1,3.4,'#a7ad96',1.7);}
  else if(id==='selene'){poly(c,[[-5,-18],[-7,-7],[-11,-3],[-4,-3],[1,-8],[4,-7],[7,-5],[4,-16]],'#488383','#476967');line(c,-4,-16,-7,-5,'#b8c4a1',1.3);poly(c,[[-4,-31],[0,-34],[5,-30],[2,-29]],'#739898');}
  else if(id==='mira'){poly(c,[[-7,-16],[-2,-20],[2,-15],[-3,-7],[-8,-10]],'#ac8255','#695c4b');poly(c,[[-5,-16],[-2,-18],[0,-15],[-4,-11]],'#d6c49a');line(c,-4,-15,-2,-15,'#758c80',1);line(c,7,-14,13,-19,'#766047',2);}
  else if(/knitter|widow|mender|steward|grief|tenant|hatter|tender|runner|sister/.test(id)){
   const textiles=/knitter|mender|widow/.test(id),pot=/tender|steward/.test(id);poly(c,[[-5,-21],[2,-21],[4,-10],[-5,-8]],pot?'#b9b5a0':textiles?'#aa8876':'#8e9b87');line(c,-4,-15,4,-17,'#d6be94',1.2);
   if(textiles){oval(c,-7,-13,3.2,2.9,'#a58066');line(c,-10,-12,-5,-18,'#c9c4a6',1);}
   if(pot){line(c,6,-12,9,-23,'#bbad8b',1.5);oval(c,9,-24,2.3,2,'#949d89');}
  }
  if(opts.mark){const j=Math.sin(t*2.1)*1.2;poly(c,[[-3,-39+j],[0,-43+j],[3,-39+j],[0,-36+j]],'#f5d291','#7e7152');}
  c.restore();
}
export function creature(c,x,y,t,color='#9b624e'){
  c.save();c.translate(x,y);oval(c,0,3,19,4,'#3e524c55');const f=Math.sin(t*3)*2;
  for(const d of [-1,1]){for(let i=0;i<3;i++){line(c,d*(6+i*1.8),-6,d*(12+i*3),-1+f,'#584e40',2);line(c,d*(12+i*3),-1+f,d*(15+i*3),3,'#675948',2);}}
  poly(c,[[-13,-5],[-10,-15],[-4,-18],[7,-18],[13,-12],[14,-7],[6,-3],[-5,-3]],color,'#584f46');for(const d of [-1,1]){line(c,d*7,-13,d*9,-20,'#645a4c',2);oval(c,d*9,-20,2,1.8,'#eace93');}
  line(c,-6,-15,6,-16,'#c99366',1.6);c.restore();
}
