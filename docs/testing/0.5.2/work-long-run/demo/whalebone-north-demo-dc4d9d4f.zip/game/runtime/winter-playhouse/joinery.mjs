import {poly,line,oval} from '../paint.mjs';
export {poly,line,oval};
export function patch(c,p,points,fill,edge){
 poly(c,points.map(([x,y,z=0])=>p(x,y,z)),fill,edge);
}
export function timber(c,p,a,b,color,width=3){
 const x=p(...a),y=p(...b);line(c,...x,...y,color,width);
}
export function face(c,p,x,y,draw){
 const [a,b]=p(x,y),[u,v]=p(x+1,y);
 c.save();c.transform((u-a)/31,(v-b)/31,0,1,a,b);draw();c.restore();
}
export function arch(c,x,floor,w,h,paint){
 c.beginPath();c.moveTo(x,floor);c.lineTo(x,floor-h+w*.46);c.bezierCurveTo(x,floor-h-w*.16,x+w,floor-h-w*.16,x+w,floor-h+w*.46);
 c.lineTo(x+w,floor);c.closePath();c.fillStyle=paint;c.fill();
}
export function chair(c,x,y,height,tone='#916d47'){
 c.save();c.translate(x,y);poly(c,[[-10,-height],[1,-height-3],[10,-height],[1,-height+4]],'#c9a66f','#624e3d');
 for(const [px,py] of [[-9,0],[1,4],[9,0]])line(c,px,-height+py,px,py,tone,2.5);
 line(c,-8,-height,-8,-height-13,tone,2.4);line(c,2,-height-3,2,-height-16,tone,2.4);
 line(c,-8,-height-10,2,-height-13,tone,3);c.restore();
}
