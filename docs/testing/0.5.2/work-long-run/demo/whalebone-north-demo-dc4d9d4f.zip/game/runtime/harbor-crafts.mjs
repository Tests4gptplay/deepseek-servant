import {arc,line,oval,poly} from './paint.mjs';
import {box,plate,wood} from './voyage-shapes.mjs';

const brick=['#c08c68','#925e50','#6d4d47'];
const slate=['#a3b0a2','#71857d','#526660'];
const straw=['#d6ba83','#ab8c62','#876a4c'];

export function bakehouse(c,p,x,y,fired=true,t=0){
  box(c,p,x-1.03,y-.72,2.08,1.45,0,15,brick);
  const [a,b]=p(x,y+.45,14);
  c.save();c.translate(a,b);
  c.beginPath();c.moveTo(-37,4);c.bezierCurveTo(-40,-30,-20,-39,-7,-40);
  c.bezierCurveTo(16,-47,36,-29,38,-4);c.closePath();
  const dome=c.createLinearGradient(-22,-36,27,5);dome.addColorStop(0,'#d6b08a');dome.addColorStop(.55,'#b47e64');dome.addColorStop(1,'#83584c');c.fillStyle=dome;c.fill();c.strokeStyle='#73564b';c.stroke();
  for(const [yy,ww] of [[-7,33],[-15,31],[-23,26],[-31,20]]){line(c,-ww,yy,ww,yy-4,'#916953',1.3);for(let k=-ww+8;k<ww;k+=12)line(c,k,yy,k+2,yy-6,'#987158',1);}
  c.beginPath();c.moveTo(-21,4);c.bezierCurveTo(-22,-25,11,-30,14,0);c.closePath();c.fillStyle='#473e39';c.fill();c.strokeStyle='#d9b185';c.lineWidth=3;c.stroke();c.lineWidth=1;
  if(fired){const glow=c.createRadialGradient(-4,-5,0,-4,-5,24);glow.addColorStop(0,'#f7bf58');glow.addColorStop(1,'#e5783700');oval(c,-4,-6,22,12,glow);for(let i=0;i<4;i++){let px=-13+i*6;poly(c,[[px,0],[px-1,-6],[px+3,-12-Math.sin(t*4+i)*3],[px+4,-4],[px+7,-7],[px+5,-1]],i%2?'#eaa24e':'#faD17c');}}
  line(c,-23,6,17,1,'#c79b76',3);c.restore();
  const peel=p(x+.46,y+1.1,7);line(c,...peel,...p(x+1.55,y+1.1,1),'#8b694e',3);oval(c,...peel,8,4,'#bc976b');
}
export function servingWindow(c,p,x,y,width=1.9,latch=false,high=false){
  const sill=high?28:12, top=sill+20;
  poly(c,[p(x,y,2),p(x+width,y,2),p(x+width,y,top+5),p(x,y,top+5)],'#acaa91','#676c5d');
  poly(c,[p(x+.12,y,sill),p(x+width-.12,y,sill),p(x+width-.12,y,top),p(x+.12,y,top)],'#49615e','#d5c396');
  for(let q=.16;q<width;q+=.35)line(c,...p(x+q,y,2),...p(x+q,y,sill-2),'#828c79',1);
  line(c,...p(x,y,sill),...p(x+width+.08,y,sill),'#dac297',3);
  const hinge=x+width*.54;
  if(latch){
    poly(c,[p(hinge,y,sill),p(hinge+.17,y+.65,sill),p(hinge+.17,y+.65,top),p(hinge,y,top)],'#b49472','#685c50');
    line(c,...p(hinge+.1,y+.29,sill+8),...p(hinge+.2,y+.62,sill+9),'#d1a761',3);
  }else{
    poly(c,[p(hinge,y,sill),p(x+width-.14,y,sill),p(x+width-.14,y,top),p(hinge,y,top)],'#a68c70','#60594e');
    line(c,...p(hinge-.07,y+.03,sill+8),...p(hinge+.44,y+.03,sill+8),'#d0ad72',3);
  }
}
export function washRun(c,p,x,y,high,tide,t=0){
  const z=high?15:2;
  for(const xx of [0,1.6])for(const yy of [0,.73])line(c,...p(x+xx,y+yy),...p(x+xx,y+yy,z+7),'#756958',3);
  box(c,p,x,y,1.7,.84,z,7,slate);
  plate(c,p,x+.12,y+.11,1.45,.60,z+7.3,tide==='high'?'#76aaa6':'#647f77');
  for(let k=0;k<3;k++)line(c,...p(x+.21+k*.34,y+.32,z+8),...p(x+.40+k*.34,y+.31+Math.sin(t+k)*.035,z+8),'#d5e2c8',1.3);
  for(let i=0;i<5;i++)line(c,...p(x+1.1+i*.10,y+.12,z+7.7),...p(x+1.1+i*.10,y+.69,z+7.7),'#a6987d',1.8);
}
export function coalRack(c,p,x,y,bread=false){
  box(c,p,x,y,1.8,.81,0,7,wood);
  if(bread){for(let i=0;i<6;i++){const q=p(x+.29+(i%3)*.53,y+.25+Math.floor(i/3)*.33,9);oval(c,...q,9,4,'#c89b66');line(c,q[0]-3,q[1]-2,q[0]+1,q[1]-1,'#ebcc92',1.3);}}
  else for(let j=0;j<13;j++){const q=p(x+.2+(j%5)*.31,y+.2+(Math.floor(j/5)%2)*.42,10+Math.floor(j/10)*5);poly(c,[[q[0]-5,q[1]],[q[0]-3,q[1]-5],[q[0]+3,q[1]-6],[q[0]+6,q[1]-2],[q[0]+3,q[1]+1]],j%2?'#464746':'#575653','#3f4444');}
}
export function handcart(c,p,x,y,withCoal){
  for(const dy of [-.03,.83]){let [a,b]=p(x+.91,y+dy,5);oval(c,a,b,8,10,'#514b44');arc(c,a,b,7,0,Math.PI*2,'#b6926b',1.8);line(c,a-5,b-5,a+5,b+5,'#b6926b',1.4);}
  box(c,p,x,y,1.6,.80,7,5,wood);for(const d of [.12,.68])line(c,...p(x+1.35,y+d,10),...p(x+2.24,y+d,18),'#876348',3);
  if(withCoal)coalRack(c,(a,b,z=0)=>p(a,b,z+13),x-.08,y+.02,false);
}
export function skiff(c,p,x,y,tide,t=0,loaded=false){
  const [a,b]=p(x,y,tide==='high'?8:1);c.save();c.translate(a,b+Math.sin(t*1.3+x)*1.2);
  oval(c,1,6,44,8,'#436e7055');poly(c,[[-43,-5],[-24,-4],[12,-12],[40,-19],[30,-4],[6,5],[-24,9]],'#795c50','#4b5351');
  poly(c,[[-43,-5],[-18,-14],[40,-19],[24,-10],[-17,1]],'#c29e73','#786850');
  poly(c,[[-31,-5],[-15,-11],[26,-15],[14,-10],[-16,-2]],'#50605a');
  for(const w of [-17,1,15])line(c,w-3,-7-w*.12,w+8,-2-w*.12,'#c0a17d',2.3);
  line(c,-14,-16,12,4,'#b79972',2);poly(c,[[8,1],[14,0],[24,6],[20,8]],'#c2a376');if(loaded){oval(c,-13,-9,6,3,'#e0d1a6');oval(c,-4,-11,5,2.6,'#9cad98');}c.restore();
}
export function seedBed(c,p,x,y,grown=false){
  box(c,p,x,y,1.85,.84,0,6,straw);plate(c,p,x+.09,y+.08,1.67,.66,6.4,'#756554');
  for(let n=0;n<9;n++){const [a,b]=p(x+.21+(n%5)*.32,y+.22+Math.floor(n/5)*.31,7);if(grown){line(c,a,b,a-1,b-6,'#596a4f',1.3);oval(c,a-3,b-5,3.3,1.6,'#8eae70');oval(c,a+1.8,b-7,3,1.5,'#b1c588');}else oval(c,a,b,2.1,1.1,'#caa477');}
}
