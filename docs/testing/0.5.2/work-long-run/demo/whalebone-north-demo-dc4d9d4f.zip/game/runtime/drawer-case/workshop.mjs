import {line,oval,poly,arc} from '../paint.mjs';
import {box,plate} from '../voyage-shapes.mjs';

const wood=['#bc9b68','#896443','#664938'];
const blue=['#648d93','#426d79','#294e5c'];
const iron='#3d5555';
const join=(c,p,a,b,fill,w=1)=>line(c,...p(...a),...p(...b),fill,w);

export function cabinet(c,p,x,y,bottom=11,count=12,open=false){
 const wide=count===12?2.3:1.8,deep=.7,tall=count===12?31:22,columns=count===12?4:3,rows=count/columns;
 box(c,p,x,y,wide,deep,bottom,tall,blue);
 for(let j=0;j<rows;j++)for(let i=0;i<columns;i++){
   const u=x+.055+i*(wide-.11)/columns,v=u+(wide-.11)/columns-.025;
   const z=bottom+1.3+j*(tall-2.6)/rows,h=z+(tall-2.6)/rows-1.4;
   const pulled=open&&i===0&&j===rows-1?.11:0,front=y+deep+pulled;
   poly(c,[p(u,front,z),p(v,front,z),p(v,front,h),p(u,front,h)],(i+j)%3===0?'#659097':'#527e88','#315661');
   const a=p((u+v)/2,front,h-2);oval(c,...a,1.7,1.1,'#deb676');
 }
 for(const u of [x+.05,x+wide-.05])join(c,p,[u,y+deep,bottom],[u,y+deep,bottom+tall],'#b99964',1.5);
 plate(c,p,x-.045,y-.04,wide+.09,deep+.08,bottom+tall+1,'#71969a','#3c626a');
 if(open){const a=p(x+.36,y+.5,bottom+tall+1);oval(c,...a,4.8,2.2,'#bea776');}
}
export function shortWheels(c,p,x,y,loaded=true){
 const deep=.83,wide=2.42;
 for(const [u,v] of [[.18,.05],[.18,.8],[2.21,.8]]){
  const [a,b]=p(x+u,y+v,4);
  c.save();c.translate(a,b);c.rotate(-.14);oval(c,0,0,5,4.6,'#4c4439');oval(c,0,-.4,3,3.1,'#ba9c68');oval(c,0,0,1.1,1.1,iron);c.restore();
 }
 box(c,p,x,y,wide,deep,6,3.5,wood);
 if(loaded)cabinet(c,p,x+.08,y+.045,10,12,true);
 join(c,p,[x+wide-.05,y+.15,10],[x+wide+.44,y+.15,17],'#795b40',2.3);
}
function mill(c,p,x,y){
 const [a,b]=p(x+.4,y+.5);
 oval(c,a,b+3,28,10,'#574e466b');oval(c,a,b-2,23,10,'#646a65');
 c.fillStyle='#7a8078';c.fillRect(a-23,b-12,46,11);oval(c,a,b-12,23,10,'#adb0a3');
 arc(c,a-2,b-12,7.3,.2,4.3,'#626960',2.4);
 line(c,a+3,b-11,a+29,b-20,'#68533d',3.2);oval(c,a+29,b-20,3,2,'#a58456');
 for(let i=0;i<10;i++)oval(c,a-15+(i*13)%28,b-16+(i*7)%10,1.2,.6,'#c7a56c');
}
function marks(c,p,x,y){
 for(let i=0;i<3;i++){
  const u=x+.2+i*.2,v=y+.3+i*.31;
  join(c,p,[u,v,.8],[u+2.6,v,.8],i===1?'#635545':'#816b50',2);
  join(c,p,[u+.08,v+.05,1],[u+2.55,v+.05,1],'#c9ae7b',.8);
 }
 const [a,b]=p(x+1.05,y+.1);arc(c,a,b,7,.5,4,'#b9aa91',1.5);
}
export function workshopProp(c,p,f,s){
 const {x,y}=f,flags=s.flags;
 if(f.id==='drawer-three-tracks'){marks(c,p,x,y);shortWheels(c,p,x+(flags['drawer-land-pass']?2.1:1.25),y-.18,!!flags['drawer-land-mode']);return true;}
 if(f.id==='drawer-stone-root'){mill(c,p,x,y);return true;}
 if(f.id==='drawer-blue-front'){
  if(flags['drawer-shop-back']||(!flags['drawer-water-mode']&&!flags['drawer-land-mode']&&!flags['drawer-settled']))cabinet(c,p,x-.45,y-.1,1,12,true);
  else{plate(c,p,x-.4,y,1.85,.75,1,'#9a8268','#685645');join(c,p,[x-.12,y+.3,1],[x+1.1,y+.3,1],'#436e77',2);}
  return true;
 }
 if(f.id==='drawer-outer-six'||f.id==='drawer-inner-six'){
  box(c,p,x+.12,y-.18,2.44,1,0,10,wood);
  if(flags['drawer-shop-back']&&f.id==='drawer-outer-six'){
   box(c,p,x+.14,y-.16,2.4,.94,10,5,['#d0b481','#ad8a5b','#876847']);
   for(let i=0;i<5;i++)box(c,p,x+.3+i*.42,y-.1,.055,.78,15,6,wood);
  }else cabinet(c,p,x+.28,y-.12,10,6,f.id==='drawer-outer-six');
  return true;
 }
 return false;
}
