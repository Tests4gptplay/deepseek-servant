import {face,rod,beam,box,plate,lamp,ring,oval,poly,sail,hanging,oak,tar,brass} from './fixtures.mjs';
export function hem(c,p,s,t){
 const seen=!!s.flags['salt-survivors'],x=7.62,y=5.62;
 for(const a of [x,x+2.36])beam(c,p,[a,y,0],[a,y,35],3.6);
 beam(c,p,[x-.12,y,35],[x+2.46,y,35],4.4);
 sail(c,p,[x+.10,y,33],[x+2.23,y,33],seen?29:21,'#c7bb94',t,true);
 const a=p(x+.27,y,seen?23:22),b=p(x+1.47,y,seen?23:22),dx=b[0]-a[0],dy=b[1]-a[1];
 for(let i=0;i<9;i++){const k=i/8,px=a[0]+dx*k,py=a[1]+dy*k;rod(c,(u,v)=>[u,v],[px-1.6,py+3],[px+1.8,py-2],i%2?'#586b61':'#776d51',1.4);}
 for(const k of [1.65,2.04]){const q=p(x+k,y,seen?18:23);oval(c,...q,4.8,3.6,'#dcd3af');ring(c,q,2.1,'#a29671',.83);}
 if(seen){sail(c,p,[x+.36,y+.06,13],[x+1.15,y+.06,13],10,'#a89676',t);rod(c,p,[x+.33,y+.08,11],[x+1.22,y+.08,11],'#e7dfbe',1.5);}
}
export function ribDeck(c,p,s,t){
 for(const i of [3,8,13,18,23,27]){const y=2.35;face(c,p,[[i-.22,y,0],[i+.15,y,1],[i+.74,y-1.47,11],[i+.94,y-2.02,16],[i+.72,y-2.09,15],[i+.52,y-1.43,9]],'#96a094','#697f78');}
 for(const k of [.15,.77])rod(c,p,[5,7+k,1],[24.9,7+k,1],'#877c65',1.5);
 for(const i of [5,10,15,20,24]){const q=p(i,7.54,1);oval(c,...q,1.5,1.08,'#cec29c');}
 for(let j=0;j<6;j++){const x=24.25+j*.20,y=12.11+j*.4;box(c,p,x,y,1.22,.38,-4+j*.60,2.5,oak);}
 for(const y of [12.18,14.84]){beam(c,p,[25.54,y,0],[25.54,y,19],3.5);ring(c,p(25.54,y,16),3,'#baab80');}
 hanging(c,p,[25.54,12.18,18],[25.54,14.84,18],4,'#c6b58e',2);
 lamp(c,p,25.54,12.18,16,t,true,.73);
}
export function lash(c,p,s,t){
 const x=20.85,y=11.88;for(let j=0;j<4;j++){const xx=x+j*.2;rod(c,p,[xx,y,0],[xx,y+.96,0],j===1?'#e3cf9f':'#8a7b62',2);}
 if(s.flags['ward-skiff-ready']){beam(c,p,[x+.83,y+.16,0],[x+.83,y+.16,13],3.4);sail(c,p,[x+.83,y+.14,13],[x+1.34,y+.14,13],7,'#ddd4ba',t);lamp(c,p,x+.8,y+.16,10,t,true,.52);}
}
export function roomWork(c,p,map,s,t,add){
 if(map.id==='dry-court'){
  for(const [x,y,w] of [[6.4,8.17,4.1],[16.65,8.2,2.48]])add(x+y+w*.55,()=>{beam(c,p,[x,y,0],[x,y,23],3);beam(c,p,[x+w,y,0],[x+w,y,23],3);hanging(c,p,[x,y,23],[x+w,y,23],4,'#a99b75',1.65);for(let j=0;j<3;j++)sail(c,p,[x+.16+j*(w/3),y,21],[x+.69+j*(w/3),y,20],13-j*.8,['#c8bda4','#a1aaa0','#d3b8a1'][j],t,j===1);});
 }
 if(map.id==='whale-roofs'){
  for(const [x,y,z] of [[17.5,10.68,12],[22.4,11.03,17],[26.05,15.4,13]])add(x+y,()=>{beam(c,p,[x,y,0],[x,y,z],3);lamp(c,p,x,y,z,t,true,.64);});
  add(40.4,()=>{const x=24.95,y=15.46;box(c,p,x,y,1.68,.77,0,8,tar);sail(c,p,[x+.12,y+.79,9],[x+.86,y+.79,9],7,'#c6b69a',t,true);});
 }
}