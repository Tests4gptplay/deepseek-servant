import {poly,line,oval,arc} from './paint.mjs';
import {box,plate} from './voyage-shapes.mjs';

export const timber=['#ceb28c','#977659','#584a40'];
export const seawall=['#748588','#4d6269','#344c53'];
export function stroke(c,p,a,b,color,width=1){line(c,...p(...a),...p(...b),color,width);}
export function add(queue,x,y,fn){queue.push([x+y,fn]);}
export function flare(c,x,y,r,color){
 const gradient=c.createRadialGradient(x,y,1,x,y,r);gradient.addColorStop(0,color);gradient.addColorStop(1,'rgba(246,177,87,0)');
 c.fillStyle=gradient;c.fillRect(x-r,y-r,2*r,2*r);
}
export function lantern(c,x,y,high=30,wet=false,t=0){
 const dark='#3d4141',rim='#b48054',glass='#ffe1a1';
 line(c,x,y,x,y-high-9,dark,3);line(c,x-1,y-high-8,x+9,y-high-8,rim,2);
 const a=x+8,b=y-high;flare(c,a,b,36+Math.sin(t*2+a)*1.4,'rgba(255,181,88,.31)');
 poly(c,[[a-5,b-3],[a+5,b-3],[a+4,b+6],[a-3,b+6]],glass,rim);
 poly(c,[[a-7,b-4],[a,b-9],[a+6,b-3]],dark);line(c,a-3,b+7,a+4,b+7,dark,2);line(c,a,b-2,a,b+6,'#cf8f4e',1);
 if(wet){for(let i=0;i<6;i++){const dx=Math.sin(t+i*1.7)*3;line(c,x-4+dx,y+4+i*2,x+10+dx,y+4+i*2,i%2?'#c39668':'#8d8771',1.25);}}
}
export function nightSky(c,w,h,winter){
 const g=c.createLinearGradient(0,0,0,h);g.addColorStop(0,winter?'#233547':'#132537');g.addColorStop(.43,winter?'#779197':'#536878');g.addColorStop(1,winter?'#9db0a4':'#354c5a');c.fillStyle=g;c.fillRect(0,0,w,h);
 for(let i=0;i<18;i++){const x=(i*.237%1)*w,y=((i*43%97)/97)*h*.27;oval(c,x,y,i%4===0?1.2:.7,.7,'#cccfbf');}
 const horizon=h*.29;for(let layer=0;layer<2;layer++){const pts=[[0,horizon+58]];for(let i=0;i<=14;i++){const x=i*w/14,peak=Math.sin(i*1.4+layer)*14+Math.cos(i*.8+2)*13;pts.push([x,horizon+layer*24+peak]);}pts.push([w,horizon+62],[0,horizon+62]);poly(c,pts,layer?'#5b7279':'#607884');}
}
export function surface(c,p,x,y,w,h,wet,t,winter=false){
 const ground=wet?(winter?'#557d80':'#345860'):(winter?'#9baca1':'#777a72');
 plate(c,p,x,y,w,h,0,ground,wet?'#486c70':'#879184');
 const step=wet?1.7:1.18;
 for(let row=0;row<h;row+=step){let ix=0;for(let col=.2+(Math.round(row*2)%2)*.39;col<w-.35;col+=1.7,ix++){
  const qx=x+col,qy=y+row+.23,seed=Math.cos((ix+1)*4.1+row*2.3),length=(wet?.35:.65)+.21*seed;
  if(wet){const [a,b]=p(qx,qy);line(c,a-6+seed*3,b,a+6+Math.sin(t*1.4+ix+row)*3,b+.25,ix%3?'#63878a':'#9cb7ac',.95);}
  else{stroke(c,p,[qx,qy],[qx+length,qy],winter?'#bbc4b6':'#969686',1);stroke(c,p,[qx+length,qy],[qx+length,qy+.26],'#687b77',.8);}
 }}
}
export function board(c,p,x,y,w,h,z=0,wet=false){
 box(c,p,x,y,w,h,z,3,wet?['#8c9484','#616e65','#515c59']:timber);
 for(let i=.23;i<w;i+=.51){stroke(c,p,[x+i,y,z+3.3],[x+i,y+h,z+3.3],wet?'#596f69':'#806850',1.05);
  for(const k of [.13,Math.max(.15,h-.13)]){const a=p(x+i-.1,y+k,z+3.7);oval(c,...a,1.15,.75,'#5f5950');}}
}
export function steps(c,p,x,y,count,across=1.8){
 for(let i=0;i<count;i++){const z=i*2.6;box(c,p,x+i*.30,y,.36,across,0,z+2.5,seawall);stroke(c,p,[x+i*.30,y,z+2.8],[x+i*.30,y+across,z+2.8],'#a3aea0',1.4);}
}
export function cottage(c,p,x,y,w,d,options={}){
 const {h=46,door=.18,window=.65,open=false,lit=true,roof='#657b7b',wall='#bbac8b'}=options;
 const z=4,fy=y+d,wallFace=[p(x,fy,z),p(x+w,fy,z),p(x+w,fy,z+h),p(x,fy,z+h)];
 box(c,p,x,y,w,d,0,z,seawall);poly(c,wallFace,wall,'#59615a');
 poly(c,[p(x+w,y,z),p(x+w,fy,z),p(x+w,fy,z+h),p(x+w,y,z+h)],'#716f63','#475755');
 for(let i=.07;i<w;i+=.56){stroke(c,p,[x+i,fy,z],[x+i,fy,z+h],'#887f6b',i<.1?3:1);}
 for(let j=.12;j<d;j+=.48)stroke(c,p,[x+w,y+j,z+2],[x+w,y+j,z+h-1],'#848174',1);
 for(const xx of [x+.1,x+w-.12])stroke(c,p,[xx,fy,z],[xx,fy,z+h+1],'#63574a',3.8);
 const dx=x+w*door,dy=fy+.018,dw=Math.min(.74,w*.24);
 const doorway=[p(dx,dy,z+.6),p(dx+dw,dy,z+.6),p(dx+dw,dy,z+32),p(dx,dy,z+32)];
 poly(c,doorway,open?'#263e40':'#7c6250','#4a4942');stroke(c,p,[dx-.04,dy,z+34],[dx+dw+.05,dy,z+34],'#d3ae82',3);
 if(open){const inner=p(dx+dw*.63,dy,z+14);line(c,inner[0]-5,inner[1]+7,inner[0]-5,inner[1]-7,'#655f4b',2);line(c,inner[0]-5,inner[1]-7,inner[0]+3,inner[1]-5,'#c49669',2);}
 if(open){poly(c,[p(dx,dy,z+1),p(dx+.05,dy,z+31),p(dx-.38,dy+.28,z+29),p(dx-.38,dy+.28,z+2)],'#94765b','#5b574e');}
 else{for(let j=1;j<=3;j++)stroke(c,p,[dx+dw*j/4,dy,z+1],[dx+dw*j/4,dy,z+31],'#a28a6b',1);const k=p(dx+dw*.8,dy,z+14);oval(c,...k,1.9,1.5,'#e0bf78');}
 const wx=x+w*window,ww=Math.min(.85,w*.23),wy=dy+.018;
 const wwpts=[p(wx,wy,z+14),p(wx+ww,wy,z+14),p(wx+ww,wy,z+32),p(wx,wy,z+32)];
 poly(c,wwpts,lit?'#f1bf79':'#718d8b','#5c5146');stroke(c,p,[wx+ww/2,wy,z+15],[wx+ww/2,wy,z+32],'#655f53',2);
 stroke(c,p,[wx,wy,z+23],[wx+ww,wy,z+23],'#786958',1.8);stroke(c,p,[wx-.08,wy,z+13],[wx+ww+.08,wy,z+13],'#d4bc99',3);
 const e=.16,mid=y+d*.48,rise=19;
 poly(c,[p(x-e,y-e,z+h),p(x+w+e,y-e,z+h),p(x+w+e,mid,z+h+rise),p(x-e,mid,z+h+rise)],'#667d7a','#485c5c');
 poly(c,[p(x-e,mid,z+h+rise),p(x+w+e,mid,z+h+rise),p(x+w+e,fy+e,z+h),p(x-e,fy+e,z+h)],roof,'#495d5b');
 for(let xx=x;xx<x+w;xx+=.47)stroke(c,p,[xx,mid,z+h+rise],[xx+.09,fy+e,z+h+1],'#82918b',1);
 stroke(c,p,[x-e,fy+e,z+h-1],[x+w+e,fy+e,z+h-1],'#463f39',3);
 for(let j=0;j<3;j++){const a=p(x+w*.46,fy+.045,z+h-5-j*4);line(c,a[0]-2,a[1],a[0]+4,a[1]+1,'#a29477',1);}
 box(c,p,x+w*.70,y+d*.28,.29,.31,z+h+8,15,['#b4a78a','#897c68','#6c7060']);
}
export function quayEdge(c,p,x,y,w){
 for(let k=0;k<w;k+=.84){
  const span=Math.min(.80,w-k);box(c,p,x+k,y,span,.37,-4,6,['#a7a797','#7d8276','#637474']);
  stroke(c,p,[x+k+.05,y+.35,2.3],[x+k+span-.03,y+.35,2.3],'#c1bd9e',1);
 }
}
export function dryingRack(c,p,x,y,span,fish=true){
 for(const k of [0,span])stroke(c,p,[x+k,y],[x+k,y,30],'#6f5c45',2.8);
 stroke(c,p,[x,y,29],[x+span,y,28],'#cab087',1.3);
 for(let i=0;i<5;i++){
  const [a,b]=p(x+span*(.14+i*.17),y,27-i%2*1.5);
  if(fish){line(c,a,b,a-1,b+5,'#705f48',1);poly(c,[[a-1,b+4],[a+2,b+7],[a,b+13],[a-2,b+15],[a-4,b+10]],i%2?'#c6ae83':'#8ba59a','#727c6e');}
  else{const w=3.5+i%2;poly(c,[[a-w,b+1],[a+w,b+2],[a+w-1,b+13],[a-w-2,b+12]],i%2?'#a36e59':'#b8ae94','#7d776a');}
 }
}
export function coop(c,p,x,y){
 const [a,b]=p(x,y);oval(c,a,b,8,3,'#4b5c52');poly(c,[[a-6,b-11],[a+6,b-11],[a+5,b-1],[a-5,b-1]],'#ac805d','#6a5847');
 oval(c,a,b-11,6,2.4,'#887254');for(const [dx,dy]of [[-5,-19],[-2,-23],[1,-23],[4,-19],[6,-18]]){line(c,a,b-10,a+dx,b+dy,'#6e846a',1.5);oval(c,a+dx,b+dy,2.2,1.7,'#91a482');}
}

export function reedBed(c,p,x,y,w,h,t){
 for(let i=0;i<20;i++){const xx=x+((i*31)%19)/19*w,yy=y+((i*11)%23)/23*h,[a,b]=p(xx,yy),s=4+((i*7)%11);
  line(c,a,b,a+Math.sin(i+.8*t)*2,b-s,'#728c78',1.5);line(c,a,b-1,a-3,b-s*.66,'#9aa38c',1);}
}
export function tracks(c,p,points,calf=false){
 for(let i=1;i<points.length;i++){const [ax,ay]=points[i-1],[bx,by]=points[i],count=Math.ceil(Math.hypot(bx-ax,by-ay)/(calf?.67:.91));
  for(let j=0;j<count;j++){const f=j/count,x=ax+(bx-ax)*f,y=ay+(by-ay)*f,side=j%2?.12:-.12,[u,v]=p(x,y+side);
   oval(c,u-1.8,v,calf?2.6:4,calf?1.05:1.5,'#486665');oval(c,u+1.5,v-.8,calf?1.7:2.7,1,'#56716d');}}
}
export function net(c,p,x,y,w,drawn){
 const top=29,span=w*(1-.81*drawn);
 for(const k of [0,w]){stroke(c,p,[x+k,y],[x+k,y,top+6],'#665b4c',3);const a=p(x+k,y,top+6);oval(c,...a,2.7,1.8,'#cbb38a');}
 stroke(c,p,[x,y,top],[x+w,y,top],'#b9a882',1.8);
 for(let k=0;k<=8;k++){const a=k*span/8,drop=4*Math.sin(Math.PI*k/8);stroke(c,p,[x+a,y,top-drop],[x+a+(drawn?.015:.09),y+.1,4+drawn*15-drop*.4],'#b7bd9e',1);}
 for(let r=0;r<4;r++)for(let k=0;k<8;k++){const a=k*span/8,b=(k+1)*span/8,z=top-2-r*(5-drawn*2);
  stroke(c,p,[x+a,y+.035,z-3*Math.sin(Math.PI*k/8)],[x+b,y+.05,z-3*Math.sin(Math.PI*(k+1)/8)-1.5],'#82968b',.9);}
}
export function cart(c,p,x,y,angle=0){
 const [a,b]=p(x,y);c.save();c.translate(a,b);c.rotate(angle);
 for(const [dx,dy] of [[-13,0],[9,7]]){arc(c,dx,dy,8,0,Math.PI*2,'#493f37',3);arc(c,dx,dy,6,0,Math.PI*2,'#b69467',1.2);for(let j=0;j<4;j++){const a=j*Math.PI/4;line(c,dx-Math.cos(a)*6,dy-Math.sin(a)*6,dx+Math.cos(a)*6,dy+Math.sin(a)*6,'#99856a',1);}}
 poly(c,[[-21,-13],[-7,-20],[14,-13],[13,-4],[-6,-5],[-20,-9]],'#ad8860','#62513f');
 line(c,12,-9,31,-1,'#c6a777',2);line(c,9,-5,27,2,'#896e50',2);c.restore();
}
