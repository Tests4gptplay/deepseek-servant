export function loadoutRatings(defs,hero,base,career){
 const weapon=defs[hero.weapon],coat=defs[hero.armor],charm=defs[hero.charm];
 const resists={...charm?.resists};
 if(career)resists[career.ward]=(resists[career.ward]||0)+career.amount;
 return {attack:base.attack+(weapon?.power||0),defense:base.defense+(coat?.defense||0),pierce:weapon?.break||0,resists};
}
