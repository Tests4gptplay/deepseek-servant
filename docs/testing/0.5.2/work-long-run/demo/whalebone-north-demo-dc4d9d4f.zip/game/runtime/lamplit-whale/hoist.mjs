import {rod,face,beam,box,plate,lamp,ring,oval,tar,oak,brass,sail,hanging} from './fixtures.mjs';
import {wheel} from '../voyage-shapes.mjs';
function basket(c,p,x,y,z,cloth,t){
 box(c,p,x,y,1.35,.88,z,5,['#ad926c','#866b50','#655c48']);plate(c,p,x+.09,y+.10,1.16,.65,z+5.3,'#625e4e');for(let i=0;i<=5;i++){const a=x+i*.26;rod(c,p,[a,y+.88,z],[a,y+.88,z+12],'#bfa078',2);}
 for(const yy of [y,y+.88]){for(const xx of [x,x+1.35])rod(c,p,[xx,yy,z+11],[x+.68,y+.44,z+34],'#a39776',1.55);}
 for(const yy of [y,y+.88])rod(c,p,[x,yy,z+11],[x+1.35,yy,z+11],'#c3a77f',2.2);
 for(const xx of [x,x+1.35])rod(c,p,[xx,y,z+10],[xx,y+.90,z+10],'#b39c76',2.3);if(cloth)sail(c,p,[x+.09,y+.9,z+12],[x+.92,y+.9,z+12],13,'#b97863',t,true);
}
export function pitFloor(c,p,s,t){
 const x=10,y=4,w=4,h=7;
 plate(c,p,x,y,w,h,1,'#2f484d');face(c,p,[[x,y,1],[x+w,y,1],[x+w-.42,y+.56,-22],[x+.38,y+.56,-22]],'#586b68');
 face(c,p,[[x,y,1],[x,y+h,1],[x+.38,y+h-.48,-22],[x+.38,y+.56,-22]],'#67736a');
 for(let i=1;i<6;i++)rod(c,p,[x+.12,y+i,1],[x+.43,y+i,-16],'#a59a7e',2);
 for(const yy of [y+.19,y+h-.16])rod(c,p,[x,yy,3],[x+w,yy,3],'#ad9671',2);
 for(let i=0;i<8;i++){const xx=x+.65+(i%3)*.76,yy=y+1.1+i*.59;rod(c,p,[xx,yy,-12],[xx+.46,yy,-12],'#7b9891',1);}
 const low=s.tide==='low';for(let j=0;j<5;j++)box(c,p,14.25+j*.22,13.3+j*.27,.68,.28,-6+j*1.8,2.3,low?oak:tar);
 if(!low){plate(c,p,14.18,13.4,1.55,1.55,3,'#719897c2');for(let j=0;j<3;j++)rod(c,p,[14.3,13.65+j*.38,3],[15.05,13.65+j*.38,3],'#c3d5bba6',1.4);}
}
export function lift(c,p,s,t){
 const right=s.flags['lift-proved'];const X=13.12,Y=6.54;
 for(const y of [Y-.63,Y+1.1]){beam(c,p,[X-1.6,y,0],[X-1.6,y,53],6);beam(c,p,[X+1.37,y,0],[X+1.37,y,53],6);beam(c,p,[X-1.78,y,53],[X+1.6,y,53],8);rod(c,p,[X-1.5,y,41],[X-.65,y,53],'#a79068',3.3);}
 const A=[X-.75,Y+.02,52],B=[X+.68,Y+.02,52];
 for(const z of [A,B]){const v=p(...z);wheel(c,v[0],v[1],7,right?.82:.15,7);}
 const za=right?15:-9,zb=right?-8:14;
 const xa=X-1.58,xb=X+.1,yy=Y-.2;
 rod(c,p,A,[xa+.68,yy+.44,za+34],'#d1bc90',2.2);rod(c,p,B,[xb+.68,yy+.44,zb+34],'#ad986f',2);
 if(right){rod(c,p,[X-1.17,Y+.29,42],[X+.85,Y-.25,47],'#d0ab76',2.4);}
 basket(c,p,xa,yy,za,true,t);basket(c,p,xb,yy,zb,false,t);lamp(c,p,X-1.5,Y+.98,35,t,true,.66);
}
export function pitFeature(c,p,f,s,t){
 if(f.kind==='water'&&f.x===10)return true;
 if(f.kind==='wall'&&f.y===0){
  box(c,p,0,0,f.w,1.9,0,30,['#687d78','#536d69','#425e5e']);
  for(let i=.45;i<f.w;i+=2.55){beam(c,p,[i,1.95,1],[i+.28,1.70,28],4);rod(c,p,[i+.28,1.74,28],[i+.78,1.48,32],'#b3a585',2);}
  for(const [x,z] of [[4.45,12],[10.2,15],[17.7,13],[23.1,14]])lamp(c,p,x,2.01,z,t,true,.70);
  return true;
 }
 if(f.label==='上舱配重'){
  for(let j=0;j<2;j++)for(let i=0;i<2;i++){const x=f.x+.35+i*1.55,y=f.y+.37+j*1.60,h=12+(j===0?7:0);
   box(c,p,x,y,1.37,1.25,0,h,['#8a9285','#65726b','#526460']);for(let k=.26;k<1.3;k+=.63){beam(c,p,[x+k,y,h],[x+k,y+1.25,h],2.2);rod(c,p,[x+k,y+1.26,1],[x+k,y+1.26,h],'#b09f7c',1.5);}
  }return true;
 }
 if(f.kind==='crane'&&f.label==='反提双筐'){lift(c,p,s,t);return true;}
 if(f.kind==='building'&&f.label==='停梯暖房'){box(c,p,f.x+.1,f.y+.1,f.w-.2,f.h-.2,0,20,tar);for(let i=0;i<5;i++)beam(c,p,[f.x+.35+i*.85,f.y+f.h-.06,1],[f.x+.35+i*.85,f.y+f.h-.06,21],2.5);lamp(c,p,f.x+3.5,f.y+f.h,15,t,true,.9);return true;}
 return false;
}