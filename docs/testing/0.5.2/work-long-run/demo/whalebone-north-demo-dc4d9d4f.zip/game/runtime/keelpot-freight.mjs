import {fieldLoads,landGoods} from './keelpot-low-carry.mjs';

export const names={blue:'青布鱼瓮',rust:'赭布鱼瓮',rack:'整副蚝苗架',near:'靠岸半盘',sea:'朝海半盘'};
const weigh=x=>x==='rack'?2:1;
export const units=boat=>boat.reduce((sum,key)=>sum+weigh(key),0);
export const newLoad=()=>({boat:[],shoulder:null,ashore:[]});
const showLoad=f=>f.boat.length?f.boat.map(k=>names[k]).join('、'):'两肋尚空';
function boatActions(op,s,f){
 const flag=s.flags;
 function getPot(key){
  if(flag['keelpot-launched'])return '起缆后的鱼瓮各有去处。晚货要等舟在对岸真卸过，方能上肩。';
  if(f.shoulder)return '你肩上已有'+names[f.shoulder]+'。一副扁担只容一件，先放到舟上，或送回原座。';
  if(f.boat.includes(key))return names[key]+'已经在舟里。实物不能在木座上再拿一遍。';
  f.shoulder=key;flag['keelpot-on-shoulder']=true;return '你把'+names[key]+'的耳绳绕上担头。推斜埠下去，在双肋舟边实际放手。';
 }
 function putBack(){
  if(!f.shoulder)return '两端担头都空着。';
  const item=f.shoulder;f.shoulder=null;flag['keelpot-on-shoulder']=false;flag['keelpot-crossed']=false;
  return names[item]+'落回原来的垫座。你现在能空手改路。';
 }
 if(op==='fish')return [['担起青布瓮',()=>getPot('blue')],['担起赭布瓮',()=>getPot('rust')],['把所担鱼瓮放回',putBack]];
 if(op==='seed')return [['沿浸水滑木把整苗架推入舟',()=>{
  if(f.shoulder)return '手上有瓮，不能两手平推整架。先把瓮放回或放进舟。';
  if(f.boat.includes('rack'))return '整架已经浮在两道肋之间。';
  if(units(f.boat)>0)return '瓮已压住一道肋。苗架横跨两肋，一半悬空会把幼壳磨干。到舟边卸回后能改线。';
  f.boat.push('rack');return '双肋同时吃水。整架连原来那层咸水浮进舟里，一只鱼瓮也塞不进剩下的三角空隙。';
 }]];
 if(op==='boat')return [
 ['将肩上货物安上空肋',()=>{
  if(!f.shoulder)return '肩上没有实物。青布和赭布两只瓮在鱼铺斜架，苗架另有水道。';
  if(units(f.boat)+weigh(f.shoulder)>2)return '两道肋都在吃水，第三件会压住舷耳。你仍扛着原件，可以退回。';
  const item=f.shoulder;f.boat.push(item);f.shoulder=null;flag['keelpot-on-shoulder']=false;
  return names[item]+'压稳一肋。舟上现在是'+showLoad(f)+'。';
 }],
 ['把上一件卸回去',()=>{
  if(f.shoulder)return '担头已占，要先把手上的货放回原座。';
  if(!f.boat.length)return '双肋都是空的。';
  const item=f.boat.pop();
  if(item==='rack')return '整架沿滑木退回水床。幼苗带着原水，可以重新选择。';
  f.shoulder=item;flag['keelpot-on-shoulder']=true;
  return '你把'+names[item]+'从舟里担起，得亲自送回鱼铺木座。';
 }]];
 if(op==='cast')return [['确认这一班出舟并把缆交还蒲岸',()=>{
  if(s.tide!=='high')return '水还在第一枚系耳下，舟底搁石。到双尺旁等真涨水，已装的实物会留在舟上。';
  if(f.shoulder)return '还有东西在你肩上，蒲岸不能把它也算进船。先自己放稳。';
  if(units(f.boat)!==2)return '只装满两肋才起缆。两只鱼瓮各压一肋，或一副苗架横占两肋。';
  const fish=!f.boat.includes('rack');
  if(!flag[fish?'keelpot-young-wait':'keelpot-fish-wait'])return fish?'禾盏还没答应让苗留内沟。先去摸遮索，听她本人怎么说。':'商枣和灶嫂还没同意改腌。先看青瓮上的卤，再问今晚用哪口灶。';
  flag['keelpot-launched']=true;flag[fish?'keelpot-fish-first':'keelpot-seed-first']=true;
  return fish?'蒲岸解下最后一圈缆。鱼先到，可以保住今晚的鲜汤。禾盏会在内沟等你，苗得分两趟。现在从高水口上舟。':'整架随高水出埠。商枣已把青鱼改腌，今晚灶班只开豆汤。两瓮各要有人担到凉窖。现在从高水口上舟。';
 }]];
 return [];
}
export function keelpotFreight(ctx,e,close){
 const s=ctx.state.player, f=s.progress.keelpotFreight??=newLoad(), op=e.action.op;
 const flag=s.flags;
 let entries;
 if(op==='land'||op==='put'||op==='cross')entries=landGoods(op,s,f);
 else if(flag['keelpot-launched']){
  if(op==='fish'||op==='seed')entries=fieldLoads(op,s,f);
  else entries=[['摸清舟的位置',()=>flag['keelpot-landed']?'空肋已经交到对岸，蒲岸去了粮船当班。另一家的货从露出的低脚路人肩过去。':'缆已经脱手。上高水口到对岸，用木踵卸货，这才算接到。']];
 }else entries=boatActions(op,s,f);
 const body='潮位'+(s.tide==='high'?'已过第二枚系耳':'落在第一枚系耳下')+'。舟肋 '+units(f.boat)+'/2（'+showLoad(f)+'）。肩上：'+(names[f.shoulder]||'空')+'。低脚路已接 '+f.ashore.length+'/2 件。';
 ctx.ui.show('freight',e.name,body,[...entries.map(([label,go])=>[label,()=>{
  const msg=go();ctx.sync();ctx.ui.show('freight-result',e.name,msg,[['放稳手，回到现场',close]]);
 }]),['先放手看一看',close]]);
}
