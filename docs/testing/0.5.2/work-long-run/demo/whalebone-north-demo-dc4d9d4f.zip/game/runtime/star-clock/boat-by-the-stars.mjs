import {plate,lagoon} from './brass-and-water.mjs';
import {charts,directions,rowOne} from './blackwater-lanes.mjs';
import {sight,mend} from './star-and-rate.mjs';
import {syncParty} from '../party.mjs';
const col='甲乙丙丁戊己',row=['北汊','上环','中梁','南脊','尾沟'];
function sail(ctx,close){
 const {ui,sound,state,sync}=ctx,s=state.player,chart=charts[s.tide],prev=s.progress.starBoat;
 const valid=prev?.tide===s.tide&&Array.isArray(prev.at)&&prev.at.length===2&&prev.at.every(Number.isInteger)&&prev.at[0]>=0&&prev.at[0]<6&&prev.at[1]>=0&&prev.at[1]<5&&!chart.land.has(prev.at.join(','));
 let at=valid?[...prev.at]:[...chart.start],clean=valid?prev.clean===true:true,note='';
 function reset(){at=[...chart.start];clean=true;note='米娘让艇倒回篷下，重新放静橹尖。';keep();show();}
 function keep(){s.progress.starBoat={tide:s.tide,at:[...at],clean};}
 function move(dx,dy){const next=rowOne(chart,at,dx,dy);at=next.at;
  if(next.outcome==='ground'){clean=false;s.flags['star-clock-grounded']=true;note='橹尖碰到白礁。米娘带艇退回出发桩，水路与准钟都还在。';}
  else if(next.outcome==='drift')note='进了带箭的水格，流把艇另送了一格。';
  else note='橹只动一下，船静下来。';keep();sync();
  if(next.outcome==='landed'){
   s.flags['star-clock-crossed']=true;if(clean)s.flags['star-clock-quiet']=true;delete s.progress.starBoat;sound('gate');sync();
   ui.show('star-instrument','橹尖靠到了玻璃台',clean?'全程没惊动水面。对岸黑窗里透出一小道青色，像桌子下面伸出一根孩子的手指。':'白沫盖住了岸边的低窗。下趟若想看看里面，把船收回出发桩，全程别让橹碰白礁。',[['系住艇，步行登台',close]]);plate(ui,'小艇抵达青玻璃灯桩',c=>lagoon(c,chart,at));return;
  }show();
 }
 function show(){const where=col[at[0]]+'列'+row[at[1]],legend=Array.from({length:5},(_,y)=>col.split('').map((_,x)=>{const k=[x,y].join(',');return chart.land.has(k)?'礁':chart.flow[k]?(chart.flow[k][0]?'东':'北'):(x===5&&y===1)?'灯':'水';}).join('')).join(' ／ ');
  ui.show('star-instrument',s.tide==='high'?'涨潮无灯渡':'低潮无灯渡',where+'　'+(note||'从甲列南脊划到己列上环。每划一步，带箭的格会立刻再推一格，白礁不可落橹。'),[...directions.map(([name,x,y])=>[name,()=>move(x,y)]),['从泊桩重起',reset],['系在这里，先上岸',close]],'水路自北向南，格内按甲至己排列　'+legend);plate(ui,'六列五行水图；小艇在'+where+'。'+legend,c=>lagoon(c,chart,at));
 }show();
}
function give(ctx,close){
 const {ui,state,world,sound,sync}=ctx,s=state.player;
 function receipt(){
  const ferry=!!s.flags['star-clock-ferry'];
  ui.show('dialogue',ferry?'米娘':'粟铅',ferry?'米娘抱走准钟。粟铅拿起没了内环的观星筒，登粮船去，靠自己的眼睛给船队报刻。她们隔着舟帮，各敲了一下钟箱。':'准钟穿过两层毛毡，放进粮船的定架。米娘把星线系上自家篷口，雾乔在灯下伸着手，等她把线的另一头递来。',[['收起手中的铜内圈',close]]);
 }
 if(s.flags['star-clock-settled']){receipt();return;}
 function hand(ferry){
  const full=ferry?'留表给夜渡班':'带表登护粮前船';
  ui.show('dialogue',ferry?'米娘':'护粮领舵',ferry?'明早我按这一只钟，把几班小艇从雾里接回来。粮船得请粟铅亲自守上几夜星台。':'起雾还要按刻分开的粮船会拿到同一只准钟。米娘没有这只表，她肯不肯把原铜线留在小艇篷口，得由她自己答。',[[full,()=>{if(!s.flags['star-clock-settled']){s.flags[ferry?'star-clock-ferry':'star-clock-grain']=true;s.flags['star-clock-settled']=true;const bag=syncParty(world,s).stock;bag['star-seam-rule']=(bag['star-seam-rule']||0)+1;sound('solve');sync();}receipt();}],['再听另一边',choose]]);
 }
 function choose(){ui.show('dialogue','两张都在等的航桌','一只准钟，两套生活。带表的人可以在看不见天时交班；留下星线的人要有人守夜。粟铅把自己的床铺卷起来，等你们选完。',[['听夜渡班怎么走',()=>hand(true)],['听护粮前船怎么走',()=>hand(false)],['先把箱搭在干处',close]]);}choose();
}
export function useStarTable(ctx,e,close){
 const key=e.action.station;if(key==='sight')return sight(ctx,close);if(key==='clock')return mend(ctx,close);if(key==='sail')return sail(ctx,close);if(key==='give')return give(ctx,close);throw Error('未知星台工位');
}
