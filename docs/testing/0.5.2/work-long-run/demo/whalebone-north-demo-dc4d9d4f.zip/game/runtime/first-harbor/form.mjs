import {poly,line,oval,rand} from '../paint.mjs';
import {plate,box} from '../voyage-shapes.mjs';
export {poly,line,oval,plate,box};
export const timber=['#ab8660','#815e47','#604c41'],stone=['#babba4','#979a87','#79877c'];
export const stroke=(c,p,a,b,color,width=1)=>line(c,...p(...a),...p(...b),color,width);
export const face=(c,p,points,fill,edge)=>poly(c,points.map(q=>p(...q)),fill,edge);
export function sag(c,p,a,b,drop,color,width=1.4){
 const A=p(...a),B=p(...b);c.beginPath();c.moveTo(...A);c.quadraticCurveTo((A[0]+B[0])/2,(A[1]+B[1])/2+drop,...B);c.strokeStyle=color;c.lineWidth=width;c.stroke();c.lineWidth=1;
}
export function windowFront(c,p,x,y,z,w,h,shutter=false,light=false){
 const pt=(u,v)=>p(x+u,y,z+v);
 poly(c,[pt(-.055,-1.5),pt(w+.055,-1.5),pt(w+.055,h+1.3),pt(-.055,h+1.3)],'#6a6756');
 poly(c,[pt(0,0),pt(w,0),pt(w,h),pt(0,h)],light?'#d7b974':'#46605f');
 poly(c,[pt(.045,1.4),pt(w*.46,1.4),pt(w*.46,h-1.3),pt(.045,h*.68)],light?'#f0d598':'#70928b');
 line(c,...pt(w*.55,0),...pt(w*.55,h),'#ac9c7d',1.3);line(c,...pt(0,h*.45),...pt(w,h*.45),'#a69779',.85);
 stroke(c,p,[x-.09,y+.06,z-2.3],[x+w+.10,y+.06,z-2.3],'#dfc8a3',2.1);
 if(shutter){
  for(const [a,b] of [[x-.27,x-.075],[x+w+.065,x+w+.25]]){
   face(c,p,[[a,y+.025,z],[b,y+.025,z+.15],[b,y+.025,z+h],[a,y+.025,z+h]],'#728879','#53695f');
   for(let zz=3;zz<h-1;zz+=3)stroke(c,p,[a+.018,y+.035,z+zz],[b-.018,y+.035,z+zz],'#a2a98d',.65);
  }
 }
}
export function doorFront(c,p,x,y,w,h,base=0,inside=false){
 const pt=(u,v)=>p(x+u,y,base+v);
 poly(c,[pt(-.09,0),pt(w+.09,0),pt(w+.09,h+2),pt(-.09,h+2)],'#6c6251');
 poly(c,[pt(0,0),pt(w,0),pt(w,h),pt(0,h)],inside?'#344b4a':'#5c665a');
 if(inside){poly(c,[pt(0,0),pt(w*.28,3),pt(w*.28,h-2),pt(0,h)],'#947557');}
 else{for(let j=1;j<4;j++)line(c,...pt(j*w/4,1),...pt(j*w/4,h-2),'#7f806a',.75);line(c,...pt(.08,5),...pt(w-.08,h-4),'#9e9679',1.3);}
 stroke(c,p,[x-.1,y+.06,base+1],[x+w+.13,y+.06,base+1],'#ddc7a0',2);
 const k=pt(w*.8,h*.44);oval(c,...k,1.35,1.32,'#d5b77c');
}
export function gable(c,p,x,y,w,h,z,rise,pal,style='slate'){
 const a=[x-.13,y-.1,z+1],b=[x+w+.16,y-.1,z+1],d=[x-.16,y+h+.15,z],e=[x+w+.19,y+h+.15,z];
 const mid=y+h*.44,lo=[x-.16,mid,z+rise],hi=[x+w+.18,mid,z+rise];
 face(c,p,[b,e,hi],pal[3],pal[2]);face(c,p,[a,b,hi,lo],pal[0],pal[2]);face(c,p,[lo,hi,e,d],pal[1],pal[2]);
 const pitch=style==='copper'?.54:style==='plank'?.32:.53;
 for(let u=.04;u<w+.1;u+=pitch)stroke(c,p,[x+u,mid,z+rise],[x+u,y+h+.13,z+.3],style==='plank'?'#d5ae785c':'#c8bb966c',.85);
 if(style!=='plank'){
  for(let q=.24;q<1;q+=.22){const yy=mid+(y+h+.13-mid)*q,zz=z+rise*(1-q);stroke(c,p,[x-.15,yy,zz],[x+w+.18,yy,zz],'#3a575451',.8);}
 }
 stroke(c,p,lo,hi,'#dbc19a',2.35);stroke(c,p,d,e,'#504f43',2.3);
 for(let u=.12;u<w+.08;u+=.76)stroke(c,p,[x+u,y+h+.09,z],[x+u,y+h+.09,z-3.6],'#68604e',1.8);
}
export function rainpipe(c,p,x,y,z){
 stroke(c,p,[x,y,1],[x,y,z-3.5],'#556d69',2.6);
 for(let h=5;h<z-4;h+=13)stroke(c,p,[x-.05,y,h],[x+.09,y,h],'#b9b090',1);
}
export function renderPlaster(c,p,x,y,w,h,z,key){
 for(let k=0;k<Math.floor(w*6);k++){const xx=x+.13+rand(key,k)*(w-.32),zz=3+rand(key+k,17)*(z-7);
  stroke(c,p,[xx,y+h+.012,zz],[xx+.08+rand(k,30)*.20,y+h+.012,zz+.3],'#625f4d32',.8);}
}
