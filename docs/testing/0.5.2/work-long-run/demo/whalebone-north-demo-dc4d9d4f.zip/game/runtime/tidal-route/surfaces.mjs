import {poly,line,oval,rand} from '../paint.mjs';
export const point=(p,q,z=0)=>p(q[0],q[1],z);
export function edge(c,p,a,b,color,width=1,z=0){line(c,...point(p,a,z),...point(p,b,z),color,width);}
export function surface(c,p,ring,z,fill,stroke){poly(c,ring.map(q=>point(p,q,z)),fill,stroke);}
const bounds=ring=>[Math.min(...ring.map(q=>q[0])),Math.max(...ring.map(q=>q[0])),Math.min(...ring.map(q=>q[1])),Math.max(...ring.map(q=>q[1]))];
function clipped(c,p,ring,paint){c.save();c.beginPath();ring.forEach((q,i)=>c[i?'lineTo':'moveTo'](...point(p,q)));c.closePath();c.clip();paint(...bounds(ring));c.restore();}
export function builtEdge(c,p,ring,depth,palette){
 for(let i=0;i<ring.length;i++){const a=ring[i],b=ring[(i+1)%ring.length];poly(c,[point(p,a),point(p,b),point(p,b,-depth),point(p,a,-depth)],palette[i%2],palette[0]);}
}
export function post(c,p,x,y,h=11,rope=false){
 const [a,b]=p(x,y);oval(c,a,b+2,4,1.7,'#38595b77');poly(c,[[a-2.5,b],[a-2.7,b-h],[a+2.2,b-h-1],[a+2.5,b]],'#715e49','#4f5147');
 oval(c,a,b-h,2.8,1.35,'#dbbf89');if(rope){line(c,a-3,b-h+4,a+3,b-h+2,'#e0c99b',1.5);line(c,a-3,b-h+6,a+3,b-h+4,'#a48660',1);}
}
export function planking(c,p,ring,type){
 const afloat=type==='float',bridge=type==='gangway';builtEdge(c,p,ring,afloat?4:8,afloat?['#395c59','#50706a']:['#514f42','#6f604b']);
 surface(c,p,ring,0,afloat?'#a68a61':bridge?'#ad8e6b':'#a98561','#716b51');
 clipped(c,p,ring,(x0,x1,y0,y1)=>{
  if(bridge||afloat){for(let x=Math.floor(x0*3)/3;x<x1+.7;x+=.33){
    edge(c,p,[x,y0-.4],[x,y1+.4],'#6b5c4c',1.5);edge(c,p,[x+.06,y0],[x+.06,y1],'#d6b98b',.85);}}
  else{for(let y=y0+.08;y<y1+.2;y+=.28){edge(c,p,[x0-.2,y],[x1+.3,y],'#705c4c',1.2);
    for(let x=x0+.2;x<x1;x+=3.8){const off=rand(Math.round(x),Math.round(y*9));edge(c,p,[x+off,y],[x+off,y+.27],'#665a4b',.9);edge(c,p,[x+off+.17,y+.10],[x+off+1.7,y+.1],'#c5a77b',.75);}}}
 });
 for(let i=0;i<ring.length;i++)edge(c,p,ring[i],ring[(i+1)%ring.length],'#dcc49a',1.5);
}
export function intertidal(c,p,ring,kind,tide){
 const rock=kind==='reef',stair=kind==='stairs',bank=kind==='bank';
 builtEdge(c,p,ring,stair?8:rock?4:3,rock?['#4c5f61','#71827a']:['#6c7368','#7c8172']);
 surface(c,p,ring,0,rock?'#79877e':stair?'#b5ae90':bank?'#9c9c83':'#a19b7e',rock?'#596b68':'#747b69');
 clipped(c,p,ring,(x0,x1,y0,y1)=>{
   if(stair){for(let v=y0+.17;v<y1+.3;v+=.43){
     edge(c,p,[x0-.5,v],[x1+.5,v-.18],'#716e60',1.8);edge(c,p,[x0-.5,v+.06],[x1+.4,v-.12],'#d8c6a1',1.1);}
   }else for(let x=Math.floor(x0);x<x1+1;x++)for(let y=Math.floor(y0);y<y1+1;y++){
     const n=rand(x+89,y-13),u=x+.07+.77*n,v=y+.15+.68*rand(x-31,y);
     if(rock||bank){const r=.13+.28*n;surface(c,p,[[u-r,v],[u-.1,v-r*.62],[u+r*.75,v-r*.4],[u+r,v+.02],[u+.04,v+r*.5]],n*3, n>.5?'#a4a796':'#8c9989','#677971');}
     else{edge(c,p,[u-.19,v],[u+.48,v+.08],n>.5?'#c0b79c':'#818471',1);if(n>.76){const [a,b]=p(u,v);oval(c,a,b,4,1.5,'#83a39a');}}
   }
 });
 for(let i=0;i<ring.length;i+=2)edge(c,p,ring[i],ring[(i+1)%ring.length],tide==='high'?'#deedda':'#b9d2c3',1.4,-2);
}
export const rectangle=(x,y,w,h)=>[[x,y],[x+w,y],[x+w,y+h],[x,y+h]];
