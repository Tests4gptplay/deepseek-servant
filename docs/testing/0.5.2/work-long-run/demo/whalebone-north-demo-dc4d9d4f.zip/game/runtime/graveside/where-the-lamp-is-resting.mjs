import {line,oval,poly} from '../paint.mjs';
export function workAtTheGrave(c,p,s){
 const f=s.flags,a=p(10.75,10.35),end=p(12.10,10.06);
 c.save();
 for(const side of [-1,1]){
  const shift=side*5;
  const pts=f['coffin-home']?[[a[0]-24,a[1]+7+shift],[a[0]-32,a[1]+11+shift],[a[0]-42,a[1]+10+shift],[a[0]-39,a[1]+6+shift],[a[0]-30,a[1]+5+shift],[a[0]-27,a[1]+6+shift]]:[[a[0]-29,a[1]+3+shift],[a[0]-11,a[1]+1+shift],[end[0]+5,end[1]+3+shift]];
  for(let j=1;j<pts.length;j++){line(c,...pts[j-1],...pts[j],'#756851',2.7);line(c,pts[j-1][0],pts[j-1][1]-.6,pts[j][0],pts[j][1]-.6,'#c9b08a',1);}
 }
 const [u,v]=p(13.48,10.04);
 for(let i=0;i<13;i++){const n=(i*17)%23;oval(c,u-10+n,v+3+(i%3)*1.3,i%3+.8,.65,i%2?'#e0d8b8':'#abae92');}
 c.restore();
}
export function lampAtTheEdge(c,p,e,s){
 if(e.id!=='grave-cover-edge')return false;
 const [a,b]=p(e.x+.45,e.y+.48);
 oval(c,a+1,b+3,9,3,'#56665b66');
 if(s.flags['grave-signed']){poly(c,[[a-12,b],[a-7,b-6],[a+3,b-6],[a+9,b-2],[a+3,b+2]],'#c7b99a','#837d69');line(c,a-9,b-1,a+5,b-3,'#978d76',1.2);}
 poly(c,[[a-3,b],[a-4,b-7],[a-2,b-12],[a+2,b-12],[a+4,b-6],[a+4,b]],'#c8a674','#746a51');
 oval(c,a,b-5,1.8,3.2,'#f6dea0');line(c,a-4,b-6,a-5,b-12,'#716a57',1);line(c,a-5,b-12,a-1,b-15,'#716a57',1);line(c,a-1,b-15,a+3,b-12,'#716a57',1);return true;
}
