// Trace the union of wet or dry cells, then round each step of the shoreline.
const cache=new WeakMap();
function rim(rows,test){
 const edges=new Map(),corners=(x,y)=>x+','+y,inside=(x,y)=>test(rows[y]?.[x]);
 function border(x,y,a,b){const key=corners(x,y);if(!edges.has(key))edges.set(key,[]);edges.get(key).push([a,b]);}
 for(let y=0;y<rows.length;y++)for(let x=0;x<rows[y].length;x++)if(inside(x,y)){
  if(!inside(x,y-1))border(x,y,x+1,y);if(!inside(x+1,y))border(x+1,y,x+1,y+1);
  if(!inside(x,y+1))border(x+1,y+1,x,y+1);if(!inside(x-1,y))border(x,y+1,x,y);}
 const rings=[];
 while(edges.size){const first=edges.keys().next().value;let key=first,ring=[];
  do{const [x,y]=key.split(',').map(Number),out=edges.get(key);if(!out)break;
   const next=out.pop();if(!out.length)edges.delete(key);ring.push([x,y]);key=corners(...next);
  }while(key!==first);
  if(ring.length<3)continue;
  const smooth=ring.flatMap(([x,y],i)=>{const [nx,ny]=ring[(i+1)%ring.length];return [[.77*x+.23*nx,.77*y+.23*ny],[.23*x+.77*nx,.23*y+.77*ny]];});
  rings.push(smooth);
 }
 return rings;
}
export function contours(map){
 if(!cache.has(map)){const rows=map.driftbay.relief;cache.set(map,{shore:rim(rows,r=>r==='.'||r==='#'),rock:rim(rows,r=>r==='#'),trail:rim(rows,r=>r==='.')});}
 return cache.get(map);
}
export function outline(c,p,rings,z){
 c.beginPath();for(const ring of rings){const last=p(...ring[ring.length-1],z),first=p(...ring[0],z);
  c.moveTo((first[0]+last[0])/2,(first[1]+last[1])/2);
  for(let i=0;i<ring.length;i++){const a=p(...ring[i],z),b=p(...ring[(i+1)%ring.length],z);
   c.quadraticCurveTo(a[0],a[1],(a[0]+b[0])/2,(a[1]+b[1])/2);}
  c.closePath();}
}
export function wash(c,p,rings,z,color){outline(c,p,rings,z);c.fillStyle=color;c.fill('evenodd');}
export function seam(c,p,rings,z,color,width){outline(c,p,rings,z);c.strokeStyle=color;c.lineWidth=width;c.stroke();c.lineWidth=1;}
