import {panel,cord,oval,lantern,hull,pointOn} from './materials.mjs';

const skins={
 shop:{floor:'#7f6b4a',wood:['#a27750','#b48756','#9f774d'],rib:'#71543e',cap:'#d9af73',height:53},
 window:{floor:'#748178',wood:['#72897f','#799086','#91a095'],rib:'#785747',cap:'#dcb987',height:76},
 bed:{floor:'#635c4c',wood:['#726653','#79705b','#655e4c'],rib:'#654e3e',cap:'#bfab81',height:49},
 kin:{floor:'#796850',wood:['#ad8363','#b68d6d','#9a7158'],rib:'#6a4b3e',cap:'#cfb184',height:63},
 flood:{floor:'#4e6561',wood:['#726b55','#858875','#8e8164'],rib:'#53554a',cap:'#b5b18b',height:54},
 ramp:{floor:'#806c4d',wood:['#9e8057','#a98d61','#846c4e'],rib:'#795e42',cap:'#dfbd81',height:49},
 quiet:{floor:'#6c6253',wood:['#8b7664','#a3876a','#94735b'],rib:'#6b5043',cap:'#d0b188',height:59}
};
export const styles={'heel-hall':'shop','heel-high-sill':'window','heel-low-turn':'bed','heel-folded-room':'kin','heel-flooded-hall':'flood','heel-broad-ramp':'ramp','heel-quiet-return':'quiet'};
function seaward(c,q){
 const e=.72;
 panel(c,q,[[.24,e,21],[.78,e,24],[.78,e,69],[.24,e,64]],'#3b5759','#49483c');
 for(const [z,k] of [[24,'#52817b'],[30,'#739c8e'],[37,'#9eb6a0'],[46,'#b8c3a4'],[57,'#c3ccac']]){
  panel(c,q,[[.26,e,z],[.76,e,z+3],[.76,e,z+10],[.26,e,z+7]],k);
 }
 cord(c,q,[[.27,e,34],[.39,e,37],[.50,e,34],[.63,e,41],[.76,e,38]],'#6a8d7d',2.2);
 panel(c,q,[[.20,.76,16],[.27,.76,19],[.24,.76,68],[.18,.76,65]],'#825843','#493b32');
 panel(c,q,[[.78,.76,18],[.83,.76,20],[.84,.76,74],[.77,.76,73]],'#7c5946','#4b4036');
 for(const u of [.35,.54,.69])cord(c,q,[[u,e,21],[u+.015,e,67]],'#604c3a',3.5);
 for(const z of [33,52])cord(c,q,[[.24,e,z],[.77,e,z+4]],'#7c6851',2.3);
 panel(c,q,[[.18,.87,16],[.85,.87,20],[.84,.70,23],[.19,.70,20]],'#d2b47f','#74644e');
 // A sailcloth blind has lost two loops on the old child's side.
 panel(c,q,[[.22,.74,69],[.81,.74,74],[.77,.74,64],[.65,.745,66],[.54,.76,57],[.43,.78,60],[.38,.80,50],[.30,.78,58],[.22,.76,53]],'#b76a54','#755446');
 for(const u of [.27,.37,.49,.62,.74])cord(c,q,[[u,.736,69],[u-.017,.77,60]],'#d18c6c',1.2);
 for(const u of [.26,.44,.64]){oval(c,q(u,.79,15),3,2.2,'#414d47');oval(c,q(u,.79,16),1.35,.9,'#cbb78d');}
}
function lowHull(c,q){
 for(let j=0;j<3;j++){
  const u=.17+j*.30;
  panel(c,q,[[u-.06,.73,2],[u+.08,.73,4],[u+.03,.715,53],[u-.035,.715,49]],'#737f6a','#4d574e');
  for(const z of [8,25,43]){oval(c,q(u,.746,z),4.1,2.8,'#4c594f');oval(c,q(u-.004,.747,z+1),2.3,1.2,'#b6aa81');}
 }
 for(let j=0;j<3;j++){
  const u=.10+j*.28;cord(c,q,[[u,.74,17],[u+.08,.74,18.5],[u+.19,.74,16],[u+.25,.74,17.4]],j%2?'#cbbaa0':'#96a797',2);
 }
 for(let j=0;j<9;j++){const u=(j+.55)/10;oval(c,q(u,.75,4+(j*11%7)),2+(j%3),1.5+(j%2),'#c7c0a0');}
}
function hanging(c,q,theme){
 const wet=theme==='flood',kin=theme==='kin'||theme==='quiet';
 cord(c,q,[[.11,.735,45],[.33,.75,35],[.64,.76,34],[.89,.73,48]],'#514c37',2.2);
 for(let j=0;j<6;j++){
  const u=.21+j*.106,z=36+Math.abs(j-2.5)*2.7;
  if(kin){
   panel(c,q,[[u,.75,z],[u+.052,.75,z+.4],[u+.055,.75,z-13-(j%3)*2],[u+.014,.75,z-16]],j%2?'#8aa095':'#b87867','#5e5b4a');
  }else{
   cord(c,q,[[u,.76,z],[u+.005,.78,z-7]],'#786849',1.3);
   oval(c,q(u+.008,.78,z-10),4.6,7.5,wet?'#776c51':j%2?'#b28755':'#97654f');
   oval(c,q(u+.008,.78,z-5),1.45,1.65,'#d3b985');
  }
 }
 if(kin||wet)lantern(c,q(.86,.79,40),true);
 if(wet)for(const z of [5,10])cord(c,q,[[.045,.76,z],[.38,.765,z+2],[.65,.76,z+1],[.956,.76,z+4]],z===5?'#74a4a0':'#adbd9c',2);
}
function blockedLoft(c,q){
 // This rib is sealed. The family hung the drying shoe lasts from it after the rescue.
 const knots=[[.08,.77,60],[.32,.78,46],[.63,.78,43],[.92,.75,62]];
 cord(c,q,knots,'#574a37',3.1);cord(c,q,knots,'#bb9d71',1.15);
 for(let j=0;j<4;j++){
  const u=.23+j*.155,z=45+Math.abs(j-1.4)*2;
  cord(c,q,[[u,.78,z],[u+.015,.80,z-13]],'#9d845a',1.8);
  panel(c,q,[[u-.026,.815,z-13],[u+.008,.80,z-9],[u+.038,.80,z-15],[u+.049,.815,z-23],[u+.016,.83,z-26],[u-.032,.825,z-21]],j%2?'#b98c62':'#8b674b','#57493a');
 }
 panel(c,q,[[.07,.78,11],[.25,.78,14],[.27,.76,30],[.09,.76,29]],'#8f6651','#624934');
 for(const z of [15,20,25])cord(c,q,[[.09,.785,z],[.24,.785,z+2]],'#b39169',1.2);
}
function oysterSide(c,q){
 for(let j=0;j<24;j++){
  const u=.045+(j*17%89)/100,v=.73+(j%3)*.008,z=4+(j*13%29);
  const k=q(u,v,z),r=2.4+(j%5)*.36;
  oval(c,k,r*1.4,r,'#a9a393');oval(c,[k[0]-.55,k[1]-.6],r*.94,r*.55,j%3?'#dad0ad':'#8eab9c');
  if(j%2===0)cord(c,q,[[u,v,z],[u+.01,v,z+3]],'#666b61',1);
 }
 cord(c,q,[[.02,.755,7],[.20,.755,8],[.46,.755,6],[.72,.755,9],[.97,.755,6]],'#a3b09e',2.4);
}
function wedgedDoor(c,q,underwater){
 panel(c,q,[[.19,.76,4],[.73,.76,10],[.81,.748,51],[.27,.748,47]],underwater?'#766f54':'#aa8055','#5c4b39');
 for(const u of [.27,.35,.43,.51,.59,.67]){
  cord(c,q,[[u,.768,8],[u+.069,.753,46+(u-.3)*9]],'#715739',1.65);
 }
 for(const z of [17,33])cord(c,q,[[.24,.769,z],[.75,.769,z+5]],'#a9b19b',2.6);
 oval(c,q(.64,.775,29),5,3,'#494b3d');oval(c,q(.637,.779,30),3.1,1.7,'#d3ba80');
}

export function wall(c,p,map,f){
 const theme=styles[map.id],q=pointOn(f,p);hull(c,q,skins[theme],Math.max(f.w,f.h));
 if(theme==='window'){if(f.x===19)seaward(c,q);else blockedLoft(c,q);}
 else if(theme==='bed'){if(f.x===0)oysterSide(c,q);else lowHull(c,q);}
 else if((theme==='shop'||theme==='flood')&&f.x===32)wedgedDoor(c,q,theme==='flood');
 else hanging(c,q,theme);
}
