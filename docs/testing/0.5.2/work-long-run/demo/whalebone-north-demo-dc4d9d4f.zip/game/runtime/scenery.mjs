import {poly,line,oval,arc,seed,rand} from './paint.mjs';
import {house,gate} from './architecture.mjs';
import {funeralCart} from './quay.mjs';
import {balance} from './trades.mjs';
export function prop(c,p,f,t,tide,flags={}){
  const k=(f.kind+' '+(f.label||'')).toLowerCase();
  const w=f.w||1,h=f.h||1;const [x,y]=p(f.x+w/2,f.y+h/2);
  if(f.kind==='coffin-cart')return funeralCart(c,x,y);
  if(f.kind==='weighbeam'||f.kind==='回皮秤')return balance(c,x+11,y-8,!!(flags.weighed||flags['wet-sample']),t);
  if(/house|warehouse|building|shed|hall|tower|chapel|屋|宅|房|仓房|作坊|钟塔/.test(k))return house(c,p,f);
  if(f.kind!=='lamp'&&/crane|hoist|gantry|scale|counterweight|lift|winch|吊|秤|绞|滑轮|砝码/.test(k))return gate(c,x,y);
  c.save();c.translate(x,y);
  if(f.kind==='rope'){
    const len=Math.min(58,w*11);line(c,-len,0,-len,-23,'#746b52',2.1);line(c,len,1,len,-21,'#71674f',2.1);
    c.beginPath();c.moveTo(-len,-21);c.quadraticCurveTo(0,-12,len,-20);c.strokeStyle='#9b8c6c';c.lineWidth=1.6;c.stroke();
    if(/晾/.test(k)){for(const [j,col] of [[-.66,'#dcd3b3'],[-.25,'#a58871'],[.22,'#b5c4b2']]){const off=j*len;poly(c,[[off,-17],[off+10,-16],[off+8,-4],[off-2,-6]],col,'#929985');}}
    else for(const end of [-len,len])for(let n=0;n<3;n++)arc(c,end+3,3,7-n,0,Math.PI*2,'#a28c6b',1);
  }else if(f.kind==='crate'&&/袋/.test(k)){
    const n=Math.min(5,w+h+1);for(let j=0;j<n;j++){const dx=(j%3)*8-9+(j>=3?4:0),dy=j>=3?-6:0;
      oval(c,dx,dy+2,7,4,'#87887070');oval(c,dx,dy,7.1,5.3,/盐/.test(k)?'#c4bea3':'#b69a70');line(c,dx-5,dy,dx+4,dy+2,'#897a60');line(c,dx+3,dy-3,dx+5,dy-5,'#82785c');}
  }else if(/boat|ship|sail|ferry|船|帆/.test(k)){
    c.translate(0,Math.sin(t*1.1+f.x)*1.4+(tide==='high'?-2:2));
    oval(c,2,6,39,6,'#406d70a0');poly(c,[[-37,-4],[-17,0],[24,-5],[37,-12],[29,0],[6,7],[-22,8]],'#775647','#4a514a');
    poly(c,[[-36,-4],[-6,-10],[36,-12],[23,-5],[-17,0]],'#b4946e','#665e50');line(c,-4,-7,-4,-52,'#645d4c',2);
    poly(c,[[-7,-46],[-7,-12],[-30,-14]],'#e6d3a6','#a3916f');poly(c,[[-2,-47],[16,-18],[-2,-13]],'#b5745a','#806951');line(c,-4,-50,30,-9,'#68746a');line(c,-34,-3,-47,4,'#736e55');
  }else if(/market|stall|awning|棚|摊|市场/.test(k)){
    for(const xx of [-17,16])line(c,xx,2,xx,-26,'#69593f',3);
    for(let i=0;i<6;i++){let a=-22+i*7;poly(c,[[a,-27],[a+6,-32],[a+13,-32],[a+7,-26],[a+6,-22],[a,-23]],i%2?'#e2c89d':'#a76554');}
    poly(c,[[-20,-11],[14,-16],[23,-12],[-12,-7]],'#d1ad7a');poly(c,[[-12,-7],[23,-12],[22,-4],[-12,1]],'#9b7855');
    for(let i=0;i<7;i++)oval(c,-10+i*4,-12+(i%3),2.2,1.7,i%2?'#a85844':'#b49a52');
  }else if(/rib|bone|arch|骨|拱/.test(k)){
    for(let i=0;i<3;i++){c.beginPath();c.moveTo(-15+i*8,3+i*2);c.quadraticCurveTo(-31+i*7,-17-i*3,-6+i*8,-40-i*4);c.quadraticCurveTo(-22+i*8,-15,-10+i*8,2+i*2);c.fillStyle='#e4d3ac';c.fill();c.strokeStyle='#a09779';c.stroke();}
  }else if(/lamp|beacon|bell|signal|灯|钟|标杆/.test(k)){
    line(c,0,3,0,-31,'#535d51',3);line(c,-5,-28,6,-28,'#594f43',2);poly(c,[[-4,-29],[4,-29],[3,-37],[-3,-37]],'#ebbd78','#645e4b');poly(c,[[-6,-37],[0,-42],[6,-37]],'#596b65');
  }else if(/wall|cliff|rock|breakwater|崖|堤|墙|礁/.test(k)){
    const n=Math.max(2,Math.min(8,w+h));for(let i=0;i<n;i++){const u=(i/(n-1)-.5)*Math.min(104,w*23);const d=rand(i,seed(k))*8;poly(c,[[u-12,1+d],[u-9,-10],[u+3,-15+d],[u+12,-10+d],[u+17,1+d]],'#91a096','#627c78');}
  }else if(/sign|退潮尺|摹图|牌/.test(k)){
    line(c,0,2,0,-18,'#70694f',2.4);poly(c,[[-7,-19],[7,-21],[7,-13],[-7,-11]],'#b6a37d','#736c54');
    line(c,-4,-16,4,-17,'#736950');line(c,-3,-14,3,-15,'#807657');
  }else if(/barrel|cargo|crate|post|rope|bollard|桶|箱|缆|柱/.test(k)){
    oval(c,1,2,10,4,'#63726577');poly(c,[[-7,-1],[-8,-15],[4,-18],[10,-14],[9,0],[0,3]],'#a27c54','#6c654e');line(c,-7,-12,8,-13,'#726650',2);line(c,-6,-3,9,-5,'#726650',2);oval(c,1,-15,7,2.5,'#c1a377');
  }
  c.restore();
}
