import {face,rod,beam,box,plate,lamp,ring,sail,hanging,oval,ash,tar,oak,brass,rand} from './fixtures.mjs';
import {fronts} from './fronts.mjs';
import {bed,tub} from '../voyage-shapes.mjs';
function port(c,p,x,y,z,lit,t,i=0){
 const q=p(x,y,z);oval(c,...q,7,8,'#4c5c56');ring(c,q,7,'#c4b08a',1.02);
 if(lit){oval(c,q[0],q[1],4.7,6.5,'#e1c58e');rod(c,p,[x,y,z-4],[x,y,z+5],'#857451',1.35);}
 else{rod(c,p,[x-.085,y,z-4],[x+.12,y,z+5],'#a39375',1.6);}
}
export function quarters(c,p,f,map,t){
 if(f.kind!=='building')return false;const {x,y,w,h}=f,hold=map.id==='crib-hold';
 const ht=hold?(x===13?41:x===18?34:32):(x===1?46:x===3?43:x===17?38:x===8?41:39),near=y+h-.09;
 const tone=hold?(x===20?['#879085','#7c8270','#546964']:['#7e897c','#747d6d','#57635b']):(x===3?['#b29a88','#af957c','#827767']:['#a3aba1','#a29d86','#788778']);
 box(c,p,x+.12,y+.1,w-.24,h-.2,0,ht,tone);
 for(let i=0;i<w;i++){const a=x+.28+i;face(c,p,[[a,near,0],[a+.12,near,0],[a+.20,near,ht-2],[a+.07,near,ht-2]],i%2?'#6e786c':'#8d8c76');}
 face(c,p,[[x+.02,y+.1,ht],[x+w,y+.05,ht],[x+w,y+h*.49,ht+7],[x+.04,y+h*.49,ht+7]],hold?'#71827c':'#889b91','#626f65');
 face(c,p,[[x+.04,y+h*.49,ht+7],[x+w,y+h*.49,ht+7],[x+w,near+.12,ht],[x+.02,near+.12,ht]],hold?'#8c9a88':'#a5ad9b','#767c69');
 for(let j=0;j<w;j++){rod(c,p,[x+.3+j,y+.2,ht],[x+.3+j,y+h*.49,ht+7],'#9eaa95',1.25);rod(c,p,[x+.3+j,y+h*.49,ht+7],[x+.3+j,near+.08,ht],'#8a947d',1.2);}
 for(let row=1;row<=4;row++){
  const u=row/5,yy=y+h*.49+(h*.49)*u,zz=ht+7-7*u;
  rod(c,p,[x+.04,yy,zz],[x+w-.04,yy,zz],hold?'#768a7d':'#899a89',1.15);
  for(let j=.4+(row%2)*.55;j<w-.15;j+=1.28){const e=Math.min(w-.05,j+.61);rod(c,p,[x+j,yy,zz+.5],[x+e,yy,zz+.5],hold?'#a0ac97':'#b5bba5',.7);}
 }
 beam(c,p,[x+.03,near+.1,ht],[x+w-.04,near+.10,ht],3.8);
 const door=x+.49;face(c,p,[[door,near+.02,0],[door+.64,near+.02,0],[door+.64,near+.02,18],[door,near+.02,18]],'#475b55');
 if(hold&&x===13){for(let z=8;z<ht-2;z+=8)beam(c,p,[x+.38,near+.06,z],[x+2.35,near+.06,z],3.2);}
 else{for(let j=0;j<Math.floor((w-1)/1.3);j++)port(c,p,x+1.75+j*1.15,near+.04,ht*.55,j%3!==1,t);}
 if(!hold&&x===17){for(let i=0;i<4;i++)sail(c,p,[x+2+i*1.5,near+.2,19],[x+2.8+i*1.5,near+.2,19],10,['#c6ac86','#929e91','#be9279','#d5c39f'][i],t,!!(i%2));}
 if(hold&&x===20){for(let i=0;i<4;i++){box(c,p,x+2+i*.78,near+.02,.6,.25,4,3,oak);const q=p(x+2.3+i*.78,near+.22,10);oval(c,...q,2.8,3.6,i%2?'#adb89d':'#ac846b');}}
 if(!hold&&x===1){const v=p(x+.4,y+h*.52,ht+8);tub(c,...v,6,'#7b8f88');}
 fronts(c,p,f,map,null,t,ht);lamp(c,p,door+1.12,near+.11,ht*.70,t,!hold||x!==13,.70);return true;
}
export function wardBed(c,p,s,t){
 const done=s.flags['bar-freed'],x=13.27,y=7.61;bed(c,p,x,y,true);const xx=x+1.55,yy=y+.81;
 face(c,p,[[xx-.36,yy+.27,0],[xx+.45,yy+.27,0],[xx+.25,yy+.27,done?7:2.2]],done?'#d5af75':'#5e6459','#7a674e');
 if(!done){beam(c,p,[xx-.88,yy+.13,2.5],[xx+.48,yy+.13,7.2],4.1);}
 if(done){rod(c,p,[xx-.1,yy+.28,2.8],[xx+.29,yy+.28,4.6],'#ae875f',1.1);}
}
export function corridor(c,p,s,t){
 for(let k=0;k<7;k++){const x=2.3+k*3.4;face(c,p,[[x,4.85,0],[x+.18,4.85,0],[x+.52,4.2,11],[x+.70,4.03,18],[x+.56,4.03,18],[x+.28,4.22,10]],'#75867c');}
 for(const y of [5.15,7.94]){rod(c,p,[1.1,y,1],[25.25,y,1],'#ac9e79',1.35);}
 const q=p(5.9,7.78,3);tub(c,...q,5.6,'#a58e68');
}