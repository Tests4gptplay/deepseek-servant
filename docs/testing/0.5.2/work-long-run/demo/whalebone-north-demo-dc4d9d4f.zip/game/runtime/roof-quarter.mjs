import {line,poly,oval,rand,seed} from './paint.mjs';
export function roofFloor(c,p,map){
 const crossing=map.id==='upper-spar',w=map.width,h=map.height;
 if(!crossing){
  for(let y=2;y<h;y+=2.8){
   const yy=Math.min(h,y+2.8);
   poly(c,[p(0,y),p(w,y),p(w,yy),p(0,yy)],y%5>.8?'#657b7660':'#55716e70');
   line(c,...p(0,yy),...p(w,yy),'#59726b',2);
   for(let x=0;x<w;x+=2.3){line(c,...p(x,y),...p(x+.04,yy),'#b3a78d',1.1);}
  }
 }else{
  for(let x=1;x<w;x+=4.55){
   const e=Math.min(w,x+3.6);
   poly(c,[p(x,3),p(e,3),p(e,5),p(x,5)],'#88786499');
   line(c,...p(x,3),...p(e,3,4),'#b09a77',2.5);
   line(c,...p(x,8),...p(e,10.5,-9),'#695c4a',5);line(c,...p(e,8),...p(x,10.5,-9),'#8e7758',4);
  }
 }
}
export function belowRoofs(c,p,map){
 const w=map.width,h=map.height,onWhale=map.id==='whale-roofs';
 if(onWhale){
  const a=p(-5,-5,-23),b=p(w+2,-5,-23),e=p(w+2,1,-14),d=p(-5,1,-14);
  const base=[a,b,e,d];poly(c,base,'#7e8a80','#75867b');
  poly(c,[d,e,[e[0]-9,e[1]+49],[d[0]+9,d[1]+49]],'#647c78','#617975');
  for(let i=0;i<w+3;i+=3){const [x,y]=p(i,1,-16);c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+7,y+15,x+4,y+39);c.strokeStyle='#8ba096';c.lineWidth=2;c.stroke();}
 }
 for(let i=0;i<9;i++){
  const a=-5+i*3.8,b=-2.1-(i%3)*.7,z=-24-i%3*7;
  const A=p(a,b,z),B=p(a+2.8,b,z),D=p(a,b+1.7,z),E=p(a+2.8,b+1.7,z);
  const R=p(a,b+.8,z+17),S=p(a+2.8,b+.8,z+17);
  const bottom=v=>[v[0],v[1]+26];poly(c,[D,E,bottom(E),bottom(D)],'#8b9384','#788778');poly(c,[E,B,bottom(B),bottom(E)],'#6d827b','#657b74');
  poly(c,[p(a+2.8,b,z),p(a+2.8,b+1.7,z),S],'#a29c87','#89907e');
  for(let j=0;j<3;j++){const [wx,wy]=p(a+.5+j*.7,b+1.72,z-4);poly(c,[[wx,wy],[wx+4,wy+1.8],[wx+4,wy+8],[wx,wy+6]],'#697d74');}
  poly(c,[A,B,S,R],onWhale?'#8e9e91':'#9e9d8b','#7d8c80');
  poly(c,[R,S,E,D],i%2?'#88968b':'#a39a85','#79877d');
  line(c,...S,...E,'#a6ac96',1.2);
 }
}
export function roofFeature(c,p,f,map){
 const k=f.kind,title=f.label||'',w=f.w||1,h=f.h||1,local=(a,b,z=0)=>p(f.x+a,f.y+b,z);
 if(k==='building'){
  const rise=/伙房|库/.test(title)?24:16,key=Math.abs(seed(title));
  const A=local(0,0,13),B=local(w,0,13),D=local(0,h,13),E=local(w,h,13);
  const R=local(-.10,h*.47,13+rise),S=local(w+.12,h*.47,13+rise);
  poly(c,[D,E,local(w,h),local(0,h)],'#9d947a','#697368');
  poly(c,[E,B,local(w,0),local(w,h)],'#7d8676','#63756e');
  poly(c,[A,B,S,R],key%2?'#8c8e7e':'#82968c','#61776e');poly(c,[R,S,E,D],key%2?'#9b705d':'#687e78','#616f65');
  line(c,...R,...S,'#d1b88d',2.8);
  for(let i=.35;i<w;i+=.67)line(c,...local(i,h*.48,13+rise),...local(i,h,14),'#c1ad8b',1.05);
  for(const q of [.22,.57,.85]){let x=w*q;line(c,...local(x,h+.03,12),...local(x,h+.03,-1),'#8d7c60',2);}
  const pos=local(w*.6,h*.31,19+rise);poly(c,[[pos[0]-4,pos[1]+8],[pos[0]-4,pos[1]-7],[pos[0]+3,pos[1]-10],[pos[0]+4,pos[1]+6]],'#887360','#6c6857');
  return true;
 }
 if(k==='pier'){
  const y=h*.9;
  line(c,...local(0,y),...local(w,y),'#635844',5);
  for(let i=.25;i<w;i+=1.8){line(c,...local(i,y),...local(i,y,13),'#6a5945',2.2);line(c,...local(i,y,11),...local(Math.min(i+1.8,w),y,11),'#b5a17c',1.25);}
  if(/高处|雨檐/.test(title))line(c,...local(0,.15),...local(w,.15),'#c6b183',2.4);
  return true;
 }
 return false;
}
