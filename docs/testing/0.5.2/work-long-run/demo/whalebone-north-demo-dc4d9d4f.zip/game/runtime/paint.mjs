export function poly(c,points,fill,stroke){
  c.beginPath();for(let i=0;i<points.length;i++){const p=points[i];i?c.lineTo(...p):c.moveTo(...p)}c.closePath();
  if(fill){c.fillStyle=fill;c.fill()}if(stroke){c.strokeStyle=stroke;c.stroke()}
}
export function line(c,x1,y1,x2,y2,color,width=1){
  c.strokeStyle=color;c.lineWidth=width;c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();c.lineWidth=1;
}
export function oval(c,x,y,rx,ry,color){
  c.beginPath();c.ellipse(x,y,Math.max(.1,rx),Math.max(.1,ry),0,0,Math.PI*2);c.fillStyle=color;c.fill();
}
export function arc(c,x,y,r,a,b,color,w=1){
  c.beginPath();c.arc(x,y,r,a,b);c.strokeStyle=color;c.lineWidth=w;c.stroke();c.lineWidth=1;
}
export function rand(x,y=0){let a=Math.imul((x|0)^0x213b28,0x45d9f3b)^Math.imul((y|0)^431,0x27d4eb2d);a=Math.imul(a^(a>>>16),0x45d9f3b);return ((a^(a>>>16))>>>0)/4294967296;}
export function seed(str){let h=13;for(const s of String(str))h=Math.imul(h,31)+s.charCodeAt(0)|0;return h;}
export function sky(c,w,h,t,showWhale=true){
  const horizon=h*.245;
  const g=c.createLinearGradient(0,0,0,h);g.addColorStop(0,'#84a6ad');g.addColorStop(.17,'#eee0bd');g.addColorStop(.26,'#b7ccbf');g.addColorStop(.44,'#74a7a4');g.addColorStop(1,'#316e75');c.fillStyle=g;c.fillRect(0,0,w,h);
  oval(c,w*.74,horizon*.46,20,20,'#fff1ccab');
  for(let k=0;k<3;k++){
    const pts=[[0,horizon+8]];for(let x=-32;x<=w+48;x+=24){const v=rand(x/24,k);const edge=horizon-7-k*7+12*Math.sin(x/(100+k*28)+k);pts.push([x,edge-11*v],[x+14,edge-11*v+2]);}pts.push([w+52,horizon+15],[0,horizon+15]);poly(c,pts,['#9eafaa','#809e9d','#698d90'][k]);
  }
  if(showWhale){const bx=w*.66,by=horizon+9,sc=Math.min(1.1,w/760);
  c.save();c.translate(bx,by);c.scale(sc,sc);c.fillStyle='#486e74';c.beginPath();c.moveTo(-78,1);c.bezierCurveTo(-54,-12,-26,-11,-15,-12);c.bezierCurveTo(10,-18,42,-15,57,-3);c.lineTo(80,0);c.bezierCurveTo(45,9,-30,9,-78,1);c.fill();
  for(let k=0;k<9;k++){const x=-47+k*9,y=-9-6*rand(k);c.fillRect(x,y-5,5,6);poly(c,[[x-1,y-5],[x+2,y-9],[x+6,y-5]],'#486e74')}line(c,13,-12,13,-35,'#486e74',2);poly(c,[[13,-32],[23,-28],[13,-25]],'#647e7d');c.restore();}
  for(let i=0;i<130;i++){const y=horizon+16+rand(i,2)*(h-horizon);const x=(rand(i,3)*w+t*(1+i%4)*.8)%(w+22)-11;line(c,x,y,x+4+rand(i,6)*19,y,'#dfebcd70',1);}
  for(let i=0;i<5;i++){const x=w*(.2+i*.032)+Math.sin(t*.18+i)*7,y=horizon*(.24+.16*rand(i));c.strokeStyle='#526d72';c.beginPath();c.moveTo(x-5,y-2);c.quadraticCurveTo(x-1,y-3,x,y);c.quadraticCurveTo(x+2,y-3,x+6,y-3);c.stroke();}
}
