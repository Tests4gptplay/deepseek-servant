import {poly,line,oval} from '../paint.mjs';
const gold='#bc9a5d',iron='#485e5d',pale='#d8cc9e',glass='#80b2a5';
function stand(c,p,x,y,w,h,top,ink){
 const q=(a,b,z=0)=>p(x+a,y+b,z);for(const i of [.1,w-.1])for(const j of [.1,h-.1])line(c,...q(i,j),...q(i,j,top),iron,2.3);
 poly(c,[q(0,0,top),q(w,0,top),q(w,h,top),q(0,h,top)],ink,iron);
}
function dial(c,a,b,r,angle,twin=false){
 oval(c,a,b,r,r*.83,'#4c625c');oval(c,a,b,r-2,(r-2)*.83,'#c9bea0');
 for(let n=0;n<12;n++){const t=n*Math.PI/6;line(c,a+Math.sin(t)*r*.73,b-Math.cos(t)*r*.60,a+Math.sin(t)*r*.88,b-Math.cos(t)*r*.74,'#596657',n%3?.75:1.4);}
 line(c,a,b,a+Math.sin(angle)*r*.67,b-Math.cos(angle)*r*.57,'#374847',1.7);if(twin)line(c,a,b,a+Math.sin(angle+.64)*r*.48,b-Math.cos(angle+.64)*r*.44,'#96704e',1.5);oval(c,a,b,1.5,1.5,gold);
}
function wheel(c,a,b,r,angle){
 c.save();c.translate(a,b);c.scale(1,.78);c.rotate(angle);
 for(let j=0;j<14;j++){const v=j*2*Math.PI/14;line(c,Math.cos(v)*(r-2),Math.sin(v)*(r-2),Math.cos(v)*(r+1.2),Math.sin(v)*(r+1.2),gold,2.4);}
 oval(c,0,0,r-1,r-1,'#b2925c');oval(c,0,0,r-4,r-4,'#3d5755');for(let j=0;j<5;j++){const v=j*2*Math.PI/5;line(c,0,0,Math.cos(v)*(r-3),Math.sin(v)*(r-3),gold,1.7);}oval(c,0,0,2.5,2.5,'#dfc887');c.restore();
}
function tripod(c,p,x,y,z){
 const at=p(x,y,z);for(const [dx,dy] of [[-.38,.40],[.52,.34],[.05,-.38]])line(c,...p(x+dx,y+dy),...at,iron,3);return at;
}
export function starPlaces(c,p,m,s,t,ordered){
 const add=(x,y,fn)=>ordered.push([x+y+.05,fn]);
 if(m.id==='star-clock-quay'){add(10.9,10.15,()=>{stand(c,p,10,9.65,1.9,.84,11,'#86775c');const [a,b]=p(11,10.1,22);dial(c,a,b,9,1.08,true);});}
 if(m.id==='meridian-shutter'){
  line(c,...p(4,11.8,1),...p(24,11.8,1),'#d7be7d',2);
  for(let j=0;j<16;j++)line(c,...p(5+j,11.70,1),...p(5+j,12.0,1),j%3?'#9f8f71':pale,j%3?1:1.6);
  add(19.1,10.1,()=>{const [a,b]=tripod(c,p,19.1,10.1,25);c.save();c.translate(a,b);c.rotate(-.45);c.fillStyle='#b29561';c.fillRect(-17,-2,34,4);c.fillStyle=glass;c.fillRect(12,-4,6,8);c.restore();oval(c,a,b,3,3,iron);});
 }
 if(m.id==='pendulum-cellar')add(16.8,9.25,()=>{stand(c,p,15.45,8.6,3,1.1,13,'#85775f');const [a,b]=p(16.8,9.25,23);const age=s.flags['star-clock-tested']?1:.89;
  for(const j of [-1,1]){line(c,a+j*29,b+8,a+j*29,b-35,iron,3);dial(c,a+j*20,b-22,12,t*.08*(j>0?age:1)+j,true);}
  line(c,a-31,b-35,a+31,b-35,gold,2);const dx=Math.sin(t*1.9)*5;line(c,a+2,b-28,a+dx,b+6,iron,1.8);oval(c,a+dx,b+7,4.2,5.2,gold);wheel(c,a-12,b+1,8,t*.3);wheel(c,a+1,b-3,9,-t*.27);
 });
 if(m.id==='night-oar-road')add(18.5,10.35,()=>{const [a,b]=p(18.5,10.35);poly(c,[[a-37,b+2],[a-22,b-6],[a+29,b-7],[a+40,b-11],[a+26,b+5],[a-16,b+10]],'#6d5945',iron);line(c,a-26,b-2,a+31,b-7,pale,1.6);line(c,a-12,b-16,a+17,b+9,'#ae885b',2.8);line(c,a-18,b+9,a+11,b-15,'#b99767',2.8);});
 if(m.id==='mothglass-landing')add(16.25,9.2,()=>{stand(c,p,15.1,8.6,2.2,1.0,13,'#69867c');const [a,b]=p(16,9.1,15);poly(c,[[a-12,b-4],[a,b-9],[a+12,b-4],[a+1,b+2]],'#93b6a1',iron);if(!s.flags['star-clock-settled'])dial(c,a+1,b-10,9,.8);else{line(c,a-7,b-3,a+7,b-5,gold,2);}});
}
