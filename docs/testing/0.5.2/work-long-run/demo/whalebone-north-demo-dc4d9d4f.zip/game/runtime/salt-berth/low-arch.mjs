import {line,oval,poly} from '../paint.mjs';
import {box,plate} from '../voyage-shapes.mjs';

const basalt=['#8e9488','#69766e','#53625d'];
function join(c,p,a,b,color,w){line(c,...p(...a),...p(...b),color,w);}
function face(c,p,x,y,width,front){
  const A=(u,z)=>p(x+u,y,z);
  const crown=34.5,mid=width/2,rx=width*.34;
  c.beginPath();c.moveTo(...A(0,0));c.lineTo(...A(0,crown+6));c.lineTo(...A(width,crown+6));c.lineTo(...A(width,0));c.closePath();
  c.moveTo(...A(mid-rx,0));c.lineTo(...A(mid-rx,5));
  c.bezierCurveTo(...A(mid-rx,31),...A(mid+rx,31),...A(mid+rx,5));c.lineTo(...A(mid+rx,0));c.closePath();
  c.fillStyle=front?'#8c9284':'#69786e';c.fill('evenodd');
  for(let i=0;i<9;i++){
    const a=Math.PI-i*Math.PI/9,b=Math.PI-(i+1)*Math.PI/9;
    const stone=(angle,outer)=>A(mid+Math.cos(angle)*(rx+(outer?.25:0)),5+Math.sin(angle)*(20+(outer?6:0)));
    poly(c,[stone(a,false),stone(b,false),stone(b,true),stone(a,true)],['#c0b9a1','#aaa88e','#bab49d'][i%3],'#777d71');
  }
  for(const a of [0,width-.55]){
    for(let k=0;k<4;k++)join(c,p,[x+a,y+.015,4+k*8],[x+a+.54,y+.015,4+k*8],k===0?'#68877e':'#7c8173',1);
  }
  join(c,p,[x,y+.03,35],[x+width,y+.03,35],'#c1b9a2',2.2);
}
function arch(c,p,x,y,high){
  const length=3.9,depth=1.23,left=x-1.0,back=y-.58;
  plate(c,p,left+.30,back+.2,length-.60,depth-.18,0,'#456b6c','#456463');
  for(let i=0;i<4;i++)join(c,p,[left+.6+i*.55,back+.34,high?5:1],[left+.98+i*.55,back+.7,high?5:1],'#9fbdb1',1.3);
  face(c,p,left,back,length,false);
  poly(c,[p(left,back,40.5),p(left+length,back,40.5),p(left+length,back+depth,40.5),p(left,back+depth,40.5)],'#c3bda4','#969b89');
  for(let i=.35;i<length;i+=.53)join(c,p,[left+i,back,41],[left+i,back+depth,41],'#a29f8e',.95);
  face(c,p,left,back+depth,length,true);
  for(let i=0;i<3;i++)join(c,p,[left+length-.58,back+depth+.015,11+i*2],[left+length-.15,back+depth+.015,13+i*2],'#5f635a',1.6);
}
const interiors=new Set(['eelstep-house','box-in-the-loft','kiln-by-ear','cold-kiln-yard']);
function stairs(c,p,x,y,carried){
  for(let i=0;i<7;i++){
    const dx=x+i*.39,z=1+i*2.15;
    box(c,p,dx,y,.45,1.38,z,2.65,[i%2?'#ba9d78':'#ccb18a','#9c7959','#795f48']);
    join(c,p,[dx+.05,y+1.28,z+3],[dx+.40,y+1.28,z+3],'#d5c39d',1);
  }
  for(let i=0;i<=4;i++){
    const dx=x+i*.60,z=2+i*3.5;
    join(c,p,[dx,y-.08,z],[dx,y-.08,z+19],'#6a5844',2.8);
    join(c,p,[dx,y-.045,z+11],[dx,y-.045,z+17],'#c5ac82',1.2);
  }
  join(c,p,[x-.07,y-.09,21],[x+2.49,y-.09,35],'#b49b74',3.4);
  const bx=carried?x+2.17:x-.13,by=y+.53,bz=carried?16:2;
  box(c,p,bx,by,.83,.64,bz,9,['#bc9562','#967449','#765a3f']);
  for(const d of [.12,.59]){
    join(c,p,[bx+d,by-.005,bz+9.4],[bx+d,by+.65,bz+9.4],'#65766a',1.8);
    join(c,p,[bx+d,by+.655,bz+9.4],[bx+d,by+.655,bz+1],'#758071',2);
  }
}
function wall(c,p,f,work){
  const {x,y,w}=f;
  poly(c,[p(x,y+1),p(x+w,y+1),p(x+w,y+1,39),p(x,y+1,39)],work?'#a58469':'#a29983','#79775f');
  for(let n=.35;n<w;n+=.75)join(c,p,[x+n,y+1,2],[x+n,y+1,38],work?'#977960':'#958874',.9);
  for(let n=.4;n<w-1.2;n+=3.5){
    const left=x+n;
    poly(c,[p(left,y+1.02,12),p(left+1.05,y+1.02,12),p(left+1.05,y+1.02,31),p(left,y+1.02,31)],'#70938e','#756b57');
    join(c,p,[left+.52,y+1.05,12],[left+.52,y+1.05,31],'#d3b58a',1.6);
    join(c,p,[left-.07,y+1.05,12],[left+1.11,y+1.05,12],'#d0b792',3.1);
  }
  join(c,p,[x,y+1.03,39],[x+w,y+1.03,39],'#766a53',3);
}
export function berthRoomObject(c,p,map,f,s){
  if(f.id==='pot-black-arch'){arch(c,p,f.x,f.y,s.tide==='high');return true;}
  if(f.id==='pot-stair-corner'){stairs(c,p,f.x-.8,f.y-.20,!!s.flags['pot-stair-tried']);return true;}
  if(f.id==='pot-gray-handrail'){
    join(c,p,[f.x-.26,f.y+.20,2],[f.x-.26,f.y+.20,18],'#6b6650',2.5);
    join(c,p,[f.x+1.23,f.y+.20,2],[f.x+1.23,f.y+.20,24],'#6b6650',2.5);
    join(c,p,[f.x-.46,f.y+.20,18],[f.x+1.42,f.y+.20,24],'#c7ad83',3.5);return true;
  }
  if(f.id||!interiors.has(map.id)||f.kind!=='building')return false;
  if(f.y<10){wall(c,p,f,map.id==='kiln-by-ear'||map.id==='cold-kiln-yard');}
  else{
    const {x,y,w}=f;for(let dx=.55;dx<w-.7;dx+=2.5){
      box(c,p,x+dx,y+.78,.92,.60,0,10,['#c2a77f','#8b755a','#6e624d']);
      oval(c,...p(x+dx+.40,y+1,11),6.3,2.5,'#e1ceb1');
    }
  }
  return true;
}
export function placeBerthInterior(c,p,map,s,ordered){
  if(map.id==='box-in-the-loft'){
    ordered.push([25.95,()=>stairs(c,p,13.62,10.92,!!s.flags['pot-box-up'])]);
    ordered.push([15.6,()=>stairs(c,p,5.1,9.6,false)]);
  }
  if(map.id==='bridge-draught'){
    for(const [x,y] of [[5.3,10.2],[8.5,10.2]])ordered.push([x+y,()=>{
      box(c,p,x,y,.19,.24,0,12,basalt);
      for(let k=0;k<3;k++)join(c,p,[x+.03,y+.25,3+k*2],[x+.18,y+.25,3+k*2],k===2?'#d1bc90':'#6f8778',1.3);
    }]);
  }
}
