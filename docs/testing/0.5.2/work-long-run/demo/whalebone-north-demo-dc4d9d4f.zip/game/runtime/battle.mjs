import {loadoutRatings} from './field-kit/ratings.mjs';
import {startPosts,takePost,registerGust,keepWindVoyage} from './windloom-posts.mjs';
import {pairMove,learnedPairs,usePair,letPass,takeMark} from './battle-pairs/two-ends.mjs';
import {sailedEncounter} from './passage-school.mjs';
import {selected,basics} from '../rules/vocations.mjs';
import {spellHit} from './elements.mjs';
import {stats,syncParty,addXP} from './party.mjs';
import {items} from './gear.mjs';
import {intent,retaliation} from './enemy-moves.mjs';
const skills={'护送':'break','回索':'brace','退潮':'heal','标线':'mark'};
export function begin(world,s,spec){
 const expedition=syncParty(world,s),gear=items(world);spec=sailedEncounter(s,spec);
 const party=expedition.roster.map(id=>{
   const d=world.actors[id],h=expedition.heroes[id],base=stats(world,id,h.level),raw=d.technique||d.skills?.[0]||'协作技';
   const choice=selected(s,id);
   const original=typeof raw==='string'?{name:raw,kind:skills[raw]||'break',cost:2}:raw;
   const skill=choice?{name:choice.tech,kind:choice.kind,power:choice.power,heal:choice.heal,cost:choice.cost,element:choice.element}:{...original,element:original.element||basics[id]?.element};
   const ratings=loadoutRatings(gear,h,base,choice);
   return {id,name:d.name,...h,...ratings,specialist:!!choice,prep:expedition.fieldPrep?.[id],maxHp:base.hp,maxMp:base.mp,skill,lane:'close',hurt:0};
 });
 const max=Math.max(1,Number(spec.hp)||20),actor=party.findIndex(h=>h.hp>0);
 return {pairsKnown:learnedPairs(s),...(spec.windloom?{windloom:startPosts(spec,party,s)}:{}),name:spec.name||spec.enemy||'对手',hp:max,max,spec,party,stock:{...expedition.stock},items:gear,actor,round:1,phase:actor<0?'lose':'active',intent:intent(spec,max,1),opening:party.some(h=>h.prep==='mark')?3:0,teamGuard:false,log:spec.objective||'看清对手的动作。',last:null};
}
export function move(b,kind,clock=0){
 if(b.phase!=='active')return false;
 const h=b.party[b.actor],skill=h.skill,armor=b.intent.kind==='shell';
 let hit=0,desc='';
 if(pairMove(kind)){
  desc=usePair(b,h,kind);if(!desc)return false;
 }else if(kind==='skill'){
  const cost=skill.cost??2;if(h.mp<cost){b.log='气力不足，架势可以回气。';return false;}
  h.mp-=cost;hit=h.attack+(skill.power??3);
  if(skill.kind==='heal'){for(const a of b.party)if(a.hp>0)a.hp=Math.min(a.maxHp,a.hp+(skill.heal||5));hit=Math.ceil(hit/2);}
  if(skill.kind==='brace'){h.lane='edge';if(h.specialist)b.teamGuard=true;}if(skill.kind==='mark')b.opening=3;
  if(skill.kind==='break'&&armor)hit+=h.pierce+3;const spell=spellHit(hit,skill,b.spec,h.specialist);hit=spell.hit;desc=skill.name+(spell.note?'（'+spell.note+'）':'');
 }else if(kind==='attack'){hit=armor?Math.max(1,Math.floor(h.attack/2)):h.attack;desc='进击';}
 else if(kind==='guard'){hit=1;h.lane='close';desc='守桩架势';}
 else if(kind==='cover'&&b.windloom){hit=1;h.lane='edge';desc='让出自己的位置扶住旁人';}
 else if(kind==='dodge'){h.lane='edge';hit=b.intent.counter==='dodge'?2:0;desc='侧移至外缘';}
 else if(kind==='salve'){
  const key='brine-dose',item=b.items[key];if(!(b.stock[key]>0)){b.log='盐膏已经用完。';return false;}
  b.stock[key]--;h.hp=Math.min(h.maxHp,h.hp+item.heal);h.mp=Math.min(h.maxMp,h.mp+item.restore);h.prep='ward';desc=item.name+' · 下一击备有寒潮隔层';
 }else if(kind==='tonic'){
  const item=b.items.tonic;if(!(b.stock.tonic>0)||(h.hp>=h.maxHp&&h.mp>=h.maxMp)){b.log='药剂尚不能使用。';return false;}
  b.stock.tonic--;h.hp=Math.min(h.maxHp,h.hp+(item.heal||0));h.mp=Math.min(h.maxMp,h.mp+(item.restore||0));desc=item.name;
 }else return false;
 if(!pairMove(kind))letPass(b,h);
 if(kind==='attack'||kind==='skill'){const mark=takeMark(b);if(mark){hit+=mark;desc+=' · 双点照准 +'+mark;}if(kind==='attack'||skill.kind!=='brace')h.lane='close';if(b.opening){hit+=b.opening+h.pierce;b.opening=0;}}
 if(b.windloom)hit=takePost(b,h,kind,hit);
 h.action=kind==='cover'?'guard':kind;b.hp=Math.max(0,b.hp-hit);b.log=h.name+' · '+desc+(hit?'，击中 '+hit:'')+'。';
 b.last={a:b.actor,kind,start:clock,hit};
 if(!b.hp){b.phase='win';return true;}
 const next=b.party.findIndex((member,i)=>i>b.actor&&member.hp>0);
 if(next>=0){b.actor=next;return true;}
 retaliation(b);if(b.windloom)registerGust(b);b.last.response={name:b.intent.name,hits:b.party.filter(p=>p.hurt>0).map(p=>p.id)};b.round++;b.actor=b.party.findIndex(a=>a.hp>0);
 if(b.actor<0){b.phase='lose';return true;}
 b.intent=intent(b.spec,b.hp,b.round);return true;
}
export function settle(world,s,b,won){
 if(b.windloom)keepWindVoyage(s,b,won);
 const ex=s.expedition;ex.stock={...b.stock};if(ex.fieldPrep)delete ex.fieldPrep;
 const id=b.spec.id||'encounter',first=!s.flags['reward:'+id],r=b.spec.rewards||{};
 for(const h of b.party){
  const dest=ex.heroes[h.id];dest.hp=Math.max(won?1:0,h.hp);dest.mp=h.mp;
  if(won)addXP(world,h.id,dest,first?(r.xp??(8+4*(b.spec.level||1))):(r.repeatXp??2));
 }
 if(won&&first){s.flags['reward:'+id]=true;for(const [k,n] of Object.entries(r.items||{}))ex.stock[k]=(ex.stock[k]||0)+n;
   if(!r.items&&b.spec.reward)s.inventory['salvage:'+id]=1;
 }
}
export function partyLine(b){return b.party.map(h=>h.name+' '+h.hp+'/'+h.maxHp+' · 气'+h.mp).join('　');}
