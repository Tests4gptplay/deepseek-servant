import {fieldTool,shirt,stroke} from './etched-tools.mjs';
import {smallFind} from './etched-finds.mjs';
function textile(c){
 const light=c.createLinearGradient(12,0,214,95);light.addColorStop(0,'#385853');light.addColorStop(.43,'#62766a');light.addColorStop(1,'#334e49');c.fillStyle=light;c.fillRect(0,0,240,92);
 for(let j=-75;j<290;j+=3.5){stroke(c,'M'+j+' 0l65 92','#ddd3ac15',.65);stroke(c,'M'+(j+55)+' 0l-31 92','#172e2b25',.70);}
 for(const y of [11,80]){stroke(c,'M8 '+y+'Q99 '+(y+2)+' 231 '+y,'#a5a488',1);c.save();c.setLineDash([3,4]);stroke(c,'M8 '+(y+2)+'Q99 '+(y+4)+' 231 '+(y+2),'#c0b495',.8);c.restore();}
}
export function layItemOnCloth(panel,key,item,info){
 const card=document.createElement('figure');card.dataset.fieldSketch='kit';card.className='work-cloth';
 const canvas=document.createElement('canvas');canvas.width=600;canvas.height=230;canvas.setAttribute('role','img');canvas.setAttribute('aria-label',item.name+'的器物图');const c=canvas.getContext('2d');c.scale(2.5,2.5);textile(c);
 c.save();c.translate(119,46);c.scale(1.31,1.14);c.lineJoin='round';c.lineCap='round';c.shadowColor='#102b29a6';c.shadowOffsetY=2;c.shadowBlur=2;
 if(item.slot==='weapon')fieldTool(c,key);else if(item.slot==='armor')shirt(c,key);else smallFind(c,key);c.restore();
 const caption=document.createElement('figcaption'),who=document.createElement('span'),status=document.createElement('span');
 who.textContent=info.owner+' · '+info.slot;status.textContent=info.left;caption.append(who,status);card.append(canvas,caption);panel.querySelector('p').before(card);
}
