const keys={ArrowLeft:[-1,0],a:[-1,0],ArrowRight:[1,0],d:[1,0],ArrowUp:[0,-1],w:[0,-1],ArrowDown:[0,1],s:[0,1]};
export function bindInput(root,ui,ops) {
 let delay=0,repeat=0,last=0;
 function stop(){clearTimeout(delay);clearInterval(repeat);}
 function handle(e){
  if(e.altKey||e.ctrlKey||e.metaKey||e.target.tagName==='INPUT')return;
  const key=e.key.length===1?e.key.toLowerCase():e.key;
  if(!ui.panel.hidden){
    if(key==='Escape'){e.preventDefault();ops.dismiss();return;}
    if(key==='e'||(key===' '&&e.target.tagName!=='BUTTON')){e.preventDefault();if(!e.repeat)(ui.panel.querySelector('.options button:focus') || ui.panel.querySelector('.options button'))?.click();return;}
    if(['ArrowDown','ArrowRight','ArrowUp','ArrowLeft'].includes(key)){
      const btns=[...ui.panel.querySelectorAll('button')];if(!btns.length)return;e.preventDefault();
      const i=btns.indexOf(document.activeElement),d=['ArrowUp','ArrowLeft'].includes(key)?-1:1;btns[(i+d+btns.length)%btns.length].focus();
    }return;
  }
  if(keys[key]){e.preventDefault();if(!e.repeat||performance.now()-last>=100){ops.move(...keys[key]);last=performance.now();}return;}
  if(key==='e'||(key===' '&&e.target.tagName!=='BUTTON')){e.preventDefault();if(!e.repeat)ops.interact();return;}
  if(key==='j')ops.journal();
 }
 window.addEventListener('keydown',handle);window.addEventListener('blur',stop);
 for(const b of root.querySelectorAll('[data-dir]')){
   const direction=b.dataset.dir.split(',').map(Number);
   b.addEventListener('pointerdown',e=>{e.preventDefault();if(!ui.panel.hidden)return;stop();b.setPointerCapture(e.pointerId);ops.move(...direction);delay=setTimeout(()=>{repeat=setInterval(()=>ops.move(...direction),145)},230);});
   b.addEventListener('pointerup',stop);b.addEventListener('pointercancel',stop);b.addEventListener('lostpointercapture',stop);
   b.addEventListener('click',e=>{if(e.detail===0&&ui.panel.hidden)ops.move(...direction);});
 }
 ui.q('[data-key=use]').addEventListener('click',()=>{if(ui.panel.hidden)ops.interact()});
 ui.q('[data-key=log]').addEventListener('click',()=>{if(ui.panel.hidden)ops.journal()});
 ui.q('[data-key=save]').addEventListener('click',()=>{if(ui.panel.hidden)ops.save()});
}
