import {allows} from '../state.mjs';
import {visitedPlaces,knownWay,ribbon} from './passages.mjs';
import {drawSheet} from './sketch.mjs';

const name=map=>map.name.split(/\s*[·｜]\s*/).at(-1);
const waters=['','低潮','涨潮','低潮与涨潮'];
const perPage=5;
function bearing(state,exit){
 const dx=exit.x-state.x,dy=exit.y-state.y;
 if(!dx&&!dy)return '就在脚下';
 return [dx<0?'西 '+(-dx)+' 格':dx>0?'东 '+dx+' 格':'',dy<0?'北 '+(-dy)+' 格':dy>0?'南 '+dy+' 格':''].filter(Boolean).join('，');
}
export function fieldAtlas(ctx,back){
 const {ui,world,state}=ctx,s=state.player,known=visitedPlaces(s);
 const named=id=>name(world.maps[id]);
 function home(){
  const mark=s.fieldChart?.mark;
  const groups=[...new Set(known.map(id=>String(world.maps[id].act)))].sort((a,b)=>Number(a)-Number(b));
  const options=[];
  if(mark)options.push(['翻到红线 · '+named(mark),()=>place(mark,home)]);
  for(const group of groups)options.push(['第 '+group+' 幕 · '+known.filter(id=>String(world.maps[id].act)===group).length+' 处',()=>list(group,0)]);
  options.push(['回到航海志',back]);
  ui.show('field-chart','走过的航图','我在'+named(s.map)+'。'+(known.length===1?'这页先从脚下记起。走过一个门口，就会在航图上多出一段实线。':'这本航图认得 '+known.length+' 个落脚处。翻到地名，就能查自己由哪条路走过。'),options,'实线按当时行走的方向画。');
 }
 function list(group,page){
  const ids=known.filter(id=>String(world.maps[id].act)===group).reverse();
  const part=ids.slice(page*perPage,(page+1)*perPage);
  const options=part.map(id=>[(s.map===id?'此地 · ':'')+named(id),()=>place(id,()=>list(group,page))]);
  if(page>0)options.push(['前一页',()=>list(group,page-1)]);
  if((page+1)*perPage<ids.length)options.push(['后一页',()=>list(group,page+1)]);
  options.push(['回到总图',home]);
  ui.show('field-chart','第 '+group+' 幕的落脚处',part.map(id=>named(id)).join('　·　'),options,(page+1)+' / '+Math.ceil(ids.length/perPage)+'　按亲历初次到访逆序。');
 }
 function place(id,again){
  const route=knownWay(world,s,id,allows),first=route?.[0],options=[];
  const marked=s.fieldChart?.mark===id;
  if(marked)options.push(['取下红线',()=>{s.fieldChart.mark=null;place(id,again);}]);
  else options.push(['在这里系红线',()=>{ribbon(s,id);place(id,again);}]);
  options.push(['翻回前页',again],['回到航海志',back]);
  let summary;
  if(id===s.map)summary='就在脚下。';
  else if(!first)summary='来过这地方。手里的航页还拼不出从此处回去的一条实线。';
  else{
   const next=first.exit,open=allows(s,next.requires);
   summary='从'+named(s.map)+'起，先去'+named(first.to)+'。\n'+next.label+'　·　'+bearing(s,next)+'。\n';
   summary+=(open?'眼前这段可以动身。':'眼前这段现在走不通。回到出入口可再看当地的线索。')+(first.tides===3?' 低潮和涨潮都曾从这里走过。':' 先前在'+waters[first.tides]+'走过这里。');
   if(route.length>1)summary+='\n其后循已走过的 '+(route.length-1)+' 段。往后各处潮况到时再看。';
  }
  ui.show('field-chart',named(id)+(marked?' · 红线在此':''),summary,options, '脚下的航页　'+named(s.map));
  drawSheet(ui,world.maps[s.map],s,first);
 }
 home();
}
