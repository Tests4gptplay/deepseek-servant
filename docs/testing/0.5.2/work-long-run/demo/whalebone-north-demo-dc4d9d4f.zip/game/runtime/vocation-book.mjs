import {paths,basics,relics,milestones,selected,openPath,terms} from '../rules/vocations.mjs';
import {addXP,stats} from './party.mjs';
import {equip} from './gear.mjs';

export function claim(s,world,id){
 const h=s.expedition.heroes[id],stamp=h.studies||{};
 const waiting=milestones.filter(([flag])=>s.flags[flag]&&!stamp[flag]);
 let award=0;
 for(const [flag,,xp] of waiting){stamp[flag]=true;award+=xp;}
 if(award){h.studies=stamp;addXP(world,id,h,award);}
 return award;
}
export function fieldcraft(s,world,id){
 const path=selected(s,id)||basics[id];if(!path)return '没有此项手艺。';
 const ex=s.expedition,tag=s.map+'|'+id,used=ex.fieldUses||{};
 if(used[tag])return '这里的准备已经做过。换到另一处再看。';
 if(path.field==='tend'){
  let delta=0;for(const member of ex.roster){const h=ex.heroes[member],max=stats(world,member,h.level).hp,n=h.hp>0?Math.min(max-h.hp,5):0;h.hp+=n;delta+=n;}
  if(!delta)return '大家体力完整，敷布留着。';used[tag]=true;ex.fieldUses=used;return '换过干布后，同行者共恢复 '+delta+' 点体力。';
 }
 if(ex.fieldPrep?.[id])return '上次准备仍在，下一场交战会用到。';
 const prep=ex.fieldPrep||{};prep[id]=path.field;ex.fieldPrep=prep;used[tag]=true;ex.fieldUses=used;
 if(path.field==='mark'){
  const m=world.maps[s.map],nearest=[...m.exits].sort((a,b)=>(Math.abs(a.x-s.x)+Math.abs(a.y-s.y))-(Math.abs(b.x-s.x)+Math.abs(b.y-s.y)))[0];
  return '下次起手有 3 点破绽。最近的通路为'+(nearest?.label||'眼前的小路')+'。';
 }
 return path.field==='brace'?'扶索拴牢。下一场首次受击减 3 点。':'已备好隔层。下一场首次潮、寒或震击减 5 点。';
}
export function ledger(ctx,id,again){
 const {ui,state,world,sound}=ctx,s=state.player,h=s.expedition.heroes[id],book=paths[id],choice=selected(s,id),base=basics[id];if(!book)return again();
 const pending=milestones.filter(([key])=>s.flags[key]&&!h.studies?.[key]);
 const claimables=Object.entries(relics).filter(([key,v])=>s.flags[v.source]&&!s.expedition.relicsSeen?.[key]);
 const available=openPath(s,id),path=choice||base;
 const body=[book.title+(choice?' → '+choice.name:' · 基础行当'),choice?choice.desc:'已会 '+base.tech+'，可在途经现场运用'+base.out+'。',
  available?'进阶手记已可练习；两条支路与基础行当均可随时切换。':'进阶手记尚未满页。'+book.where+'或达到 Lv6 后可以修习。',
  choice?'防护　'+terms[choice.ward]+' '+Math.round(choice.amount*100)+'%':'',
  pending.length?'可总结的经历　'+pending.map(q=>q[1]).join('、'):''].filter(Boolean).join('\n');
 const options=[];
 if(available){for(const t of book.choices)if(t.id!==choice?.id)options.push(['研习'+t.name,()=>confirm(t)]);}
 if(choice)options.push(['回到'+book.title,()=>{delete h.career;sound('touch');ledger(ctx,id,again);}]);
 if(pending.length)options.push(['整理航程心得 ＋'+pending.reduce((a,v)=>a+v[2],0)+' 经验',()=>{const xp=claim(s,world,id);sound('solve');ui.toast('已记 '+xp+' 点经验');ledger(ctx,id,again);}]);
 for(const [key,item]of claimables)options.push(['领取'+item.name,()=>{const seen=s.expedition.relicsSeen||{};if(!seen[key]){seen[key]=true;s.expedition.relicsSeen=seen;s.expedition.stock[key]=(s.expedition.stock[key]||0)+1;}ledger(ctx,id,again);}]);
 options.push([path.out,()=>{const txt=fieldcraft(s,world,id);ui.show('field','现场手艺 · '+path.out,txt,[['回到手记',()=>ledger(ctx,id,again)]]);}]);
 options.push(['返回装备',again]);ui.show('vocation',world.actors[id].name+' · 行当手记',body,options);
 function confirm(t){
  ui.show('vocation',t.name,t.desc+'\n战中施用「'+t.tech+'」耗气 '+t.cost+'；'+terms[t.ward]+'防护 '+Math.round(t.amount*100)+'%。\n野外手艺　'+t.out,[['采用这条道路',()=>{h.career=t.id;sound('solve');ledger(ctx,id,again);}],['再想一想',()=>ledger(ctx,id,again)]]);
 }
}
