import {marked} from './state.mjs';

export function entries(world, state) {
 const opening = world.maps[world.start.map].entities || [];
 return Object.values(world.quests || {}).filter(q => {
  const flags = [q.startFlag,q.endFlag,...q.stages || []].filter(Boolean);
  if (flags.some(key=>marked(state,key))) return true;
  return q.kind === 'main' && state.map === world.start.map &&
   opening.some(e => e.action?.id === q.startFlag || e.action?.set === q.startFlag);
 });
}
