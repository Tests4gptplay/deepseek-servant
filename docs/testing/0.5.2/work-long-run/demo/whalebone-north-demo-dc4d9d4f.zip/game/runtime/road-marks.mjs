import {line,poly,oval} from './paint.mjs';
export function roadUse(c,p,f){
 if(f.kind!=='path'||(f.w||0)<6)return;
 const xx=f.x,yy=f.y,w=f.w,d=f.h||1;
 for(const lane of [.28,.72]){
  const v=yy+d*lane;
  for(let i=0;i<3;i++){const a=xx+w*(i*.32+.03),b=xx+w*(i*.32+.31);
   line(c,...p(a,v),...p(b,v),'#978c7163',2.5);line(c,...p(a,v+.045),...p(b,v+.045),'#e2dbc066',1);}
 }
 if(/双车道/.test(f.label||'')){
   const x=xx+w*.57,y=yy+.22;
   poly(c,[p(x-.09,y+.8),p(x+.09,y+.8),p(x+.09,y+.22),p(x+.28,y+.22),p(x,y-.1),p(x-.28,y+.22),p(x-.09,y+.22)],'#c99c64');
   const [sx,sy]=p(x+.43,y+.18);c.save();c.translate(sx,sy);line(c,-6,-1,6,-1,'#a78255',1.3);line(c,0,-3,0,3,'#a78255',1.3);
   oval(c,-5,1,2,1,'#ae8757');oval(c,5,1,2,1,'#ae8757');c.restore();
 }
}
