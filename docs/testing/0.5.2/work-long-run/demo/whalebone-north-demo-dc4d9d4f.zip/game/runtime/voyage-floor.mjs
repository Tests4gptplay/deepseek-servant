import {plate,box,wood,iron} from './voyage-shapes.mjs';
import {line,poly,oval,arc} from './paint.mjs';

export function floorWorks(c,p,map,s,t){
 if(map.id==='winter-ward'){
  plate(c,p,2.2,6.4,16.5,1.3,.4,'#9b8e78');
  for(let i=0;i<8;i++)for(const y of [6.47,7.54]){
    line(c,...p(2.4+i*1.96,y,1),...p(3.9+i*1.96,y,1),'#c0ae8e',1.4);
  }
  for(const [x,y] of [[7,7],[9,6],[11,5]]){const[a,b]=p(x,y);line(c,a-7,b,a+7,b,'#d6c394',2);line(c,a+6,b,a+1,b-4,'#dbc79d',1.4);}
 }
 if(map.id==='ratchet-loft'){
  for(const [from,to] of [[[6.2,5.8],[18.4,9.5]],[[18.5,9.4],[18.7,13.8]],[[8.6,9.5],[18.2,9.5]]]){
   const[a,b]=p(...from,5),[x,y]=p(...to,5);line(c,a,b,x,y,'#4a524d',7);line(c,a,b-1,x,y-1,'#a69b7b',1.5);
   for(let k=0;k<12;k++){const q=(k+.25)/12;line(c,a+(x-a)*q,b+(y-b)*q-2,a+(x-a)*q+3,b+(y-b)*q+2,'#737f72',1.5);}
  }
  const flow=s.flags['drum-vent'];for(let j=0;j<5;j++){const a=p(15+j*.5,8-j*.5);line(c,a[0],a[1]+2,a[0]+7+(flow?6*Math.sin(t+j):0),a[1]+2,flow?'#c1ded1':'#688782',1.8);}
 }
 if(map.id==='flood-stair'||(s.flags['harbor-tilted']&&['wharf-scale','wake-court'].includes(map.id))){
  const [x,y]=map.id==='wharf-scale'?[19,12]:map.id==='wake-court'?[6,10]:[8,10];
  for(let k=0;k<5;k++){const a=p(x+k*.39,y+k*.18),b=p(x+k*.39+1.8,y+k*.18+.7);
   line(c,...a,...b,'#6e8e879e',2);line(c,a[0]+3,a[1]+2,b[0]-4,b[1]+1,'#b0c2adad',1);}
 }
}
export function wardScreens(c,p,x,y){
 for(const [i,tint] of [[0,'#c7bd9c'],[2,'#aab8a8']]){
  const a=p(x+i*1.45,y),b=p(x+i*1.45,y+1.8);
  line(c,a[0],a[1],a[0],a[1]-32,'#726651',2.6);line(c,b[0],b[1],b[0],b[1]-32,'#726651',2.5);
  line(c,a[0],a[1]-32,b[0],b[1]-32,'#88775a',1.6);
  poly(c,[[a[0]-2,a[1]-30],[b[0]+6,b[1]-33],[b[0]+7,b[1]-13],[a[0]-3,a[1]-10]],tint,'#9c927c');
  for(let k=1;k<7;k++)line(c,a[0]+(b[0]-a[0])*k/8,a[1]+(b[1]-a[1])*k/8-29,a[0]+(b[0]-a[0])*k/8-1,a[1]+(b[1]-a[1])*k/8-12,'#9d9c873d',1.4);
 }
}
export function ratchetCase(c,p,f,t){
 const x=f.x,y=f.y,w=f.w||2,h=f.h||2,[a,b]=p(x+w*.5,y+h*.55);
 if(f.kind==='crane'){
  box(c,p,x+.35,y+.3,w*.77,h*.65,0,8,iron);
  for(const side of [-1,1]){line(c,a+side*25,b,a+side*25,b-34,'#796f5d',5);oval(c,a+side*21,b-21,10,15,'#7c8272');}
  for(let i=0;i<7;i++)arc(c,a-18+i*5,b-20,12,-1.65,1.63,i%2?'#657062':'#ac9271',2.4);
 }else{
  box(c,p,x+.2,y+.2,w*.7,h*.72,0,13,iron);
  for(let i=0;i<6;i++)line(c,a-24+i*9,b+5,a-24+i*9,b-23,'#5e6a64',2.6);
  line(c,a-27,b-22,a+26,b-22,'#9f9b83',3);line(c,a-26,b-9,a+26,b-9,'#999680',2);oval(c,a,b-10,5,5,'#bf946b');
 }
}
