import {footing,footingName} from './charts.mjs';
export function waterStep(state,map,previous,s){
  const from=footing(map,previous[0],previous[1]),to=footing(map,s.x,s.y);
  if(!from&&!to){state.waterPassage=null;return '';}
  const last=state.waterPassage,afloat=to==='rowing';
  const count=afloat?(from==='rowing'&&last?.owner===s&&last.map===map.id?last.strokes+1:1):0;
  state.waterPassage={owner:s,map:map.id,from,to,dx:s.x-previous[0],dy:s.y-previous[1],strokes:count,at:performance.now()};
  if(afloat&&from!=='rowing')return '从踏口上艇，方向键或方向盘每划一桨前进一格。';
  if(!afloat&&from==='rowing')return '搭住'+footingName(map,to)+'，收桨上岸。';
  return '';
}
export function waterReadout(root,state,map){
  const s=state.player,k=footing(map,s.x,s.y);
  if(state.waterPassage&&state.waterPassage.owner!==s)state.waterPassage=null;
  if(!k){delete root.dataset.footing;delete root.dataset.oarStrokes;return;}
  const count=state.waterPassage?.map===map.id&&k==='rowing'?state.waterPassage.strokes:0;
  root.dataset.footing=k;root.dataset.oarStrokes=String(count);
  const chapter=root.querySelector('.chapter');
  if(chapter)chapter.textContent+='　·　'+footingName(map,k)+(k==='rowing'&&count?' '+count+'桨':'');
}
