import {face,rod,plate,box,line,oval,poly,beam,hanging,ring,lamp} from '../lamplit-whale/fixtures.mjs';
import {cliff,rib,rack,gauge,lit,capstan,slate,timber} from './shore-craft.mjs';
function tower(c,p,x,y,scale,litNow,t){
 const a=p(x,y);c.save();c.translate(...a);c.scale(scale,scale);
 poly(c,[[-32,1],[-24,-37],[-16,-48],[13,-47],[19,-33],[26,-4],[8,5]],'#776f65','#514f50');
 poly(c,[[-26,-2],[-20,-34],[-10,-42],[-2,-41],[-6,2]],'#ad937b');
 for(let z=9;z<=35;z+=8){line(c,-22+z*.1,-z,17-z*.1,-z+2,'#65594e',1.2);for(const dx of [-13,3,12])line(c,dx+(z%3)*2,-z,dx+(z%3)*2-1,-z+5,'#8c7a63',1.1);}
 c.beginPath();c.moveTo(-6,-1);c.lineTo(-6,-12);c.quadraticCurveTo(-2,-21,3,-13);c.lineTo(3,0);c.fillStyle='#3e4a49';c.fill();line(c,-8,0,5,1,'#c7af89',1.8);
 for(const yy of [-32,-27,-22])line(c,8,yy,14,yy+1,'#c5a780',1.3);
 line(c,-17,-44,13,-45,'#b4a185',2.4);line(c,-17,-47,13,-48,'#514f4a',1.3);
 line(c,-2,-40,-2,-79,'#414b4c',5);line(c,0,-42,0,-79,'#b8a17d',1.5);
 const arms=[[-23,-68],[22,litNow?-72:-58]];for(const [i,[dx,yy]] of arms.entries()){
  line(c,0,-73,dx,yy,'#4d5553',3);line(c,0,-65,dx,yy,'#9c896a',1.4);
  if(litNow)lit(c,dx,yy,15,i?'#ffb07c':'#ffe2a3');
  if(i){poly(c,[[dx-4,yy-2],[dx-1,yy-6],[dx+3,yy-5],[dx+6,yy],[dx+2,yy+4],[dx-3,yy+2]],'#db8b65','#5e5854');line(c,dx,yy-3,dx+1,yy+2,'#ffd3a5',1.3);}
  else{poly(c,[[dx-6,yy-3],[dx+5,yy-3],[dx+5,yy+3],[dx-6,yy+3]],'#dfc393','#5a5650');line(c,dx-3,yy-2,dx-3,yy+2,'#fff3bd',1.6);line(c,dx+2,yy-2,dx+2,yy+2,'#fff3bd',1.6);}
 }c.restore();
}
function onceWreck(c,p,f,s){
 const x=f.x+f.w*.5,y=f.y+f.h*.55,[a,b]=p(x,y);c.save();c.translate(a,b);c.rotate(-.12);
 poly(c,[[-110,-10],[-88,-33],[-37,-42],[43,-35],[83,-20],[101,-30],[93,-5],[71,14],[5,30],[-52,20]],'#594c46','#3c494a');
 poly(c,[[-110,-10],[-85,-30],[-39,-38],[39,-31],[79,-18],[91,-19],[66,2],[6,15],[-55,6]],'#9b7f5f','#5c5950');
 for(let i=0;i<9;i++){const u=-74+i*16,yy=Math.abs(i-4)*1.8;line(c,u,-28+yy,u+6,9-yy,'#63564b',3.8);line(c,u+2,-28+yy,u+8,7-yy,'#c2a582',1.2);}
 for(const [yy,ink] of [[5,'#b78662'],[12,'#cad1b7']]){c.beginPath();c.moveTo(-94,yy-13);c.quadraticCurveTo(-6,yy+28,81,yy-15);c.strokeStyle=ink;c.lineWidth=2.4;c.stroke();}
 poly(c,[[-49,-38],[-10,-53],[5,-48],[35,-31],[5,-33],[-11,-44]],'#877465','#514e48');line(c,-28,-39,-39,-67,'#66564b',4);line(c,-38,-66,-11,-56,'#a98e66',1.5);
 for(let i=0;i<3;i++)line(c,51-i*6,-22,61-i*7,-15,'#ded5b3',1.4);c.restore();
}
export function headwaterFeature(c,p,m,f,s,t){
 const x=f.x,y=f.y,w=f.w,h=f.h;
 if(m.id==='rib-survey'&&f.kind==='wall'){
  const k=x===19;cliff(c,p,x+.1,y+.3,w-.2,h-.6,k?19:24,x);
  rib(c,p,x+w*.40,y+h*.60,k?101:123,k?93:145,k);
  if(x===13)rib(c,p,x+w*.72,y+h*.22,82,91,false);
  if(k){const q=p(x+w*.55,y+h*.76,5);oval(c,...q,12,5,'#9b8e72');ring(c,[q[0]-1,q[1]-1],6,'#ccbb93',.52);}

  if(!k)rack(c,p,x+w*.44,y+h*.75,27);return true;
 }
 if(m.id==='red-beacon'&&f.kind==='wall'){cliff(c,p,x+.16,y+.20,w-.35,h-.45,34,5);tower(c,p,x+w*.53,y+h*.58,1.18,!!s.flags['remote-lit'],t);return true;}
 if(m.id==='wreck-slope'&&f.kind==='boat'){onceWreck(c,p,f,s);return true;}
 if(m.id==='wreck-slope'&&f.kind==='wall'){cliff(c,p,x,y,w,h,34,17);for(let i=0;i<3;i++)rod(c,p,[x+.5+i*.5,y+h*.79,12],[x+1.1+i*.5,y+h*.66,24],'#b9a186',3.4);return true;}
 return false;
}
export function headwaterPlaces(c,p,m,s,t,add){
 const high=s.tide==='high';
 if(m.id==='rib-survey'){add(13.4,6.9,()=>{beam(c,p,[12.7,6.4,13],[14.5,7.1,38],5);rack(c,p,13.7,7.2,41);hanging(c,p,[12.8,6.9,23],[16.8,8.1,13],3,'#a98d64',1.7);});}
 if(m.id==='deep-sluice'){
  add(13.2,6.9,()=>{rack(c,p,12.9,6.7,39);beam(c,p,[12.9,6.7,39],[14.9,6.5,42]);hanging(c,p,[13.2,6.9,30],[15.2,7.1,21],5,'#917b5f');gauge(c,p,14.2,7,high);});
  add(19.7,5.7,()=>tower(c,p,19.7,5.7,.50,!!s.flags['remote-lit'],t));
 }
 if(m.id==='red-beacon'){add(8.2,7.7,()=>capstan(c,p,8.2,7.7));add(17.2,7.6,()=>{rack(c,p,17,7.1,32);lamp(c,p,17.6,7.4,25,t,true,1);gauge(c,p,18.1,7.8,high);});}
 if(m.id==='wreck-slope'){add(15.1,8.8,()=>{capstan(c,p,15.1,8.8);hanging(c,p,[12,8.8,11],[15.2,8.8,9],4,'#b5b99b',2);});}
}
