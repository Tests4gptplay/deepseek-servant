import {paintSaltCarpet,saltRoomFeature,saltRoomInstrument} from './salt-song/inside-a-sounding-hull.mjs';
import {songRoomFurniture} from './salt-song/the-boat-beneath-the-bench.mjs';
import {starSurface,lampsAcrossTheWater} from './star-clock/surfaces-under-starlight.mjs';
import {hearthRise,hearthGround} from './lullaby-worn-landings.mjs';
import {kitchenWorker,companionsWatching} from './lullaby-faces-at-work.mjs';
import {kitchenHomes} from './lullaby-port-homes.mjs';
import {hearthFeature} from './lullaby-hearth-art.mjs';
import {hearthStage} from './lullaby-guides-in-scene.mjs';
import {currentPair,residentPresent} from './lullaby-partners.mjs';
import {starSky,starFeature} from './star-clock/the-copper-dome-and-the-black-shore.mjs';
import {starPlaces} from './star-clock/the-transit-and-the-box-on-the-quay.mjs';
import {makeShoreProjection} from './coast-light/the-headland-has-a-horizon.mjs';
import {deck,architecture,anchorItem,anchorPlaces,chamberLight} from './anchor-release/scene.mjs';
import {profileAt} from './coast-light/shore-profiles.mjs';
import {waterBeyondTheQuay} from './coast-light/the-water-outside-the-walking-grid.mjs';
import {movingWater} from './driftbay-watermarks.mjs';
import {bayLandmarks} from './driftbay-landmarks.mjs';
import {baySky} from './driftbay-horizon.mjs';
import {bayGround} from './driftbay-shelves.mjs';
import {bayLife,bayObject} from './driftbay-life.mjs';
import {northern,northernHorizon,watchLight,northernFloor,northernFeature,northernEntity,northernPlaces} from './north-lights/scene.mjs';
import {expandedSample} from './quaybill-close-reading.mjs';
import {quaybillFeature} from './quaybill-wharf-art.mjs';
import {quaybillInstrument} from './quaybill-instruments.mjs';
import {lamplit,lowerHouses,whaleFeature,whaleEntity,whaleFloor,whalePlaces} from './lamplit-whale/scene.mjs';
import {puppetPlace,parkedPartner} from './second-shadow/light-through-the-puppet.mjs';
import {roleAtWork} from './second-shadow/where-the-ropeman-stands.mjs';
import {familyWater} from './winter-family/the-water-under-the-table.mjs';
import {familyBuildings} from './winter-family/kitchen-smoke-and-rib-shadows.mjs';
import {shoreFamily} from './winter-family/the-shawl-and-the-reed-spoon.mjs';
import {windCloth,windSceneObject} from './windloom-cloth-yard.mjs';
import {watchLanding} from './winter-voice/the-last-two-landings.mjs';
import {portBuilding,clearFront} from './first-harbor/buildings.mjs';
import {portPerson} from './first-harbor/people.mjs';
import {portFloor,portPlaces} from './first-harbor/places.mjs';
import {drawVoiceRoom} from './winter-voice/rooms.mjs';
import {dockDetail,visibleLoad} from './keelpot-working-quay.mjs';
import {paintKeelpot} from './keelpot-tidal-art.mjs';
import {inhabitedHeel} from './folded-house-art/rooms.mjs';
import {heelturnJoinery} from './heelturn-joinery.mjs';
import {landmarkFeature,landmarkFloor,landmarkCourt} from './winter-playhouse/places.mjs';
import {scorerockHorizon} from './scorerock-horizon.mjs';
import {saltcoatEntity,saltcoatFeature,saltcoatDetail,saltcoatGallery} from './saltcoat-scene/index.mjs';
import {workshopProp} from './drawer-case/workshop.mjs';
import {quayProp,caseFocus,caseStudy} from './drawer-case/quay-and-closeup.mjs';
import {wardBuildings,marketPlaces} from './return-harbor/market.mjs';
import {clothingHouseObject,clothingHouseFloor} from './return-harbor/cloth-house.mjs';
import {homeSquareObject} from './return-harbor/square.mjs';
import {returnShoreObject} from './return-harbor/wharf.mjs';
import {berthObjects,placeBerth} from './salt-berth/door-boat.mjs';
import {berthRoomObject,placeBerthInterior} from './salt-berth/low-arch.mjs';
import {houseRoomFloor,interiors} from './home-life/room-surfaces.mjs';
import {houseRoomFeature} from './home-life/room-fittings.mjs';
import {householdObject} from './home-life/index.mjs';
import {easedHeight,shoulderScene,shoulderHeight} from './whale-breath.mjs';
import {workAlongShore} from './whale-workplaces.mjs';
import {winterRig} from './winter-pilot-rig.mjs';
import {fieldScenes} from './field-art.mjs';
import {oldQuarters,quayArchitecture} from './quay-architecture.mjs';
import {focalTitle,surveyFrame} from './worksite-focus.mjs';
import {partition,floorLane} from './workshop-walls.mjs';
import {workshopBays} from './workshop-bays.mjs';
import {nightPlaces,nightFeature} from './bell-workshops.mjs';
import {saltPlaces,saltWorkshop} from './rye-workshops.mjs';
import {wrenPlaces,wrenFeature} from './wren-workshops.mjs';
import {housePlaces,houseFeature,houseFloor} from './harbor-houses.mjs';
import {exchangeFeature,exchangeItem,shoalWater} from './exchange-art.mjs';
import {winterHarborFeature,winterHarborItem} from './winter-harbor-art.mjs';
import {relayFeature,relayItem} from './evacuation-art.mjs';
import {nightSky} from './household-art.mjs';
import {tiltedPlace,streetGround,streetObjects,streetItem} from './tilted-doors.mjs';
import {courtPlace,courtGround,courtObjects,courtItem} from './winter-courts.mjs';
import {sky,poly,line,oval,arc} from './paint.mjs';
import {tile,material} from './tiles.mjs';
import {prop} from './scenery.mjs';
import {figure,creature} from './figures.mjs';
import {funeralCart, shore, mooring, coils} from './quay.mjs';
import {headland} from './headland.mjs';
import {roadUse} from './road-marks.mjs';
import {district,enclosed,hull,roomBackdrop} from './districts.mjs';
import {shell} from './cutaway.mjs';
import {vigilWalls,vigilFixtures} from './vigil-room.mjs';
import {roofFloor,belowRoofs,roofFeature} from './roof-quarter.mjs';
import {rationProp,berthState} from './ration-quay.mjs';
import {works} from './harbor-industry.mjs';
import {maritime,waterMarks} from './hold-salt.mjs';
import {hour,light,frontOpacity} from './atmosphere.mjs';
import {clue} from './clues.mjs';
import {interiorProp} from './interior-furniture.mjs';
import {coastCliffs} from './coastal-cliffs.mjs';
import {wildCoast,coastWater,capeLand} from './coastal-ground.mjs';
import {graveGround} from './grave.mjs';
import {floorWorks} from './voyage-floor.mjs';
import {lateHorizon,nearPoint} from './voyage-horizon.mjs';
import {socialFeature,socialItem} from './social-scenes.mjs';
import {northFeature,northItem} from './north-sites.mjs';
import {winterFeature,winterItem} from './winter-sites.mjs';
import {finalFeature,finalItem} from './finale-sites.mjs';
import {paintCombItem} from './comb-art.mjs';
import {paintCombGround} from './comb-ground.mjs';
import {combCamera} from './comb-camera.mjs';
import {bays as travelBays} from './tidal-route/charts.mjs';
import {paintBay,waterFeature} from './tidal-route/bays.mjs';
import {paintLocal,localReplacement} from './tidal-route/local-works.mjs';
import {paintWaterVoyager} from './tidal-route/rowing.mjs';
export function makeScene(canvas,world,get){
 const c=canvas.getContext('2d',{alpha:false}),reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
 let w=1,h=1,zoom=1,camX,camY,prevMap,frame=0,stamp=0;
 const mats=new Map();
 function draw(ms){
  const state=get(),s=state.player,map=world.maps[s.map],battle=state.battle,t=reduce?0:ms/1000;
  const rect=canvas.getBoundingClientRect(),ratio=Math.min(devicePixelRatio||1,2);
  w=Math.max(1,Math.round(rect.width));h=Math.max(1,Math.round(rect.height));
  if(canvas.width!==Math.round(w*ratio)||canvas.height!==Math.round(h*ratio)){canvas.width=Math.round(w*ratio);canvas.height=Math.round(h*ratio);}
  c.setTransform(ratio,0,0,ratio,0,0);const area=district(map),winter=courtPlace(map.id),street=tiltedPlace(map.id),family=winter||street,indoors=!family&&enclosed(area);
  if(starSky(c,w,h,map,t)){lampsAcrossTheWater(c,w,h,map,t);}else if(map.driftbay)baySky(c,w,h,map.driftbay,t);else if(family)nightSky(c,w,h,winter);else if(indoors)roomBackdrop(c,w,h,area);else if(!(!battle&&northernHorizon(c,w,h,map,s,t))&&!lateHorizon(c,w,h,map,t,s)){sky(c,w,h,t,!hull(map));if(!hull(map))headland(c,w,h,t);}
  zoom=indoors?Math.max(.72,Math.min(1.42,w/880,h/490)):Math.max(.76,Math.min(1.42,w/850,h/470));
  if(w<620)zoom=Math.max(zoom,indoors?.97:1.04);
  const dt=Math.max(0,Math.min(1,(ms-stamp)/130));stamp=ms;
  if(prevMap!==s.map||reduce){camX=s.x;camY=s.y;prevMap=s.map;}else{camX+=(s.x-camX)*dt;camY+=(s.y-camY)*dt;}
  const windFight=!!battle?.windloom;canvas.parentElement.toggleAttribute('data-windloom',windFight);
  const billScene=map.id.startsWith('quaybill-'),billActive=billScene&&state.scenicFocus?.map===s.map;canvas.parentElement.toggleAttribute('data-quaybill',billScene);
  const anchorFight=battle?.spec?.id==='anchor-clutch',pinShot=map.id==='ratchet-loft'&&!battle&&Math.abs(s.x-13)+Math.abs(s.y-13)<=1;
  const anchorX=anchorFight?(w>760?.51:.52):pinShot&&w<700?.44:windFight?(w>760?.38:.56):billActive?(w>760?.33:.5):.5;
  if(anchorFight)zoom=Math.min(w>760?1.65:1.29,zoom*1.23);
  if(windFight)zoom=Math.min(w>760?1.78:1.48,zoom*1.25);
  const anchorY=anchorFight?(w<700?.385:.43):pinShot&&w<700?.45:windFight?(w>760?.53:.34):billActive?(w>760?.51:.29):battle?(w<700?.39:.48):family?(w<700?.425:.53):indoors?.53:.59;
  const track=indoors&&!battle?(w<550?.78:.43):1;
  const focus=state.scenicFocus?.map===s.map?state.scenicFocus:null,motion=state.scenicMotion?.map===s.map?state.scenicMotion:null;
   const working=motion&&!reduce&&ms/1000-motion.at<1.8,rise=reduce?shoulderHeight(s.flags):easedHeight(s,motion,t);
   const fraction=working?Math.max(0,Math.min(1,(ms/1000-motion.at)/1.8)):1;
   const blend=flag=>{const end=Number(!!s.flags[flag]),start=working?Number(!!motion.fromFlags?.[flag]):end;return start+(end-start)*fraction*fraction*(3-2*fraction);};
   const shot=!battle&&(focus||(working?motion:null)),title=shot?focalTitle(s.map):'';
   canvas.parentElement.toggleAttribute('data-instrument',!!title||!!caseFocus(shot));
   canvas.parentElement.toggleAttribute('data-household',family&&!battle);
   if(working)canvas.dataset.motion=motion.id;else if(canvas.dataset.motion)delete canvas.dataset.motion;
   let viewX=camX*track+(map.width-1)*.5*(1-track),viewY=camY*track+(map.height-1)*.5*(1-track);
   if(map.id==='ratchet-loft'&&!battle&&w<620&&s.x===11&&s.y===11){viewX+=.42;viewY-=.22;}if(shot){viewX+=(Math.max(-2.5,Math.min(2.5,shot.x-viewX)))*.5;viewY+=(Math.max(-2.5,Math.min(2.5,shot.y-viewY)))*.5;}
   else if(map.id==='split-cistern'&&s.x<8){viewX+=1.5;viewY-=.45;}
  c.save();c.translate(w*anchorX,h*anchorY);c.scale(zoom,zoom);
  if(battle?.comb){const camera=combCamera(battle,ms,reduce);c.translate(camera.x,camera.y);canvas.dataset.combFocus=camera.focus;}else if(canvas.dataset.combFocus)delete canvas.dataset.combFocus;
   const ordinary=(x,y,z=0)=>[(x-y-viewX+viewY)*31,(x+y-viewX-viewY-1)*14-z-hearthRise(map,x,y)];
  const p=battle?ordinary:makeShoreProjection(map,viewX,viewY,anchorY,h,zoom,ordinary);
  const visible=(x,y,pad=90)=>x>-w*anchorX/zoom-pad&&x<w*(1-anchorX)/zoom+pad&&y>-(h*anchorY)/zoom-pad&&y<(h*(1-anchorY))/zoom+pad;
  if(area==='roofs'){belowRoofs(c,p,map);if(!battle&&!s.flags['harbor-tilted'])lowerHouses(c,p,map,t);}
  if(!mats.has(map.id))mats.set(map.id,Array.from({length:map.height},(_,y)=>Array.from({length:map.width},(_,x)=>material(map,x,y))));
  const onNorth=!battle&&northern(map.id);const actTwo=!battle&&!s.flags['harbor-tilted']&&lamplit(map.id);const livingPort=!battle&&!s.flags['harbor-tilted']&&['wharf-scale','rope-market','lower-tide','coffin-hoist','wake-court','wick-house'].includes(map.id);const colors=mats.get(map.id),ordered=[];waterBeyondTheQuay(c,p,map,s,t,colors,visible);coastCliffs(c,p,map,t,colors,visible);
  for(let y=0;y<map.height;y++)for(let x=0;x<map.width;x++){
    if(map.driftbay)continue;
    const [a,b]=p(x+.5,y+.5);if(!visible(a,b,56))continue;
    const edge=[];if(x===map.width-1)edge.push(0);if(y===map.height-1)edge.push(1);
    if(!starSurface(c,p,map,x,y,colors[y][x],s.tide,t))tile(c,p,x,y,colors[y][x],s.tide,t,wildCoast(map.id)?[]:edge);
    if(!indoors&&!travelBays.has(map.id)&&!wildCoast(map.id)&&colors[y][x]!=='water'){
      for(const [dx,dy,side] of [[0,1,'south'],[1,0,'east']]){
        if(colors[y+dy]?.[x+dx]!=='water')continue;
        ordered.push([x+y+1.96,()=>{
          shore(c,p,x,y,side,t);
          if((x+y)%3===0){const pt=side==='south'?p(x+.4,y+.95):p(x+.94,y+.42);mooring(c,...pt,t);if((x+y)%2===0)coils(c,pt[0]+7,pt[1]-4);}
        }]);
      }
    }
  }
  paintCombGround(c,p,map,s,t);paintSaltCarpet(c,p,map);starPlaces(c,p,map,s,t,ordered);songRoomFurniture(c,p,map,s,t,ordered);
   if(area==='roofs')roofFloor(c,p,map);
  houseRoomFloor(c,p,map);
  marketPlaces(c,p,map,s,ordered);clothingHouseFloor(c,p,map,s,ordered);
  placeBerth(c,p,map,s,t,ordered);placeBerthInterior(c,p,map,s,ordered);
  if(family){
    if(winter){courtGround(c,p,map,s,t);if(!landmarkCourt(c,p,map,s,t,ordered))courtObjects(c,p,map,s,t,ordered,blend);}
    else{streetGround(c,p,map,s,t);streetObjects(c,p,map,s,t,ordered,blend);}
  }else{
  floorLane(c,p,map,s);houseFloor(c,p,map,s);workshopBays(c,p,map,s,t,ordered);housePlaces(c,p,map,s,t,ordered);
   saltPlaces(c,p,map,s,t,ordered);wrenPlaces(c,p,map,s,t,ordered);nightPlaces(c,p,map,s,t,ordered);
   floorWorks(c,p,map,s,t);coastWater(c,p,map,t);capeLand(c,p,map);graveGround(c,p,map,s);shoalWater(c,p,map,s,t);
  shoulderScene(c,p,map,s,rise,t,ordered);workAlongShore(c,p,map,s,t,ordered);winterRig(c,p,map,s,t,ordered,blend);oldQuarters(c,p,map,s,t,ordered);fieldScenes(c,p,map,s,t,ordered);
   if(area==='ration')ordered.push([32.8,()=>berthState(c,p,map,s,t)]);
  }
  if(indoors){
   poly(c,[p(0,0),p(map.width,0),p(map.width,map.height),p(0,map.height)],area==='hold'?'#344a4859':'#60453828');
   shell(c,p,map,area,s,t);
   if(area==='vigil'){vigilWalls(c,p,s,t);vigilFixtures(c,p,s,t,ordered);}
  }
  hearthGround(c,p,map,s,t,ordered);hearthStage(c,p,map,s,t,ordered);companionsWatching(c,p,map,s,t,ordered);
  if(map.driftbay){bayGround(c,p,map,s,t,visible);bayLandmarks(c,p,map,s,t,ordered);movingWater(c,p,map,s,t,ordered);bayLife(c,p,map,s,t,ordered);}
  if(area==='hold'||map.biome==='salt-market'||area==='yard')waterMarks(c,p,map,s,t);
  paintBay(c,p,map,s,t,visible);paintLocal(c,p,map,s);deck(c,p,map,s,t);if(actTwo)whaleFloor(c,p,map,s,t);if(onNorth)northernFloor(c,p,map,s,t);if(livingPort)portFloor(c,p,map,s);landmarkFloor(c,p,map,s,t);familyWater(c,p,map,s,t);
  if(map.id!=='salt-song-room'&&map.id!=='under-the-doorknock'&&!family&&!interiors[map.id])for(const f of map.features||[])if(!travelBays.has(map.id))roadUse(c,p,f);
  if(!family)for(const f of map.features||[]){const [a,b]=p(f.x+(f.w||1)/2,f.y+(f.h||1)/2);if(visible(a,b,220))ordered.push([actTwo&&map.id==='counterlift'&&f.label==='反提双筐'?f.x+f.y-.45:livingPort&&clearFront(f,camX,camY)?Math.min(f.x+f.y+(f.kind==='weighbeam'?((f.w||1)+(f.h||1))*.5-.2:(f.w||1)+(f.h||1)-.8),camX+camY+.45):f.x+f.y+(f.kind==='weighbeam'?((f.w||1)+(f.h||1))*.5-.2:(f.w||1)+(f.h||1)-.8),()=>{c.save();c.globalAlpha*=livingPort&&clearFront(f,camX,camY)?1:frontOpacity(p,f,camX,camY,area);try{if(saltRoomFeature(c,p,map,f))return;if(starFeature(c,p,map,f))return;if(profileAt(c,p,map,f))return;if(architecture(c,p,map,f,s,t))return;if(puppetPlace(c,p,map,f,s,t))return;if(kitchenHomes(c,p,map,f,t)||hearthFeature(c,p,map,f,s,t)||quaybillFeature(c,p,map,f,s,t)||windCloth(c,p,map,f,s,t))return;if(watchLanding(c,p,map,f,s,t)||familyBuildings(c,p,map,f,s,t))return;if(drawVoiceRoom(c,p,map,f,s,t))return;if(paintKeelpot(c,p,map,f,s,t))return;if(inhabitedHeel(c,p,map,f,s))return;if(heelturnJoinery(c,p,map,f,s))return;if(landmarkFeature(c,p,map,f,s,t))return;if((onNorth&&northernFeature(c,p,map,f,s,t))||(actTwo&&whaleFeature(c,p,map,f,s,t))||(livingPort&&portBuilding(c,p,map,f,s,t))||saltcoatFeature(c,p,map,f,s)||waterFeature(c,p,map,f,s,t)||localReplacement(map,f))return;if(workshopProp(c,p,f,s)||quayProp(c,p,f,s))return;if(wardBuildings(c,p,map,f)||clothingHouseObject(c,p,map,f))return;if(homeSquareObject(c,p,f,s)||returnShoreObject(c,p,f,s,t))return;if(berthObjects(c,p,f,s,t)||berthRoomObject(c,p,map,f,s))return;if(householdObject(c,p,f,s,t))return;if(houseRoomFeature(c,p,map,f,s))return;if(quayArchitecture(c,p,map,f,s))return;partition(c,p,map,f,s);if(nightFeature(c,p,map,f,s,t)||saltWorkshop(c,p,map,f,s,t)||wrenFeature(c,p,map,f,s,t)||houseFeature(c,p,map,f,s,t)||exchangeFeature(c,p,map,f,s,t)||winterHarborFeature(c,p,map,f,s,t)||relayFeature(c,p,map,f,s,t)||socialFeature(c,p,map,f,s,t)||northFeature(c,p,map,f,s,t)||winterFeature(c,p,map,f,s,t)||finalFeature(c,p,map,f,s,t))return;
    if(maritime(c,p,map,f,area,s,t)||works(c,p,f,area,s,t))return;
    if(indoors&&interiorProp(c,p,f,area,s,t))return;
    if(area==='roofs'&&roofFeature(c,p,f,map))return;
    if(area==='ration'&&rationProp(c,p,f,s,t))return;
    if(f.kind!=='coffin-cart'||!s.flags['coffin-aboard'])prop(c,p,f,t,s.tide,s.flags);}finally{c.restore();}}]);}
  for(const e of map.exits||[]){const [a,b]=p(e.x+.5,e.y+.5);if(visible(a,b))poly(c,[[a-7,b],[a,b-3],[a+7,b],[a,b+3]],'#dfc088aa','#867758');}
  for(const e of map.entities||[]){if(battle?.spec?.entityId===e.id)continue;
    if(!residentPresent(s,e))continue;
    if(!s.flags['harbor-tilted']&&['rescue-porters','court-roll','thread-hand','press-workers','sling-wards'].includes(e.id))continue;const [a,b]=p(e.x+.5,e.y+.5);if(!visible(a,b))continue;ordered.push([e.x+e.y+1,()=>{
    nearPoint(c,a,b,t,!battle&&Math.abs(s.x-e.x)+Math.abs(s.y-e.y)<=1);
    if(saltRoomInstrument(c,p,map,e))return;if(anchorItem(c,p,map,e,s,t,focus,blend,!!battle))return;if(shoreFamily(c,a,b,t,e)||kitchenWorker(c,a,b,t,e)||bayObject(c,a,b,t,e)||quaybillInstrument(c,a,b,t,e,s)||windSceneObject(c,a,b,t,e,s)||dockDetail(c,a,b,t,e,s))return;if((onNorth&&northernEntity(c,p,map,e,s,t))||(actTwo&&whaleEntity(c,p,map,e,s,t))||saltcoatEntity(c,p,map,e,s,focus,motion,t,reduce)||(livingPort&&portPerson(c,p,map,e,s,t))||paintCombItem(c,p,map,e,s,t))return;
    if(family){
      if(streetItem(c,p,map,e,s,t)||courtItem(c,p,map,e,s,t))return;
      if(e.kind==='npc'){figure(c,a,b,e.id,t,{scale:1.08});return;}
    }
    if(exchangeItem(c,p,map,e,s,t)||winterHarborItem(c,p,map,e,s,t)||relayItem(c,p,map,e,s,t)||socialItem(c,p,map,e,s,t)||northItem(c,p,map,e,s,t)||winterItem(c,p,map,e,s,t)||finalItem(c,p,map,e,s,t))return;
    if(e.kind==='npc'){
      if(e.id==='pall-bearer'&&!s.flags['coffin-aboard']&&!(map.features||[]).some(f=>f.kind==='coffin-cart'))funeralCart(c,a+23,b-10);
      figure(c,a,b,e.id,t,{scale:1.08});
    }
    else if(e.kind==='enemy'||e.action?.type==='battle')creature(c,a,b,t);
    else{if(indoors&&interiorProp(c,p,e,area,s,t))return;
     if(area==='ration'&&rationProp(c,p,e,s,t))return;
     if(!clue(c,a,b,e)&&!(e.id==='balance-arm'&&(map.features||[]).some(f=>f.kind==='weighbeam')))prop(c,p,{kind:e.name||e.id,x:e.x,y:e.y},t,s.tide,s.flags);oval(c,a,b,6,2.5,'#847853');line(c,a,b-2,a,b-11,'#77694c',1.5);poly(c,[[a,b-17],[a+3,b-13],[a,b-10],[a-3,b-13]],'#f0d596','#786e50');}
  }]);}
  const [ax,ay]=p(camX+.5,camY+.5),dash=Math.min(1,Math.abs(s.x-camX)+Math.abs(s.y-camY));
  if(!battle)ordered.push([camX+camY+1.06,()=>{if(paintWaterVoyager(c,ax,ay,map,s,state,t,w))return;oval(c,ax,ay,12,4,'#fae4a884');figure(c,ax,ay,s.cycle?.id==='afterwatch'?'yuanzi':(currentPair(s)?.active||roleAtWork(s)),t,{scale:w<620?1.27:1.15,stride:dash>.09?t*14:0,flip:s.facing[0]<0||s.facing[1]>0,mark:true});visibleLoad(c,ax,ay,s);}]);
  if(!battle){anchorPlaces(c,p,map,s,t,ordered);parkedPartner(c,p,map,s,t,ordered);saltcoatGallery(c,p,map,s,ordered);}if(actTwo)whalePlaces(c,p,map,s,t,ordered);if(onNorth)northernPlaces(c,p,map,s,t,ordered);if(livingPort)portPlaces(c,p,map,s,t,ordered);
  ordered.sort((a,b)=>a[0]-b[0]);for(const [,paint] of ordered)paint();
  if(battle)state.paintBattle(c,ax,ay,t,battle);
  c.restore();if(!family)light(c,w,h,hour(map,s),indoors);if(onNorth)watchLight(c,w,h,map,s);chamberLight(c,w,h,map);if(title)surveyFrame(c,w,h,map,s,shot,rise,t,blend);if(shot)caseStudy(c,w,h,shot,s,t,reduce);if(!battle)saltcoatDetail(c,w,h,map,s,focus,motion,t,reduce);
  if(!battle)scorerockHorizon(c,w,h,map,s,t,reduce);
  if(billActive&&!battle)expandedSample(c,w,h,focus?.id,s);
 }
 function loop(ms){draw(ms);frame=requestAnimationFrame(loop);}
 frame=requestAnimationFrame(loop);return {stop(){cancelAnimationFrame(frame);}};
}
