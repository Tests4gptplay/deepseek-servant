import {box,plate,poly,oval,face,stroke,gable,doorFront,windowFront,rainpipe,renderPlaster,timber,stone} from './form.mjs';
import {plans,walls,roofs} from './lots.mjs';
import {tradeFront,roofTrade} from './trades.mjs';
import {shops} from './craft.mjs';
export function clearFront(f,cx,cy){if(f.kind!=='building')return false;const x=cx+.5,y=cy+.5;
 return (y>=f.y+f.h-.03&&x>=f.x-.3&&x<=f.x+f.w+.34)||(x>=f.x+f.w-.03&&y>=f.y-.3&&y<=f.y+f.h+.34);
}
const pair=(v,lo,hi)=>Math.min(hi,Math.max(lo,v));
function endWindow(c,p,x,y,z,w,h,open){
 face(c,p,[[x,y,z],[x,y+w,z],[x,y+w,z+h],[x,y,z+h]],'#756f5c');
 face(c,p,[[x+.012,y+.06,z+1.5],[x+.012,y+w-.06,z+1.5],[x+.012,y+w-.06,z+h-1.3],[x+.012,y+.06,z+h-1.3]],open?'#455753':'#68847b');
 stroke(c,p,[x+.015,y+w*.50,z+.5],[x+.015,y+w*.50,z+h],'#a5a087',1.2);
 stroke(c,p,[x+.03,y-.055,z-.6],[x+.03,y+w+.06,z-.6],'#c4b798',1.65);
}
function loggia(c,p,x,y,w,z,tone){
 box(c,p,x,y,w,.36,z-3,3,timber);
 for(let u=0;u<=w+.01;u+=.45)stroke(c,p,[x+u,y+.34,z],[x+u,y+.34,z+8],tone,1.55);
 stroke(c,p,[x,y+.34,z+8],[x+w,y+.34,z+8],tone,2.3);
 for(let u=.2;u<w;u+=1.18)stroke(c,p,[x+u,y-.15,z-9],[x+u,y+.30,z-2],tone,2.3);
}
export function portBuilding(c,p,map,f,s,t){
 if(f.kind!=='building')return false;const row=plans[map.id]?.find(v=>v[0]===f.label);if(!row)return false;
 const [,type,z,rise,roof,wall]=row,wp=walls[wall],rp=roofs[roof];
 const x=f.x+.07,y=f.y+.07,w=f.w-.14,h=f.h-.14,Y=y+h+.008,X=x+w+.01;
 const facePt=p(s.x+.5,s.y+.5),corner=p(x,y),lo=p(x,y+h)[0],hi=p(x+w,y)[0],front=p(x+w,y+h)[1];
 if(!clearFront(f,s.x,s.y)&&s.x+s.y+1.1<x+y+w+h-.78&&facePt[0]>lo-8&&facePt[0]<hi+8&&facePt[1]>corner[1]-z-rise-14&&facePt[1]<front+7){
  c.globalAlpha=Math.min(c.globalAlpha,.38);
 }
 plate(c,p,x+.13,y+.20,w+.18,h+.10,0,'#404e4b42');
 box(c,p,x,y,w,h,0,z,wp);
 face(c,p,[[x,Y,0],[x+w,Y,0],[x+w,Y,5],[x,Y,5]],'#8e8d78');
 face(c,p,[[X,y,0],[X,y+h,0],[X,y+h,5],[X,y,5]],'#778278');
 for(let u=.34;u<w;u+=.58)stroke(c,p,[x+u,Y,0],[x+u+.04,Y,4.6],'#6b756d',.8);
 for(let u=.28;u<h;u+=.62)stroke(c,p,[X,y+u,0],[X,y+u-.04,4.8],'#656e66',.75);
 renderPlaster(c,p,x,y,w,h,z,37+f.x*41+f.y*13);
 const domestic=['balcony','bunks','wick','guard'].includes(type);
 const doorW=type==='store'||type==='winch'?1.22:domestic?.86:.81;
 const center=type==='wick'?11.48:x+w*(type==='scale'?.53:type==='soup'?.62:.30);
 const dx=pair(center-doorW*.5,x+.17,x+w-doorW-.26);
 const open=type==='wick'||['soup','rope','wake','winch','fish'].includes(type);
 doorFront(c,p,dx,Y+.004,doorW,type==='store'?47:45,0,open);
 for(let u=x+.40;u<x+w-.50;u+=1.16){
  if(u+.45>dx-.17&&u<dx+doorW+.15)continue;
  windowFront(c,p,u,Y+.012,15,.50,16,domestic||type==='soup',type==='wick'||type==='soup');
 }
 const story=z>=75;
 if(story){
  stroke(c,p,[x,Y,48.5],[x+w,Y,48.5],'#8b8167',2.2);stroke(c,p,[X,y,48.5],[X,y+h,48.5],'#7b816f',1.7);
  for(let u=x+.32;u<x+w-.42;u+=1.12)windowFront(c,p,u,Y+.014,54,.44,Math.min(18,z-59),type==='wick'||type==='balcony',type==='wick');
  if(domestic)loggia(c,p,x+w*.43,Y+.025,w*.47,49,'#79694f');
 }
 for(let v=.42;v<h-.52;v+=1.22){endWindow(c,p,X,y+v,15,.54,16,domestic);if(story)endWindow(c,p,X,y+v+.08,54,.44,Math.min(17,z-59),false);}
 stroke(c,p,[x,Y,0],[x,Y,z],'#978c74',1.5);rainpipe(c,p,x+w-.1,Y+.035,z);
 gable(c,p,x,y,w,h,z,rise,rp,roof);roofTrade(c,p,type,x,y,w,h,z,rise,t);
 tradeFront(c,p,type,x,Y,w,h,z,dx,doorW,t,s);shops(c,p,type,x,Y,w,h,z,t);
 return true;
}
