import {line,oval,rand} from '../paint.mjs';
const pictures=new Map();
for(const [place,file] of [['edge-bleach','the-worn-back-of-the-turning-stone'],['burial-cape','the-limestone-at-the-funeral-path']]){
 if(typeof Image==='undefined')continue;
 const face=new Image();
 face.src=new URL('../../assets/coast-light/'+file+'.png',import.meta.url).href;
 pictures.set(place,face);
}
function seaPink(c,p,x,y,seed,flowers){
 const [a,b]=p(x,y);
 oval(c,a+2,b+1,7,1.7,'#52635e6b');
 for(let j=0;j<8;j++){
  const shift=(rand(seed,j)-.5)*10,length=3+rand(j+17,seed)*6;
  line(c,a+shift*.27,b,a+shift,b-length,'#63755b',.9);
  if(flowers&&j%3===0){
   oval(c,a+shift,b-length,1.35,1.05,'#af8881');oval(c,a+shift-.35,b-length-.4,.65,.42,'#e2c1aa');
  }
 }
}
function scree(c,p,x,y,seed){
 const [a,b]=p(x,y),r=1.1+rand(seed,4)*3;
 c.beginPath();c.moveTo(a-r,b);c.lineTo(a-r*.48,b-r*.46);c.lineTo(a+r*.5,b-r*.38);c.lineTo(a+r,b+.15);c.lineTo(a+r*.25,b+r*.25);c.closePath();c.fillStyle='#758278';c.fill();
 line(c,a-r*.48,b-r*.46,a+r*.5,b-r*.38,'#bcbca5',.68);
}
export function profileAt(c,p,m,f){
 const spit=m.id==='edge-bleach',cape=m.id==='burial-cape';
 if(!(spit||cape)||f.kind!=='wall'||f.x!==(spit?3:2)||f.y!==4)return false;
 const image=pictures.get(m.id);
 if(!image?.complete||!image.naturalWidth)return false;
 const cx=f.x+3+(cape?.20:0),cy=f.y+2+(cape?.22:0);
 const [x,y]=p(cx,cy),right=p(cx+.5,cy-.5),down=p(cx+.5,cy+.5);
 const scaleX=(right[0]-x)/31,scaleY=.67+.33*Math.min(1,Math.max(.10,(down[1]-y)/14));
 const [shadeX,shadeY]=p(f.x+2.9,f.y+2.42);
 oval(c,shadeX+6,shadeY+3,spit?68:59,spit?16:13,'#51645e54');
 c.drawImage(image,x-176*scaleX,y-160*scaleY,350*scaleX,235*scaleY);
 const seam=spit?[[1.28,3.59],[2.02,3.92],[4.05,3.98],[5.48,2.88]]:[[.52,3.24],[1.16,3.69],[2.3,3.84],[4.64,3.35]];
 for(const [i,[u,v]] of seam.entries()){
  for(let j=0;j<6;j++)scree(c,p,f.x+u+(rand(i+91,j)-.5)*.57,f.y+v+.19+rand(j,i+219)*.34,i*31+j);
  seaPink(c,p,f.x+u+.07,f.y+v+.26,77+i,cape);
 }
 return true;
}
