function evidence(c){
 const voice=c.witness;
 if(!voice||voice.round!==c.round)return false;
 return c.material?.[voice.key==='runner'?'basket':'hull']===c.round;
}

export function billDesk(api){
 const {c,s,show,note,mark}=api;
 if(c.verdict){note('留在桌上的单',c.verdict==='quiet'?'盲号两笔，四袋随船、两袋供岸灶。晏家先垫未盖全名的两袋。':'红榜两袋转用。晏甫自签商行，换回公仓的兑粮票；病人没有落名。');return;}
 const retract=()=>{c.draft=null;note('收回自己的手迹','墨条揭了下来，留下手印的时间还有。新的比对仍可继续。');};
 const wrong=()=>{
  c.round++;c.accused=(c.accused||0)+1;c.draft='accused';c.consent=0;
  s.flags['quaybill-material']=false;s.flags['quaybill-voice']=false;mark('rumor');
  note('有人把副单钉上街绳','“晏甫截了两袋。”远处已有人念给孩子听，他女儿得在开铺时多解一次绳。请把原物再对一遍，拿新拓样去问另一边真的在场者，然后才能更正。');
 };
 function resolve(){
  if(!evidence(c)){note('押在空处的纸角','旧话没有压在今天的原件上。走到实物取新样，再走到另一地点，请亲见者对这个样说话。在公议桌上换个答案不够。');return;}
  show('哪一笔应叫别人看见','四只随舟升降，另两只在岸灶蒸成夜班的饭。五号泊的牌留在岸上，写“栖鸥”不能替六只袋认去处。你的证据不能给病人起名字。',[
   ['留盲号私下分录，晏家暂垫两袋',()=>finish('quiet')],
   ['公布转用单，请责任商行自署',()=>{if(c.consent!==c.round){note('公议桌','晏甫也有不签字的权利。带着核好的样和答话去街角，当面问他，再回来。');return;}finish('posted');}],
   ['卷好证据再想一会儿',retract]
  ]);
 }
 function finish(mode){
  c.verdict=mode;c.correction=!!c.accused;c.accepted={witness:{...c.witness},material:{...c.material},round:c.round};
  mark(mode);mark('settled');if(c.accused)mark('corrected');
  note('晾干后的两行字',mode==='quiet'?'两行盖同一盲号，岑藕肯担收据。晏家暂领不出两袋现粮，仍给不愿报姓名的人留一床。锚断之后，去撤离石阶看这张票准带走什么。':'晏甫把商行与自己的名字贴在转用两袋那行。公仓照此放粮，夜班人要额外排一道换匿名票。锚断后去看晏家的担保究竟能换几袋。');
 }
 const options=[
  ['先把“全数上船”夹在自己的草签里',()=>{c.draft='all-aboard';note('可以抽回的草签','玛拉没叫旁人听见。沿着岸墙一直走的划痕，真会跟船一起开走吗？');}],
  ['当街钉出“晏甫截了两袋”的指证',()=>show('话传得比回头快','这是公开指认。立刻收单能撤下纸，没法收回街坊垫的那一班工钱。',[['愿意当众署名钉上',wrong],['把话收回',retract]])],
  ['分开船身和泊位，把四袋与两袋各归其处',resolve]
 ];
 if(c.draft)options.unshift(['抽回自己的草签或钉单',retract]);
 show('临水听账桌','你可以在私夹里试推，也可以公开署名。单双面都是真纸，问题是船名落在泊位，还是船腹。',options);
}

export function sellerVoice(api){
 const {c,show,note}=api;
 if(c.verdict){note('晏甫',c.verdict==='quiet'?'你保了他们的口风。我也答应这回先垫两袋。等你们在收粮坡再见我，看看我还带得动哪一袋。':'工钱没有再从我女儿身上扣。只是替班人过去肯把白班的后门钥匙托给我，现在得请票手来开。');return;}
 const line=c.accused?'我的女儿早上解下“截粮”那张纸，下午就有人把它塞回门框里。你肯回来问，我也肯看原件。':'我家的笔是真笔，两只袋确实从栈房没了。我不认识五号船上每个人的脸，我只认垫了谁的粮。';
 show('粮商晏甫',line,[['问他愿不愿意本人给公开转用单落名',()=>{
  if(!evidence(c)){note('晏甫','先拿亲见和原物，要我给一张猜测署名，我不肯。');return;}
  c.consent=c.round;note('晏甫','我签我自己的名，在两袋公粮那一边。不替病过的人写名字。这样能领到两袋现货，匿名的脚夫要晚一轮换票，我也知道。');
 }]]);
}
