import {line,oval,poly} from '../paint.mjs';
const bearings={
 'rib-survey':[.79,.31,1.10],'deep-sluice':[.77,.30,.85],'red-beacon':[.74,.30,.69],'wreck-slope':[.66,.27,.52],
 'leeward-buttons':[.70,.29,.43],'sock-stair':[.73,.27,.46],'egg-meridian':[.66,.33,.40],'edge-bleach':[.71,.28,.42],'fan-throat':[.75,.25,.37]};
export const northern=id=>Object.hasOwn(bearings,id)||id==='silent-gimbal';
export const isWatch=(m,s)=>northern(m.id)&&!!s.flags['north-watch-dark'];
function distantRib(c,x,y,scale,gone,color){
 c.save();c.translate(x,y);c.scale(scale,scale);c.fillStyle=color;
 for(const [dx,ht] of [[-32,26],[-8,45],[14,37],[35,gone?9:28]]){
  c.beginPath();c.moveTo(dx-5,1);c.bezierCurveTo(dx-7,-ht*.62,dx-3,-ht,dx+16,-ht-1);c.bezierCurveTo(dx+6,-ht*.81,dx,-ht*.34,dx+1,1);c.fill();
 }c.restore();
}
export function northernHorizon(c,w,h,m,s,t){
 const loc=bearings[m.id];if(!loc)return false;const night=isWatch(m,s),high=s.tide==='high',lineY=h*(['edge-bleach','red-beacon','rib-survey'].includes(m.id)?.235:.43);
 const g=c.createLinearGradient(0,0,0,h);g.addColorStop(0,night?'#152a3d':'#71909b');g.addColorStop(.40,night?'#566679':'#dfd8b4');g.addColorStop(.58,night?'#354e60':'#99b6ad');g.addColorStop(1,night?'#273f50':'#507879');c.fillStyle=g;c.fillRect(0,0,w,h);
 if(night){for(let i=0;i<28;i++){const x=(i*119.3%317)/317*w,y=h*(.04+(i*13%17)*.014);oval(c,x,y,i%4?.7:1.3,i%4?.7:1.2,'#dedbc4b8');}
  oval(c,w*.87,h*.14,10,10,'#d7d8ba');oval(c,w*.87+4,h*.14-2,9,9,'#263c4d');}
 else oval(c,w*.84,h*.17,12,12,'#fff1c6');
 const ridge=layer=>{const pts=[[0,lineY+24]];for(let i=0;i<=23;i++){const x=i*w/23,y=lineY+(Math.sin(i*.85+loc[2])*9+Math.cos(i*.43+layer)*11+layer*10);pts.push([x,y]);}pts.push([w,lineY+43],[0,lineY+43]);poly(c,pts,layer?(night?'#405661':'#94a69d'):(night?'#526471':'#a3b2a6'));};
 ridge(0);distantRib(c,w*loc[0],lineY-8,loc[2]*(w<550?.67:1),true,night?'#6e777a':'#c5bba0');ridge(1);
 const bx=w*(loc[0]-.15),by=lineY+3;line(c,bx,by,bx,by-12,night?'#333e49':'#7d7466',2);
 line(c,bx-3,by-9,bx+4,by-11,'#826e5e',1);if(night&&s.flags['remote-lit']){oval(c,bx-3,by-11,2,1.7,'#ffd3a0');oval(c,bx+4,by-13,1.3,1.2,'#ffb482');}
 for(let i=0;i<11;i++){const x=(i*83+w*.2)%(w+33),y=lineY+29+(i%4)*5+(high?-2:0);line(c,x,y,x+8+(i%3)*9,y,night?'#a3b2b046':'#dbe5d46a',1);}
 return true;
}
export function watchLight(c,w,h,m,s){
 if(!isWatch(m,s))return;
 const g=c.createRadialGradient(w*.5,h*.53,12,w*.5,h*.49,Math.max(w,h)*.70);
 g.addColorStop(0,'#203b501c');g.addColorStop(.34,'#1f3c5138');g.addColorStop(.74,'#172e456b');g.addColorStop(1,'#11273a87');c.fillStyle=g;c.fillRect(0,0,w,h);
}
