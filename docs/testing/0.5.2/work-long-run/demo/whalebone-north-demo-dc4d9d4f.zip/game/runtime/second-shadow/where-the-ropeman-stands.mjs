export const loft='twohand-puppet-loft';
export const ropes={heron:[10,6],seal:[21,6]};
const places={mara:[4,12],ivo:[6,6]};
const near=(a,b)=>Math.abs(a[0]-b[0])+Math.abs(a[1]-b[1])<=1;
const tuple=(v)=>Array.isArray(v)&&v.length===2&&v.every(Number.isInteger);
export const roleAtWork=s=>s.map===loft&&s.progress?.twoHandStage?.active==='ivo'?'ivo':'mara';
export function stageBook(s){
 const source=s.progress.twoHandStage,book=source&&typeof source==='object'&&!Array.isArray(source)?source:{};
 if(!['mara','ivo'].includes(book.active))book.active='mara';
 if(!['heron','seal'].includes(book.figure))book.figure='heron';
 if(![0,1,2].includes(book.weight))book.weight=0;
 if(!Object.hasOwn(ropes,book.hold||''))book.hold=null;
 const positions=book.parked&&typeof book.parked==='object'?book.parked:{};
 for(const id of ['mara','ivo'])if(!tuple(positions[id]))positions[id]=[...places[id]];
 book.parked=positions;
 for(const n of ['slips','switches','handsOff'])if(!Number.isSafeInteger(book[n])||book[n]<0)book[n]=0;
 return s.progress.twoHandStage=book;
}
export function afterStageStep(s){
 if(s.map!==loft||!s.progress?.twoHandStage)return;
 const b=stageBook(s);b.parked[b.active]=[s.x,s.y];
 if(b.active==='ivo'&&b.hold&&!near(b.parked.ivo,ropes[b.hold])){b.hold=null;b.handsOff++;}
}
export function takeBothHome(s){
 if(s.map!==loft||!s.progress?.twoHandStage)return;
 const b=stageBook(s);if(b.hold)b.handsOff++;b.hold=null;b.active='mara';b.parked={mara:[...places.mara],ivo:[...places.ivo]};
}
export function exchangeStagePlaces(world,s,walkable){
 const b=stageBook(s),next=b.active==='mara'?'ivo':'mara';b.parked[b.active]=[s.x,s.y];
 let place=b.parked[next];if(!tuple(place)||!walkable(world.maps[loft],...place))place=places[next];
 b.active=next;b.switches++;[s.x,s.y]=place;s.facing=next==='ivo'?[0,1]:[1,0];
 return next==='ivo'?'蓝绳往上一翘。你现在走的是伊沃，他站上巷时，玛拉的鞋还留在原来的台下。':'幕下那双鞋重新着力。你现在走的是玛拉，伊沃留在你最后看见他的地方。';
}
export function holdAt(s,which){
 const b=stageBook(s);
 if(b.active!=='ivo')return '绳泡贴着伊沃的肩，你现在踩的是玛拉的鞋。伸手去拉旁边蓝套，让上巷的人来。';
 if(!near([s.x,s.y],ropes[which]))return '两道麻索隔着一整根梁，得走到这一根跟前。';
 b.hold=which;b.parked.ivo=[s.x,s.y];
 return which==='heron'?'伊沃把长颈麻索兜住前臂。用同一立柱上的蓝套把手交给玛拉；自己走开两步，麻索便回松。':'伊沃用拇指顶住裂铃下的皮索。对面的踏板仍然空着。你可以不挪脚，在这里交班。';
}
export function pushFoot(s){
 const b=stageBook(s),need=b.figure==='heron'?2:1;
 if(b.active!=='mara')return '这块踏木要玛拉压。伊沃在这里，北巷便没有他来持索。两处不是一个人的两种身份。';
 if(b.hold!==b.figure||!near(b.parked.ivo,ropes[b.figure])){
  b.slips++;return b.hold?'台上的影子朝错处扭了。伊沃守着另一根索；请他亲自换过去，台下的踏长可以先留住。':'你压下去，上巷空着，铁皮杯嗒的一声落回垫里。没有人被拽倒。留着踏长，让伊沃站回正确的地方。';
 }
 if(b.weight!==need){b.slips++;return b.weight>need?'劲太大，皮脚擦了一下上梁。玛拉抬足，偶会落回布兜，缩短一档再试。':'影子只在幕脚挪了半寸。重量压不到前面，往外一档让脚站远点。';}
 s.flags['twohand-'+b.figure+'-balanced']=true;s.flags['twohand-any-rehearsal']=true;
 return b.figure==='heron'?'两口踏长把木腿托起来。鹤的脚趾先离地，然后颈子弯下来够水。有人在幕外悄悄移开一只凳子。':'一口踏长托住皮腹。海豹的鼻尖往下潜，托住它的人同时松了少许，尾巴最后钻过布袋做的洞。';
}
