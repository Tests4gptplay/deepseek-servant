import {cloth,handLamp,shape,stone,trace} from './slate-and-sailcloth.mjs';
export const cutRows=['晏禾签下巨锚销槽，半城坠海。','晏禾两次返航，载回遇险的人。'];
function groove(c,points,angle,w=2){
 const delta=angle*1.05;trace(c,points.map(([x,y])=>[x+delta,y+1]),'#e4dbc1',w+.5);
 trace(c,points.map(([x,y])=>[x-delta,y-.8]),'#586357',w);
}
function mark(c,txt,x,y,angle){
 c.font='500 22px "Noto Serif CJK SC","Noto Sans CJK SC",serif';c.textBaseline='middle';
 const delta=angle*.7;for(const [dx,dy,col] of [[delta,1.4,'#e7dcc0'],[-delta,-.6,'#45564e'],[0,0,'#53605a']]){c.fillStyle=col;c.fillText(txt,x+dx,y+dy);}
}
function pin(c,a){
 groove(c,[[145,81],[179,79],[184,87],[182,112],[149,115],[143,109],[145,81]],a,1.8);
 groove(c,[[157,88],[174,87],[174,95],[165,99],[166,107],[157,108],[157,88]],a,2.6);
 groove(c,[[152,112],[162,108],[169,110],[178,103]],a,1);
}
function voyage(c,a){
 for(const [x,y] of [[142,158],[160,169]]){
  groove(c,[[x,y+6],[x+9,y+10],[x+25,y+7],[x+32,y+1],[x+14,y+3],[x,y+6]],a,1.5);
  groove(c,[[x+12,y+3],[x+13,y-9],[x+21,y-1]],a,1.4);
 }
 groove(c,[[143,188],[152,185],[160,188],[176,183],[184,184]],a,.9);
}
export function shine(canvas,state,angle){
 const c=canvas.getContext('2d');if(!c)return;
 const factor=canvas.width/720;c.setTransform(factor,0,0,factor,0,0);c.clearRect(0,0,720,310);
 const lamp=360+angle*146;stone(c,lamp);
 const flags=state.flags,marks=[flags['epitaph-fault'],flags['epitaph-rescue']];
 for(const [i,on] of marks.entries()){
  const y=97+i*69;
  if(on){
   (i?voyage:pin)(c,angle);mark(c,cutRows[i],204,y+4,angle);
   for(let j=0;j<5;j++)trace(c,[[186+j*17,y+21],[190+j*17,y+20],[192+j*17,y+19]],'#d8c9a9',1.2);
  }else{
   const top=y-27;cloth(c,[[110,top+3],[184,top-6],[344,top+1],[463,top-5],[594,top+2],[602,top+44],[530,top+50],[439,top+43],[296,top+55],[180,top+47],[111,top+49]],'left');
   trace(c,[[116,top+42],[183,top+40],[294,top+46],[440,top+36],[529,top+43],[594,top+37]],'#776e5e',1.9);
  }
 }
 if(!flags['grave-signed']){
  cloth(c,[[83,44],[102,40],[132,51],[121,87],[130,168],[123,219],[131,263],[106,272],[87,249],[93,177],[83,116]],'left');
 }else{
  cloth(c,[[525,232],[554,222],[586,232],[624,219],[648,230],[632,254],[607,264],[552,262],[513,249]],'right');
  trace(c,[[524,246],[564,240],[590,246],[626,237]],'#7f7561',2.8);
 }
 handLamp(c,lamp);
}
