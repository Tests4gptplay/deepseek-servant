import {face,rod,beam,hanging,box,oak,tar,brass,lamp} from '../lamplit-whale/fixtures.mjs';
import {line,poly,oval,arc} from '../paint.mjs';
import {gear,socket,rod as rail} from './forged.mjs';
function bolts(c,p,x,y,w,h){
 for(const [i,j] of [[.17,.15],[w-.17,.15],[.17,h-.15],[w-.17,h-.15]]){
  const a=p(x+i,y+j,1.8);oval(c,...a,2.3,1.2,'#cebc94');}
}
function railBed(c,p,x,y,w,h){
 box(c,p,x,y,w,h,0,2.6,tar);for(let i=.18;i<w;i+=.55)rod(c,p,[x+i,y+.05,3],[x+i,y+h-.06,3],'#9c9c7b',1.14);bolts(c,p,x,y,w,h);
}
function flume(c,p,x,y,length,t){
 face(c,p,[[x,y,1],[x+length,y,1],[x+length,y+.56,1],[x,y+.56,1]],'#517a7e');
 for(let j=0;j<Math.ceil(length*.98);j++){const u=(j*.94+t*.68)%length;rod(c,p,[x+u,y+.22,1.7],[x+Math.min(length,u+.26),y+.23,1.7],j%2?'#c0d9c6':'#9cbdab',1.6);}
}
export function deck(c,p,m,s,t){
 if(m.id==='ratchet-loft'){
  for(const [x,y,w] of [[6.4,9.7,9],[7.9,12.3,7.4],[15.5,8.4,4.6]])railBed(c,p,x,y,w,.55);
  for(const [a,b] of [[[7.1,5.7,22],[17.8,9.1,5]],[[19,14.2,20],[14.1,13.3,4]],[[9,9.7,8],[13.8,13.35,7]]]){
   hanging(c,p,a,b,s.flags['clutch-still']?8:1.1,'#344c4a',3.2);hanging(c,p,[a[0],a[1]+.10,a[2]],b,s.flags['clutch-still']?8:1.8,'#be9c66',1.2);}
  flume(c,p,10.5,7.95,6.2,t);if(s.flags['clutch-still'])flume(c,p,15.7,8.72,3.3,t);
  for(const x of [7,12,17]){lamp(c,p,x,7.8,16,t,true,.74);}
 }else if(m.id==='anchor-yard'){
  railBed(c,p,12.9,9.2,7.5,.77);for(let j=0;j<2;j++)hanging(c,p,[6.0,9.17+j*.17,6],[23.7,8.9+j*.17,16],s.flags['bran-unpinned']?13:2.4,j?'#cab17d':'#5a5546',j?1.1:3);
 }else if(m.id==='weir-sleeve'&&s.flags['clutch-still']){
  flume(c,p,8.3,9.15,5.1,t);flume(c,p,13.6,9.35,6.4,t);
  for(const [x,y] of [[10,8.9],[14.7,9.1],[19.7,9.5]]){beam(c,p,[x,y,0],[x,y,15],3);for(let z=4;z<14;z+=3)rod(c,p,[x-.09,y,z],[x+.11,y,z],'#dbc391',1);}
 }else if((m.id==='lee-cutter'||m.id==='safe-keel')&&s.flags['harbor-tilted']){
  const x=m.id==='lee-cutter'?9.15:16.5,y=m.id==='lee-cutter'?7.42:10.35;
  face(c,p,[[x-.35,y+.55,0],[x+1.24,y-.18,0],[x+6.65,y+3.58,0],[x+4.64,y+5.68,0]],'#628e90','#4d777a');
  for(let i=0;i<11;i++){const u=(i*.29+t*.3)%3.2,xx=x+.7+u+i%2*.55,yy=y+.95+u*.85;
   rod(c,p,[xx,yy,1],[xx+.21,yy-.07,1],'#bad1bb',1.4);}
  for(const v of [-.25,.5]){beam(c,p,[x+v,y+.4,1],[x+v+.65,y+.76,1],3);}
 }else if(m.id==='flood-stair'&&s.flags['harbor-tilted']){
  for(let i=0;i<7;i++){
   const x=9.3+i*1.77,y=8.34+(i%2)*.9;const a=p(x,y);oval(c,a[0],a[1],8,2,'#d4e4c997');
   for(let n=0;n<2;n++){const u=(t*.4+i*.27+n*.5)%1;rod(c,p,[x-.18+u*.25,y+.06,0],[x+.15+u*.25,y+.09,0],'#e0eacb',1.1);}
  }
  const a=p(11,9.5);gear(c,a[0],a[1]-1,8,.52,true);rail(c,a[0]-18,a[1]+4,a[0]-4,a[1]-3,2,'#bfab82');
 }
}
export function architecture(c,p,m,f,s,t){
 if(m.id!=='ratchet-loft')return false;
 const x=f.x,y=f.y,w=f.w||1,h=f.h||1;
 if(f.kind!=='crane'&&f.kind!=='crate')return false;
 const cage=f.kind==='crate',spin=s.flags['clutch-still']?0:t*.67;
 box(c,p,x+.13,y+.2,w-.25,h-.4,0,6.5,tar);
 for(const xx of [x+.5,x+w-.5])for(const yy of [y+.46,y+h-.48])beam(c,p,[xx,yy,5],[xx,yy,32],4);
 for(const yy of [y+.45,y+h-.48])beam(c,p,[x+.46,yy,31],[x+w-.47,yy,31],5);
 for(const xx of [x+.48,x+w-.48])beam(c,p,[xx,y+.43,30],[xx,y+h-.5,30],4);
 const a=p(x+w*.51,y+h*.48,11);c.save();c.translate(...a);
 if(cage){gear(c,-13,-8,18,spin,true);gear(c,13,-12,14,-spin*1.3);for(let j=0;j<7;j++)rail(c,-26+j*9,-24,-25+j*9,10,2);}
 else{for(let i=0;i<5;i++){const dx=-18+i*8,dy=2-i*1.2;oval(c,dx,dy,9,15,i%2?'#b79464':'#81785e');arc(c,dx,dy,9,-1.3,1.3,'#d3b68a',1.35);}gear(c,18,-3,16,spin);}
 c.restore();for(const xx of [x+.52,x+w-.5])lamp(c,p,xx,y+.42,29,t,true,.66);
 return true;
}
