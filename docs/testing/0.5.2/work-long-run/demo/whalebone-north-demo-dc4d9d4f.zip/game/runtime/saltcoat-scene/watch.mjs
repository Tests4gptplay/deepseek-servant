import {poly,line,oval} from '../paint.mjs';
const rind='#4d3f37',wood='#947755',light='#d3bd8d';
const coats={singer:['#785165','#dea98c','#b5c4af'],watcher:['#566e73','#b78066','#ca9564'],apprentice:['#637568','#bd9070','#d4b570'],vendor:['#a16b48','#c89471','#d5bc85'],waker:['#777768','#bd9170','#b5be9d']};
function limb(c,points,ink,width){for(let i=1;i<points.length;i++)line(c,...points[i-1],...points[i],ink,width);}
export function person(c,who,pose='rest',beat=1,face=1){
 const [coat,skin,trim]=coats[who];c.save();c.scale(face,1);
 const kid=who==='apprentice';if(kid)c.scale(.84,.84);const y=pose==='seat'?5:0;
 oval(c,0,0,9,2.9,'#31352e50');line(c,-3,-9+y,-5,0,'#504b42',3);line(c,3,-9+y,5,-1,'#514b42',3);
 line(c,-5,0,-1,0,'#3f3a34',2);line(c,5,-1,8,-1,'#3f3a34',2);c.translate(0,y);
 poly(c,[[-5,-23],[1,-25],[5,-22],[5,-13],[8,-7],[-6,-7],[-5,-18]],coat,'#4d4540');
 poly(c,[[-5,-22],[0,-24],[4,-21],[1,-19],[-5,-18]],trim);
 if(who==='singer'){poly(c,[[-5,-19],[0,-15],[-1,-8],[-5,-7]],'#5b3e50');line(c,-3,-14,0,-13,'#d19b79',1);}
 if(who==='vendor'||kid)poly(c,[[-4,-17],[3,-18],[5,-8],[-4,-7]],kid?'#a78a66':'#d8b47e','#776449');
 oval(c,.2,-27,4.3,4.8,skin);poly(c,[[-5,-27],[-4,-32],[0,-34],[4,-31],[5,-28],[0,-30],[-3,-26]],'#554239','#514035');
 if(who==='singer'){poly(c,[[-5,-30],[-1,-35],[4,-33],[5,-31],[0,-32],[-5,-26]],trim);line(c,-4,-29,-7,-24,trim,1.8);}
 if(who==='watcher')oval(c,-4,-29,3.8,3.4,'#64483e');
 line(c,2,-28,3.4,-28,'#4a3c37',.9);
 let elbow=[7,-15],hand=[6,-12],tip=[7.5,-11];
 if(pose==='stop'){elbow=[8,-16];hand=[11,-21];tip=[11,-25];}
 if(pose==='signal'){elbow=[8,-18];hand=[9+beat*4,-18-beat*7];tip=[hand[0]-3,hand[1]-2.5];}
 if(pose==='offer'){elbow=[8,-16];hand=[10+beat*5,-16];tip=[hand[0]+2,-16.5];}
 if(pose==='hold'){elbow=[7,-16];hand=[9,-18];tip=[10,-20];}
 if(pose==='work'){elbow=[7,-17];hand=[10,-15+3*beat];tip=[12,-15+3*beat];}
 limb(c,[[3,-21],elbow],rind,4.7);limb(c,[[3,-21],elbow],coat,3.5);limb(c,[elbow,hand],trim,3);
 oval(c,...hand,2,1.8,skin);limb(c,[hand,tip],skin,1.8);
 if(pose==='signal'||pose==='stop'){const [x,y]=hand;line(c,x+.3,y-.8,x+.8,y-3.1,skin,1);line(c,x+1.7,y,x+2.1,y-2.7,skin,1);}
 if(pose==='hold'||pose==='work')limb(c,[[-3,-19],[-3,-14],[3,-15]],skin,1.6);
 c.restore();
}
export function plank(c,x=0,y=0,w=40){
 const h=w/2;poly(c,[[x-h,y-7],[x-h+9,y-12],[x+h,y-5],[x+h-10,y]],wood,rind);
 poly(c,[[x-h,y-7],[x+h-10,y],[x+h-10,y+3],[x-h,y-4]],'#695540',rind);
 line(c,x-h+4,y-7,x+h-12,y-1,light,1);line(c,x-h+4,y-3,x-h+4,y+3,rind,2.5);
 line(c,x+h-12,y+1,x+h-12,y+6,rind,2.5);
}
export function pass(c,x=0,y=-12,other=false){
 c.save();c.translate(x,y);c.rotate(other?-.22:.2);poly(c,[[-4,-4],[2,-4],[4,-2],[4,4],[-3,4],[-4,2]],'#e7c68c','#66523e');
 line(c,-1,-2,-1,2,'#b96c4e',1.6);line(c,1,-1,2.5,0,'#4e6e6b',1);c.restore();
}
export function cup(c,x,y,cover=false,hot=true){
 oval(c,x+1,y+1,7.4,2.5,'#473c3750');
 poly(c,[[x-6,y-5],[x+6,y-5],[x+4,y],[x+1,y+1],[x-3,y]],cover?'#82968a':'#ba977c','#655544');
 oval(c,x,y-4.7,6.2,1.8,cover?'#aeb9a0':'#e1cf9f','#786652');
 if(cover){oval(c,x,y-6,4.3,1.2,'#b5c3b1');oval(c,x,y-7,1.3,1.1,'#5c746a');}
 if(hot){limb(c,[[x-1,y-7],[x-2,y-10],[x,y-13]],'#ede2bd99',1.1);line(c,x+2,y-10,x+3,y-14,'#eee1b774',1);}
}
export function shutter(c,{open=.45,hand=false,beat=1,lit=true,curtain=false}={}){
 oval(c,1,1,21,3.6,'#4c463656');const a=-18,b=18,top=-34,low=-10;
 poly(c,[[a,-1],[a,top],[b,top-3],[b,-4],[14,-4],[14,top+1],[-14,top+4],[-14,-1]],'#856b51',rind);
 poly(c,[[-14,top+4],[14,top+1],[14,low-2],[-14,low+1]],lit?'#605949':'#4b514b','#4e4339');
 if(lit)poly(c,[[-12,-29],[2,-30],[12,-25],[12,-15],[-12,-12]],'#c59e6c');
 if(hand){
  // The singer stands inside the right jamb. The elbow stays under the sill: only she raises the hand.
  poly(c,[[6,-14],[9,-20],[14,-21],[14,-13],[8,-12]],'#654a60','#4a4045');
  oval(c,10,-24,2.4,3.1,'#bb896c');poly(c,[[7,-25],[8,-28],[12,-28],[13,-26],[10,-26],[8,-24]],'#53433c');
  line(c,9,-15,4,-18,'#4b4247',3.6);line(c,9,-15,4,-18,'#9a7981',2.3);
  c.save();c.translate(3.2,-17.5-beat*2.7);c.rotate(-.15-beat*.24);
  poly(c,[[2,1],[.8,-2.7],[-.8,-5.1],[-2,-5.2],[-2,-2.2],[-3.3,-4.4],[-4.3,-4.0],[-3.8,-1.3],[-5.7,-2.1],[-6.2,-.9],[-3.1,2],[-.7,2.4]],'#e7bb96','#704c44');
  line(c,-.5,-1.1,1,-2.3,'#a47663',.8);c.restore();
 }
 for(const side of [-1,1]){const width=curtain&&side===-1?13.8:14*(1-open),xx=side*14,xx2=side*(14-width);
  poly(c,[[xx,-31],[xx2,-31],[xx2,-12],[xx,-11]],curtain?'#6e8885':'#826c54',rind);
  line(c,xx-side,-28,xx-side,-14,curtain?'#abb3a0':'#b69770',1.2);}
 line(c,-18,-9,18,-12,'#5c5143',3);line(c,-16,-10,16,-12.5,'#dac298',1.2);
}
