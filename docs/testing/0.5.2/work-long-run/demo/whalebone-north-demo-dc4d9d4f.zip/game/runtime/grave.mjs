import {workAtTheGrave,lampAtTheEdge} from './graveside/where-the-lamp-is-resting.mjs';
import {plate,box,wood} from './voyage-shapes.mjs';
import {poly,line,oval,arc,rand} from './paint.mjs';
import {figure} from './figures.mjs';

export function graveGround(c,p,map,s){
 if(map.id!=='burial-cape')return;workAtTheGrave(c,p,s);
 for(let i=0;i<94;i++){
  const x=2+rand(i,81)*22,y=4+rand(i,77)*12;
  if((x>7&&x<18&&y>7&&y<12)||rand(i,22)<.35)continue;
  const[a,b]=p(x,y);oval(c,a,b,4+rand(i,60)*4,1.5,'#83938380');
  for(let k=0;k<4;k++)line(c,a+k*1.8-3,b,a-3+k*2.2,b-2-rand(i,k)*3,'#77896e',.9);
 }
 const x=10.90,y=10.27;
 plate(c,p,x-.97,y-.45,2,.9,.5,'#806e59','#b5a184');
 for(let j=0;j<5;j++)line(c,...p(x-.87+j*.39,y+.51,1),...p(x-.69+j*.39,y+.55,1),'#c4b28d',1.3);
}
export function graveObject(c,p,e,s,t){
 if(lampAtTheEdge(c,p,e,s))return true;const x=e.x+.5,y=e.y+.5,f=s.flags;
 if(e.id==='lower-coffin'){
  const xx=x+.45,yy=y-.66;
  if(!f['coffin-home']){
   box(c,p,xx-1,yy-.43,1.98,.85,2,5,wood);box(c,p,xx-.89,yy-.36,1.78,.72,7,6,['#d8c4a0','#ad9273','#7f7562']);
   for(const n of [-.50,.52])line(c,...p(xx+n,yy-.37,14),...p(xx+n,yy+.37,14),'#6c8276',2.2);
   for(const [k,d] of [[0,-1],[1,1]]){const a=p(xx+d*.95,yy+.50),b=p(xx+d*1.36,yy+.66);
    line(c,a[0],a[1]-5,b[0],b[1]-12,'#a99469',1.7);figure(c,...b,k?'ivo':'selene',t,{scale:.95});}
  }else{
   box(c,p,xx-.91,yy-.36,1.82,.72,0,2,['#a18c70','#7c6a56','#7a6c57']);
   const[a,b]=p(xx,yy,4);for(let i=0;i<8;i++){line(c,a-14+i*4,b+(i%2),a-11+i*4,b-2,'#7d846d',1.3);oval(c,a-11+i*4,b-2,1.7,1.2,i%2?'#d2c6a3':'#c8aa88');}
  }
  return true;
 }
 if(e.id==='engrave-slot'||e.id==='engrave-return'){
  const[a,b]=p(x+.28,y-.35);
  if(e.id==='engrave-slot'){line(c,a-8,b+1,a+6,b-3,'#686d61',2.7);poly(c,[[a+4,b-6],[a+12,b-8],[a+15,b-3],[a+7,b]],'#90785e');}
  else{oval(c,a,b-3,8,3.8,'#b6a179');arc(c,a,b-4,6,0,Math.PI*1.8,'#717b6b',1);};return true;
 }
 if(e.id==='cover-letters'){
  const[a,b]=p(x+.45,y-.53);poly(c,[[a-29,b+1],[a-29,b-26],[a-23,b-35],[a+25,b-36],[a+30,b-31],[a+30,b+2]],'#a6ad9c','#687975');
  poly(c,[[a-29,b-26],[a-23,b-35],[a+25,b-36],[a+22,b-32],[a-21,b-31]],'#c2c6ad');
  const lines=[['epitaph-fault','签图　坠海'],['epitaph-rescue','返航　救人']];
  c.save();c.fillStyle='#435a54';c.font='7.5px serif';for(let i=0;i<2;i++){if(f[lines[i][0]])c.fillText(lines[i][1],a-20,b-21+i*10);}
  c.restore();
  if(!f['grave-signed']){poly(c,[[a-29,b-29],[a-20,b-32],[a-21,b-5],[a-25,b+1],[a-30,b-3]],'#b5a58a');}
  return true;
 }
 return false;
}
