// Old saves may contain a completed public weighing from before two later evidence stations existed.
export function readingSignedHearing(s,entity){
 return entity.id==='petition-counter'&&s.map==='petition-hall'&&s.flags['quaybill-settled']===true&&
  s.flags['shortfall-proved']===true&&s.flags['event:petition-hall:petition-counter']===true;
}
