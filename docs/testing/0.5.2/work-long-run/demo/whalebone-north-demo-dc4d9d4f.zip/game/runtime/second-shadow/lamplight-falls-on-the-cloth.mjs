const fill=(c,ink,shape)=>{c.beginPath();shape();c.fillStyle=ink;c.fill();};
function heron(c,x,y,pull,beat){
 c.save();c.translate(x,y);const up=pull*9,neck=1.5+up*.7;
 c.strokeStyle='#614c3b';c.lineWidth=2.4;c.lineCap='round';
 for(const [dx,k] of [[-7,1],[1,-1]]){
  c.beginPath();c.moveTo(dx,1);c.lineTo(dx+5+pull*4*k,7-pull*2);c.lineTo(dx-1+pull*6*k,13-up*.58);c.lineTo(dx+4+pull*6*k,13-up*.58);c.stroke();
 }
 fill(c,'#604a39',()=>{c.moveTo(-18,-1);c.quadraticCurveTo(-20,-7,-10,-9);c.quadraticCurveTo(-1,-11,3,-10);c.quadraticCurveTo(6,-10,8,-15-neck);c.quadraticCurveTo(11,-23-neck,16,-21-neck);c.lineTo(26,-18-neck);c.lineTo(17,-17-neck);c.quadraticCurveTo(12,-17-neck,11,-9);c.quadraticCurveTo(9,-1,0,2);c.quadraticCurveTo(-10,4,-18,-1);});
 fill(c,'#886341',()=>{c.moveTo(-17,-6);c.quadraticCurveTo(-10,-12,-3,-10-up*.25);c.lineTo(1,-4+beat);c.quadraticCurveTo(-4,2,-17,-6);});
 c.fillStyle='#ead5a0';c.beginPath();c.arc(15,-20-neck,.85,0,7);c.fill();c.restore();
}
function seal(c,x,y,pull,beat){
 c.save();c.translate(x,y);c.rotate(-.08+pull*.21);
 fill(c,'#5c5550',()=>{c.moveTo(-20,4);c.quadraticCurveTo(-11,-10,1,-7);c.quadraticCurveTo(5,-16,13,-12);c.quadraticCurveTo(20,-11,23,-5);c.quadraticCurveTo(21,-2,14,-4);c.quadraticCurveTo(12,3,3,5);c.quadraticCurveTo(-9,7,-16,4);c.lineTo(-24,9+beat);c.lineTo(-22,4);c.lineTo(-28,3+beat);c.closePath();});
 fill(c,'#87735a',()=>{c.moveTo(6,0);c.quadraticCurveTo(0,6,-3,9);c.quadraticCurveTo(3,11,10,2);});
 c.fillStyle='#eddbb1';c.beginPath();c.arc(15,-10,1,0,7);c.fill();c.restore();
}
export function litScrim(c,q,book,t){
 const A=q(.05,.12,75),B=q(.95,.12,75),D=q(.05,.12,7);
 c.save();c.transform((B[0]-A[0])/300,(B[1]-A[1])/300,(D[0]-A[0])/68,(D[1]-A[1])/68,A[0],A[1]);
 c.strokeStyle='#614534';c.lineWidth=5;c.beginPath();c.moveTo(-4,-3);c.quadraticCurveTo(145,0,304,-4);c.stroke();
 c.beginPath();c.moveTo(0,2);c.quadraticCurveTo(78,8,150,4);c.quadraticCurveTo(224,9,300,2);c.lineTo(296,65);c.quadraticCurveTo(231,59,166,65);c.quadraticCurveTo(99,72,4,65);c.closePath();c.fillStyle='#c49966';c.fill();c.strokeStyle='#8e6547';c.lineWidth=1.6;c.stroke();c.clip();
 const light=c.createRadialGradient(152,39,8,152,40,151);light.addColorStop(0,'#ffe3aa');light.addColorStop(.47,'#eecd8c');light.addColorStop(1,'#ad8056');c.fillStyle=light;c.fillRect(-3,-2,307,75);
 for(let u=4;u<300;u+=4){c.strokeStyle=u%12?'#79523514':'#8b644c39';c.lineWidth=.65;c.beginPath();c.moveTo(u,1);c.quadraticCurveTo(u+1,34,u-1,69);c.stroke();}
 for(let k=0;k<3;k++){c.strokeStyle=['#9a784d','#b49360','#8d7554'][k];c.lineWidth=1;c.beginPath();c.moveTo(0,54+k*3);for(let x=0;x<301;x+=9)c.lineTo(x,54+k*3+Math.sin(x*.051+k)*2);c.stroke();}
 const which=book?.figure||'heron',held=book?.hold===which,pull=held?(book.weight===(which==='heron'?2:1)?1:.4):0,beat=held?Math.sin(t*1.8)*.8:0;
 if(which==='heron')heron(c,153,47-pull*6,pull,beat);else seal(c,153,47-pull*5,pull,beat);
 for(const u of [8,28,56,91,129,169,203,242,268,292]){c.lineWidth=1.1;c.strokeStyle='#886a46';c.beginPath();c.moveTo(u,5);c.lineTo(u+2,2);c.stroke();}
 c.strokeStyle='#a27b54';c.setLineDash([3,2]);c.strokeRect(32,16,28,13);c.strokeRect(233,33,19,17);c.restore();
}
