import {litScrim} from './lamplight-falls-on-the-cloth.mjs';
import {panel,cord,oval,lantern,rope} from '../folded-house-art/materials.mjs';
import {figure} from '../figures.mjs';
import {loft,roleAtWork} from './where-the-ropeman-stands.mjs';
const edge='#534536',bronze='#b59460',ink='#4c4b43';
function bird(c,x,y,scale,raised){
 c.save();c.translate(x,y);c.scale(scale,scale);
 const curve=(color,fn,w)=>{c.beginPath();fn();if(w){c.strokeStyle=color;c.lineWidth=w;c.stroke();}else{c.fillStyle=color;c.fill();}};
 const h=raised?3:-2;
 curve('#806747',()=>{c.moveTo(-14,0);c.quadraticCurveTo(-13,-6,-5,-7);c.quadraticCurveTo(0,-12-h,7,-14-h);c.lineTo(8,-11-h);c.quadraticCurveTo(2,-8,2,-4);c.quadraticCurveTo(1,1,-8,3);c.closePath();});
 curve('#b89d70',()=>{c.moveTo(-13,-3);c.quadraticCurveTo(-9,-7,-3,-7);c.lineTo(-1,-2);c.quadraticCurveTo(-5,3,-13,-3);});
 curve(edge,()=>{c.moveTo(7,-14-h);c.lineTo(15,-13-h);c.lineTo(7,-11-h);c.closePath();});
 for(const k of [-7,-2])curve(ink,()=>{c.moveTo(k,2);c.lineTo(k+3,7+h);c.lineTo(k-1,13-h);c.lineTo(k+4,13-h);},1.4);
 oval(c,[6,-13-h],1.05,1,'#e1c99b');c.restore();
}
function seal(c,x,y,scale,raised){
 c.save();c.translate(x,y);c.scale(scale,scale);c.rotate(raised?.16:-.11);
 c.beginPath();c.moveTo(-15,4);c.bezierCurveTo(-12,-7,-3,-8,4,-5);c.quadraticCurveTo(7,-11,12,-8);c.quadraticCurveTo(17,-8,18,-3);c.quadraticCurveTo(13,0,10,-1);c.quadraticCurveTo(5,5,-9,4);c.lineTo(-17,6);c.closePath();c.fillStyle='#5a797b';c.fill();c.strokeStyle=edge;c.stroke();
 oval(c,[12,-6],1,1,'#d5c997');c.beginPath();c.moveTo(5,1);c.lineTo(1,6);c.lineTo(7,3);c.fillStyle='#849d94';c.fill();c.restore();
}
function scrim(c,q,low,book){
 const h=low?36:52;
 for(const u of [.05,.94])cord(c,q,[[u,.49,1],[u,.46,h+9]],edge,4.5);
 panel(c,q,[[.08,.48,7],[.91,.48,6],[.91,.46,h-5],[.73,.46,h-3],[.49,.46,h-7],[.10,.46,h]],'#caba94',edge);
 for(let i=0;i<15;i++){
 const u=.12+i*.052;cord(c,q,[[u,.47,8],[u+.006,.47,h-9]],i%4===0?'#a38d6e':'#dbccab',i%4===0?1.3:.7);
 }
 cord(c,q,[[.04,.46,h+4],[.48,.46,h+1],[.95,.46,h-1]],'#936f4c',3.5);
 const [x,y]=q(.52,.5,low?21:29);
 if(book?.figure==='seal')seal(c,x,y,1.07,book.weight===1);else bird(c,x,y,1.13,book?.weight===2);
 for(const x of [.06,.92])lantern(c,q(x,.56,h-6),true);
}
function rig(c,q,b){
 for(const u of [.07,.52,.93]){
  cord(c,q,[[u,.8,1],[u,.43,48]],'#604d38',4.5);cord(c,q,[[u,.04,2],[u,.43,48]],'#897754',3.8);
 }
 cord(c,q,[[.025,.43,49],[.52,.43,48],[.97,.43,45]],'#a37b4e',5.5);
 for(const [u,kind] of [[.26,'heron'],[.71,'seal']]){
  const taut=b?.hold===kind;
  rope(c,[q(u-.16,.44,49),q(u-.06,.5,taut?48:36),q(u,.46,44)],taut?'#c3a16a':'#85745a');
  const h=kind===b?.figure&&taut?21:10;
  cord(c,q,[[u,.45,45],[u,.53,h+5]],'#9b9276',1.3);const [x,y]=q(u,.53,h);
  if(kind==='heron')bird(c,x,y,1.28,taut);else seal(c,x,y,1.25,taut);
 }
}
function bench(c,q){
 for(const u of [.10,.85])for(const v of [.23,.70])cord(c,q,[[u,v],[u,v,12]],'#5b4e3b',2.8);
 panel(c,q,[[.04,.18,13],[.96,.18,13],[.96,.8,13],[.04,.8,13]],'#a8875f',edge);
}
function stove(c,q,t){
 panel(c,q,[[.15,.28],[.75,.28],[.75,.75],[.15,.75]],'#71685a',edge);
 const [x,y]=q(.43,.54,13);oval(c,[x,y+3],16,7,'#5a5149');oval(c,[x,y],16,5,'#b5a17d');oval(c,[x,y],11,2.8,'#9b734c');
 for(let i=0;i<3;i++){const shift=Math.sin(t*.65+i);oval(c,[x-5+i*4+shift,y-9-i*4],2.6+i,2,'#d1cab377');}
}
export function puppetPlace(c,p,map,f,s,t){
 if(!map.id.startsWith('twohand-')||!f.kind.startsWith('stage-'))return false;
 const q=(u,v,z=0)=>p(f.x+u*f.w,f.y+v*f.h,z),b=s.progress?.twoHandStage;
 if(f.kind==='stage-screen')scrim(c,q,map.id!==loft,b);
 else if(f.kind==='stage-rig'){litScrim(c,q,b,t);rig(c,q,b);}
 else if(f.kind==='stage-bench')bench(c,q);
 else if(f.kind==='stage-cooker')stove(c,q,t);
 else if(f.kind==='stage-counter'){
  bench(c,q);for(let i=0;i<3;i++)cord(c,q,[[.16+i*.24,.22,15],[.16+i*.24,.7,15]],b?.weight===i?bronze:ink,i===b?.weight?3.2:1.8);
 }else{for(const u of [.14,.78])cord(c,q,[[u,.6],[u,.6,29]],edge,3);rope(c,[q(.14,.6,31),q(.44,.6,19),q(.78,.6,31)],'#5a7880');}
 return true;
}
export function parkedPartner(c,p,map,s,t,ordered){
 if(map.id!==loft)return;
 const b=s.progress?.twoHandStage,who=roleAtWork(s)==='mara'?'ivo':'mara';
 const coords=b?.parked?.[who]||(who==='ivo'?[6,6]:[4,12]);if(!Array.isArray(coords)||coords.length!==2||!coords.every(Number.isInteger))return;
 const [x,y]=coords,[a,z]=p(x+.5,y+.5);
 ordered.push([x+y+1.035,()=>{figure(c,a,z,who,t,{scale:1.15});if(who==='ivo'&&b?.hold){c.strokeStyle='#ad915e';c.lineWidth=2;c.beginPath();c.moveTo(a+8,z-15);c.quadraticCurveTo(a+11,z-28,a-6,z-44);c.stroke();}}]);
}
