import {line,oval,poly,arc} from './paint.mjs';
import {box,plate,wood,iron} from './voyage-shapes.mjs';

const copper=['#cd926d','#966651','#654d48'];
function cord(c,a,b,sag,color,width=2){
 c.strokeStyle=color;c.lineWidth=width;c.beginPath();c.moveTo(...a);
 c.quadraticCurveTo((a[0]+b[0])/2,(a[1]+b[1])/2+sag,...b);c.stroke();c.lineWidth=1;
}
export function wheelCradle(c,p,x,y,offset=0){
 for(const dx of [-.9,.74]){box(c,p,x+dx,y-.25,.19,.56,0,33,wood);box(c,p,x+dx-.1,y-.48,.39,.9,0,4,iron);}
 line(c,...p(x-.83,y,29),...p(x+.84,y,29),'#514b40',4);
 const [a,b]=p(x,y,29);oval(c,a,b,14,13,'#5e726d');arc(c,a,b,12,0,Math.PI*2,'#c8b88b',2.2);
 for(let i=0;i<5;i++){const t=offset+i*2*Math.PI/5;line(c,a,b,a+Math.cos(t)*11,b+Math.sin(t)*10,'#b5a279',2.4);}oval(c,a,b,3,3,'#7f6552');
}
export function liftBasket(c,p,x,y,lift=12,turned=false){
 wheelCradle(c,p,x,y,turned?.85:0);
 const axis=p(x,y,31),hook=p(x+(turned?.68:-.38),y+.35,lift+11);
 cord(c,axis,hook,2,'#decaa1',2.3);
 box(c,p,x-.66,y+.11,1.24,.70,lift,5,wood);
 for(const dx of [-.57,.5])for(const dy of [.17,.71])line(c,...p(x+dx,y+dy,lift+4),...hook,'#a59473',1.6);
 for(let j=0;j<4;j++)line(c,...p(x-.58+j*.3,y+.83,lift+1),...p(x-.58+j*.3,y+.83,lift+9),'#c5a673',1.6);
}
export function ironEye(c,p,x,y,moving=false,slack=false){
 const z=moving?10:3;box(c,p,x-.48,y-.3,.96,.64,z,7,moving?wood:iron);
 const [a,b]=p(x,y,z+9);arc(c,a,b-2,6,0,Math.PI*2,moving?'#b88665':'#d7bd85',3);
 cord(c,[a+3,b-2],p(x+1.52,y-.75,moving?13:6),slack?14:2,'#b8a77b',2.8);
 if(moving)for(let j=0;j<3;j++)oval(c,a-10-j*4,b-8-j*2,2.4-j*.35,1.7,'#d1e6d7');
}
export function waterEye(c,p,x,y,pale,open=false){
 const rim=pale?19:5;const [a,b]=p(x,y,rim),radius=24;
 box(c,p,x-.59,y-.59,1.18,1.18,0,rim+2,pale?['#d2c7ac','#a49b85','#7a8275']:['#9c9990','#797e72','#526d65']);
 oval(c,a,b,radius,12,pale?'#ddd2b9':'#afa995');oval(c,a,b,radius-4,9.2,'#3b5c60');
 oval(c,a,b+1,radius-6,6,pale?'#91c6bc':'#4b767b');
 for(let k=0;k<5;k++){const q=Math.PI*k/4;line(c,a+Math.cos(q)*19,b+Math.sin(q)*8,a+Math.cos(q)*25,b+Math.sin(q)*13,'#8e8976',1.4);}
 const post=p(x-.79,y-.13,rim+26);line(c,...p(x-.79,y-.13,rim+1),...post,'#806953',4);line(c,...post,...p(x+.25,y-.13,rim+26),'#c6ac7b',3);
 if(pale){const k=p(x+.1,y-.1,rim+17);line(c,...p(x+.1,y-.13,rim+26),...k,'#d4c5a6',1.2);poly(c,[k,[k[0]+8,k[1]+2],[k[0]+7,k[1]+13],[k[0]+1,k[1]+12]],'#dfddc3');}
 else for(const dx of [-9,4])oval(c,a+dx,b,5,1.8,'#a4a583');
 if(open)for(let j=0;j<3;j++)line(c,a+4+j*3,b+5+j*2,a+13+j*3,b+5+j*2,'#c5e6d7',1.2);
}
export function sluice(c,p,x,y,on){
 box(c,p,x-.73,y-.35,1.45,.74,0,4,iron);
 const progress=Number(on);const a=p(x-.49,y-.08,9),b=p(x+.49,y-.08,10+14*progress);
 line(c,...a,...b,'#89614b',5);oval(c,...b,3.2,3.2,'#d8b277');
 for(let i=0;i<4;i++)line(c,...p(x-.55+i*.32,y+.24,2),...p(x-.55+i*.32,y+.24,18-10*progress),'#918773',2.8);
}
export function galley(c,p,x,y,burning=true){
 box(c,p,x-.65,y-.47,1.3,.94,0,15,copper);const [a,b]=p(x,y,15);
 oval(c,a,b,22,9,'#4d5050');oval(c,a,b-3,20,8,'#675b50');oval(c,a,b-5,18,6,'#b6835a');
 if(burning){const q=p(x+.33,y+.43,7);oval(c,...q,8,4,'#ef9f4a');line(c,q[0]-4,q[1]+1,q[0],q[1]-4,'#ffe0a0',1.8);}
}
export function tideStep(c,p,x,y,high=false){
 for(let i=0;i<5;i++){const z=(4-i)*4;box(c,p,x+i*.30,y-.78,.36,1.6,0,z+2,['#a6ada0','#838e82','#667c72']);if(i>=3&&high)plate(c,p,x+i*.3,y-.77,.33,1.54,z+2.3,'#6c9f9d');}
}
export {cord};
