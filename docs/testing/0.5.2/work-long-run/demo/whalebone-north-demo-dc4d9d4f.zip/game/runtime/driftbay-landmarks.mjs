import {line,poly,oval,rand} from './paint.mjs';
const formations={
 scree:[[7,5,98,58,1],[16,2,72,33,3],[22,10,60,32,4],[9,16,38,19,1]],
 roof:[[5,2,68,73,4],[12,3,85,84,5],[14,10,89,53,2],[20,11,55,72,0],[6,16,49,27,1]],
 pools:[[4,4,60,51,2],[15,3,66,49,0],[21,8,63,33,1],[22,18,44,23,2]],
 throat:[[6,5,52,70,1],[13,7,79,88,5],[16,15,58,55,4],[22,10,54,66,3]],
 heights:[[5,5,71,45,2],[12,2,70,91,1],[18,2,87,65,0],[23,3,64,48,3],[28,12,49,36,4]],
 lens:[[4,9,52,42,1],[12,7,68,75,4],[18,9,61,51,3],[25,3,60,49,0]],
 cradle:[[5,6,61,40,2],[12,10,70,51,1],[19,6,68,28,3],[23,16,42,33,5]]};
const facets={scree:['#645d67','#847a84','#c0a890','#e4c098'],roof:['#354956','#556977','#849799','#c2c3ac'],
 pools:['#495c5a','#677675','#9b9e85','#c9c0a0'],throat:['#324b4b','#4a6663','#718076','#a5ae93'],
 heights:['#4b4961','#70677d','#a496a8','#d3bfbd'],lens:['#3f6267','#618288','#9bb2a4','#d0d8bb'],cradle:['#4c594b','#6f795e','#9c9e73','#c9b77e']};
function cliff(c,a,b,w,h,seed,pal){const [shade,mid,lit,cap]=pal,peak=a+w*(.13+rand(seed)*.09),ox=a-w*.42;
 const top=[[ox,b-h*.47],[a-w*.27,b-h*.71],[peak-w*.18,b-h],[peak+w*.13,b-h*.95],[a+w*.48,b-h*.41]];
 poly(c,[[ox-6,b],...top,[a+w*.47,b+2],[a+w*.08,b+7]],shade);
 poly(c,[top[0],top[1],top[2],[peak-w*.24,b-h*.21],[a-w*.31,b-4]],mid);
 poly(c,[top[2],top[3],top[4],[a+w*.12,b-h*.12],[peak,b-h*.27]],lit);
 poly(c,[top[1],top[2],top[3],[peak+w*.1,b-h*.84],[peak-w*.08,b-h*.9]],cap);
 for(let i=0;i<5;i++){const y=b-h*(.17+.12*i);line(c,peak-w*.16,y,peak+w*.15,y+h*.04,i===3?cap:shade+'a0',i===3?2:1);}
}
export function bayLandmarks(c,p,map,s,t,ordered){
 const id=map.driftbay.id,pal=facets[id];
 for(const [x,y,w,h,seed] of formations[id]){const [a,b]=p(x+.4,y+.55);ordered.push([x+y+.7,()=>{
  c.save();if(Math.abs(s.x-x)<=1&&Math.abs(s.y-y)<=2)c.globalAlpha=.57;
  cliff(c,a,b,w,h,seed,pal);c.restore();}]);}
 if(id==='roof'){const [a,b]=p(13,9);ordered.push([21.1,()=>{poly(c,[[a-52,b-39],[a-19,b-62],[a+24,b-65],[a+63,b-53],[a+38,b-46],[a+15,b-50],[a-19,b-44],[a-42,b-32]],'#566573','#a1a397');}]);}
 if(id==='lens'){for(let k=0;k<6;k++){const [a,b]=p(21.8+k*.52,6.5-k*.11);line(c,a,b-18-k%2*5,a+1,b-2,'#cde9daae',1.35);
  const phase=(t*.75+k*.23)%1;oval(c,a+1,b-2+phase*2,2+phase*5,1+phase,'#b2dbbd65');}}
 if(id==='cradle'){const [a,b]=p(24,9);for(let i=0;i<22;i++){const theta=i*2.4,r=2+Math.sqrt(i)*2.9;oval(c,a+Math.cos(theta)*r,b+Math.sin(theta)*r*.37,2.7,1.1,'#d3cba5');}}
}
