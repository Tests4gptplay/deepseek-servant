import {face,rod,plate,box,line,oval,poly,beam,hanging,ring,lamp,sail} from '../lamplit-whale/fixtures.mjs';
import {cliff,gauge,lit,capstan,slate,timber,spool} from './shore-craft.mjs';
import {boatshed,windSock,shell} from './island-works.mjs';
export function windFeature(c,p,m,f,s,t){
 const x=f.x,y=f.y,w=f.w,h=f.h,high=s.tide==='high',night=!!s.flags['north-watch-dark'];
 if(m.id==='leeward-buttons'&&f.kind==='building'){boatshed(c,p,x,y,w,h,[2,12,22,33,13].indexOf(x),t,night);return true;}
 if(m.id==='sock-stair'){
  if(f.kind==='building'){boatshed(c,p,x,y,w,h,1,t,night);return true;}
  if(f.kind==='wall'){cliff(c,p,x,y,w,h,x===1?51:22,x);return true;}
  if(f.kind==='rope'){hanging(c,p,[x+.5,y+.4,15],[x+w-.5,y+.4,22],7,'#776f59',1.65);for(const [i,k] of [[.16,1],[.76,0]])windSock(c,p,x+w*i,y+.35,k?49:40,t,!!k);return true;}
 }
 if(m.id==='egg-meridian'){
  if(f.kind==='building'){boatshed(c,p,x,y,w,h,2,t,night);return true;}
  if(f.kind==='boat'){
   const u=x+w*.45,v=y+h*.68;
   for(let i=0;i<3;i++){beam(c,p,[u-1.3,v-.45+i*.42,3],[u+1.0,v-.45+i*.42,9],4);shell(c,p,u-.8+i*.64,v-.10,12,['#b87962','#d1ba8a','#929e8a'][i],true);}
   capstan(c,p,u+1.3,v-.35);return true;
  }
  if(f.kind==='wall'){cliff(c,p,x,y,w,h,31,11);return true;}
  if(f.kind==='rope'){const z=high?19:9;hanging(c,p,[x+.5,y+.34,z],[x+w-.8,y+.34,z-2],6,'#8b8068',2);for(const i of [.18,.54,.82])shell(c,p,x+w*i,y+.31,z-5,i===.54?'#c67b62':'#c9c1a0',i!==.54||!high);return true;}
 }
 if(m.id==='edge-bleach'){
  if(f.kind==='building'){boatshed(c,p,x,y,w,h,2,t,night);return true;}
  if(f.kind==='wall'){cliff(c,p,x,y,w,h,39,7);for(let j=0;j<3;j++)rod(c,p,[x+.45+j*.25,y+h*.82,8+j*2],[x+w*.65,y+h*.88,14+j*2],j===1?'#e1d7b3':'#a3a08b',j===1?2.4:1.1);return true;}
  if(f.kind==='rope'){hanging(c,p,[x+.18,y+.31,9],[x+w-.4,y+.31,11],8,'#b3a68b',2);return true;}
 }
 if(m.id==='fan-throat'&&f.kind==='wall'){cliff(c,p,x,y,w,h,x===3?42:25,x);return true;}
 return false;
}
export function windPlaces(c,p,m,s,t,add){
 const hi=s.tide==='high';
 if(m.id==='leeward-buttons'){
  add(14.3,10.2,()=>{sail(c,p,[12.1,9.6,32],[15.1,9.7,36],11,'#a4a68a',t,true);box(c,p,14.1,10.1,.81,.54,4,7,timber);spool(c,p,13.7,10.1,3);});
 }
 if(m.id==='sock-stair'){
  add(10.2,8.3,()=>windSock(c,p,10.2,8.3,43,t));add(18.5,9.7,()=>{for(let i=0;i<3;i++)box(c,p,17.5+i*.22,9.2+i*.3,1.2,.42,0,9-i*2,slate);gauge(c,p,19,9.7,hi);});
 }
 if(m.id==='egg-meridian'){
  add(14.9,8.3,()=>{capstan(c,p,14.9,8.3);shell(c,p,15.7,8.5,hi?10:4,'#cf8c70',!s.flags['egg-out']);});
  add(22.2,10.5,()=>{gauge(c,p,21.6,10.6,hi);hanging(c,p,[21.6,10.6,17],[23.1,10.6,9],7,'#928468',2);shell(c,p,22.5,10.6,hi?7:2,'#a0ae95',!!s.flags['float-paired']);});
 }
 if(m.id==='edge-bleach'){
  add(8.7,8.8,()=>{cliff(c,p,8.2,8.2,.9,.66,20,3);rod(c,p,[8.3,8.8,7],[9.0,8.84,13],'#dfd4ad',4);spool(c,p,9,8.9,1);});
  add(22.8,9.2,()=>{capstan(c,p,22.8,9.2);gauge(c,p,23.4,9.2,hi);});
 }
 if(m.id==='fan-throat')add(21.2,11,()=>{windSock(c,p,21.2,11,30,t,true);gauge(c,p,21.9,10.8,hi);});
}
