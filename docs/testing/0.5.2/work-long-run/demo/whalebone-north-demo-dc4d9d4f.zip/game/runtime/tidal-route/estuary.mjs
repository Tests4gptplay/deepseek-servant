import {poly,line,oval,rand} from '../paint.mjs';
import {surface,edge,post} from './surfaces.mjs';

function wash(c,p,pairs,fill){
 c.beginPath();pairs.forEach(([x,y],i)=>c[i?'lineTo':'moveTo'](...p(x,y)));c.closePath();c.fillStyle=fill;c.fill();
}
function ripple(c,x,y,w,alpha){
 c.beginPath();c.moveTo(x-w,y+1);c.bezierCurveTo(x-w*.51,y-1.9,x-w*.2,y+2,x,y+.4);
 c.quadraticCurveTo(x+w*.56,y-2,x+w,y-.5);c.lineWidth=.95;c.strokeStyle=alpha;c.stroke();
}
export function waterBody(c,p,m,s,t,visible){
 const w=m.width,h=m.height,low=s.tide!=='high',north=p(w*.7,0),south=p(w*.28,h);
 const g=c.createLinearGradient(...north,...south);g.addColorStop(0,low?'#729e9e':'#4d868c');g.addColorStop(.45,low?'#5e9290':'#417c83');g.addColorStop(.8,low?'#7ba99f':'#5c9698');g.addColorStop(1,'#779d99');
 wash(c,p,[[0,0],[w,0],[w,h],[0,h]],g);
 const channels=m.id==='hulls-not-in-line'?[[0,15,9,16,19,15,29,12.5,36,12,46,13],[0,18,11,20,22,18,32,16.8,42,14,47,16]]:[[0,9,9,9,17,11,29,12.4,39,10.2,44,8.8],[0,19,8,18,16,15.3,25,13.5,36,14,43,16]];
 for(const route of channels){
  const points=[];for(let i=0;i<route.length;i+=2)points.push(p(route[i],route[i+1]));
  c.save();c.lineCap='round';for(const [width,alpha] of [[22,'#437e7c0c'],[12,'#3b76760c'],[4,'#55918a10']]){
   c.beginPath();c.moveTo(...points[0]);for(let i=1;i<points.length-1;i++){const a=points[i],b=points[i+1];c.quadraticCurveTo(...a,(a[0]+b[0])*.5,(a[1]+b[1])*.5);}c.lineTo(...points.at(-1));c.strokeStyle=alpha;c.lineWidth=width;c.stroke();
  }c.restore();
 }
 for(let y=.5;y<h;y+=1.85)for(let x=.4;x<w;x+=2.35){
  const seed=rand(Math.floor(x*8),Math.floor(y*3)),[u,v]=p(x+seed*1.35,y+.6*rand(y,x));if(!visible(u,v,35))continue;
  const sway=t?Math.sin(t*.55+x*.43+y*.76)*.9:0;ripple(c,u,v+sway,3+seed*7,seed>.65?'#c6ded0aa':'#cee3cc55');
  if(seed>.75)ripple(c,u+5,v+2.9+sway,3+seed*4,'#4e858257');
 }
}
function pile(c,p,x,y,height){
 const [a,b]=p(x,y);oval(c,a,b+2,5.5,2.1,'#7da39a');
 poly(c,[[a-3.1,b+1],[a-3.6,b-height],[a+2,b-height-1],[a+2.9,b]],'#655e4c','#4f5c52');
 line(c,a-1,b-2,a-1.2,b-height+1,'#a79673',1);
}
function ribFoot(c,p,x,y,mirror){
 const [a,b]=p(x,y);oval(c,a+1,b+2,13.4,4.9,'#426b67');
 poly(c,[[a-13,b+1],[a-9,b-4],[a-2,b-6],[a+8,b-3],[a+14,b+1],[a+2,b+3]],'#899487','#687c72');
 for(let j=0;j<4;j++)oval(c,a-7+j*3,b-1+(j%2),1.5,.9,'#d1c9ad');
 ripple(c,a+mirror*6,b+3,11,'#c3d6bb');
}
function vaultedRib(c,p,f){
 const x=f.x+f.w*.66,y=f.y+3.3;const a=p(x,y),b=p(x-.7,y+5.5);
 ribFoot(c,p,x,y,1);ribFoot(c,p,x-.7,y+5.5,-1);
 const outer=[],inner=[],crest=[];
 for(let i=0;i<=22;i++){const q=i/22,bend=Math.sin(Math.PI*q)**.82,h=46*bend;
  const ax=a[0]*(1-q)+b[0]*q+8*bend,ay=a[1]*(1-q)+b[1]*q-h;
  const width=4.5+9*(1-q)**3+3*Math.sin(q*Math.PI);
  outer.push([ax,ay-width]);inner.push([ax+1.7,ay+width*.28]);crest.push([ax,ay-width*.70]);
 }
 poly(c,[...outer,...inner.slice().reverse()],'#c3bba0','#6f7968');
 for(let j=1;j<crest.length;j++){line(c,...crest[j-1],...crest[j],'#e1d7b6',1.2);if(j%3===0){line(c,inner[j][0]-2,inner[j][1]-1,crest[j][0]+2,crest[j][1]+3,'#9c9e86',.9);}}
 for(const q of [a,b]){line(c,q[0]-6,q[1]-2,q[0]+4,q[1]+1,'#c4b795',2);ripple(c,q[0]+5,q[1]+4,7,'#bfd6bd');}
}
function landing(c,p,x,y,w,h,roof,wall,green=false){
 const rise=24,ring=[[x,y],[x+w,y],[x+w,y+h],[x,y+h]];
 const pt=(q,z=0)=>p(q[0],q[1],z);
 const shadow=ring.map(([a,b])=>[a+.38,b+.51]);surface(c,p,shadow,0,'#315e5d55');
 const apron=[[x-.15,y-.17],[x+w+.27,y-.17],[x+w+.38,y+h+.41],[x+.19,y+h+.51],[x-.26,y+h+.21]];
 surface(c,p,apron,-2,'#8c8770','#637666');
 for(let i=.28;i<w+.1;i+=.8){pile(c,p,x+i,y+h+.44,6.5);edge(c,p,[x+i-.28,y+h+.17],[x+i+.20,y+h+.20],'#c5b291',1.1);}
 poly(c,[pt(ring[1]),pt(ring[2]),pt(ring[2],rise),pt(ring[1],rise)],'#767d69','#53695d');
 poly(c,[pt(ring[2]),pt(ring[3]),pt(ring[3],rise),pt(ring[2],rise)],wall,'#626d5d');
 for(const z of [4,8,12,16,20])edge(c,p,[x+.06,y+h],[x+w-.06,y+h],'#877e636f',.8,z);
 const a=pt(ring[0],rise),b=pt(ring[1],rise),d=pt(ring[2],rise),e=pt(ring[3],rise),rl=pt([x,y+h*.48],rise+12),rr=pt([x+w,y+h*.48],rise+12);
 poly(c,[a,b,rr,rl],roof,'#656758');poly(c,[rl,rr,d,e],roof,'#575f53');
 for(let j=.1;j<1;j+=.13){const q=u=>[rl[0]+(rr[0]-rl[0])*u,rl[1]+(rr[1]-rl[1])*u],z=u=>[e[0]+(d[0]-e[0])*u,e[1]+(d[1]-e[1])*u];line(c,...q(j),...z(j),'#c8b49488',.85);}
 for(let u=.19;u<.93;u+=.29){
  const q=[x+w*u,y+h],q2=[x+w*u+.24,y+h];poly(c,[pt(q,7),pt(q,15),pt(q2,15),pt(q2,7)],green?'#477c72':'#697c72','#d6c69e');
 }
 const door=p(x+w*.67,y+h+.015),[dx,dy]=door;
 poly(c,[[dx-6,dy-2],[dx-6,dy-14],[dx+3,dy-11],[dx+3,dy+2]],'#655f4d','#524e42');line(c,dx-4,dy-11,dx-4,dy-2,'#978269',1);oval(c,dx+1,dy-5,1,.8,'#d2b57b');
 const [cx,cy]=p(x+w*.27,y+h*.53,rise+10);
 poly(c,[[cx-3.8,cy+1],[cx-4,cy-9],[cx+2,cy-10],[cx+3.8,cy-7],[cx+3.4,cy+3]],'#947a66','#5f6457');line(c,cx-4.4,cy-9,cx+2,cy-10,'#d2ba96',1.7);
 const [nx,ny]=p(x+w*.18,y+h+.18);line(c,nx-9,ny-10,nx+9,ny-5,'#745c45',1.5);
 for(let j=0;j<5;j++){line(c,nx-9+j*4,ny-9+j*.9,nx-6+j*3.2,ny-1+j*.7,'#a5a489',1);line(c,nx-7+j*3.2,ny-1+j*.7,nx-5+j*4,ny-8+j*.9,'#758777',.9);}
 for(const u of [.1,.82])post(c,p,x+w*u,y+h+.31,9,true);
}
export function landingObject(c,p,m,f){
 const home=m.id==='hulls-not-in-line';
 if(home&&f.kind==='wall'&&f.x===33){vaultedRib(c,p,f);return true;}
 if(home&&f.kind==='wall'&&f.x===38){landing(c,p,39.3,20.0,4.7,2.2,'#9a705b','#baa786');return true;}
 if(!home&&f.kind==='wall'){
  if(f.x===19)landing(c,p,19.4,18.5,3.0,2.35,'#806b59','#a49a7f',true);
  else if(f.x===17)landing(c,p,18.1,4.7,4.8,2.1,'#896d5b','#beab88',true);
  else if(f.y===17)landing(c,p,6.8,18.4,4.1,1.95,'#a47360','#bca487');
  else landing(c,p,5.8,2.4,3.7,1.65,'#8c7863','#ab9a7e');
  return true;
 }
 return false;
}
