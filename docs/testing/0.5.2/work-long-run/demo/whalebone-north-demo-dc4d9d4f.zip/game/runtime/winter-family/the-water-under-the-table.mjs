import {poly,line,oval} from '../heelturn-cabins.mjs';

function plane(c,p,x,y,w,h,fill,edge){
 poly(c,[p(x,y),p(x+w,y),p(x+w,y+h),p(x,y+h)],fill,edge);
}
function stroke(c,p,points,tint,width=1){
 line(c,points.map(([x,y,z])=>p(x,y,z||0)),tint,width);
}
function wetBoards(c,p){
 plane(c,p,10.8,10.65,8.4,2.95,'#564c40','#483f3a');
 plane(c,p,10.98,10.8,8.02,2.63,'#274f58','#383f39');
 plane(c,p,11.10,11.05,7.81,2.22,'#37666b');
 for(let i=0;i<12;i++){
  const x=11.08+i*.63;
  const u=p(x,11.20+i%3*.44);
  line(c,[[u[0]-8,u[1]+2],[u[0]-3,u[1]],[u[0]+7,u[1]+.5]],i%3===0?'#98b9a5':'#527f7c',1.4);
 }
 for(const y of [10.74,13.28])stroke(c,p,[[10.8,y,1],[15,y,2],[18.96,y,1]],'#bd9364',3.5);
 for(const x of [11.1,14.1,18.5]){
  plane(c,p,x,10.64,.17,2.9,'#96764f','#614c39');stroke(c,p,[[x,10.65,1],[x,13.5,1]],'#d7bd8c',1);
 }
 // Narrow inspection openings stay wet. Mossed cross planks carry the playable walking lane.
 for(let i=0;i<28;i++){
  const x=10.91+i*.285,sister=x>=16.95&&x<=17.95;
  const y=sister?11.02:10.94,left=sister?1.0:2.48;
  if(i%3===0||sister)plane(c,p,x,y,.115,left,i%2?'#9d845e':'#877657','#605e49');
  if(!sister){
   plane(c,p,x,12.04,.29,.85,i%4===0?'#947c56':'#a58a61','#746349');
   stroke(c,p,[[x+.03,12.13,1.2],[x+.14,12.46,1.2],[x+.2,12.83,1.2]],'#c0a677',1.15);
  }
 }
 for(const y of [12.02,12.91]){
  stroke(c,p,[[10.89,y,1.2],[13.83,y,1.2],[16.95,y,1.2]],'#675f48',2.1);
  stroke(c,p,[[18.06,y,1.2],[18.97,y,1.2]],'#675f48',2.1);
 }
 stroke(c,p,[[17.04,12.05,1.3],[17.04,13.12,1.3],[18.01,13.12,1.3],[18.01,12.06,1.3]],'#c0a378',2.8);
 const ledge=p(18.6,12.55);oval(c,ledge,12,4,'#7e694c');
 for(let i=0;i<4;i++)stroke(c,p,[[18.45+i*.05,12.63,1],[18.38+i*.12,12.72,5+i%2*2]],'#91aa73',2.4);
}
function floe(c,p,x,y,size,high,n){
 const v=[[0,.14],[.50,0],[.97,.24],[1,.64],[.44,.94],[.10,.77]];
 const face=v.map(([a,b])=>p(x+a*size,y+b*size*.57));
 poly(c,face,high?'#97c1c4':'#668f96','#62878d');
 poly(c,face.map(([a,b])=>[a,b-3-n%3]),n%3?'#b1d3d0':'#d5e1d5','#82a6a7');
 const p0=face[0],p1=face[3];line(c,[[p0[0]+2,p0[1]-5],[(p0[0]+p1[0])/2+1,(p0[1]+p1[1])/2-8],[p1[0]-3,p1[1]-3]],'#e3e9d9',1.4);
}
function whale(c,pt,extent,phase,young){
 const [x,y]=pt;c.save();c.translate(x,y);c.rotate(-.16);c.scale(extent,extent);
 const ink=young?'#516969':'#3b5257',crest=young?'#94a9a1':'#8d9a95',water='#a4c7bd';
 function curve(fill,fn){c.beginPath();fn();c.fillStyle=fill;c.fill();}
 const rise=1.2*Math.sin(phase);
 curve(ink,()=>{c.moveTo(-45,3);c.bezierCurveTo(-35,-8,-15,-15+rise,4,-13+rise);c.bezierCurveTo(13,-13,17,-16,22,-19);c.quadraticCurveTo(21,-12,28,-10);c.quadraticCurveTo(38,-8,48,-4);c.quadraticCurveTo(57,0,45,3);c.bezierCurveTo(17,8,-25,8,-45,3);});
 c.strokeStyle=crest;c.lineWidth=1.7;c.beginPath();c.moveTo(-36,-2);c.quadraticCurveTo(-15,-13+rise,-2,-12+rise);c.stroke();
 const tx=-48,ty=2+Math.sin(phase)*1.7;
 curve(ink,()=>{c.moveTo(tx+6,ty);c.quadraticCurveTo(tx-8,ty-9,tx-23,ty-7);c.quadraticCurveTo(tx-16,ty+1,tx-6,ty+3);c.quadraticCurveTo(tx-13,ty+8,tx-20,ty+10);c.quadraticCurveTo(tx-4,ty+11,tx+8,ty+3);});
 for(let i=0;i<3;i++){c.strokeStyle=i===1?'#c6d6c6':water;c.lineWidth=1.25;c.beginPath();c.moveTo(-48-i*4,4+i*3);c.bezierCurveTo(-24,9+i,27,9+i*3,51+i*4,2+i*2);c.stroke();}
 if(!young){c.strokeStyle='#d9dfce';c.lineWidth=1.3;for(let i=0;i<4;i++){c.beginPath();c.moveTo(28,0);c.quadraticCurveTo(29+i,-13,34+i*2,-12-i*2);c.stroke();}}
 c.restore();
}
export function familyWater(c,p,map,s,t){
 if(!map.id.startsWith('whalefall-'))return;
 if(map.id==='whalefall-porch'){wetBoards(c,p);for(const [x,y,h] of [[4,2.5,1.2],[5,4.7,.9],[2,17.5,1.6],[6,19,1.1]])floe(c,p,x,y,h,s.tide==='high',1);return;}
 if(map.id==='whalefall-mouth'){
  for(let i=0;i<13;i++){const x=17.15+(i*5%17),y=.7+(i*7%10)*.45;floe(c,p,x,y,.48+(i%4)*.38,s.tide==='high',i);}
  const drift=.32*Math.sin(t*.30);whale(c,p(22.3+drift,4.5-drift),1.16,t*.8,false);whale(c,p(23.8+drift,5.7-drift),.59,t*1.3+.9,true);
  if(s.flags['whalefall-wood-short'])for(const [x,y] of [[25.3,5.4],[26.5,5.9],[27.9,6.0]]){const a=p(x,y);oval(c,a,5.8,1.4,'#c3d4bf');}
 }else if(map.id==='whalefall-glass'){
  for(let i=0;i<14;i++){const x=i<6?i%4*1.72:22+(i*3%9),y=.5+(i*7%10)*.34;floe(c,p,x,y,.85+i%3*.38,s.tide==='high',i);}
  const cup=p(10.45,8.24),rear=p(12.15,7.15);
  for(const [pt,visible] of [[cup,true],[rear,s.tide==='high']]){
   const [x,y]=pt;oval(c,[x,y],17,5,'#81a9ad');oval(c,[x,y+1],13,3.2,visible?'#587f86':'#ccdbd0');
   if(visible){c.beginPath();c.ellipse(x,y,8+Math.sin(t*.7),1.9,0,0,Math.PI*2);c.strokeStyle='#ccded6';c.lineWidth=1.2;c.stroke();}
   line(c,[[x-14,y+1],[x-8,y+3],[x+3,y+4]],'#ccbda0',1.4);
  }
  for(let i=0;i<9;i++)stroke(c,p,[[6.7+i*.72,8.0,1],[6.91+i*.7,8.1,1],[7.06+i*.7,8.09,1]],i%3?'#718b8b':'#a38b67',1.7);
 }
}
