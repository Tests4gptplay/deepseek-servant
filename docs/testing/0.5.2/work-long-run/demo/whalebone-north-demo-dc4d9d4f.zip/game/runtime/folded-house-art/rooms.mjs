import {openHeelCabin} from '../heelturn-cabins.mjs';
import {heelturnJoinery} from '../heelturn-joinery.mjs';
import {panel,cord,pointOn,oval,lantern,rope} from './materials.mjs';
import {wall,styles} from './walls.mjs';
import {stove,linens,lasts,traversed,cornerLight} from './occupants.mjs';

function house(c,p,map,f,style){
 openHeelCabin(c,p,map,f);
 const q=pointOn(f,p);
 const warm=['shop','kin','quiet'].includes(style),night=map.act===6;
 const cloth=style==='window'?'#b87960':style==='bed'?'#678077':warm?'#a7684d':'#799384';
 // A low front rail and rolled awning leave the floor and doorway visible.
 for(const u of [.11,.64])cord(c,q,[[u,.91,1],[u,.91,42]],'#5e4d39',3);
 const points=[[.08,.40,56],[.66,.40,60],[.68,.91,38],[.08,.91,34]];
 panel(c,q,points,cloth,'#6a553e');
 for(let j=0;j<6;j++){
  const u=.10+j*.093;
  if(j%2===0)panel(c,q,[[u,.40,56+j*.55],[u+.039,.40,56.2+j*.55],[u+.039,.91,34.8+j*.55],[u,.91,34.5+j*.55]],warm?'#c1a579':'#a3afa0');
  panel(c,q,[[u,.91,34+j*.6],[u+.086,.91,35+j*.6],[u+.074,.91,28+j*.62],[u+.032,.91,27+j*.62],[u,.91,29+j*.6]],j%2?cloth:warm?'#b88768':'#82968b','#655a48');
 }
 rope(c,[q(.08,.92,34),q(.31,.92,33),q(.69,.92,38)],'#bb9b68');
 const flags=style==='quiet'||night;
 lantern(c,q(.64,.92,33),flags);cornerLight(c,q,map.id);
 if(style==='bed'){
  for(let j=0;j<4;j++){
   const u=.16+j*.106;const k=q(u,.93,21+j%2*3);oval(c,k,2.7,6.3,'#aba986');
   cord(c,q,[[u,.93,33],[u,.93,25+j%2*3]],'#766346',1);
  }
 }
}
function wornRunner(c,p,f,style){
 if(f.w<6||f.h<1)return;
 const q=pointOn(f,p);
 if(style==='bed'){
  for(let j=0;j<6;j++){
   const u=.09+j*.15;cord(c,q,[[u,.42,1],[u+.031,.44,1],[u+.065,.38,1]],'#73614955',1.3);
  }
 }else if(['shop','quiet','kin'].includes(style)&&f.h>=2){
  for(const u of [.22,.69]){
   panel(c,q,[[u,.20,1],[u+.065,.20,1],[u+.065,.78,1],[u,.78,1]],style==='shop'?'#a48860aa':'#8b9177a0');
   for(let j=0;j<4;j++)cord(c,q,[[u+.012+j*.012,.24,1.3],[u+.012+j*.012,.75,1.3]],'#cbb489a0',1);
  }
 }
}
export function inhabitedHeel(c,p,map,f,s){
 const style=styles[map.id];if(!style)return false;
 if(f.kind==='wall'){wall(c,p,map,f);return true;}
 if(f.kind==='building'){house(c,p,map,f,style);return true;}
 if(f.kind==='path'){openHeelCabin(c,p,map,f);wornRunner(c,p,f,style);return true;}
 if(!['heel-pantry','heel-longbed','heel-workbench','heel-stair'].includes(f.kind))return false;
 heelturnJoinery(c,p,map,f,s);
 const q=(a,b,z=0)=>p(f.x+a,f.y+b,z),night=map.act===6;
 if(f.kind==='heel-pantry')stove(c,q,night);
 else if(f.kind==='heel-longbed')linens(c,q,night||!!s.flags['heel-bed-turned']);
 else if(f.kind==='heel-workbench')lasts(c,q,night);
 else traversed(c,q,!!s.flags['heel-child-turn']);
 return true;
}
