import {playerStation,sight} from '../content/scorerock-optics.mjs';

const labels={old:'南趾窝',beam:'东横缆',inlet:'石颊内弯',mouth:'岩嘴外'};
function fillPath(c,points,fill,stroke){
 c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();
 c.fillStyle=fill;c.fill();if(stroke){c.strokeStyle=stroke;c.stroke();}
}
function stroke(c,points,color,width=1){
 c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));
 c.strokeStyle=color;c.lineWidth=width;c.stroke();
}
export function scorerockHorizon(c,w,h,map,player,t,reduce){
 const place=playerStation(map,player);
 if(!place||!player.flags['score-old-station'])return;
 const b=sight(place,player.flags),small=w<550,card=Math.min(small?193:320,w*.53),scale=card/320;
 const x=w-card-(small?7:17),y=small?8:13;
 c.save();c.translate(x,y);c.scale(scale,scale);
 c.fillStyle='#202f30';c.fillRect(0,0,320,139);
 c.strokeStyle='#c99d62';c.lineWidth=2;c.strokeRect(2,2,316,135);
 c.fillStyle='#ead5a8';c.font='600 15px system-ui,sans-serif';
 c.fillText('米拉的瞄框   '+labels[place]+' · '+(b.facing==='south'?'回望南面':'正看北面'),12,21);
 c.save();c.beginPath();c.rect(8,29,304,91);c.clip();
 const sky=c.createLinearGradient(0,29,0,120);sky.addColorStop(0,'#667895');sky.addColorStop(.53,'#edd7b0');sky.addColorStop(1,'#d8bd9b');
 c.fillStyle=sky;c.fillRect(8,29,304,91);
 fillPath(c,[[5,77],[39,73],[63,75],[92,67],[115,72],[158,63],[191,68],[224,67],[258,73],[276,72],[315,75],[315,90],[5,90]],'#7a8990');
 c.fillStyle='#426e76';c.fillRect(8,80,304,40);
 const pos=r=>160+145*Math.atan(r)/1.30;
 if(b.cut!==null){
  const k=pos(b.cut);
  fillPath(c,[[k-45,82],[k-26,75],[k-17,68],[k-11,57],[k-6,62],[k-3,69],[k+3,69],[k+8,55],[k+14,51],[k+18,70],[k+32,75],[k+44,82]],'#384c52');
  stroke(c,[[k+6,67],[k+12,55],[k+15,57]],'#c8bb9e');
 }
 for(let i=0;i<13;i++){const yy=84+(i%5)*7,xx=10+((i*37+(reduce?0:t*2))%270);stroke(c,[[xx,yy],[xx+10,yy+.6],[xx+16,yy-1]],i%2?'#9fb6ae':'#719597',1.4);}
 if(!b.occluded&&b.spray&&b.vent!==null){
  const v=pos(b.vent),crest=reduce?.82:Math.max(0,Math.sin(t*1.8))*1.05,base=88;
  for(let i=0;crest>.04&&i<9;i++){const off=(i-4)*1.25,hh=(22-Math.abs(i-4)*2.5)*crest;
   stroke(c,[[v+off*.55,base],[v+off*.83,base-hh*.66],[v+off*1.4,base-hh],[v+off*1.6,base-hh+2.2]],i%2?'#e0eee7':'#fff5df',1.45);}
 }
 if(b.occluded&&b.facing==='north')fillPath(c,[[8,90],[8,47],[33,42],[55,43],[84,55],[103,56],[141,47],[196,44],[218,57],[225,72],[256,79],[270,94]],'#36484d','#526264');
 if(b.sleeve!==null){
  const k=pos(b.sleeve),bob=reduce?0:Math.sin(t*2.4)*1.2;
  stroke(c,[[k+5,105+bob],[k+17,112],[k+28,113]],'#e1d09c');
  fillPath(c,[[k-9,101+bob],[k+11,99+bob],[k+7,105+bob],[k-5,106+bob]],'#c99d58');
  stroke(c,[[k,100+bob],[k,76+bob]],'#433f33',2.3);
  fillPath(c,[[k,76+bob],[k+13,78+bob],[k+9,85+bob],[k,83+bob]],'#b34134','#7e3b31');
 }
 c.restore();
 for(let i=0;i<11;i++){const xx=15+i*29;stroke(c,[[xx,121],[xx,121+(i%5?3:7)]],'#bda274');}
 stroke(c,[[160,30],[160,37]],'#f1d294');stroke(c,[[160,116],[160,121]],'#f1d294');
 c.fillStyle='#d9cba8';c.font='11px system-ui,sans-serif';c.textAlign='center';c.fillText(b.facing==='south'?'船尾 · 近袖的活绳':'同高视线 · 中缝',160,134);
 c.restore();
}
