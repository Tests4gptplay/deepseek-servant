import {box,plate,face,stroke,poly,line,oval,sag,timber,stone} from './form.mjs';
function wheel(c,q,r){
 const [x,y]=q;c.save();c.translate(x,y);c.scale(.86,1);c.beginPath();c.arc(0,0,r,0,Math.PI*2);c.strokeStyle='#5f6050';c.lineWidth=3.4;c.stroke();c.beginPath();c.arc(0,0,r-2,0,Math.PI*2);c.strokeStyle='#bd9d72';c.lineWidth=1.15;c.stroke();
 for(let i=0;i<4;i++){c.rotate(Math.PI/4);line(c,-r+2,0,r-2,0,'#82775a',1.7);}oval(c,0,0,2.9,2.9,'#c0aa80');c.restore();
}
export function shops(c,p,k,x,y,w,h,z,t){
 if(k==='rope'){
  const a=x+w*.56,L=Math.min(w*.40,2.2);
  face(c,p,[[a,y+.04,47],[a+L,y+.04,47],[a+L,y+.04,z+7],[a+L*.49,y+.04,z+18],[a,y+.04,z+7]],'#415351','#725f4e');
  for(let i=0;i<7;i++)stroke(c,p,[a+.15+i*L*.11,y+.07,58],[a+.20+i*L*.11,y+.07,z+5],'#c1ab7a',1.2);
  for(const u of [a+.06,a+L-.06])stroke(c,p,[u,y+.06,45],[u,y+.06,z+8],'#ac8b61',3.4);
  face(c,p,[[a-.11,y-.22,z+4],[a+L*.50,y-.22,z+19],[a+L*.5,y+.36,z+17],[a-.13,y+.36,z+2]],'#7f948c','#5b7169');
  face(c,p,[[a+L*.50,y-.22,z+19],[a+L+.16,y-.22,z+5],[a+L+.16,y+.36,z+2],[a+L*.5,y+.36,z+17]],'#536f70','#5a6459');
  box(c,p,a-.12,y+.03,L+.23,.55,44,4,timber);for(const u of [a,a+L-.14])stroke(c,p,[u,y+.04,35],[u,y+.51,44],'#766450',3.2);
  stroke(c,p,[a+L*.55,y-.09,z+8],[a+L*.55,y+.93,z+5],'#796145',4);const q=p(a+L*.55,y+.91,z+3);wheel(c,q,3.5);
  sag(c,p,[a+L*.55,y+.88,z],[a+L*.55,y+.73,14],2,'#b9a06f',1.45);
 }else if(k==='pump'||k==='sluice'){
  const a=x+w*.44,yy=y+.07;
  if(k==='pump'){
   box(c,p,a-.55,yy,1.23,.42,0,9,stone);
   const q=p(a,yy+.26,21);wheel(c,q,14);
   stroke(c,p,[a-.25,yy+.17,13],[a-.25,yy+.17,35],'#697971',3.4);
   for(let i=0;i<2;i++)stroke(c,p,[a+.58+i*.19,yy+.07,7],[a+.58+i*.19,yy+.07,z+7],'#74887b',3);
   box(c,p,x+w*.67,y-h*.43,.79,.57,z+7,13,['#a39e7e','#7b8c80','#667e78']);
   for(let i=0;i<3;i++)stroke(c,p,[x+w*.67+.10,y-h*.43+.58,z+11+i*3],[x+w*.67+.68,y-h*.43+.58,z+11+i*3],'#4c6965',1.3);
  }else{
   face(c,p,[[a,yy,5],[a+1.05,yy,5],[a+1.05,yy,30],[a,yy,30]],'#4f6968','#777c65');
   for(let n=0;n<6;n++)stroke(c,p,[a+.08,yy+.02,7+n*3.8],[a+.98,yy+.02,7+n*3.8],'#a39e78',1.6);
   for(const u of [a-.05,a+1.09])stroke(c,p,[u,yy+.05,1],[u,yy+.05,36],'#817455',3);
   wheel(c,p(a+.52,yy+.09,35),6.7);
  }
 }
}
export function gantry(c,p,s,t){
 for(const [x,y] of [[14.93,8.57],[15.51,8.57]]){
  box(c,p,x-.11,y-.12,.22,.24,0,57,timber);
  stroke(c,p,[x,y,18],[x-.10,y+1.30,53],'#a68c64',4.2);
 }
 const a=[15.23,8.50,55],b=[13.44,12.42,61];
 stroke(c,p,a,b,'#514c41',8);stroke(c,p,[a[0],a[1],57],[b[0],b[1],63],'#c0a67c',2.25);
 wheel(c,p(...b),5.2);const level=s.flags['coffin-aboard']?40:20;const swing=Math.sin(t*.68)*.025;
 for(const dx of [-.04,.04])sag(c,p,[b[0]+dx,b[1],58],[b[0]+dx+swing,b[1],level],0,'#847356',1.3);
 const q=p(b[0]+swing,b[1],level);c.beginPath();c.moveTo(q[0],q[1]);c.bezierCurveTo(q[0]-1,q[1]+5,q[0]+6,q[1]+7,q[0]+6,q[1]+1);c.strokeStyle='#5a6154';c.lineWidth=2;c.stroke();c.lineWidth=1;
}
