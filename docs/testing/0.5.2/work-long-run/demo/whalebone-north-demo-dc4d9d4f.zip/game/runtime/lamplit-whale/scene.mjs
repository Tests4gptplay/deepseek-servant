import {oilHouse,seamShop,oilskin} from './signal-shop.mjs';
import {raisedDeck,lowerHouses,roofHousehold} from './cutaway.mjs';
export {lowerHouses};
import {roofBuildings,roofThings} from './roofs.mjs';
import {pitFloor,pitFeature} from './hoist.mjs';
import {quarters,wardBed,corridor} from './cabins.mjs';
import {lockThings,blinds,lockMark} from './watergate.mjs';
import {hem,ribDeck,lash,roomWork} from './residents.mjs';
import {rod,beam,box,plate,lamp,face,ring,oak,tar,brass,sail,oval} from './fixtures.mjs';
const places=new Set(['upper-spar','whale-roofs','counterlift','crib-hold','dry-court','organ-lock','west-lamp','seam-cell']);
export const lamplit=id=>places.has(id);
export function whaleFloor(c,p,m,s,t){
 if(m.id==='whale-roofs'){raisedDeck(c,p,m,s,t);ribDeck(c,p,s,t);}
 if(m.id==='counterlift')pitFloor(c,p,s,t);
 if(m.id==='crib-hold')corridor(c,p,s,t);
 if(m.id==='upper-spar')lash(c,p,s,t);
 if(m.id==='west-lamp'){
  for(const x of [6.6,9.8]){rod(c,p,[x,10.2,1],[x-.75,14.15,1],'#8c8b76',1.5);}
 }
}
export function whaleFeature(c,p,m,f,s,t){
 if(f.id)return false;
 if(m.id==='whale-roofs'){
  if(roofBuildings(c,p,f,t))return true;
  if(f.label==='无人应的炉灯'){beam(c,p,[15.4,7.4,0],[15.4,7.4,23],3.4);lamp(c,p,15.4,7.4,22,t,true,1);return true;}
 }
 if(m.id==='counterlift')return pitFeature(c,p,f,s,t);
 if(['dry-court','crib-hold'].includes(m.id)&&quarters(c,p,f,m,t))return true;
 if(m.id==='organ-lock')return lockThings(c,p,f,s,t);
 if(m.id==='west-lamp'&&f.label==='灯油小库'){oilHouse(c,p,f,t);return true;}
 if(m.id==='west-lamp'&&f.label==='遮光百叶'){blinds(c,p,s,t);return true;}
 if(m.id==='west-lamp'&&f.label==='信号柱'){
  for(const [x,y,h] of [[15.85,9.8,37],[15.85,12,31]]){box(c,p,x,y,.38,.39,0,h,tar);ring(c,p(x+.17,y+.21,h),5,'#b29a72');}
  beam(c,p,[16.03,9.98,29],[16.03,12.18,24],4);return true;
 }
 if(m.id==='seam-cell'&&f.label==='旧帆架'){
  box(c,p,8.1,2.3,3.58,1.5,0,8,oak);for(let i=0;i<4;i++){const x=8.35+i*.76;beam(c,p,[x,3.4,7],[x,3.4,25],3.1);sail(c,p,[x,3.46,24],[x+.6,3.46,24],9+i%2*4,['#a4aa94','#c4ab89','#94a093','#c1b798'][i],t);}return true;
 }
 return false;
}
export function whaleEntity(c,p,m,e,s,t){
 if(m.id==='whale-roofs')return roofThings(c,p,e,s,t);
 if(m.id==='counterlift'&&e.id==='lift-invert'){const x=15.28,y=8.35;box(c,p,x,y,.54,.37,0,10,oak);rod(c,p,[x+.15,y+.22,10],[x+.47,y+.21,s.flags['lift-proved']?13:23],'#bfa274',2.8);return true;}
 if(m.id==='crib-hold'&&e.id==='underbed-bar'){wardBed(c,p,s,t);return true;}
 if(m.id==='seam-cell'&&e.id==='bobbins-gear'){oilskin(c,p,e,s,t);return true;}
 if(m.id==='seam-cell'&&e.id==='old-sail-hems'){hem(c,p,s,t);return true;}
 if(m.id==='crib-hold'&&e.id==='bar-after-move'){
  if(s.flags['bar-freed']){const x=e.x+.21,y=e.y+.35;box(c,p,x,y,.43,.26,0,4,oak);rod(c,p,[x+.06,y+.1,4],[x+.39,y+.1,5],'#d0ab72',1.5);}
  return true;
 }return lockMark(c,p,e,s,t);
}
export function whalePlaces(c,p,m,s,t,ordered){const add=(depth,draw)=>ordered.push([depth,draw]);roomWork(c,p,m,s,t,add);if(m.id==='whale-roofs')roofHousehold(c,p,s,t,add);if(m.id==='seam-cell')seamShop(c,p,s,t,add);}