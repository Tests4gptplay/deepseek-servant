const ids=new Set(['aunt-stays','port-crust','port-stool','share-salt','port-window','port-pan','roof-own-name','roof-chew','ivo-screen','ivo-far','child-question','child-apart','mother-open','mother-hush','mara-wait','mara-leave']);
export function attachHearthVoice(ui,button){
 const media=document.createElement('audio');media.hidden=true;media.dataset.lullabyAudio='';media.preload='auto';button.parentElement.append(media);
 let generation=0,objectUrl=null,pending=null;
 function stop(){generation++;pending?.abort();pending=null;media.pause();delete media.dataset.clip;delete media.dataset.file;
  if(objectUrl){media.removeAttribute('src');media.load();URL.revokeObjectURL(objectUrl);objectUrl=null;}}
 const show=ui.show,hide=ui.hide;ui.show=(...args)=>{stop();show(...args);};ui.hide=()=>{stop();hide();};
 ui.hearthVoice=async id=>{if(!ids.has(id)||button.getAttribute('aria-pressed')!=='true')return;
  const at=generation,req=new AbortController();pending=req;media.dataset.clip=id;media.dataset.file=id+'.ogg';
  try{const source=await fetch(new URL('../assets/lullaby-voices/'+id+'.ogg',import.meta.url),{signal:req.signal});if(!source.ok)return;
   const clip=await source.blob();if(at!==generation||button.getAttribute('aria-pressed')!=='true')return;
   objectUrl=URL.createObjectURL(clip);media.src=objectUrl;media.volume=.77;await media.play();
  }catch{}finally{if(pending===req)pending=null;}};
 new MutationObserver(()=>{if(button.getAttribute('aria-pressed')!=='true')stop();}).observe(button,{attributes:true,attributeFilter:['aria-pressed']});
}
