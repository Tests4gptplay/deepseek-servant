export function workAtObject(api,key){
 const {c,s,show,note,record}=api;
 const hull=key==='hull',tool=c[key]??={inside:false,level:'high'};
 const title=hull?'贴合船肋的双边木规':'浴房两只补过的篓衬';
 const turn=hull?'舟首倒榫':'蓝线毛边',low=hull?'舷线':'热汽',high=hull?'岸墙':'冷盐水';
 function menu(){
  const instruction=hull?'沿舟首倒榫看：上排六道一路直通岸墙，下排四道弯痕能随舷升降。退水才能贴到下排。':'热汽穿过里层，会留一小片麦黄色。外侧的六圈蓝线都能擦上盐，不能凭颜色说六袋都上过船。';
  const face=tool.inside?'内面朝你':'外面朝你',at=tool.level==='low'?low:high;
  show(title,instruction+' 现在'+face+'，木规压在'+at+'。',[
   ['翻到'+turn+'的另一面',()=>{tool.inside=!tool.inside;menu();}],
   ['把规脚移到'+(tool.level==='low'?high:low),()=>{tool.level=tool.level==='low'?'high':'low';menu();}],
   [hull?'压下木规取四个会随船升降的拓痕':'揭开两只袋底看麦浆透到哪层',()=>{
    if(!tool.inside||tool.level!=='low'||(hull&&s.tide!=='low')){
     c.falseSamples=(c.falseSamples||0)+1;
     const reason=hull&&s.tide!=='low'?'潮水漫过下排；廊外有双尺，等退水再回到这一点。':!tool.inside?'正面印着同一名字，六件都会蹭上。把木规或篓衬翻转到背面。':'这一排碰的是岸墙或袋外咸水。沿指示移到舟身或热灶的一边。';
     show(title,reason,[['把无用的样留作对照，重新摆',menu]]);return;
    }
    record(key);
    note(title,hull?'四道抽长的弯痕靠着活动船肋。第五、第六道直且短，贯进岸墙，移动舟身不能带走它们。取到四弯二直的拓样。请到浴房让另一位在场者说亲眼见的那半边。':'两只袋从里面烫黄，缝脚里有熟麦，四只外面有盐、内芯仍干。取到两热四干的对照。去五号泊问亲手站船的人，谁把这两只带去了哪儿。');
   }]
  ],'quaybill-work',hull?'退潮时用尺；平潮去看浴房的锅也能独立查。':'篓衬两面都能再翻。另一条取证路可从船舷开始。');
 }
 menu();
}

export function hearBothSides(api,key){
 const {c,s,show,note,mark}=api,hull=key==='runner',needed=hull?'basket':'hull';
 const title=hull?'舟脚庹英':'借灶人岑藕',crew=s.expedition?.roster||[];
 const remember=mode=>{
  if(c.material?.[needed]!==c.round){note(title,hull?'我的脚只踩在舟里，跟船走的四袋我数过。剩下两袋去了哪里，先去浴房的篓衬取样再回来。不凭船上的耳闻替岸上的人作证。':'我在岸屋接过两袋。你得先到五号泊认出哪几道磨痕属于活动舟身，再回来问我两处是不是同一趟。');return;}
  c.witness={key,mode,round:c.round};mark('voice');
  const line=hull?(mode==='watch'?'伊沃把自己的旧港卫绳留在门外，把误封求救路的事讲给她听。庹英说：“我押着四袋上跳板，另外两袋转到浴房，我还去领过那锅热麦。我肯署船脚班，不写谁在发烧。”':'庹英用脚跟给玛拉比第四眼。她只认四袋过舷，两袋在岸边换了手。她愿意在盲号下面留鞋底拓印。'):(mode==='kin'?'瑟琳把家里的第二把勺拿出来。岑藕认出那一勺就是替她舅母留的，说出那天亲手撕下的两条里衬。瑟琳愿意陪她去作证，要求保住病人的姓名。':'玛拉退到门帘外。岑藕只从门槛送出一片烫黄的旧里衬。她肯承认岸灶实收两袋，要把人名留下。');
  note(title,line);
 };
 const options=hull?[['让庹英只说脚下亲见的东西',()=>remember('foot')]]:[['把取证板留在帘外，请她自己挑能说的话',()=>remember('blind')]];
 if(hull&&crew.includes('ivo'))options.unshift(['请伊沃先交代他曾封过求救航道',()=>remember('watch')]);
 if(!hull&&crew.includes('selene'))options.unshift(['请同行的瑟琳拿出家里的一把勺',()=>remember('kin')]);
 const extra=hull?'她不想再给穿制服的人写一句能拿走饭碗的话。':'岑藕把两把勺收进袖口，有一把是瑟琳家人的。未经同意，谁也不递给公议桌。';
 show(title,extra,options);
}
