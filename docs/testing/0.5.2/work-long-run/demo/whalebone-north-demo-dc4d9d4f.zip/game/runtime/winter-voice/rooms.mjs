import {panel,cord,oval,rope,lantern} from '../folded-house-art/materials.mjs';
const ink='#314947',bone='#dccfa6',pale='#e6d9b3',oak='#73583e';
function wetTable(c,q,t){
 panel(c,q,[[.05,.52,12],[.65,.52,12],[.65,.93,12],[.05,.93,12]],'#54796e',ink);
 for(let i=0;i<6;i++){const x=.07+.09*i;cord(c,q,[[x,.6,13],[x+.038,.70,13],[x+.018,.78,13]],'#9dbdb4',1.5);}
 for(const x of [.14,.88])cord(c,q,[[x,.22,0],[x,.22,31]],oak,4);
 panel(c,q,[[.035,.10,30],[.96,.10,30],[.96,.60,30],[.035,.60,30]],'#a98860',ink);
 for(const x of [.22,.54,.78]){
  oval(c,q(x,.38,32),9,4.5,'#7c6a4e');oval(c,q(x,.38,34),8,3.5,pale);oval(c,q(x,.38,35),5.9,2.1,x===.54?'#8c7044':'#809889');
 }
 const k=q(.53,.82,14);oval(c,k,7,2.9,'#b8a783');for(let j=0;j<3;j++)cord(c,q,[[.46+j*.045,.8,16],[.44+j*.04,.9,18+Math.sin(t*.76)*1.3]],'#8da667',2);
 cord(c,q,[[.81,.59,29],[.81,.68,23],[.76,.77,16]],'#bca876',2.3);
}
function ice(c,q){
 for(const [u,h,col] of [[.36,47,'#82a9afdc'],[.08,35,'#abd0cbe1']]){
  const pts=[[u,.31,2],[u+.43,.18,5],[u+.51,.22,h*.76],[u+.40,.25,h],[u+.06,.35,h*.87]];
  panel(c,q,pts,col,'#71999d');cord(c,q,[[u+.08,.33,h*.82],[u+.19,.28,h*.60],[u+.15,.28,h*.52],[u+.30,.24,h*.34]],'#deeee3',1.8);
  cord(c,q,[[u+.19,.28,h*.59],[u+.32,.25,h*.71],[u+.36,.24,h*.69]],'#b7d6d2',1.4);
 }
 const k=q(.43,.57,11);oval(c,k,3.9,3,'#ab8458');cord(c,q,[[.44,.54,11],[.47,.68,9]],'#bd8255',2);
}
function shell(c,q,u,v,z,scale=1){const [x,y]=q(u,v,z);c.save();c.translate(x,y);c.scale(scale,scale);
 c.beginPath();c.moveTo(-6,2);c.quadraticCurveTo(-4,-6,0,-6);c.quadraticCurveTo(4,-5,6,2);c.quadraticCurveTo(0,5,-6,2);c.fillStyle='#c5bda1';c.fill();c.strokeStyle='#797e69';c.stroke();
 for(const dx of [-3,0,3]){c.beginPath();c.moveTo(dx*.4,-4);c.lineTo(dx,1.5);c.stroke();}c.restore();}
function keel(c,q){
 panel(c,q,[[.02,.3,9],[.13,.27,37],[.63,.19,45],[.96,.29,30],[.91,.47,15],[.43,.59,3]],'#5a6356',ink);
 for(const [i,col]of ['#87917a','#ad9c77','#777c67','#444f49'].entries())cord(c,q,[[.08,.32,12+i*5],[.30,.39,9+i*5],[.64,.36,15+i*5],[.94,.32,21+i*3]],col,1.7);
 for(const [u,v,z,k]of [[.32,.43,17,1.3],[.42,.44,15,.94],[.50,.45,13,.72]])shell(c,q,u,v,z,k);
}
function cradle(c,q,boneRoom){
 if(boneRoom){for(let i=0;i<7;i++){const u=.1+i*.12;cord(c,q,[[u,.89,1],[u-.04,.80,19],[u-.07,.55,34+i%3*3],[u-.02,.35,42],[u+.07,.19,29],[u+.1,.12,4]],i%2?bone:'#baad8b',6);}}
 else{
  for(const [u,z]of [[.07,34],[.88,28]])cord(c,q,[[u,.5,0],[u,.5,z]],oak,3.5);
  rope(c,[q(.07,.5,33),q(.37,.52,24),q(.54,.55,22),q(.88,.5,27)]);
  for(const [u,z]of [[.34,15],[.62,18]]){cord(c,q,[[u,.53,z+9],[u,.53,z]],bone,1.2);oval(c,q(u,.53,z),5.8,2.6,'#c5ac7e');}
 }
}
function signal(c,q,kind,s,t){
 const post=kind==='voice-lamp'||kind==='voice-watch';
 for(const u of [.21,.71])cord(c,q,[[u,.46,0],[u,.46,post?43:31]],oak,4);
 cord(c,q,[[.18,.46,post?39:30],[.74,.46,post?43:30]],ink,3);
 if(kind==='voice-bell'){
  const wool=s.flags['whalefall-wool-set'];panel(c,q,[[.38,.46,27],[.56,.46,27],[.64,.46,11],[.30,.46,10]],wool?'#a5a290':'#ba9b64',ink);oval(c,q(.465,.47,10),8.3,2.4,ink);
  if(wool)cord(c,q,[[.32,.48,13],[.59,.48,16]],pale,2.5);
 }else if(kind==='voice-dial'){
  for(let i=0;i<8;i++){const u=.21+i*.073;cord(c,q,[[u,.46,29],[u,.46,21+i%2*3]],i===4?'#a46848':pale,1.7);}
 }else if(kind==='voice-lamp'){for(const u of [.22,.68])lantern(c,q(u,.49,32),!!s.flags['whalefall-lantern-set']);}
 else{
  const z=1.5+Math.sin(t*.87)*.8;for(let i=0;i<3;i++){const u=.20+i*.24;const pt=q(u,.3,z);oval(c,pt,7-i,1.5,'#d0dfd3');}
 }
}
export function drawVoiceRoom(c,p,map,f,s,t){
 if(!map.id.startsWith('whalefall-')||!f.kind.startsWith('voice-'))return false;
 const q=(u,v,z=0)=>p(f.x+f.w*u,f.y+f.h*v,z);
 c.save();try{switch(f.kind){
 case 'voice-table':wetTable(c,q,t);break;case 'voice-ice':ice(c,q);break;case 'voice-keel':keel(c,q);break;
 case 'voice-cord':cradle(c,q,false);break;case 'voice-bone':cradle(c,q,true);break;
 default:signal(c,q,f.kind,s,t);
 }}finally{c.restore();}return true;
}
