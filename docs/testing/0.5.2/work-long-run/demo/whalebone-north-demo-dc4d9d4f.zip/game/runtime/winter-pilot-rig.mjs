import {line,oval,poly,arc} from './paint.mjs';
import {box,wood,iron,plate,bed,parchment} from './voyage-shapes.mjs';
import {wheelCradle,waterEye,sluice,cord,tideStep} from './whale-rigging.mjs';
import {skiff,servingWindow} from './harbor-crafts.mjs';
import {figure} from './figures.mjs';
export const pilotMaps=new Set(['red-beacon','shiver-bars','split-cistern','dry-share']);
export function redArm(c,p,x,y,extended,near){
 const base=['#b78770','#895e56','#5d4a4c'];
 box(c,p,x-.53,y-.47,1.06,.94,0,24,base);box(c,p,x-.48,y-.43,.96,.86,24,18,['#cb9b82','#99715e','#765550']);
 const f=Number(extended),a=p(x,y,40),b=p(x+.31+1.09*f,y+(near?.58:-.36),62-21*f);
 line(c,...a,...b,'#514d44',7);line(c,a[0],a[1]-1,b[0],b[1]-1,'#dabb89',3.1);
 oval(c,...a,6.5,5.2,'#a5a997');oval(c,...a,2.5,2.4,'#424e4e');
 let lamp=p(x+.23,y+.41,22);poly(c,[[lamp[0]-7,lamp[1]-8],[lamp[0]+7,lamp[1]-9],[lamp[0]+7,lamp[1]+4],[lamp[0]-7,lamp[1]+5]],f>.60?'#f6cf83':'#44595a','#d1ad82');
 cord(c,b,p(x+.87,y+.67,6),9-6*f,'#957652',2);
}
export function transitMark(c,p,x,y,fixed,tide){
 const high=tide==='high',q=p(x,y,4);poly(c,[[q[0]-32,q[1]+6],[q[0]-21,q[1]-12],[q[0]-4,q[1]-20],[q[0]+21,q[1]-13],[q[0]+27,q[1]+1],[q[0]+6,q[1]+11]],fixed?'#596d69':'#a2b5ae','#4e6a6b');
 if(fixed){oval(c,q[0]+2,q[1]-9,8,4,'#d3b68a');oval(c,q[0]+2,q[1]-9,4.2,2.5,'#334343');}
 for(let i=0;i<3;i++)line(c,q[0]-19+i*12,q[1]+(high?-6:4),q[0]-8+i*12,q[1]+(high?-7:2),'#b2d8c7',1.6);
}
export function backWindow(c,p,x,y){
 for(const dx of [-.67,.67]){line(c,...p(x+dx,y,3),...p(x+dx,y,40),'#735b50',4);}
 line(c,...p(x-.70,y,40),...p(x+.75,y,40),'#c9a676',3);line(c,...p(x-.70,y,25),...p(x+.75,y,25),'#dcc393',4);
 for(const dx of [-.34,.22]){const q=p(x+dx,y+.42,15);oval(c,...q,3.2,2.1,'#d5b773');}
}
function jars(c,p,x,y){
 for(let i=0;i<3;i++){const [a,b]=p(x+(i%2)*.58,y+Math.floor(i/2)*.39);oval(c,a,b-4,8,7,i%2?'#9d7d5e':'#73958b');oval(c,a,b-10,4.4,2.3,'#d1bb93');}
}
export function winterRig(c,p,m,s,t,ordered,blend){
 if(!pilotMaps.has(m.id))return;
 const f=s.flags,high=s.tide==='high';
 const add=(x,y,draw)=>ordered.push([x+y+.42,draw]);
 if(m.id==='split-cistern'){
   for(const [x,y,fresh] of [[5.0,9.2,false],[7.15,9.5,true],[10.8,8.7,false],[17.1,11.4,true],[21.4,10.5,false],[23.6,9.6,true]])add(x,y,()=>waterEye(c,p,x,y,fresh,!!f['rinse-out']));
   for(const [x,y] of [[7.2,9.6],[14.1,9.3],[20.0,9.6],[22.65,10.6]])add(x,y,()=>sluice(c,p,x,y,blend('rinse-out')));
   const points=[[5,9.3],[8.3,9.5],[11.1,9.1],[14.6,9.8],[17,11.6],[20,10],[23,10.5]];
   for(let i=1;i<points.length;i++){const [x,y]=points[i],a=p(...points[i-1],3),b=p(x,y,3);cord(c,a,b,1,'#817a65',8);cord(c,a,b,1,f['trap-open']?'#70a4a1':'#b1cbb5',3); }
 }else if(m.id==='red-beacon'){
   for(const [x,y,near] of [[11.7,7.7,false],[14.9,9.8,true],[18.6,9.1,true]])add(x,y,()=>redArm(c,p,x,y,near?blend('remote-lit'):blend('outer-arm'),near));
   const pos=[[8,9],[12,8],[15,10],[19,9]];for(let i=1;i<pos.length;i++)cord(c,p(...pos[i-1],7),p(...pos[i],7),9,'#aa8760',2.3);
 }else if(m.id==='shiver-bars'){
   for(const [x,y] of [[7,9],[15.7,9.6],[26.15,10.7]])add(x,y,()=>transitMark(c,p,x,y,true,s.tide));
   for(const [x,y] of [[11,7.8],[21.8,8.6],[27.6,9.8]])add(x,y,()=>backWindow(c,p,x,y));
   for(const x of [9,23.2])add(x,11.4,()=>skiff(c,p,x,11.4,s.tide,t));
 }else{
   for(const [x,y] of [[7.6,9.1],[12.6,10.6],[15.6,9.7]])add(x,y,()=>{jars(c,p,x,y);const a=p(x+1.0,y-.36);figure(c,...a,'relay-tender',t,{scale:1.1});});
   add(11,10,()=>bed(c,p,11,10,true));add(13.25,11.16,()=>{bed(c,p,13.25,11.16,true);const q=p(13.53,11.55,11);oval(c,...q,5.2,4,'#d2a887');line(c,q[0]+5,q[1]+4,q[0]+17,q[1]+6,'#b58b74',3);});add(14.4,11.7,()=>skiff(c,p,14.4,11.7,s.tide,t,true));
 }
}
