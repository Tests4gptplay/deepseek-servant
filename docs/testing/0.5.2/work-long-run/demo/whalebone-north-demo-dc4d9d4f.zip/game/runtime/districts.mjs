// Spatial treatment follows the authored map and completed story conditions.
const cabins=new Set(['counterlift','crib-hold','organ-lock','seam-cell','bell-cistern']);
const rooms=new Set(['wick-house','brine-weigh','witness-loft','seal-vault']);
export function district(map){
 if(map.id==='wick-house')return 'vigil';
 if(cabins.has(map.id)||/underdeck|hold|bilge|cistern/.test(map.biome||''))return 'hold';
 if(rooms.has(map.id)||/interior|indoor|cellar/.test(map.biome||''))return 'room';
 if(map.id==='upper-spar'||map.id==='whale-roofs'||['net-heron','awning-rafters','counter-gantry'].includes(map.id))return 'roofs';
 if(map.id==='ration-berth')return 'ration';
 if(map.id==='signal-gallery'||map.id==='west-lamp')return 'signal';
 if(map.id==='trim-yard'||map.id==='lower-tide')return 'yard';
 if(map.id==='wake-court'||map.id==='dry-court')return 'court';
 if(map.biome==='salt-market')return 'salt';
 return 'port';
}
export const enclosed=k=>k==='vigil'||k==='room'||k==='hold';
export function hull(map){return map.biome==='whale-city'||/underdeck|bilge|whale-roof/.test(map.biome||'');}
export function roomBackdrop(c,w,h,k){
 const shade=c.createRadialGradient(w*.51,h*.49,0,w*.51,h*.48,Math.max(w*.7,h*.85));
 shade.addColorStop(0,k==='hold'?'#485551':'#65544b');shade.addColorStop(.52,k==='vigil'?'#413532':'#343d3c');shade.addColorStop(1,'#172426');
 c.fillStyle=shade;c.fillRect(0,0,w,h);
}
