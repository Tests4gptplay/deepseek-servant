import {face,rod,beam,plate,box,ring,lamp,hanging,sail,oval,oak,tar,brass} from './fixtures.mjs';
function section(c,p,a,b,inside,t){
 const start=p(...a,0),end=p(...b,0),sx=end[0]-start[0],sy=end[1]-start[1],len=Math.hypot(sx,sy);
 if(len<20)return;
 c.save();c.transform(sx/len,sy/len,0,1,start[0],start[1]);
 const grad=c.createLinearGradient(0,1,0,66);grad.addColorStop(0,'#334d52');grad.addColorStop(.46,'#41616a');grad.addColorStop(.82,'#526e6b');grad.addColorStop(1,'#71897d');
 c.beginPath();c.moveTo(0,-1);c.lineTo(len,-1);c.lineTo(len,57);c.quadraticCurveTo(len*.57,74,0,53);c.closePath();c.fillStyle=grad;c.fill();
 for(let y=12;y<55;y+=8){c.beginPath();c.moveTo(0,y);c.quadraticCurveTo(len*.50,y+7,len,y+2);c.strokeStyle=y%3?'#607b74':'#688179';c.lineWidth=1.1;c.stroke();}
 const count=Math.floor(len/45);for(let i=0;i<count;i++){
  const x=19+i*45; c.beginPath();c.moveTo(x,-1);c.bezierCurveTo(x-2,15,x+7,43,x+13,56);c.lineWidth=3.5;c.strokeStyle='#344f52';c.stroke();c.lineWidth=1;
  if(i%4===2)continue;const gx=x+12,gy=22+(i%2)*5;c.fillStyle='#364f50';c.fillRect(gx-1,gy-1,13,11);c.fillStyle=i%3===1?'#d8b979':'#a69c73';c.fillRect(gx+1,gy+2,9,5);c.fillStyle='#57685c';c.fillRect(gx+5,gy+2,1.5,5);c.fillStyle='#ac9c73';c.fillRect(gx-2,gy+8,15,1.5);
 }
 c.beginPath();c.moveTo(0,3);c.lineTo(len,3);c.lineWidth=3;c.strokeStyle='#ac9c71';c.stroke();c.restore();
}
export function lowerHouses(c,p,m,t){
 if(m.id!=='whale-roofs')return;
 section(c,p,[m.width,2],[m.width,m.height],true,t);section(c,p,[0,m.height],[m.width,m.height],false,t);
}
export function raisedDeck(c,p,m,s,t){
 if(m.id!=='whale-roofs')return;const y=11.7;
 for(const [x,dy,len] of [[3,6.5,5.3],[10.1,10.2,4.3],[20.7,y,5.2],[10.6,13.6,3.6]]){
  face(c,p,[[x,dy,1],[x+len,dy,1],[x+len,dy+.31,1],[x,dy+.31,1]],'#6476708c');
  rod(c,p,[x,dy+.1,1],[x+len,dy+.1,1],'#b0a180',1);for(let i=0;i<len;i+=.54){const q=p(x+i,dy+.21,2);oval(c,...q,1.35,.82,'#706854');}
 }
 for(const [x,y,w] of [[20.6,12.58,1.65],[22.1,9.12,1.4],[10.9,8.7,1.5],[15.9,12.8,1.25]]){
  box(c,p,x,y,w,.75,0,2,['#7f8c80','#706e60','#62716b']);plate(c,p,x+.11,y+.08,w-.23,.55,2.2,'#566c67');
  for(let i=.22;i<w-.12;i+=.29)beam(c,p,[x+i,y+.08,3],[x+i,y+.65,3],2.75);
 }
}
export function roofHousehold(c,p,s,t,add){
 const x=23.52,y=11.43;
 add(x+y,()=>{box(c,p,x-.48,y-.3,.96,.73,0,12,oak);face(c,p,[[x-.47,y+.44,10],[x+.43,y+.44,10],[x+.43,y+.44,2],[x-.47,y+.44,2]],'#495e59');for(const i of [-.30,.02,.31])rod(c,p,[x+i,y+.48,2],[x+i,y+.48,10],'#baa67d',2);lamp(c,p,x+.15,y+.46,10,t,true,.72);});
 add(34.4,()=>{const x=22.3,y=10.52;beam(c,p,[x,y,0],[x,y,26],3);beam(c,p,[x+1.86,y,0],[x+1.86,y,27],3);hanging(c,p,[x,y,26],[x+1.86,y,27],3,'#beac82',2);
  sail(c,p,[x+.12,y,24],[x+.85,y,24],15,'#a9715e',t,true);sail(c,p,[x+1.04,y,24],[x+1.56,y,24],11,'#d5cba8',t);});
}