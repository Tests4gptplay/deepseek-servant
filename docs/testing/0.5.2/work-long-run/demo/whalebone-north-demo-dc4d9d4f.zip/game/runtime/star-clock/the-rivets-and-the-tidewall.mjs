import {poly,line,oval,rand} from '../paint.mjs';
import {underStars} from './surfaces-under-starlight.mjs';

const sprite=typeof Image==='undefined'?null:new Image();
if(sprite)sprite.src=new URL('../../assets/star-watch/verdigris-watch-house.png',import.meta.url).href;
export function copperDome(c,p,f){
 if(!sprite?.complete||!sprite.naturalWidth)return false;
 const [a,b]=p(f.x+f.w*.5,f.y+f.h*.56);
 const scale=(f.w+f.h)*20/406;
 c.drawImage(sprite,a-240*scale,b-230*scale,480*scale,325*scale);return true;
}
function dryWall(c,q,w,h,z,cellar){
 const corners=[q(0,0,z),q(w,0,z),q(w,h,z),q(0,h,z)];
 poly(c,[q(0,h),q(w,h),q(w,h,z),q(0,h,z)],cellar?'#716958':'#526769','#344c52');
 poly(c,[q(w,h),q(w,0),q(w,0,z),q(w,h,z)],cellar?'#504e44':'#40565c','#344c52');
 poly(c,corners,cellar?'#a19679':'#718785','#455e63');
 for(let j=1;j<3;j++){const height=z*j/3;line(c,...q(0,h,height),...q(w,h,height),cellar?'#55554a':'#3f585f',.9);line(c,...q(w,0,height),...q(w,h,height),'#3d535a',.7);
  for(let x=.32+(j%2)*.69;x<w;x+=1.31)line(c,...q(x,h,height),...q(x+.05,h,height+z/3),'#45595c',.8);
 }
 for(let i=0;i<w;i++){if(rand(i,201)>.52)line(c,...q(i+.16,h,z+.5),...q(Math.min(w,i+.76),h,z+.5),cellar?'#c1ac85':'#abbcb0',1);}
}
function fishCrate(c,q,x,y,w,h,z){
 const a=(u,v,k=0)=>q(x+u,y+v,k);
 poly(c,[a(0,h),a(w,h),a(w,h,z),a(0,h,z)],'#72694e','#374e4b');
 poly(c,[a(w,h),a(w,0),a(w,0,z),a(w,h,z)],'#555c4b','#374e4b');
 poly(c,[a(0,0,z),a(w,0,z),a(w,h,z),a(0,h,z)],'#928467','#40544b');
 for(let j=.28;j<w;j+=.38)line(c,...a(j,0,z+.3),...a(j,h,z+.3),'#5f6555',.8);
 for(const t of [.19,.77]){line(c,...a(w*t,0,z+1),...a(w*t,h,z+1),'#b4a786',1.8);line(c,...a(w*t,h,z),...a(w*t,h),'#9b9173',1.6);}
}
function ferry(c,q,w,h){
 const spine=(a,b,z=0)=>q(a*w,b*h,z);
 const hull=[spine(.04,.56),spine(.21,.20),spine(.81,.24),spine(.98,.48),spine(.82,.70),spine(.29,.78)];
 const keel=hull.map(([x,y])=>[x+1,y+5]);poly(c,keel,'#243f48','#203942');poly(c,hull,'#736b53','#263e46');
 const inner=[spine(.14,.54),spine(.30,.32),spine(.77,.35),spine(.86,.49),spine(.75,.60),spine(.31,.65)];poly(c,inner,'#434f49','#b6a37a');
 for(const x of [.3,.48,.68])line(c,...spine(x,.32,3),...spine(x,.65,3),'#b4a383',3);
 const corners=[spine(.27,.30,19),spine(.60,.30,19),spine(.60,.65,19),spine(.27,.65,19)];
 for(const [i,x,y] of [[0,.27,.30],[1,.60,.30],[2,.60,.65],[3,.27,.65]])line(c,...spine(x,y),...corners[i],'#6e7361',1.5);
 poly(c,corners,'#788579','#384f50');line(c,...spine(.28,.48,23),...spine(.6,.48,23),'#b5b09a',2);
 const [x,y]=spine(.65,.42,14);oval(c,x,y,2.2,3.7,'#dac389');
}
export function quayFixtures(c,p,m,f){
 if(!underStars(m))return false;
 const w=f.w||1,h=f.h||1,q=(x,y,z=0)=>p(f.x+x,f.y+y,z);
 if(f.kind==='water'||f.kind==='lane'||f.kind==='pier')return true;
 if(f.kind==='lamp'){
  const [a,b]=q(.5,.5);line(c,a,b,a,b-21,'#435452',1.8);line(c,a-3,b-22,a+4,b-22,'#8e927c',2);
  poly(c,[[a-2,b-22],[a+3,b-22],[a+2,b-17],[a-2,b-17]],m.id==='night-oar-road'?'#777f6e':'#e1c68e','#50615d');
  poly(c,[[a-4,b-23],[a,b-26],[a+5,b-23]],'#64746a');return true;
 }
 if(f.kind==='rope'){
  const ends=w>=h?[[.15,.5],[w-.18,.5]]:[[.5,.16],[.5,h-.2]];
  const [u,v]=ends[0],[g,j]=ends[1],a=q(u,v,10),b=q(g,j,10);
  for(const [i,k] of ends)line(c,...q(i,k),...q(i,k,13),'#59645a',1.6);
  c.beginPath();c.moveTo(...a);c.quadraticCurveTo((a[0]+b[0])*.5,(a[1]+b[1])*.5+5,...b);c.strokeStyle='#8e8d70';c.lineWidth=1.3;c.stroke();return true;
 }
 if(f.kind==='wall'){dryWall(c,q,w,h,m.id==='pendulum-cellar'?29:m.id==='meridian-shutter'?21:16,m.id==='pendulum-cellar');return true;}
 if(f.kind==='crate'){
  const n=Math.max(1,Math.round(w/2.1));
  for(let j=0;j<n;j++){const x=(.16+j*.93)*w/n,y=.18+((j%2)*.38);fishCrate(c,q,x,y,w/n*.8,Math.min(1.45,h*.58),9+j%3*3);
   if(h>=4&&j<n-1)fishCrate(c,q,x+.2,y+1.43,w/n*.66,.95,6+(j+1)%3*2);}
  return true;
 }
 if(f.kind==='boat'){ferry(c,q,w,h);return true;}
 return false;
}
