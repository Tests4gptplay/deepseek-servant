import {figure} from './figures.mjs';
import {line,poly,oval} from './paint.mjs';
import {currentPair,guideOn} from './lullaby-partners.mjs';
const trails=new WeakMap();
export function hearthStage(c,p,m,s,t,ordered){
 if(!m.id.startsWith('lullaby-'))return;
 const guide=guideOn(m,s);
 if(guide){let state=trails.get(s);if(!state||state.map!==m.id||state.index!==guide.index){
   const prev=state?.map===m.id?state.to:guide.point;state={map:m.id,index:guide.index,from:prev,to:guide.point,at:t};trails.set(s,state);}
  const k=t?Math.min(1,Math.max(0,(t-state.at)/.82)):1,soft=k*k*(3-2*k),x=state.from[0]+(state.to[0]-state.from[0])*soft,y=state.from[1]+(state.to[1]-state.from[1])*soft;
  ordered.push([x+y+1.035,()=>{const [a,b]=p(x+.5,y+.5);figure(c,a,b,guide.guide.id,t,{scale:1.19,stride:k<1?t*11:0,flip:state.to[0]<state.from[0]});const h=t?Math.sin(t*2)*1.4:0;line(c,a+5,b-19,a+12,b-25+h,'#a97656',2.5);poly(c,[[a+10,b-27+h],[a+17,b-31+h],[a+14,b-24+h]],'#dfb16e');}]);}
 const pair=currentPair(s);
 if(pair){const id=pair.active==='mara'?'ivo':'mara',[x,y]=pair[id];ordered.push([x+y+1.01,()=>{const [a,b]=p(x+.5,y+.5);figure(c,a,b,id,t,{scale:1.19,flip:id==='ivo'});if(id==='ivo')line(c,a-4,b-16,a-10,b-16,'#bd976c',2);else line(c,a-10,b-14,a-14,b-20,'#d4bea0',2);}]);}
 if(m.id==='lullaby-double-stair')for(const x of [6,9,12,15,21,24,27]){const [a,b]=p(x,11.2);ordered.push([x+11.8,()=>{line(c,a,b,a+24,b+10,'#7a654c',2);line(c,a,b+5,a+23,b+15,'#b69c74');}]);}
 if(m.id==='lullaby-clay-hob'&&s.flags['lullaby-choice']){const asked=s.flags['lullaby-accompany'];for(let i=0;i<3;i++){const x=asked?12+i*1.5:7+i*.8,y=asked?10.1:6.4;ordered.push([x+y+1,()=>{const [a,b]=p(x+.5,y+.5);if(asked&&i<2)figure(c,a,b,'night-crew-'+i,t,{scale:1.02,flip:true});else{oval(c,a,b-2,11,4,'#927657');oval(c,a,b-4,9,3,'#e0b76d');}}]);}}
}
