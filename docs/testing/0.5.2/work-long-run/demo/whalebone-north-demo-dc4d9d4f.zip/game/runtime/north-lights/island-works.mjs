import {face,rod,plate,box,line,oval,poly,beam,hanging,ring,lamp,sail} from '../lamplit-whale/fixtures.mjs';
import {cliff,gauge,lit,capstan,slate,timber,spool} from './shore-craft.mjs';
const roofSets=[['#859892','#526d6f'],['#ad9377','#7e695e'],['#a1a388','#6f8178'],['#8c8582','#68686c']];
export function boatshed(c,p,x,y,w,h,n,t,night){
 const aw=w*.81,ah=h*.67,bx=x+w*.13,by=y+h*.16,front=by+ah,H=27+n%2*8,pitch=12+aw*1.5,roof=roofSets[n%4];
 box(c,p,bx,by,aw,ah,6,H,['#c3b293','#b49b78','#887d68']);
 for(let i=0;i<=4;i++){const xx=bx+aw*i/4;beam(c,p,[xx,front,0],[xx,front,6+H],3.6);}
 for(let i=0;i<4;i++)rod(c,p,[bx,front+.01,10+i*5],[bx+aw,front+.01,10+i*5],'#8e816a',.9);
 face(c,p,[[bx-.17,by-.15,H+6],[bx+aw+.22,by-.15,H+6],[bx+aw+.22,by+ah*.38,H+pitch+6],[bx-.17,by+ah*.38,H+pitch+6]],roof[1],'#5a655e');
 face(c,p,[[bx-.2,by+ah*.38,H+pitch+6],[bx+aw+.22,by+ah*.38,H+pitch+6],[bx+aw+.28,front+.31,H+5],[bx-.22,front+.31,H+5]],roof[0],'#616b62');
 for(let i=0;i<=7;i++){const xx=bx+aw*i/7;rod(c,p,[xx,by+ah*.38,H+pitch+6],[xx,front+.28,H+6],'#bdbaa18c',1.15);}
 const door=bx+aw*.44;face(c,p,[[door,front+.02,6],[door+.68,front+.02,6],[door+.68,front+.02,24],[door,front+.02,24]],'#465e5b');
 for(const u of [.16,.68]){const xx=bx+aw*u;face(c,p,[[xx,front+.04,16],[xx+.52,front+.04,16],[xx+.52,front+.04,25],[xx,front+.04,25]],night?'#edd2a0':'#769395','#6e7567');rod(c,p,[xx+.26,front+.04,16],[xx+.26,front+.04,25],'#746e5f',1.4);}
 const px=bx+aw*.8,py=front+.46;
 if(n%4===0){beam(c,p,[px,py,1],[px,py,32],3);sail(c,p,[px-1.25,py,30],[px,py,31],12,'#b9a77d',t,true);box(c,p,px-.9,py+.2,.73,.52,0,10,timber);for(let i=0;i<3;i++)plate(c,p,px-.82+i*.17,py+.28,.15,.22,11,'#e9d9a9');}
 if(n%4===1){box(c,p,px-.9,py,1.1,.53,9,3,timber);for(let i=0;i<3;i++)spool(c,p,px-.8+i*.26,py+.22,13,'#987a5b');}
 if(n%4===2){hanging(c,p,[px-1.7,py,27],[px,py+.1,31],3,'#a49371');for(let i=0;i<3;i++)sail(c,p,[px-1.5+i*.46,py,25],[px-1.28+i*.46,py,25],9,'#8b9f86',t);}
 if(n%4===3){const [a,b]=p(px-.28,py,8);oval(c,a,b,15,6,'#495e5b');oval(c,a,b-5,14,4.8,'#ad9270');lit(c,a,b+2,11,'#e6a161');}
 lamp(c,p,door-.12,front+.11,25,t,night,.70);
}
export function windSock(c,p,x,y,height,t,faded=false){
 const [a,b]=p(x,y,height),flap=Math.sin(t*1.7+x)*2;
 beam(c,p,[x,y,0],[x,y,height+2],3);line(c,a-2,b+2,a+4,b-2,'#675e50',1.5);
 const colors=faded?['#d1bd93','#9c8670']:['#b8745d','#ded1a1'];
 for(let i=0;i<4;i++){const xx=a+4+i*7,yy=b-1+i*1.10+flap*i*.28,r=5-i*.7;poly(c,[[xx,yy-r],[xx+7,yy-r+.9],[xx+7,yy+r+.3],[xx,yy+r]],colors[i%2],'#857867');}
 line(c,a+32,b+3+flap,a+41,b+6+flap,'#b8ac84',1.5);
}
export function shell(c,p,x,y,z,color,up=true){
 const [a,b]=p(x,y,z);oval(c,a,b+1,13,5,'#6d8982');c.beginPath();c.moveTo(a-11,b);c.bezierCurveTo(a-10,b-12,a+5,b-18,a+12,b-2);c.quadraticCurveTo(a+7,b+6,a-11,b);c.fillStyle=up?color:'#83948b';c.fill();c.strokeStyle='#5d716b';c.lineWidth=1.1;c.stroke();line(c,a-7,b-4,a+7,b-6,up?'#f0e1ad':'#b8bca0',1.5);line(c,a+6,b-7,a+8,b-14,'#bc735b',2);
}
