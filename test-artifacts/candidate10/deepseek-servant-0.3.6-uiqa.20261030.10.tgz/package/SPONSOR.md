# Support DeepSeek Servant / 赞助支持

Thank you for supporting the development and maintenance of **DeepSeek Servant**. / 感谢支持 **DeepSeek Servant** 的开发与维护。

## GitHub Sponsors / GitHub 官方赞助

- [GitHub Sponsors — Tests4gptplay](https://github.com/sponsors/Tests4gptplay)（支持单次赞助与每月赞助 / One-time and monthly sponsorships）

## International / 国际赞助

- [Ko-fi — kou392350](https://ko-fi.com/kou392350)
- [Patreon — Kou848](https://www.patreon.com/cw/Kou848)

## 爱发电 / Afdian

- [爱发电主页 / Creator page](https://afdian.com/a/kkt_ifd1)
- [直接赞助 / Direct contribution](https://afdian.com/order/create?user_id=65cbd84a9fbe11f1b2205254001e7c00&remark=&affiliate_code=)

爱发电支付由爱发电平台处理，赞助均为自愿支持。 / Contributions via Afdian are processed by Afdian and are voluntary.

## Alipay / 支付宝

请打开支付宝「扫一扫」扫描以下收款二维码：

<p align="center">
  <img src="https://raw.githubusercontent.com/Tests4gptplay/chat-agent-harness/main/assets/donations/alipay-qr.png" width="320" alt="支付宝赞助收款二维码 / Alipay donation QR code" />
</p>

**收款昵称 / Recipient:** `kouten(**天)`

Payments are handled by the respective platforms / 收款由相应平台处理。所有赞助均属自愿支持。
